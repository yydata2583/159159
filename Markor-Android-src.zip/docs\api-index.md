# API 索引（api-index.md）— Markor Android

> 本分支**定制类**的公开 API 速查 + 典型调用路径。原生类（Document/AppSettings 其余 getter 等）按需看源码。

## 1. sync 包（定制新增）

### `SyncManager`
```java
static SyncManager get()                       // 单例
void attach(Context)                           // 幂等：挂接 Activity 生命周期（MarkorBaseActivity.onCreate 调）
void setUiCallback(UiCallback)                 // 可选：接管连接弹窗（缺省用内置 AlertDialog）
void startIfEnabled()                          // 前台+启用+配置完整才启动；已在运行则重应用配置
void stop()                                    // 停引擎（退后台/关闭同步）
void checkServerConnection()                   // 探测服务器连接 → 弹窗结果
String getDeviceId()                           // 本机 Syncthing myID（未就绪=空串）
boolean isRunning()
interface UiCallback { void showConnectionResult(boolean ok, String message); }
```

### `LockClient`
```java
static LockClient get()
void setCallback(Callback)                     // 占用提示回调
void open(AppSettings, File, String deviceId)  // 登记 + 30s 心跳（未配置服务器→静默）
void close()                                   // 注销（保存/关闭/退出）
interface Callback { void onFileHeldElsewhere(String relPath, String holders); }
```

## 2. 关键原生入口（定制接入点）

### `AppSettings`（本分支新增部分）
```java
boolean isSyncEnabled()
String  getSyncDeviceName()          // 默认 "android"
String  getSyncServerDeviceId()      // 默认 ""
String  getSyncServerSyncAddress()   // 默认 ""
String  getSyncServerApi()           // 默认 ""
String  getSyncServerApiKey()        // 默认 ""
// 同步根 = getNotebookDirectory()（原生）
```

### `OutlineInjector`（纯字符串注入，无状态）
```java
static String head()                              // CSS+JS（定义 window.mkOutlineInit）
static String initCall(Context, boolean exportInLightMode)   // onload 调用
// 内部 JS API：mkOutlineInit(dark,title,empty)；jump(idx)/follow(idx)/spy()/refresh()
```

### `DocumentEditAndViewFragment`（定制钩子位置）
```java
onResume()       → LockClient.get().open(...) + setCallback(...)
onPause()        → saveDocument(false) + LockClient.get().close()
onDestroyView()  → LockClient.get().close()
```

## 3. 典型调用路径

| 我要做 | 路径 |
|---|---|
| 启停同步 | `SyncManager.get().attach(ctx)`（一次）→ `startIfEnabled()` / `stop()` |
| 设置改了同步配置 | `SettingsActivity.onPreferenceChanged` 的 `pref_key__sync_*` 分支 → `startIfEnabled()` |
| 弹连接结果 | `SyncManager` 内部 `notifyConnection`（或 `setUiCallback` 接管） |
| 文件占用提示 | `LockClient.get().open(...)` → `Callback.onFileHeldElsewhere` |
| 改大纲面板行为 | `OutlineInjector` 的 JS（`jump`/`follow`/`spy`） |
| 新设置项 | `string-not_translatable.xml` 加键 → `AppSettings` getter → `preferences_master.xml` 条目 → 双语 strings |
