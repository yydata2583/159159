/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.format;

import android.text.Editable;
import android.text.InputFilter;
import android.text.Selection;
import android.text.TextWatcher;

import net.gsantner.markor.format.markdown.MarkdownReplacePatternGenerator;
import net.gsantner.markor.frontend.textview.AutoTextFormatter;
import net.gsantner.markor.frontend.textview.ListHandler;
import net.gsantner.markor.frontend.textview.TextViewUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Markdown 语法自动补全。仅 Markdown 文档启用，其他格式不执行。
 * <ul>
 * <li>{@link #organize(String)}：一次性全文整理（补表格 |---| 分隔行、闭合未闭合的 ``` 围栏、
 * 裸标题补 # 前缀、规范分隔线为 ---、待办行规范为 - [ ] / - [x]）。宁少勿错、幂等，
 * 围栏代码块内的内容一律不改动。</li>
 * <li>{@link #newInputFilter()} + {@link #newEnterWatcher()}：回车触发的编辑辅助
 * （列表续行、空项回车清除标记、表格头行后自动插 |---|、``` 回车闭合围栏）。</li>
 * </ul>
 */
public final class MarkdownAutoFormat {

    // 表格行：以 | 开头并以 | 结尾
    private static final Pattern TABLE_ROW = Pattern.compile("^\\s*\\|.*\\|\\s*$");
    // 表格分隔行：单元格只含 - 与对齐冒号
    private static final Pattern TABLE_SEPARATOR = Pattern.compile("^\\s*\\|(\\s*:?-+:?\\s*\\|)+\\s*$");
    // Setext 标题下划线：==== 或 ----
    private static final Pattern UNDERLINE_H1 = Pattern.compile("^\\s{0,3}=+\\s*$");
    private static final Pattern UNDERLINE_H2 = Pattern.compile("^\\s{0,3}-{3,}\\s*$");
    // 其他分隔线：***、___、- - - 等
    private static final Pattern HORIZONTAL_RULE = Pattern.compile("^\\s{0,3}((\\*\\s*){3,}|(_\\s*){3,}|(-\\s*){3,})$");
    // 待办行：- [ ] / * [x] / + [] 等
    private static final Pattern CHECKBOX_LINE = Pattern.compile("^(\\s*)[-*+]\\s*\\[([ xX]?)]\\s*(.*)$");
    // 裸待办行：[ ] xxx / [x] xxx（无列表符号）
    private static final Pattern BARE_CHECKBOX_LINE = Pattern.compile("^(\\s*)\\[([ xX]?)]\\s*(.*)$");
    // 无序列表：* 或 + 开头（统一为 -）
    private static final Pattern BULLET_LINE = Pattern.compile("^(\\s*)[*+]\\s+(.*)$");

    private MarkdownAutoFormat() {
    }

    // ---------------------------------------------------------- 一次性全文整理

    /**
     * 一次性全文整理。规则保守、幂等，重复执行不再改变内容。
     */
    public static String organize(final String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }

        final String[] lines = text.split("\n", -1);
        final List<String> out = new ArrayList<>(lines.length);
        boolean inFence = false;
        int i = 0;
        while (i < lines.length) {
            final String line = lines[i];

            // 围栏行与围栏内内容原样保留
            if (isFenceLine(line)) {
                out.add(line);
                inFence = !inFence;
                i++;
                continue;
            }
            if (inFence) {
                out.add(line);
                i++;
                continue;
            }

            // 表格块：缺 |---| 分隔行时补上
            if (TABLE_ROW.matcher(line).matches()) {
                final int start = i;
                while (i < lines.length && !isFenceLine(lines[i]) && TABLE_ROW.matcher(lines[i]).matches()) {
                    i++;
                }
                out.addAll(fixTableBlock(lines, start, i));
                continue;
            }

            // 分隔线 / Setext 标题
            if (UNDERLINE_H1.matcher(line).matches() || UNDERLINE_H2.matcher(line).matches()
                    || HORIZONTAL_RULE.matcher(line).matches()) {
                final boolean isH1 = UNDERLINE_H1.matcher(line).matches();
                final boolean isH2 = UNDERLINE_H2.matcher(line).matches();
                final String prev = out.isEmpty() ? "" : out.get(out.size() - 1);
                if ((isH1 || isH2) && isPlainHeadingLine(prev)) {
                    out.remove(out.size() - 1);
                    out.add((isH1 ? "# " : "## ") + prev.trim());
                } else if (isH2 || HORIZONTAL_RULE.matcher(line).matches()) {
                    out.add("---"); // 规范分隔线
                } else {
                    out.add(line); // 孤立的 ==== 行，不动
                }
                i++;
                continue;
            }

            out.add(normalizeChecklist(line));
            i++;
        }

        // 未闭合的 ``` 围栏补闭合
        if (inFence) {
            out.add("```");
        }

        final StringBuilder sb = new StringBuilder(text.length() + 16);
        for (int j = 0; j < out.size(); j++) {
            if (j > 0) {
                sb.append('\n');
            }
            sb.append(out.get(j));
        }
        return sb.toString();
    }

    /** 表格块：已有分隔行则原样返回，否则在表头行后补 |---|---| */
    private static List<String> fixTableBlock(final String[] lines, final int start, final int end) {
        final List<String> block = new ArrayList<>(end - start + 1);
        boolean hasSeparator = false;
        for (int i = start; i < end; i++) {
            block.add(lines[i]);
            hasSeparator |= TABLE_SEPARATOR.matcher(lines[i]).matches();
        }
        if (hasSeparator || block.size() < 2) {
            return block;
        }
        final List<String> res = new ArrayList<>(block.size() + 1);
        res.add(block.get(0));
        res.add(makeTableSeparator(block.get(0)));
        res.addAll(block.subList(1, block.size()));
        return res;
    }

    /** 按表头列数生成 |---|---| */
    private static String makeTableSeparator(final String headerLine) {
        int cols = 0;
        for (int i = 0; i < headerLine.length(); i++) {
            if (headerLine.charAt(i) == '|') {
                cols++;
            }
        }
        cols = Math.max(cols - 1, 1);
        final StringBuilder sb = new StringBuilder(cols * 4 + 1);
        sb.append('|');
        for (int i = 0; i < cols; i++) {
            sb.append("---|");
        }
        return sb.toString();
    }

    /** 待办/列表行规范化：复选框统一 - [ ] / - [x]，* 与 + 开头的列表统一为 - */
    private static String normalizeChecklist(final String line) {
        Matcher m = CHECKBOX_LINE.matcher(line);
        if (m.matches()) {
            return m.group(1) + "- [" + checkedMark(m.group(2)) + "]" + withSpace(m.group(3));
        }
        m = BARE_CHECKBOX_LINE.matcher(line);
        if (m.matches()) {
            return m.group(1) + "- [" + checkedMark(m.group(2)) + "]" + withSpace(m.group(3));
        }
        m = BULLET_LINE.matcher(line);
        if (m.matches()) {
            return m.group(1) + "- " + m.group(2);
        }
        return line;
    }

    private static String checkedMark(final String box) {
        return (box == null || box.trim().isEmpty()) ? " " : "x";
    }

    private static String withSpace(final String rest) {
        return rest == null || rest.isEmpty() ? "" : " " + rest;
    }

    /** 裸标题行候选：普通文本行，非列表/引用/标题/表格/围栏/HTML 等 */
    private static boolean isPlainHeadingLine(final String line) {
        final String t = line.trim();
        if (t.isEmpty()) {
            return false;
        }
        final char c = t.charAt(0);
        return c != '#' && c != '>' && c != '|' && c != '`' && c != '-' && c != '*'
                && c != '+' && c != '_' && c != '~' && c != '<' && c != '[' && !Character.isDigit(c);
    }

    private static boolean isFenceLine(final String line) {
        return line.trim().startsWith("```");
    }

    // ---------------------------------------------------------- 回车编辑辅助

    /** 回车时的列表续行输入过滤（保持既有 Markdown 列表行为） */
    public static InputFilter newInputFilter() {
        return new AutoTextFormatter(MarkdownReplacePatternGenerator.formatPatterns);
    }

    /** 回车辅助：列表续行/空项清理 + 表格分隔行、围栏闭合 */
    public static TextWatcher newEnterWatcher() {
        return new EnterWatcher();
    }

    /**
     * 回车触发的编辑辅助。列表续行/空项回车清除标记沿用 {@link ListHandler} 既有逻辑，
     * 在其上补充：表格头行后自动插入 |---|、``` 回车自动闭合围栏。
     */
    private static class EnterWatcher extends ListHandler {
        private boolean _busy = false;
        private int _newlinePos = -1;

        EnterWatcher() {
            super(MarkdownReplacePatternGenerator.formatPatterns);
        }

        @Override
        public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {
            if (!_busy) {
                super.beforeTextChanged(s, start, count, after);
            }
        }

        @Override
        public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {
            if (_busy) {
                return;
            }
            // 记录纯回车插入位置，仅对回车做补全
            _newlinePos = (before == 0 && count > 0 && start < s.length() && s.charAt(start) == '\n') ? start : -1;
            super.onTextChanged(s, start, before, count);
        }

        @Override
        public void afterTextChanged(final Editable e) {
            if (_busy) {
                return;
            }
            _busy = true;
            try {
                super.afterTextChanged(e); // 空项清理、有序列表重排
                applyEnterAssist(e);
            } finally {
                _busy = false;
            }
        }

        private void applyEnterAssist(final Editable e) {
            final int pos = _newlinePos;
            _newlinePos = -1;
            if (e == null || pos < 0 || pos >= e.length() || e.charAt(pos) != '\n') {
                return;
            }
            // 仅处理行尾回车（回车产生的新行为空）
            if (TextViewUtils.getLineEnd(e, pos + 1) != pos + 1) {
                return;
            }
            final int lineStart = TextViewUtils.getLineStart(e, pos);
            final String endedLine = e.subSequence(lineStart, pos).toString();

            // ``` 回车：补一行空内容 + 闭合围栏，光标停在空内容行
            if (isFenceLine(endedLine) && countFencesBefore(e, lineStart) % 2 == 0) {
                e.insert(pos + 1, "\n```");
                Selection.setSelection(e, pos + 1);
                return;
            }

            // 表格头行回车：自动插入 |---| 分隔行，光标停到下一行继续输入
            if (TABLE_ROW.matcher(endedLine).matches() && !TABLE_SEPARATOR.matcher(endedLine).matches()) {
                final String prevLine = lineStart > 0
                        ? e.subSequence(TextViewUtils.getLineStart(e, lineStart - 1), lineStart - 1).toString()
                        : "";
                if (!TABLE_ROW.matcher(prevLine).matches()) {
                    final String sep = makeTableSeparator(endedLine) + "\n";
                    e.insert(pos + 1, sep);
                    Selection.setSelection(e, pos + 1 + sep.length());
                }
            }
        }

        /** 该位置之前的行中出现过的围栏行数量 */
        private static int countFencesBefore(final CharSequence text, final int end) {
            int count = 0, start = 0;
            while (start < end) {
                int nl = -1;
                for (int i = start; i < end; i++) {
                    if (text.charAt(i) == '\n') {
                        nl = i;
                        break;
                    }
                }
                final int lineEnd = nl < 0 ? end : nl;
                if (isFenceLine(text.subSequence(start, lineEnd).toString())) {
                    count++;
                }
                start = lineEnd + 1;
            }
            return count;
        }
    }
}
