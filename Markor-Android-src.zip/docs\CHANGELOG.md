# 需求与变更记录（CHANGELOG.md）— Markor Android

> **本文档由 AI 维护。** 工作方式：**用户提需求 → AI 写代码 → AI 同步更新本记录**。
> 每条需求记录：原始诉求、实现方案、涉及文件、日期。AI 接手先看这里。
> 维护规则见 [README.md](README.md)；技术决策见 [decisions.md](decisions.md)。

## 需求追溯表

| 日期 | 需求（用户原始诉求摘要） | 实现 | 涉及文件 |
|---|---|---|---|
| 10-15 | ①手机端也需要**内置同步**，只有前台时才启动 | 新建 `sync/` 包：`SyncManager`（内嵌 syncthing：`nativeLibraryDir/libsyncthing.so` 子进程 + REST 配置）；ActivityLifecycleCallbacks 计数——任一界面 onStart 启动、全部 onStop 停 | `sync/SyncManager.java` `MarkorBaseActivity.java` |
| 10-15 | ②不需要"更新同步版本"，有更新功能就删 | 审计：**无应用更新功能**（`.apk` 命中仅文件类型识别），无需删；引擎 `autoUpgradeIntervalH=0` | `sync/SyncManager.java` |
| 10-15 | ③服务器信息不写死、默认空；连接成功/失败都要弹窗 | 设置四项默认空；`checkServerConnection` 轮询 `rest/system/connections` → 三态弹窗（成功/失败/信息不全），仅前台弹（WeakReference 防泄漏） | `sync/SyncManager.java` `model/AppSettings.java` |
| 10-15 | ④（PC 的"路径错位"教训） | 手机端规避同类问题：同步目录**每次应用取当前笔记本目录**；引擎缺失明确提示 | `sync/SyncManager.java` |
| 10-15 | ⑤PC/手机只连服务器、不互连；删中继、加服务器地址 | 星型：设备表只登记服务器（introducer 不设）、`globalAnnounce/localAnnounce/relaysEnabled=false`、`addresses=[服务器同步地址]` | `sync/SyncManager.java` |
| 10-15 | ⑦源码下载保存 + 配知识库 | 已入库；`AGENTS.md` + `docs/` 七篇 | — |
| 10-15 | ⑧预览时，**大纲目录滚动时预览/渲染内容跟着滚动** | `OutlineInjector` JS：大纲列表 scroll（rAF 节流）→ `follow(idx)` 高亮+正文平滑滚动到对应标题（不收起面板）；正文 ScrollSpy 不回滚列表（防回环） | `format/OutlineInjector.java` |
| 10-15 | ⑨等通知才编译 | 遵守：全程未编译（括号配平/XML 合法性静态自查） | — |
| 10-15 | （附加，对齐服务器设计）文件锁客户端 | `LockClient`：open/30s 心跳/close、"已被其他设备打开"提示；未配置服务器静默 | `sync/LockClient.java` `DocumentEditAndViewFragment.java` |

## 答疑记录

| 问题 | 结论 |
|---|---|
| 官方安卓端怎么同步的？非二进制？ | Syncthing-Fork 也是打包 Go 原生二进制（`libsyncthing.so` 进 jniLibs）+ REST 配置；纯 Java 的 Syncthing 不存在。我们=官方同构方案，差别仅"仅前台运行" |
| 多持有者与同步冲突吗 | 不冲突（锁=提示层）；详见 PC CHANGELOG 同款条目 |

## 变更日志

- **2026-10 批次3**：预览大纲抽屉面板（`OutlineInjector`，JS 注入）。
- **2026-10 批次4**：内置同步（仅前台）+ `LockClient` + 设置页同步项 + 大纲滚动跟随；
  双语文案/pref key 配套；知识库（AGENTS.md + docs/）建立。
- ⚠️ 交付背景：批次4 首次尝试的 AI 子任务中途失败且零产出，全部手工重做——接手时先核对实际文件内容。
