# 数据模型（data-model.md）— Markor Android

> 覆盖：SharedPreferences 键表、笔记本目录结构、同步配置数据、锁协议数据。

## 1. 设置存储

- 载体：`SharedPreferences`（经 `GsSharedPreferencesPropertyBackend` / `AppSettings` 门面）。
- **pref key 全部定义在 `res/values/string-not_translatable.xml`**（值=键名，translatable=false）；
  UI 标题在 `strings.xml` 双语。
- 读取模式：`getBool(R.string.pref_key__xxx, 默认)` / `getString(...)` / `getInt(...)`。

### 本分支新增（批次4，同步）

| 键（pref_key__ 后缀） | 类型 | 默认 | 含义 |
|---|---|---|---|
| `sync_enabled` | bool | `false` | 启用同步（仅前台生效） |
| `sync_device_name` | string | `"android"` | 本机设备名称 |
| `sync_server_device_id` | string | **空** | 服务器（NAS）Syncthing 设备 ID |
| `sync_server_sync_address` | string | **空** | 服务器同步地址，如 `tcp://IP:22000` |
| `sync_server_api` | string | **空** | 服务器地址（锁 API），如 `http://IP:8910` |
| `sync_server_api_key` | string | **空** | 锁 API 密钥（Bearer） |

> 产品要求：服务器信息**一律默认空、不写死**（代码禁止 IP/域名/密钥常量）。

### 相关原生键（常用）

| 键 | 含义 |
|---|---|
| `notebook_directory` | 笔记本目录（= 同步根，默认 `/storage/emulated/0/Markor`） |
| `quicknote_filepath` / `todo_filepath` | 快记 / 待办文件 |
| `snippet_directory_path` | 片段目录（`Snippets/`） |
| `is_preview_first` | 打开文档先预览 |
| `last_edit_position__*` / `last_view_scrolly__*` | 每文件编辑/预览滚动位置 |

## 2. 笔记本目录结构（三端一致，同步根）

```
Markor/
├─ QuickNote.md      快记（应用默认）
├─ To-Do.md          待办
├─ Journal\          日记
├─ Snippets\         代码片段/模板
└─ file\             其他文件
```
升级迁移（README-server §四）：旧 `Documents/markor` → 新目录；`.app/snippets` → `Snippets/`；
`todo.txt` → `To-Do.md`（无同名时）。

## 3. 同步配置数据（applyConfig 写入 Syncthing REST）

| 项 | 值 |
|---|---|
| 引擎 home | `<filesDir>/syncthing`（`config.xml`/`index-vault/`/`cert.pem`/`key.pem`/`syncthing.log`） |
| 管理 GUI | `127.0.0.1:8385`（tls=false，仅回环；本机 API Key 每次运行随机生成） |
| 共享文件夹 | id=`markor-vault`，label=`Markor`，path=笔记本目录（每次取当前设置） |
| 服务器设备 | name=`markor-server`，`compression=metadata`，`addresses=[sync_server_sync_address]`（空→`dynamic`），**无 introducer** |
| options | `relaysEnabled=false`、`globalAnnounceEnabled=false`、`localAnnounceEnabled=false`、`autoUpgradeIntervalH=0` |

## 4. 文件锁协议数据（三端共用，服务器 README §五）

| 字段 | 值 |
|---|---|
| 请求体 | `{device_id, device_name, vault_id:"markor-vault", path:<笔记本内相对路径，/ 分隔>}` |
| 端点 | `POST /api/v1/open` → `{ok, holders}`；`/api/v1/heartbeat`（30s）；`/api/v1/close` |
| 鉴权 | `Authorization: Bearer <sync_server_api_key>` |
| holders | **其他设备**占用者数组 `[{device_id, device_name}]` → UI 提示 |
| device_id | 本机 Syncthing myID（未就绪退化为 device_name） |
| 过期 | 服务器 70s 无心跳自动过期（按设备独立，多持有者并存） |

## 5. 数据约定

| 项 | 约定 |
|---|---|
| 文件编码 | UTF-8（上游 Document 读写约定） |
| 相对路径 | 锁协议 path 一律 `/` 分隔、笔记本根内相对路径 |
| 引擎二进制 | `nativeLibraryDir/libsyncthing.so`（jniLibs 部署；缺失=同步停用） |
| 端口 | 引擎管理 8385（本机）、同步 22000（服务器监听）、锁 API 8910（服务器） |
