# 决策记录（decisions.md / ADR）— Markor Android

> 编号 A-1xx（手机端）；服务器端 A-2xx、PC 端见其 docs/decisions.md（ADR-001~019）。
> 新增按序追加；推翻标 Superseded 不删除。

### A-101：内置同步采用"打包 syncthing 原生二进制 + REST 配置"（Accepted）
- **背景**：产品要求手机端内置同步。Syncthing 协议（TLS/QUIC/块交换）无人用纯 Java 实现；官方安卓端（Syncthing-Fork）也是把 Go 内核编译为 `libsyncthing.so` 打进 jniLibs、子进程运行 + REST 配置。
- **决策**：同官方方案：`nativeLibraryDir/libsyncthing.so` 子进程（serve + 本机 REST），缺失时静默停用并提示。
- **后果**：与 PC/服务器引擎同构、协议零成本；代价是分发需携带二进制（MPL-2.0 许可声明随附）。
- **替代方案**：纯 Java 重写（否决：不存在且成本巨大）；依赖外部 Syncthing App（否决：非"内置"）；换 WebDAV 等协议（否决：与三端架构不兼容）。

### A-102：同步仅前台运行（Accepted，产品要求）
- **背景**：产品明确"只有前台时才启动同步功能"。
- **决策**：ActivityLifecycleCallbacks 计数；任一 Activity onStart 启动，全部 onStop 停止（销毁引擎进程）。无前台服务/常驻通知。
- **后果**：后台不同步（省电、无通知打扰）；切回前台自动续传。
- **替代方案**：前台服务常驻（否决：与产品要求相反）。

### A-103：星型拓扑约束（Accepted，与 PC/服务器一致）
- **背景**：PC、手机只能与服务器连接同步，设备之间不能互连。
- **决策**：设备表只登记服务器设备（不设 introducer）、`addresses=[服务器同步地址]`、`globalAnnounce/localAnnounce/relaysEnabled=false`、`autoUpgradeIntervalH=0`（不更新同步版本）。
- **后果**：连通性完全取决于配置的服务器地址；不能自动发现省配置。
- **替代方案**：dynamic 自动发现（否决：同网内设备仍可能直连）。

### A-104：连接结果必须弹窗（Accepted，产品要求）
- **背景**："连接服务器成功与否都需要有弹窗提示"；服务器信息默认空。
- **决策**：`SyncManager` 轮询 `rest/system/connections`（3s×10）判定 connected → 默认 AlertDialog（成功/失败/信息不全三态）；弹窗仅在有前台 Activity 时弹（WeakReference 防泄漏），回调可被 UiCallback 接管。
- **后果**：配置错误立即可见；不打扰后台。
- **替代方案**：仅状态栏/Toast（否决：产品要求弹窗）。

### A-105：文件锁=提示层，多持有者并存（Accepted）
- **背景**：服务器 lockserver 协议 holders=其他设备占用者；单值覆盖模型会让提示永不触发。
- **决策**：客户端 open/heartbeat/close 正常并存（不互斥）；提示用 Toast；真正写冲突由 Syncthing `.sync-conflict-*` 兜底。
- **后果**：多设备同时打开合法且互相提示；无锁阻塞。
- **替代方案**：硬独占锁（否决：未获产品确认，见 PC 知识库讨论记录）。

### A-106：大纲滚动 → 正文跟随（Accepted）
- **背景**：需求"预览时，大纲目录滚动时，预览、渲染内容会跟着滚动"（理解为期望行为）。
- **决策**：`OutlineInjector` JS 给大纲列表加 scroll 监听（rAF 节流）：取列表视口顶部最近条目 → `follow(idx)` 高亮+正文平滑滚动到对应标题（不收起面板）；正文 ScrollSpy 只更新高亮、不回滚列表（防回环）。
- **后果**：浏览大纲即预览定位；点击行为（跳转+收起）不变。
- **替代方案**：仅点击跳转（旧）；大纲滚动隔离不透传（与需求相反）。

### A-107：无应用更新功能（Accepted，审计结论）
- **背景**："不需要更新同步版本，如有更新功能，删除。"
- **决策**：全仓审计确认两端无应用自更新/检查更新入口（`.apk` 命中仅文件类型识别）；同步引擎自升级由 `autoUpgradeIntervalH=0` 关闭。
- **后果**：版本更新走应用商店/手动安装。
