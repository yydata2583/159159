/*#######################################################
 *
 *   Maintained 2017-2025 by Gregor Santner <gsantner AT mailbox DOT org>
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor;

import android.webkit.WebView;

import androidx.multidex.MultiDexApplication;

import net.gsantner.markor.model.AppSettings;

import java.io.File;

public class ApplicationObject extends MultiDexApplication {
    // Make resources not marked as unused
    @SuppressWarnings("unused")
    private static final Object[] unused_ignore = new Object[]
            {R.color.colorPrimary, R.plurals.item_selected, R.string.project_page, R.style.AppTheme_Unified, R.raw.readme};

    private static final int[] unused_ignores = new int[]{
            R.string.appearance, R.string.info, R.string.append_to_witharg, R.string.about, R.string.error_cannot_create_notebook_dir__appspecific, R.string.show_license_of_the_app, R.string.show_third_party_licenses, R.string.open_with, R.string.todo_list, R.string.task, R.string.list, R.string.history, R.string.sync, R.string.update, R.string.clear, R.string.due_date, R.string.current_date, R.string.add_task, R.string.add_x_witharg, R.string.create_note, R.string.back_to_previous_folder, R.string.app_settings, R.string.editor_settings, R.string.remember_last_folder_location_on_startup, R.string.number_of_files_witharg, R.string.main_view, R.string.contexts, R.string.projects, R.string.resources, R.string.vertical_alignment, R.string.horizontal_alignment, R.string.default_, R.string.left, R.string.right, R.string.top, R.string.bottom, R.string.center, R.string.directory, R.string.error_picture_selection, R.string.enable_undo_and_redo_be_patient, R.string.tags,
    };

    private volatile static ApplicationObject _app;
    private volatile static AppSettings _appSettings;

    public static ApplicationObject get() {
        return _app;
    }

    @Deprecated
    public static AppSettings settings() {
        return _appSettings;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        _app = this;
        _appSettings = new AppSettings(getApplicationContext());

        initNotebookLayout();

        // Per https://stackoverflow.com/a/54191884/4717438
        try {
            new WebView(getApplicationContext());
        } catch (Exception ignored) {
        }
    }

    /**
     * 三端同步规范：笔记本根目录 = /storage/emulated/0/Markor，
     * 内含 QuickNote.md、todo.txt/done.txt、Journal/、Snippets/、file/。
     * 这里负责旧目录迁移与统一目录结构。
     */
    private void initNotebookLayout() {
        try {
            final File storage = android.os.Environment.getExternalStorageDirectory();
            final File root = new File(storage, "Markor");
            final File legacy = new File(storage, "Documents/markor");

            // 旧版默认笔记本 Documents/markor -> Markor
            if (legacy.isDirectory()) {
                final File nb = _appSettings.getNotebookDirectory().getCanonicalFile();
                if (legacy.getCanonicalFile().equals(nb) || root.getCanonicalFile().equals(nb)) {
                    root.mkdirs();
                    moveChildren(legacy, root);
                    legacy.delete(); // 仅当目录为空时成功；重名冲突的留在原处
                    _appSettings.setNotebookDirectory(root);
                }
            }

            final File nbDir = _appSettings.getNotebookDirectory();

            // 旧版代码片段目录 .app/snippets -> Snippets
            final File oldSnippets = new File(nbDir, ".app/snippets");
            if (oldSnippets.isDirectory()) {
                final File snippets = new File(nbDir, "Snippets");
                snippets.mkdirs();
                moveChildren(oldSnippets, snippets);
                oldSnippets.delete();
                new File(nbDir, ".app").delete(); // 仅当目录为空时成功
            }

            // 旧版待办 todo.txt -> To-Do.md（规范目录中只有 To-Do.md）
            final File oldTodo = new File(nbDir, "todo.txt");
            final File newTodo = new File(nbDir, "To-Do.md");
            if (oldTodo.isFile() && !newTodo.exists()) {
                oldTodo.renameTo(newTodo);
            }

            // 统一目录结构
            new File(nbDir, "Journal").mkdirs();
            new File(nbDir, "Snippets").mkdirs();
            new File(nbDir, "file").mkdirs();
        } catch (Exception ignored) {
        }
    }

    private static void moveChildren(final File from, final File to) {
        final File[] children = from.listFiles();
        if (children != null) {
            for (final File child : children) {
                final File target = new File(to, child.getName());
                if (!target.exists()) {
                    child.renameTo(target);
                }
            }
        }
    }
}
