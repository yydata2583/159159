/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.sync;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import net.gsantner.markor.model.AppSettings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 手机端内置同步（批次4）：应用内嵌 Syncthing 引擎，**仅前台运行**——
 * 任一界面 onStart 启动、全部 onStop（退到后台）停止。
 * <p>
 * 星型拓扑：本机只与配置的"同步服务器"（NAS 存储节点）连接，设备之间
 * （PC ↔ 手机）不直连：设备表只登记服务器设备（不设 introducer）、
 * 关闭全局/本地发现与中继、关闭引擎自动升级（产品不需要"更新同步版本"）。
 * <p>
 * 服务器信息（设备 ID / 同步地址）一律默认为空、不写死；连接服务器
 * 成功/失败都通过 {@link UiCallback} 弹窗提示。未配置或引擎缺失时静默停用。
 * <p>
 * 引擎来源：{@code nativeLibraryDir/libsyncthing.so}（安卓上 .so 伪装是
 * 通行做法；该二进制需另行放入 jniLibs，缺失时本类自动停用同步，不崩溃）。
 */
public final class SyncManager {

    /** UI 回调：连接结果弹窗（仅前台 Activity 注册，弱引用防泄漏） */
    public interface UiCallback {
        void showConnectionResult(boolean ok, String message);
    }

    private static final String TAG = "MarkorSync";
    private static final String FOLDER_ID = "markor-vault";          // 三端约定
    private static final String SERVER_DEVICE_NAME = "markor-server";
    private static final String GUI_ADDR = "127.0.0.1:8385";         // host:port（禁止带 scheme）
    private static final String GUI_URL = "http://127.0.0.1:8385";
    private static final int CONNECT_TRIES = 10;                     // 3s × 10 ≈ 30s
    private static final int STATUS_TRIES = 40;                      // 1.5s × 40

    private static SyncManager _instance;

    public static synchronized SyncManager get() {
        if (_instance == null) {
            _instance = new SyncManager();
        }
        return _instance;
    }

    private final Handler _main = new Handler(Looper.getMainLooper());
    private final ExecutorService _io = Executors.newSingleThreadExecutor();
    private WeakReference<Activity> _uiActivity = new WeakReference<>(null);
    private WeakReference<UiCallback> _uiCallback = new WeakReference<>(null);

    private Context _appContext;
    private Process _proc;
    private String _apiKey = "";
    private String _myId = "";
    private boolean _ready = false;
    private int _startedCount = 0;
    private boolean _lifecycleHooked = false;
    private boolean _connChecking = false;

    private SyncManager() {
    }

    // ------------------------------------------------------------------
    // 生命周期：仅前台运行
    // ------------------------------------------------------------------

    /** 幂等：挂接应用生命周期并按需启动/停止同步 */
    public synchronized void attach(final Context context) {
        final Context app = context.getApplicationContext();
        if (_appContext == null) {
            _appContext = app;
        }
        if (_lifecycleHooked || !(app instanceof Application)) {
            return;
        }
        _lifecycleHooked = true;
        ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityStarted(Activity activity) {
                _uiActivity = new WeakReference<>(activity);
                onForeground();
            }

            @Override
            public void onActivityStopped(Activity activity) {
                onBackground();
            }

            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
            }

            @Override
            public void onActivityResumed(Activity activity) {
                _uiActivity = new WeakReference<>(activity);
            }

            @Override
            public void onActivityPaused(Activity activity) {
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
            }

            @Override
            public void onActivityDestroyed(Activity activity) {
            }
        });
    }

    /** 设置界面注册/注销弹窗回调 */
    public void setUiCallback(final UiCallback cb) {
        _uiCallback = new WeakReference<>(cb);
    }

    private synchronized void onForeground() {
        _startedCount++;
        startIfEnabled();
    }

    private synchronized void onBackground() {
        _startedCount = Math.max(0, _startedCount - 1);
        if (_startedCount == 0) {
            stop();   // 全部界面离开前台：停同步（产品要求"只有前台时才启动"）
        }
    }

    // ------------------------------------------------------------------
    // 引擎启停
    // ------------------------------------------------------------------

    /** 同步设置变化后也可调用：重新应用配置并重探测连接 */
    public void startIfEnabled() {
        final AppSettings s = appSettings();
        if (s == null || !s.isSyncEnabled()) {
            return;
        }
        if (_startedCount <= 0) {
            return;   // 不在前台不启动
        }
        final String serverId = s.getSyncServerDeviceId().trim();
        final String serverAddr = s.getSyncServerSyncAddress().trim();
        if (serverId.isEmpty() || serverAddr.isEmpty()) {
            notifyConnection(false,
                    "同步服务器信息未填写完整，请先到 设置→同步 填写服务器设备 ID 与服务器同步地址。");
            return;
        }
        if (_proc != null) {
            applyConfig();          // 已在运行：设置变化后重应用（修“路径错位”类问题）
            checkServerConnection();
            return;
        }
        launch();
    }

    /** 退到后台 / 关闭同步时调用 */
    public synchronized void stop() {
        _ready = false;
        _connChecking = false;
        _myId = "";
        _apiKey = "";   // 完全停止后下次启动换新 key；引擎内重启（restartEngine）保持原 key
        if (_proc != null) {
            _proc.destroy();
            _proc = null;
        }
    }

    /**
     * 批次5：Web GUI 的“重启”联动——销毁引擎进程后按当前配置重新拉起。
     * serve 模式无 monitor 进程，GUI 原生重启会直接退死进程，故必须由应用代为执行。
     * 保持同一 apiKey：Web GUI 页面临时断连后按原 key 轮询即可自动恢复。
     */
    public synchronized void restartEngine() {
        _ready = false;
        _connChecking = false;
        _myId = "";
        if (_proc != null) {
            _proc.destroy();
            _proc = null;
        }
        launch();
    }

    /** 批次5：内置同步 Web GUI 地址（供应用内 WebView 打开） */
    public String getGuiUrl() {
        return GUI_URL;
    }

    private void launch() {
        final Context ctx = _appContext;
        if (ctx == null) {
            return;
        }
        // 内置引擎：jniLibs 里的 libsyncthing.so（可执行伪装）。缺失→停用并提示。
        final File exe = new File(ctx.getApplicationInfo().nativeLibraryDir, "libsyncthing.so");
        if (!exe.exists()) {
            notifyConnection(false,
                    "未找到内置同步引擎（libsyncthing.so），同步未启用。");
            return;
        }
        final File home = new File(ctx.getFilesDir(), "syncthing");
        //noinspection ResultOfMethodCallIgnored
        home.mkdirs();
        // 批次5：apiKey 幂等生成——引擎内重启（restartEngine）保持原 key，
        // 已打开的 Web GUI 页面按原 key 轮询即可自动恢复；完全停止（stop）时清空
        if (_apiKey.isEmpty()) {
            _apiKey = UUID.randomUUID().toString().replace("-", "");
        }

        final String[] args = {
                exe.getAbsolutePath(),
                "serve",
                "--home=" + home.getAbsolutePath(),
                "--gui-address=" + GUI_ADDR,     // host:port；带 scheme/尾斜杠会解析失败
                "--gui-apikey=" + _apiKey,
                "--no-browser",
                "--no-console",
                "--log-file=" + new File(home, "syncthing.log").getAbsolutePath()
        };
        _io.execute(() -> {
            try {
                _proc = new ProcessBuilder(args).redirectErrorStream(true).start();
                pollStatus(0);
            } catch (Exception e) {
                notifyConnection(false, "同步引擎启动失败：" + e.getMessage());
            }
        });
    }

    private void pollStatus(final int tried) {
        if (_proc == null) {
            return;
        }
        try {
            final JSONObject st = rest("GET", "/rest/system/status", null);
            final String id = st != null ? st.optString("myID", "") : "";
            if (!id.isEmpty()) {
                _myId = id;
                _ready = true;
                applyConfig();
                checkServerConnection();
                return;
            }
        } catch (Exception ignored) {
        }
        if (tried >= STATUS_TRIES) {
            notifyConnection(false, "同步引擎启动超时，无法连接同步服务器（详见 syncthing.log）。");
            return;
        }
        _main.postDelayed(() -> pollStatus(tried + 1), 1500);
    }

    // ------------------------------------------------------------------
    // REST 配置（星型拓扑）
    // ------------------------------------------------------------------

    private void applyConfig() {
        _io.execute(() -> {
            try {
                final JSONObject cfg = rest("GET", "/rest/config", null);
                if (cfg == null) {
                    return;
                }
                final AppSettings s = appSettings();
                if (s == null) {
                    return;
                }
                final String serverId = s.getSyncServerDeviceId().trim();
                final String serverAddr = s.getSyncServerSyncAddress().trim();

                // devices：只登记服务器设备；不设 introducer（防设备互引破坏星型）
                JSONArray devs = cfg.optJSONArray("devices");
                if (devs == null) {
                    devs = new JSONArray();
                }
                int devIdx = -1;
                for (int i = 0; i < devs.length(); i++) {
                    if (serverId.equals(devs.getJSONObject(i).optString("deviceID"))) {
                        devIdx = i;
                        break;
                    }
                }
                final JSONObject d = devIdx >= 0 ? devs.getJSONObject(devIdx) : new JSONObject();
                d.put("deviceID", serverId);
                d.put("name", SERVER_DEVICE_NAME);
                d.put("compression", "metadata");
                d.remove("introducer");
                d.put("addresses", new JSONArray().put(serverAddr.isEmpty() ? "dynamic" : serverAddr));
                if (devIdx >= 0) {
                    devs.put(devIdx, d);
                } else {
                    devs.put(d);
                }
                cfg.put("devices", devs);

                // folders：markor-vault = 笔记本目录（每次应用取当前设置，修路径错位）
                final File notebook = s.getNotebookDirectory();
                //noinspection ResultOfMethodCallIgnored
                notebook.mkdirs();
                JSONArray folders = cfg.optJSONArray("folders");
                if (folders == null) {
                    folders = new JSONArray();
                }
                int fIdx = -1;
                for (int i = 0; i < folders.length(); i++) {
                    if (FOLDER_ID.equals(folders.getJSONObject(i).optString("id"))) {
                        fIdx = i;
                        break;
                    }
                }
                final JSONObject folder = fIdx >= 0 ? folders.getJSONObject(fIdx) : new JSONObject();
                folder.put("id", FOLDER_ID);
                folder.put("label", "Markor");
                folder.put("type", "sendreceive");
                folder.put("path", notebook.getAbsolutePath());
                JSONArray fdevs = folder.optJSONArray("devices");
                if (fdevs == null) {
                    fdevs = new JSONArray();
                }
                fdevs = ensureDevice(fdevs, _myId);
                fdevs = ensureDevice(fdevs, serverId);
                folder.put("devices", fdevs);
                if (fIdx >= 0) {
                    folders.put(fIdx, folder);
                } else {
                    folders.put(folder);
                }
                cfg.put("folders", folders);

                // options：关发现/中继（星型只走显式服务器地址）、关引擎自升级
                final JSONObject opts = cfg.optJSONObject("options");
                if (opts != null) {
                    opts.put("relaysEnabled", false);
                    opts.put("globalAnnounceEnabled", false);
                    opts.put("localAnnounceEnabled", false);
                    opts.put("autoUpgradeIntervalH", 0);   // 不需要“更新同步版本”
                    cfg.put("options", opts);
                }

                // gui：仅回环管理
                final JSONObject gui = cfg.optJSONObject("gui");
                if (gui != null) {
                    gui.put("address", GUI_ADDR);
                    gui.put("tls", false);
                    gui.put("apiKey", _apiKey);
                    cfg.put("gui", gui);
                }

                rest("PUT", "/rest/config", cfg);
            } catch (Exception ignored) {
            }
        });
    }

    private static JSONArray ensureDevice(final JSONArray arr, final String id) throws Exception {
        if (id == null || id.isEmpty()) {
            return arr;
        }
        for (int i = 0; i < arr.length(); i++) {
            if (id.equals(arr.getJSONObject(i).optString("deviceID"))) {
                return arr;
            }
        }
        return arr.put(new JSONObject().put("deviceID", id));
    }

    // ------------------------------------------------------------------
    // 连接服务器探测（成功/失败都弹窗）
    // ------------------------------------------------------------------

    public void checkServerConnection() {
        if (_connChecking) {
            return;
        }
        _connChecking = true;
        checkConnectionLoop(0);
    }

    private void checkConnectionLoop(final int tried) {
        _io.execute(() -> {
            final AppSettings s = appSettings();
            final String serverId = s != null ? s.getSyncServerDeviceId().trim() : "";
            if (serverId.isEmpty()) {
                _connChecking = false;
                notifyConnection(false, "未配置服务器设备 ID，无法连接同步服务器。");
                return;
            }
            try {
                final JSONObject root = rest("GET", "/rest/system/connections", null);
                final JSONObject conns = root != null ? root.optJSONObject("connections") : null;
                final JSONObject peer = conns != null ? conns.optJSONObject(serverId) : null;
                if (peer != null && peer.optBoolean("connected", false)) {
                    _connChecking = false;
                    notifyConnection(true,
                            "已连接到同步服务器（设备 " + serverId.substring(0, Math.min(7, serverId.length())) + "）。");
                    return;
                }
            } catch (Exception ignored) {
            }
            if (tried >= CONNECT_TRIES) {
                _connChecking = false;
                notifyConnection(false,
                        "无法连接同步服务器。\n请检查：服务器同步地址、服务器设备 ID、网络可达性（防火墙/VPN），并确认服务器端 Syncthing 已启动。");
                return;
            }
            _main.postDelayed(() -> checkConnectionLoop(tried + 1), 3000);
        });
    }

    private void notifyConnection(final boolean ok, final String message) {
        _main.post(() -> {
            final Activity a = _uiActivity.get();
            if (a == null || a.isFinishing() || a.isDestroyed()) {
                return;   // 无前台界面：不弹（下次前台重试）
            }
            final UiCallback cb = _uiCallback.get();
            if (cb != null) {
                cb.showConnectionResult(ok, message);
                return;
            }
            // 默认弹窗（连接成功/失败都要提示，产品要求）
            try {
                new AlertDialog.Builder(a)
                        .setTitle(ok ? "同步服务器" : "同步服务器")
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, null)
                        .show();
            } catch (Exception ignored) {
            }
        });
    }

    // ------------------------------------------------------------------
    // 工具
    // ------------------------------------------------------------------

    /** 本机 Syncthing 设备 ID（未就绪时为空串） */
    public String getDeviceId() {
        return _myId;
    }

    public boolean isRunning() {
        return _ready;
    }

    private AppSettings appSettings() {
        return _appContext != null ? AppSettings.get(_appContext) : null;
    }

    /** 极简 REST 客户端（本机回环，X-API-Key 鉴权） */
    private JSONObject rest(final String method, final String path, final JSONObject body) {
        HttpURLConnection conn = null;
        try {
            final URL url = new URL(GUI_URL + path);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("X-API-Key", _apiKey);
            if (body != null) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                final byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(data);
                }
            }
            final int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                return null;
            }
            final StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
            }
            final String raw = sb.toString().trim();
            return raw.isEmpty() ? new JSONObject() : new JSONObject(raw);
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
