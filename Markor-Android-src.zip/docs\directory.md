# 目录与定制改动对照（directory.md）— Markor Android

> 用途：找"改哪里"，并区分**本分支定制**与**原生 Markor**（升级上游时的冲突面）。

## 顶层

```
markor-android/
├─ AGENTS.md            AI 入口 ★
├─ docs/                分层知识库 ★
├─ app/                 唯一模块（源码/资源/构建脚本）
├─ build.gradle / settings.gradle / gradle*   Gradle 构建
├─ doc/  samples/  metadata/  experiments/    文档/示例/商店素材/实验补丁
└─ CHANGELOG.md  NEWS.md  README.md  LICENSE.txt（上游原生）
```

## app/src/main/java/net/gsantner/ 两大包

| 包 | 性质 | 说明 |
|---|---|---|
| `markor/` | 业务（**多数定制在此**） | activity / format / frontend / model / sync / util / web / widget |
| `opoc/` | 作者通用库（原生） | Gs* 工具类，上游共享，尽量不改 |

## 定制改动清单（vs 原生 gsantner/markor）⭐

| 文件 | 批次 | 改动 |
|---|---|---|
| `markor/sync/SyncManager.java` | 4 | **新增**：内置 Syncthing（引擎启停/REST 星型配置/连接弹窗/仅前台） |
| `markor/sync/LockClient.java` | 4 | **新增**：文件锁客户端（open/heartbeat/close + 占用提示） |
| `markor/format/OutlineInjector.java` | 3+4 | **新增**（批次3 大纲抽屉；批次4 大纲滚动跟随 `follow()`） |
| `markor/activity/MarkorBaseActivity.java` | 4 | onCreate 挂接 `SyncManager.attach()` |
| `markor/activity/SettingsActivity.java` | 4 | `pref_key__sync_*` 变更 → 重应用同步配置 |
| `markor/activity/DocumentEditAndViewFragment.java` | 4 | onResume 登记文件锁、onPause/onDestroyView 注销 |
| `markor/model/AppSettings.java` | 4 | 追加同步设置 getter（`isSyncEnabled/getSyncServer*`） |
| `res/xml/preferences_master.xml` | 4 | 同步 PreferenceCategory |
| `res/values/string-not_translatable.xml` | 4 | `pref_key__sync_*` 键 |
| `res/values/strings.xml` + `values-zh-rCN/strings.xml` | 3+4 | 大纲/同步/锁提示文案（双语） |

> 其余（format/ 各格式、frontend/、widget/、opoc/ 等）为原生代码，功能见上游 README。

## 各目录速查

| 位置 | 内容 |
|---|---|
| `markor/activity/` | MainActivity、DocumentActivity、DocumentEditAndViewFragment（编辑/预览核心）、SettingsActivity、MoreFragment/MoreInfoFragment、openeditor/ |
| `markor/format/` | FormatRegistry + `markdown/ todotxt/ asciidoc/ orgmode/ wikitext/ csv/ keyvalue/ plaintext/ general/ binary/` 各格式实现 |
| `markor/frontend/` | 对话框工厂、文件浏览器、搜索、文本工具 |
| `markor/model/` | `AppSettings`（设置门面）、`Document`（文档模型/保存） |
| `markor/web/` | 预览 WebView 封装 |
| `markor/widget/` | 桌面小部件（QuickNote/Todo） |
| `app/src/main/res/xml/` | `preferences_master.xml`（设置结构）、`prefactions__*`（更多页动作） |
| `app/src/main/res/values/string-not_translatable.xml` | **全部 pref key** 定义（translatable=false） |

## 改动定位速查

| 想改什么 | 动哪里 |
|---|---|
| 同步行为/拓扑 | `sync/SyncManager.java`（applyConfig 的 devices/folders/options 段） |
| 锁提示/心跳 | `sync/LockClient.java` + `DocumentEditAndViewFragment` 生命周期钩子 |
| 大纲面板样式/交互 | `format/OutlineInjector.java`（CSS/JS 字符串） |
| 新设置项 | `AppSettings` + `preferences_master.xml` + `string-not_translatable.xml`（键）+ 双语 `strings.xml` |
| 同步设置界面 | `preferences_master.xml` 同步区 + `SettingsActivity` 变更分支 |
| 预览渲染 | `format/*/XxxTextConverter`（各格式渲染器） |
