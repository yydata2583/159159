/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.sync;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import net.gsantner.markor.R;
import net.gsantner.markor.activity.MarkorBaseActivity;
import net.gsantner.markor.model.AppSettings;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

/**
 * 批次5：同步管理页——应用内 WebView 打开内嵌 Syncthing Web GUI（参考 Syncthing 安卓端做法），
 * 不用外部浏览器。
 * <p>
 * 与应用的联动点：
 * <ul>
 * <li>引擎以 serve 模式运行（无 monitor 进程），GUI 原生的“重启/关闭”会直接退死进程，
 *     因此在 {@link WebViewClient#shouldInterceptRequest} 中拦截这两个 REST 调用，改由
 *     {@link SyncManager} 销毁并重新拉起进程（重启）或停止引擎并退出本页（关闭）。</li>
 * <li>引擎未就绪（前台刚启动/正在重连）时先等待，就绪后再加载 GUI；外部链接一律交外部浏览器。</li>
 * </ul>
 */
@SuppressWarnings("deprecation")
public class SyncWebGuiActivity extends MarkorBaseActivity {

    private static final int WAIT_INTERVAL_MS = 1000;
    private static final int WAIT_MAX_TRIES = 30;   // 最长等 30s

    private final Handler _main = new Handler(Looper.getMainLooper());
    private WebView _webView;
    private View _loading;
    private int _waitTries = 0;
    private boolean _loadRequested = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sync_webgui_activity);

        final Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.sync_open_gui);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(ContextCompat.getDrawable(this, R.drawable.ic_arrow_back_white_24dp));
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        _webView = findViewById(R.id.sync_webgui_webview);
        _loading = findViewById(R.id.sync_webgui_loading);

        final WebSettings ws = _webView.getSettings();
        ws.setJavaScriptEnabled(true);    // Syncthing GUI 是 SPA，必须开 JS
        ws.setDomStorageEnabled(true);    // GUI 偏好/状态存 localStorage

        _webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(final WebView view, final String url) {
                // 拦截 GUI 的“重启/关闭”按钮对应的 REST 调用，改由应用代为执行
                final String path = localGuiPath(url);
                if (path == null) {
                    return null;
                }
                if (path.startsWith("/rest/system/restart")) {
                    _main.post(() -> SyncManager.get().restartEngine());
                    return emptyJson();
                }
                if (path.startsWith("/rest/system/shutdown")) {
                    _main.post(() -> {
                        SyncManager.get().stop();
                        Toast.makeText(SyncWebGuiActivity.this, R.string.sync_gui_shutdown, Toast.LENGTH_LONG).show();
                        finish();
                    });
                    return emptyJson();
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
                if (localGuiPath(url) != null || url.startsWith("about:") || url.startsWith("data:")) {
                    return false;   // GUI 内部页面/资源正常加载
                }
                // 外链一律交外部浏览器，不在本页内打开
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(final WebView view, final String url) {
                _loading.setVisibility(View.GONE);
            }
        });

        // 前置校验：同步未启用 / 服务器信息未填时不进页面
        final AppSettings settings = _appSettings;
        if (!settings.isSyncEnabled()) {
            showHintAndFinish(R.string.sync_gui_not_enabled);
            return;
        }
        if (settings.getSyncServerDeviceId().trim().isEmpty()
                || settings.getSyncServerSyncAddress().trim().isEmpty()) {
            showHintAndFinish(R.string.sync_gui_need_server);
            return;
        }

        // 前台策略下进入本页时引擎通常已在启动；未就绪则轮询等待
        waitEngineAndLoad();
    }

    private void waitEngineAndLoad() {
        if (SyncManager.get().isRunning()) {
            if (!_loadRequested) {
                _loadRequested = true;
                _webView.loadUrl(SyncManager.get().getGuiUrl());
            }
            return;
        }
        if (_waitTries >= WAIT_MAX_TRIES) {
            Toast.makeText(this, R.string.sync_gui_start_timeout, Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        _waitTries++;
        _main.postDelayed(this::waitEngineAndLoad, WAIT_INTERVAL_MS);
    }

    /** url 属于本机回环 GUI 时返回其路径部分，否则返回 null */
    private static String localGuiPath(final String url) {
        if (url == null) {
            return null;
        }
        final String prefix = SyncManager.get().getGuiUrl();   // http://127.0.0.1:8385
        if (url.startsWith(prefix)) {
            final String rest = url.substring(prefix.length());
            return rest.isEmpty() ? "/" : rest;
        }
        return null;
    }

    /** 合成 200 空 JSON 响应，让 GUI 的重启/关闭请求“成功”返回（实际动作由应用执行） */
    private static WebResourceResponse emptyJson() {
        return new WebResourceResponse("application/json", "UTF-8",
                new ByteArrayInputStream("{}".getBytes(StandardCharsets.UTF_8)));
    }

    private void showHintAndFinish(final int msgResId) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.sync_open_gui)
                .setMessage(msgResId)
                .setPositiveButton(android.R.string.ok, (d, w) -> finish())
                .setOnCancelListener(d -> finish())
                .show();
    }

    @Override
    public void onBackPressed() {
        if (_webView != null && _webView.canGoBack()) {
            _webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        _main.removeCallbacksAndMessages(null);
        if (_webView != null) {
            // WebView 需先从布局树移除再销毁，避免泄漏
            ((ViewGroup) _webView.getParent()).removeView(_webView);
            _webView.destroy();
            _webView = null;
        }
        super.onDestroy();
    }
}
