/*#######################################################
 *
 *   Maintained 2017-2025 by Gregor Santner <gsantner AT mailbox DOT org>
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import net.gsantner.markor.R;
import net.gsantner.markor.model.AppSettings;
import net.gsantner.markor.util.MarkorContextUtils;
import net.gsantner.opoc.frontend.base.GsFragmentBase;
import net.gsantner.opoc.model.GsSharedPreferencesPropertyBackend;
import net.gsantner.opoc.util.GsContextUtils;
import net.gsantner.opoc.util.GsFileUtils;

import java.io.File;
import java.util.ArrayList;

@SuppressWarnings({"WeakerAccess", "unused"})
public class RecentFilesFragment extends GsFragmentBase<AppSettings, MarkorContextUtils> {
    public static final String FRAGMENT_TAG = "RecentFilesFragment";

    public static RecentFilesFragment newInstance() {
        return new RecentFilesFragment();
    }

    public RecentFilesFragment() {
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.recent__fragment;
    }

    @Override
    public String getFragmentTag() {
        return FRAGMENT_TAG;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshRecentList();
    }

    private void refreshRecentList() {
        final View view = getView();
        final Activity activity = getActivity();
        if (view == null || activity == null || !isAdded()) {
            return;
        }
        final LinearLayout container = view.findViewById(R.id.recent__fragment__list_container);
        final TextView emptyView = view.findViewById(R.id.recent__fragment__empty);
        container.removeAllViews();

        final ArrayList<String> paths = _appSettings.getRecentDocuments();
        emptyView.setVisibility(paths.isEmpty() ? View.VISIBLE : View.GONE);

        final float density = getResources().getDisplayMetrics().density;
        final int colorSecondary = ContextCompat.getColor(activity, android.R.color.darker_gray);
        final int dividerColor = ContextCompat.getColor(activity, R.color.divider);

        for (final String path : paths) {
            final File file = new File(path);
            final LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.VERTICAL);
            final int pad = (int) (14 * density);
            row.setPadding(pad, pad / 2, pad, pad / 2);
            row.setClickable(true);
            row.setFocusable(true);

            final TextView title = new TextView(activity);
            title.setText(file.getName());
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);

            final TextView subtitle = new TextView(activity);
            subtitle.setText(file.getParentFile() != null ? GsFileUtils.getPath(file.getParentFile()) : path);
            subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            subtitle.setTextColor(colorSecondary);
            subtitle.setSingleLine(true);

            // 与文件页一致的隔行线：1px 分隔线，含左右内边距与文字基线对齐
            final View divider = new View(activity);
            final LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, (int) (density * 0.5f)));
            dividerLp.topMargin = pad / 2;
            divider.setLayoutParams(dividerLp);
            divider.setBackgroundColor(dividerColor);

            row.addView(title);
            row.addView(subtitle);
            row.addView(divider);
            row.setOnClickListener(v -> DocumentActivity.launch(getActivity(), file, false, null));
            row.setOnLongClickListener(v -> {
                confirmRemoveEntry(activity, file);
                return true;
            });
            container.addView(row);
        }
    }

    private void confirmRemoveEntry(final Activity activity, final File file) {
        new AlertDialog.Builder(activity)
                .setTitle(R.string.recent_remove_entry)
                .setMessage(file.getName())
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    _appSettings.setListFileInRecents(file, false);
                    Toast.makeText(activity, R.string.recent_remove_entry, Toast.LENGTH_SHORT).show();
                    refreshRecentList();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    @Override
    public AppSettings createAppSettingsInstance(Context context) {
        return AppSettings.get(context);
    }

    @Override
    public MarkorContextUtils createContextUtilsInstance(Context context) {
        return new MarkorContextUtils(context);
    }
}
