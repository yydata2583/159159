/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 *#########################################################*/
package net.gsantner.markor.format.markdown;

import java.util.ArrayList;
import java.util.List;

/**
 * Markdown 非标准写法源码侧 lint。对全文按行做一次 O(n) 扫描，输出 4 类问题的字符区间（半开区间）：
 * <ol>
 * <li>段落内未闭合的强调定界符（*、**、_、__）——只标定界符本身，不标整段；</li>
 * <li>文档结束仍未闭合的代码围栏（``` / ~~~）——标起始围栏定界符；</li>
 * <li>疑似表格：一行含 ≥2 个 | 而下一行不是 |---| 形式的分隔行——标该行；</li>
 * <li>无序列表项续行缩进不足：下一行以 1-3 个空格开头接文字，且未与列表内容列对齐——标该续行。</li>
 * </ol>
 * 围栏代码块、4 空格/tab 缩进代码块、行内反引号代码段内的内容一律不检测。
 * 强调配对采用 CommonMark 的“左右侧翼（flanking）”规则，避免把 a * b、snake_case 等误报。
 */
public final class MarkdownLint {

    /** 一个问题区间（字符偏移，半开区间 [start,end)） */
    public static final class Issue {
        public final int start;
        public final int end;

        Issue(final int start, final int end) {
            this.start = start;
            this.end = end;
        }
    }

    private MarkdownLint() {
    }

    public static List<Issue> scan(final CharSequence text) {
        final List<Issue> issues = new ArrayList<>();
        final int n = text == null ? 0 : text.length();
        if (n == 0) {
            return issues;
        }

        // 未配对的强调定界符栈，元素为 {绝对位置, 长度(1或2)}，* 与 _ 分别入栈
        final List<int[]> starStack = new ArrayList<>();
        final List<int[]> underStack = new ArrayList<>();
        int codeTicks = 0; // 跨行未闭合的行内反引号代码段长度；遇空行重置

        // 围栏状态
        boolean inFence = false;
        char fenceChar = 0;
        int fenceLen = 0;
        int fenceDelimStart = 0;
        int fenceDelimEnd = 0;

        int lineStart = 0;
        while (lineStart < n) {
            int nl = indexOfNewline(text, lineStart, n);
            final int lineEnd = nl < 0 ? n : nl;

            // 行首空格缩进；tab 按深度缩进（代码块）处理
            int indent = 0;
            while (lineStart + indent < lineEnd && text.charAt(lineStart + indent) == ' ') {
                indent++;
            }
            final boolean tabIndented = lineStart + indent < lineEnd && text.charAt(lineStart + indent) == '\t';
            boolean blank = lineStart + indent >= lineEnd;
            if (!blank) {
                blank = true;
                for (int j = lineStart + indent; j < lineEnd; j++) {
                    if (!isWhitespace(text.charAt(j))) {
                        blank = false;
                        break;
                    }
                }
            }

            // 空行：围栏内忽略；否则段落结束，挂出所有未闭合强调
            if (blank) {
                if (!inFence) {
                    flush(starStack, underStack, issues);
                    codeTicks = 0;
                }
                lineStart = lineEnd + 1;
                continue;
            }

            // 围栏定界行：0-3 空格缩进后接 ≥3 个 ` 或 ~
            int fenceRun = 0;
            char fenceRunChar = 0;
            if (indent <= 3 && !tabIndented) {
                final int p = lineStart + indent;
                final char c = text.charAt(p);
                if (c == '`' || c == '~') {
                    int k = 0;
                    while (p + k < lineEnd && text.charAt(p + k) == c) {
                        k++;
                    }
                    if (k >= 3) {
                        fenceRun = k;
                        fenceRunChar = c;
                    }
                }
            }

            if (fenceRun >= 3) {
                if (inFence) {
                    // 闭合围栏：同字符、长度不短于起始围栏、其后只剩空白
                    if (fenceRunChar == fenceChar && fenceRun >= fenceLen
                            && onlySpaces(text, lineStart + indent + fenceRun, lineEnd)) {
                        inFence = false;
                    }
                    // 围栏内不匹配的伪围栏行，整体忽略
                } else {
                    // 围栏中断当前段落，先挂出未闭合强调
                    flush(starStack, underStack, issues);
                    codeTicks = 0;
                    inFence = true;
                    fenceChar = fenceRunChar;
                    fenceLen = fenceRun;
                    fenceDelimStart = lineStart + indent;
                    fenceDelimEnd = fenceDelimStart + fenceRun;
                }
                lineStart = lineEnd + 1;
                continue;
            }

            // 围栏内容行：全部跳过
            if (inFence) {
                lineStart = lineEnd + 1;
                continue;
            }

            // 4 空格/tab 缩进代码块：本行不检测（段落状态保留）
            if (indent >= 4 || tabIndented) {
                lineStart = lineEnd + 1;
                continue;
            }

            final boolean heading = isAtxHeading(text, lineStart + indent, lineEnd);
            if (heading) {
                // ATX 标题自成块，标题前未闭合的段落强调在此结束
                flush(starStack, underStack, issues);
                codeTicks = 0;
            }

            // 行内扫描：反引号代码段 + 强调定界符，顺带统计代码段外的 | 数量
            int pipes = 0;
            int i = lineStart;
            while (i < lineEnd) {
                final char c = text.charAt(i);
                if (c == '`') {
                    int k = 0;
                    while (i + k < lineEnd && text.charAt(i + k) == '`') {
                        k++;
                    }
                    if (codeTicks == 0) {
                        codeTicks = k; // 代码段开始
                    } else if (codeTicks == k) {
                        codeTicks = 0; // 等长反引号闭合
                    }
                    i += k;
                    continue;
                }
                if (codeTicks == 0) {
                    if (c == '|') {
                        pipes++;
                    } else if (c == '*' || c == '_') {
                        int k = 0;
                        while (i + k < lineEnd && text.charAt(i + k) == c) {
                            k++;
                        }
                        if (k == 1 || k == 2) {
                            // *** 等长度 ≥3 的复合定界不检测，避免误报
                            considerDelimiter(text, n, i, k, c, starStack, underStack);
                        }
                        i += k;
                        continue;
                    }
                }
                i++;
            }

            // 标题行行内未闭合的强调立即挂出；Setext/水平规则分隔线同样结束段落
            if (heading || isRuleLine(text, lineStart + indent, lineEnd)) {
                flush(starStack, underStack, issues);
                codeTicks = 0;
            }

            final int contentStart = lineStart + indent;
            final int contentEnd = trailingNonSpace(text, lineEnd, contentStart);

            // 规则 3：疑似表格缺分隔行（本行 ≥2 个 |，本行与下一行均非分隔行形式）
            if (pipes >= 2 && !isTableSeparator(text, contentStart, contentEnd)) {
                final int nextStart = lineEnd + 1;
                if (nextStart >= n || !isTableSeparator(text, nextStart, lineEndOf(text, nextStart, n))) {
                    if (contentEnd > contentStart) {
                        issues.add(new Issue(contentStart, contentEnd));
                    }
                }
            }

            // 规则 4：-/*/+ 列表项的续行缩进不足
            final int contentColumn = bulletContentColumn(text, lineStart, lineEnd, indent);
            if (contentColumn >= 0) {
                final int nextStart = lineEnd + 1;
                if (nextStart < n) {
                    final int nextEnd = lineEndOf(text, nextStart, n);
                    flagBadContinuation(text, nextStart, nextEnd, contentColumn, issues);
                }
            }

            lineStart = lineEnd + 1;
        }

        // 文档结束：挂出未闭合强调与未闭合围栏
        flush(starStack, underStack, issues);
        if (inFence) {
            issues.add(new Issue(fenceDelimStart, fenceDelimEnd));
        }
        return issues;
    }

    // ---------------------------------------------------------- 强调配对

    /** 按 CommonMark flanking 规则判断一个定界符片段是开启还是闭合，并维护配对栈 */
    private static void considerDelimiter(final CharSequence t, final int n, final int pos, final int len, final char ch,
                                          final List<int[]> starStack, final List<int[]> underStack) {
        final char prev = pos > 0 ? t.charAt(pos - 1) : '\n';
        final char next = pos + len < n ? t.charAt(pos + len) : '\n';
        final boolean prevWs = isWhitespace(prev);
        final boolean nextWs = isWhitespace(next);
        final boolean prevPunct = isPunctuation(prev);
        final boolean nextPunct = isPunctuation(next);

        // 左、右翼判定（CommonMark 定界符规则）
        final boolean leftFlanking = !nextWs && (!nextPunct || prevWs || prevPunct);
        final boolean rightFlanking = !prevWs && (!prevPunct || nextWs || nextPunct);
        // _ 受词内限制：两侧都是字母/数字时不能开/闭
        final boolean canOpen = leftFlanking && (ch == '*' || !rightFlanking || prevPunct);
        final boolean canClose = rightFlanking && (ch == '*' || !leftFlanking || nextPunct);

        final List<int[]> stack = ch == '*' ? starStack : underStack;
        // 优先作为闭合符，与栈顶等长定界符配对（不匹配则忽略该闭合符）
        if (canClose && !stack.isEmpty() && stack.get(stack.size() - 1)[1] == len) {
            stack.remove(stack.size() - 1);
            return;
        }
        if (canOpen) {
            stack.add(new int[]{pos, len});
        }
    }

    /** 挂出栈中所有未闭合的强调定界符（只标定界符本身） */
    private static void flush(final List<int[]> starStack, final List<int[]> underStack, final List<Issue> issues) {
        for (final int[] d : starStack) {
            issues.add(new Issue(d[0], d[0] + d[1]));
        }
        starStack.clear();
        for (final int[] d : underStack) {
            issues.add(new Issue(d[0], d[0] + d[1]));
        }
        underStack.clear();
    }

    // ---------------------------------------------------------- 行级判定

    /** 若是减号、星号或加号开头的无序列表项，返回内容起始列（相对行首）；否则返回 -1 */
    private static int bulletContentColumn(final CharSequence t, final int lineStart, final int lineEnd, final int indent) {
        final int p = lineStart + indent;
        if (p >= lineEnd) {
            return -1;
        }
        final char c = t.charAt(p);
        if (c != '-' && c != '*' && c != '+') {
            return -1;
        }
        final int after = p + 1;
        if (after >= lineEnd || (t.charAt(after) != ' ' && t.charAt(after) != '\t')) {
            return -1;
        }
        int q = after;
        while (q < lineEnd && (t.charAt(q) == ' ' || t.charAt(q) == '\t')) {
            q++;
        }
        // 复选框 [ ] / [x] / [X] 也属于列表标记，计入对齐列
        if (q + 3 < lineEnd && t.charAt(q) == '['
                && (t.charAt(q + 1) == ' ' || t.charAt(q + 1) == 'x' || t.charAt(q + 1) == 'X')
                && t.charAt(q + 2) == ']'
                && (t.charAt(q + 3) == ' ' || t.charAt(q + 3) == '\t')) {
            q += 3;
            while (q < lineEnd && (t.charAt(q) == ' ' || t.charAt(q) == '\t')) {
                q++;
            }
        }
        return q - lineStart;
    }

    /** 续行以 1-3 个空格开头且未对齐内容列、又不是其他块级结构时，标记该续行 */
    private static void flagBadContinuation(final CharSequence t, final int lineStart, final int lineEnd,
                                            final int contentColumn, final List<Issue> issues) {
        int spaces = 0;
        while (lineStart + spaces < lineEnd && t.charAt(lineStart + spaces) == ' ') {
            spaces++;
        }
        // 仅 1-3 个空格（0 空格为合法懒续行，≥4 空格合法，tab 不判）
        if (spaces < 1 || spaces > 3 || lineStart + spaces >= lineEnd) {
            return;
        }
        final int p = lineStart + spaces;
        if (t.charAt(p) == '\t' || Character.isWhitespace(t.charAt(p))) {
            return;
        }
        // 与列表项内容列精确对齐的续行合法
        if (spaces == contentColumn) {
            return;
        }
        // 续行本身是另一个块级结构：列表/标题/围栏/引用/表格分隔行
        if (startsWithBullet(t, p, lineEnd) || startsWithOrdered(t, p, lineEnd)
                || isAtxHeading(t, p, lineEnd) || startsWithFence(t, p, lineEnd)
                || t.charAt(p) == '>' || isTableSeparator(t, p, trailingNonSpace(t, lineEnd, p))) {
            return;
        }
        final int end = trailingNonSpace(t, lineEnd, p);
        if (end > p) {
            issues.add(new Issue(p, end));
        }
    }

    private static boolean startsWithBullet(final CharSequence t, final int p, final int end) {
        if (p >= end) {
            return false;
        }
        final char c = t.charAt(p);
        return (c == '-' || c == '*' || c == '+') && p + 1 < end
                && (t.charAt(p + 1) == ' ' || t.charAt(p + 1) == '\t');
    }

    private static boolean startsWithOrdered(final CharSequence t, final int p, final int end) {
        int q = p;
        while (q < end && q < p + 9 && Character.isDigit(t.charAt(q))) {
            q++;
        }
        return q > p && q < end && (t.charAt(q) == '.' || t.charAt(q) == ')')
                && q + 1 < end && (t.charAt(q + 1) == ' ' || t.charAt(q + 1) == '\t');
    }

    private static boolean startsWithFence(final CharSequence t, final int p, final int end) {
        if (p >= end) {
            return false;
        }
        final char c = t.charAt(p);
        if (c != '`' && c != '~') {
            return false;
        }
        int k = 0;
        while (p + k < end && t.charAt(p + k) == c) {
            k++;
        }
        return k >= 3;
    }

    /** ATX 标题：1-6 个 # 后接空白或行尾 */
    private static boolean isAtxHeading(final CharSequence t, final int p, final int end) {
        if (p >= end || t.charAt(p) != '#') {
            return false;
        }
        int k = 0;
        while (p + k < end && t.charAt(p + k) == '#' && k <= 6) {
            k++;
        }
        return k >= 1 && k <= 6 && (p + k >= end || t.charAt(p + k) == ' ' || t.charAt(p + k) == '\t');
    }

    /** 水平规则/Setext 下划线行：去空白后只含 -（≥3 个），视为段落边界 */
    private static boolean isRuleLine(final CharSequence t, int p, final int end) {
        int dashes = 0;
        for (; p < end; p++) {
            final char c = t.charAt(p);
            if (c == '-') {
                dashes++;
            } else if (!Character.isWhitespace(c)) {
                return false;
            }
        }
        return dashes >= 3;
    }

    /**
     * GFM 表格分隔行形式：|? :?-+:? (| :?-+:?)* |?，至少 1 个 |。
     * 区间两端的空白自动忽略。
     */
    private static boolean isTableSeparator(final CharSequence t, int s, int e) {
        while (s < e && Character.isWhitespace(t.charAt(s))) {
            s++;
        }
        while (e > s && Character.isWhitespace(t.charAt(e - 1))) {
            e--;
        }
        if (s >= e) {
            return false;
        }
        int pipes = 0;
        int cellStart = s;
        for (int i = s; i <= e; i++) {
            if (i < e && t.charAt(i) != '|') {
                continue;
            }
            // 校验单元格 [cellStart,i) trim 后为 :?-+:?
            int a = cellStart;
            int b = i;
            while (a < b && Character.isWhitespace(t.charAt(a))) {
                a++;
            }
            while (b > a && Character.isWhitespace(t.charAt(b - 1))) {
                b--;
            }
            int k = a;
            if (k < b && t.charAt(k) == ':') {
                k++;
            }
            int dashes = 0;
            while (k < b && t.charAt(k) == '-') {
                k++;
                dashes++;
            }
            if (dashes == 0) {
                return false;
            }
            if (k < b && t.charAt(k) == ':') {
                k++;
            }
            if (k != b) {
                return false;
            }
            if (i < e) {
                pipes++;
                cellStart = i + 1;
            }
        }
        return pipes >= 1;
    }

    // ---------------------------------------------------------- 基础工具

    private static int indexOfNewline(final CharSequence t, final int from, final int n) {
        for (int i = from; i < n; i++) {
            if (t.charAt(i) == '\n') {
                return i;
            }
        }
        return -1;
    }

    private static int lineEndOf(final CharSequence t, final int lineStart, final int n) {
        final int nl = indexOfNewline(t, lineStart, n);
        return nl < 0 ? n : nl;
    }

    /** [start,end) 内最后一个非空白字符之后的位置（即去掉尾部空白的行尾） */
    private static int trailingNonSpace(final CharSequence t, final int end, final int start) {
        int e = end;
        while (e > start && Character.isWhitespace(t.charAt(e - 1))) {
            e--;
        }
        return e;
    }

    private static boolean onlySpaces(final CharSequence t, int p, final int end) {
        // 容忍 CRLF：行尾的 \r 也视为空白
        for (; p < end; p++) {
            final char c = t.charAt(p);
            if (c != ' ' && c != '\t' && c != '\r') {
                return false;
            }
        }
        return true;
    }

    private static boolean isWhitespace(final char c) {
        return c == '\n' || Character.isWhitespace(c);
    }

    /** 近似 CommonMark 的 Unicode 标点判定（空白、字母、数字之外的符号类字符） */
    private static boolean isPunctuation(final char c) {
        if (Character.isWhitespace(c)) {
            return false;
        }
        switch (Character.getType(c)) {
            case Character.CONNECTOR_PUNCTUATION:
            case Character.DASH_PUNCTUATION:
            case Character.START_PUNCTUATION:
            case Character.END_PUNCTUATION:
            case Character.INITIAL_QUOTE_PUNCTUATION:
            case Character.FINAL_QUOTE_PUNCTUATION:
            case Character.OTHER_PUNCTUATION:
            case Character.MATH_SYMBOL:
            case Character.CURRENCY_SYMBOL:
            case Character.MODIFIER_SYMBOL:
            case Character.OTHER_SYMBOL:
                return true;
            default:
                return false;
        }
    }
}
