/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.sync;

import android.os.Handler;
import android.os.Looper;

import net.gsantner.markor.model.AppSettings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 文件锁客户端（批次4）：对接服务器 lockserver API（协议见服务器 README §五）。
 * <ul>
 * <li>打开文档：POST /api/v1/open（登记）</li>
 * <li>打开期间每 30s：POST /api/v1/heartbeat（服务器 70s 无心跳自动过期）</li>
 * <li>保存/关闭：POST /api/v1/close（注销）</li>
 * </ul>
 * 返回的 holders 为<b>其他设备</b>占用者，经 {@link Callback} 弹提示。
 * 服务器地址 / API Key 默认为空——为空则整体静默禁用（不发任何请求）。
 */
public final class LockClient {

    /** UI 回调：其他设备占用提示 */
    public interface Callback {
        void onFileHeldElsewhere(String relPath, String holders);
    }

    private static final String VAULT_ID = "markor-vault";   // 三端约定
    private static final long HEARTBEAT_MS = 30000L;

    private static LockClient _instance;

    public static synchronized LockClient get() {
        if (_instance == null) {
            _instance = new LockClient();
        }
        return _instance;
    }

    private final Handler _main = new Handler(Looper.getMainLooper());
    private final ExecutorService _io = Executors.newSingleThreadExecutor();
    private WeakReference<Callback> _callback = new WeakReference<>(null);

    private AppSettings _settings;
    private String _relPath = "";
    private String _deviceId = "";
    private String _deviceName = "";
    private final Runnable _heartbeat = new Runnable() {
        @Override
        public void run() {
            if (_relPath.isEmpty()) {
                return;
            }
            post("/api/v1/heartbeat", body(), true);
            _main.postDelayed(this, HEARTBEAT_MS);
        }
    };

    private LockClient() {
    }

    public void setCallback(final Callback cb) {
        _callback = new WeakReference<>(cb);
    }

    /** 打开文档：登记 + 启动心跳。未配置服务器则静默。 */
    public void open(final AppSettings settings, final File file, final String deviceId) {
        _settings = settings;
        _deviceId = (deviceId == null || deviceId.isEmpty()) ? settings.getSyncDeviceName() : deviceId;
        _deviceName = settings.getSyncDeviceName();
        if (settings.getSyncServerApi().trim().isEmpty()
                || settings.getSyncServerApiKey().isEmpty()) {
            return;   // 未配置服务器：静默禁用
        }
        _relPath = relPath(settings, file);
        post("/api/v1/open", body(), true);
        _main.removeCallbacks(_heartbeat);
        _main.postDelayed(_heartbeat, HEARTBEAT_MS);
    }

    /** 保存/关闭：注销 */
    public void close() {
        _main.removeCallbacks(_heartbeat);
        if (_relPath.isEmpty()) {
            return;
        }
        post("/api/v1/close", body(), false);
        _relPath = "";
    }

    private static String relPath(final AppSettings settings, final File file) {
        try {
            final String base = settings.getNotebookDirectory().getCanonicalPath();
            final String abs = file.getCanonicalPath();
            if (abs.startsWith(base)) {
                String rel = abs.substring(base.length());
                while (rel.startsWith("/") || rel.startsWith(File.separator)) {
                    rel = rel.substring(1);
                }
                return rel.replace(File.separatorChar, '/');
            }
        } catch (Exception ignored) {
        }
        return file.getName();
    }

    private JSONObject body() {
        try {
            return new JSONObject()
                    .put("device_id", _deviceId)
                    .put("device_name", _deviceName)
                    .put("vault_id", VAULT_ID)
                    .put("path", _relPath);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void post(final String api, final JSONObject body, final boolean notifyHolders) {
        final AppSettings s = _settings;
        if (s == null) {
            return;
        }
        final String base = s.getSyncServerApi().trim();
        final String key = s.getSyncServerApiKey();
        if (base.isEmpty() || key.isEmpty()) {
            return;
        }
        _io.execute(() -> {
            try {
                final URL url = new URL(base + api);
                final HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                try {
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Authorization", "Bearer " + key);
                    final byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(data);
                    }
                    final int code = conn.getResponseCode();
                    if (code < 200 || code >= 300 || !notifyHolders) {
                        return;
                    }
                    final StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                    final JSONObject resp = new JSONObject(sb.toString());
                    final JSONArray holders = resp.optJSONArray("holders");
                    if (holders == null || holders.length() == 0) {
                        return;
                    }
                    final StringBuilder names = new StringBuilder();
                    for (int i = 0; i < holders.length(); i++) {
                        final JSONObject h = holders.getJSONObject(i);
                        final String name = h.optString("device_name", "");
                        if (names.length() > 0) {
                            names.append("、");
                        }
                        names.append(name.isEmpty()
                                ? h.optString("device_id", "").substring(0, Math.min(7, h.optString("device_id", "").length()))
                                : name);
                    }
                    final String rel = _relPath;
                    _main.post(() -> {
                        final Callback cb = _callback.get();
                        if (cb != null) {
                            cb.onFileHeldElsewhere(rel, names.toString());
                        }
                    });
                } finally {
                    conn.disconnect();
                }
            } catch (Exception ignored) {
            }
        });
    }
}
