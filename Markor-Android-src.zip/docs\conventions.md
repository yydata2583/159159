# 开发规范与操作手册（conventions.md）— Markor Android

## 1. 代码规范（跟随现有风格）

| 项 | 约定 |
|---|---|
| 语法 | Java 8（lambda/方法引用可用）；4 空格缩进；`final` 参数风格跟随周边 |
| 命名 | 类 PascalCase；方法/字段 camelCase；常量 SCREAMING_SNAKE；pref key `pref_key__xxx` |
| 设置 | 一律经 `AppSettings`（`GsSharedPreferencesPropertyBackend`）；**key 先在 `string-not_translatable.xml` 声明** |
| 文案 | `R.string` 引用；**英文 `values/strings.xml` 与简中 `values-zh-rCN/strings.xml` 成对添加**；动态诊断串可直接中文字面量 |
| 依赖 | 不引第三方库；HTTP=HttpURLConnection、JSON=org.json、异步=ExecutorService+Handler |
| 单例 | `static X get()` + 私有构造（sync 包风格） |
| 引用 | 跨生命周期引用用 `WeakReference`（Activity/回调），防泄漏 |
| 注释 | 关键机制写"为什么"；定制代码标 `批次N` 便于升级上游时识别 |

## 2. 红线（详见 AGENTS.md §3）

- **等通知才编译**（`./gradlew` 不许主动跑）；只做代码修改 + 人工自查。
- 服务器信息不写死；星型拓扑不破坏；同步仅前台；连接结果弹窗；pref key 双语成对。

## 3. 新增功能 Checklist

### 3.1 新设置项
- [ ] `string-not_translatable.xml` 加 `pref_key__xxx`
- [ ] `AppSettings` 加 getter（默认值要想清楚——服务器信息一律默认空）
- [ ] `preferences_master.xml` 加条目（照抄相邻条目的写法/图标）
- [ ] 双语 `strings.xml` 加标题/摘要（`android:summary="%1$s"` 显示当前值）
- [ ] 需要即时生效 → `SettingsActivity.onPreferenceChanged` 加分支
- [ ] 更新 `docs/data-model.md` 键表

### 3.2 同步相关
- [ ] 保持星型约束（ADR-103）：不加 introducer/发现/中继/自升级
- [ ] 配置变更后 `startIfEnabled()` 重应用（路径错位教训：别只在启动时写一次）
- [ ] 连接结果三态弹窗保持（成功/失败/信息不全）
- [ ] 三端同步改协议（PC `LockClient`、服务器 `lockserver/main.py`、README §五）

### 3.3 大纲/预览交互
- [ ] 改 `OutlineInjector` JS 时注意 Java 字符串转义（`\\s+`、`\'`）
- [ ] 保持防回环约定：spy 只高亮不滚动列表；follow 不收起面板；jump 收起
- [ ] 每次预览加载是全新 JS 上下文，不残留状态（设计如此）

## 4. 构建（未通知不要执行）

```sh
./gradlew assembleFlavorDefaultRelease     # 或 flavorAtest / flavorGplay
```
- 需 Android SDK；构建日志样例见 `build-log.txt`。
- **内置同步运行期**需 `app/src/main/jniLibs/<abi>/libsyncthing.so`（仓库不含；
  取自 syncthing 安卓交叉编译或 Syncthing-Fork，MPL-2.0 许可声明随附）。
- zip 交付注意：Windows 反斜杠路径的 zip 在 Linux 解压要规范化分隔符。

## 5. 升级上游（gsantner/markor）指引

1. 定制面集中在 `docs/directory.md` 的"定制改动清单"（10 个文件）；
2. 合并上游后逐项核对该清单是否仍生效（尤其 DocumentEditAndViewFragment 生命周期钩子）；
3. `opoc/` 为上游共享库，冲突时以上游为准、再补定制。

## 6. 测试要点（编译后人工验证）

| 场景 | 预期 |
|---|---|
| 启用同步 + 服务器信息为空 | 弹"信息未填写完整"，不起引擎 |
| 引擎二进制缺失 | 弹"未找到内置同步引擎"，不崩溃 |
| 前台↔后台切换 | 前台起引擎、后台停（日志可见进程启停） |
| 连接成功/失败 | 各有弹窗 |
| 打开被占文件 | Toast "该文件已被其他设备打开：…" |
| 大纲列表滚动 | 正文跟随滚动到对应标题，面板不收起；正文滚动时列表不高亮跳动 |
