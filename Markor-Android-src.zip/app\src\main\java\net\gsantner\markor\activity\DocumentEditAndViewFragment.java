/*#######################################################
 *
 *   Maintained 2017-2025 by Gregor Santner <gsantner AT mailbox DOT org>
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.FragmentActivity;

import com.google.android.material.snackbar.Snackbar;

import net.gsantner.markor.ApplicationObject;
import net.gsantner.markor.BuildConfig;
import net.gsantner.markor.R;
import net.gsantner.markor.format.ActionButtonBase;
import net.gsantner.markor.format.FormatRegistry;
import net.gsantner.markor.format.MarkdownAutoFormat;
import net.gsantner.markor.format.TextConverterBase;
import net.gsantner.markor.frontend.DraggableScrollbarScrollView;
import net.gsantner.markor.frontend.FileInfoDialog;
import net.gsantner.markor.frontend.MarkorDialogFactory;
import net.gsantner.markor.frontend.filebrowser.MarkorFileBrowserFactory;
import net.gsantner.markor.frontend.textview.HighlightingEditor;
import net.gsantner.markor.frontend.textview.LineNumbersView;
import net.gsantner.markor.frontend.textview.TextViewUtils;
import net.gsantner.markor.model.AppSettings;
import net.gsantner.markor.model.Document;
import net.gsantner.markor.util.MarkorContextUtils;
import net.gsantner.markor.web.DraggableScrollbarWebView;
import net.gsantner.markor.web.MarkorWebViewClient;
import net.gsantner.markor.widget.TodoWidgetProvider;
import net.gsantner.opoc.frontend.filebrowser.GsFileBrowserOptions;
import net.gsantner.opoc.frontend.settings.GsFontPreferenceCompat;
import net.gsantner.opoc.frontend.textview.TextViewUndoRedo;
import net.gsantner.opoc.util.GsContextUtils;
import net.gsantner.opoc.util.GsCoolExperimentalStuff;
import net.gsantner.opoc.web.GsWebViewChromeClient;
import net.gsantner.opoc.wrapper.GsCallback;
import net.gsantner.opoc.wrapper.GsTextWatcherAdapter;

import java.io.File;

@SuppressWarnings({"UnusedReturnValue"})
@SuppressLint("NonConstantResourceId")
public class DocumentEditAndViewFragment extends MarkorBaseFragment implements FormatRegistry.TextFormatApplier {
    public static final String FRAGMENT_TAG = "DocumentEditAndViewFragment";
    public static final String SAVESTATE_DOCUMENT = "DOCUMENT";
    public static final String START_PREVIEW = "START_PREVIEW";

    public static float VIEW_FONT_SCALE = 100f / 15.7f;

    public static DocumentEditAndViewFragment newInstance(final @NonNull Document document, final Integer lineNumber, final Boolean preview) {
        DocumentEditAndViewFragment f = new DocumentEditAndViewFragment();
        Bundle args = new Bundle();
        args.putSerializable(Document.EXTRA_DOCUMENT, document);
        if (lineNumber != null) {
            args.putInt(Document.EXTRA_FILE_LINE_NUMBER, lineNumber);
        }
        if (preview != null) {
            args.putBoolean(START_PREVIEW, preview);
        }
        f.setArguments(args);
        return f;
    }

    private HighlightingEditor _hlEditor;
    private WebView _webView;
    private ViewStub _webViewStub;
    private MarkorWebViewClient _webViewClient;
    private ViewGroup _editorHolder;
    private ViewGroup _textActionsBar;

    private DraggableScrollbarScrollView _verticalScrollView;
    private HorizontalScrollView _horizontalScrollView;
    private LineNumbersView _lineNumbersView;
    private TextView _searchResultTextView;
    private Document _document;
    private FormatRegistry _format;
    private MarkorContextUtils _cu;
    private TextViewUndoRedo _editTextUndoRedoHelper;
    private MenuItem _saveMenuItem, _undoMenuItem, _redoMenuItem;
    private boolean _isPreviewVisible;
    private boolean _nextConvertToPrintMode = false;
    private View _outlineFab;

    public DocumentEditAndViewFragment() {
        super();
    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Bundle args = getArguments();
        if (savedInstanceState != null && savedInstanceState.containsKey(SAVESTATE_DOCUMENT)) {
            _document = (Document) savedInstanceState.getSerializable(SAVESTATE_DOCUMENT);
        } else if (args != null && args.containsKey(Document.EXTRA_DOCUMENT)) {
            _document = (Document) args.get(Document.EXTRA_DOCUMENT);
        }
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.document__fragment__edit;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final Activity activity = getActivity();

        _hlEditor = view.findViewById(R.id.document__fragment__edit__highlighting_editor);
        _editorHolder = view.findViewById(R.id.document__fragment__edit__editor_holder);
        _textActionsBar = view.findViewById(R.id.document__fragment__edit__text_actions_bar);
        _webViewStub = view.findViewById(R.id.document__fragment_webview_stub);
        _verticalScrollView = view.findViewById(R.id.document__fragment__edit__content_editor__scrolling_parent);
        _lineNumbersView = view.findViewById(R.id.document__fragment__edit__line_numbers_view);
        // 批次5：大纲入口原生悬浮按钮——点击切换预览内注入的大纲抽屉（注入按钮在 WebView 缩放后会跑出屏幕）
        _outlineFab = view.findViewById(R.id.document__fragment__view__outline_fab);
        _outlineFab.setOnClickListener(v -> {
            if (_webView != null) {
                _webView.evaluateJavascript("window.__mkOutlineToggle&&window.__mkOutlineToggle();", null);
            }
        });
        _cu = new MarkorContextUtils(activity);
        _editTextUndoRedoHelper = new TextViewUndoRedo();
        _editorHolder.setOnClickListener(v -> {
            _hlEditor.requestFocus();
            _cu.showSoftKeyboard(activity, true, _hlEditor);
        });

        // Using `if (_document != null)` everywhere is dangerous
        // It may cause reads or writes to _silently fail_
        // Instead we try to create it, and exit if that isn't possible
        if (isStateBad()) {
            Toast.makeText(activity, R.string.error_could_not_open_file + " " + getDocument().file, Toast.LENGTH_LONG).show();
            if (activity != null) {
                activity.finish();
            }
            return;
        }

        _lineNumbersView.setEditText(_hlEditor);
        _lineNumbersView.setLineNumbersEnabled(_appSettings.getDocumentLineNumbersEnabled(_document.path));

        // Upon construction, the document format has been determined from extension etc.
        // Here we replace it with the last saved format.
        applyTextFormat(_appSettings.getDocumentFormat(_document.path, _document.getFormat()));

        if (activity instanceof DocumentActivity) {
            ((DocumentActivity) activity).setDocumentTitle(_document.title);
        }

        // Preview mode set before loadDocument to prevent flicker
        final Bundle args = getArguments();
        final boolean startInPreview = _appSettings.getDocumentPreviewState(_document.path);
        if (args != null && savedInstanceState == null) { // Use the launch flag on first launch
            setViewModeVisibility(args.getBoolean(START_PREVIEW, startInPreview), false);
        } else {
            setViewModeVisibility(startInPreview, false);
        }

        // Configure the editor
        // ---------------------------------------------------------
        _hlEditor.setLineSpacing(0, _appSettings.getEditorLineSpacing());
        _hlEditor.setTextSize(TypedValue.COMPLEX_UNIT_SP, _appSettings.getDocumentFontSize(_document.path));
        _hlEditor.setTypeface(GsFontPreferenceCompat.typeface(getContext(), _appSettings.getFontFamily(), Typeface.NORMAL));
        final int editorBackgroundColor = _appSettings.getEditorBackgroundColor();
        _hlEditor.setBackgroundColor(editorBackgroundColor);
        _editorHolder.setBackgroundColor(editorBackgroundColor);
        _hlEditor.setTextColor(_appSettings.getEditorForegroundColor());
        _hlEditor.setGravity(_appSettings.isEditorStartEditingInCenter() ? Gravity.CENTER : Gravity.NO_GRAVITY);
        _hlEditor.setHighlightingEnabled(_appSettings.getDocumentHighlightState(_document.path, _hlEditor.getText()));
        _hlEditor.setAutoFormatEnabled(_appSettings.getDocumentAutoFormatEnabled(_document.path));
        _hlEditor.setSaveInstanceState(false); // We will reload from disk
        _hlEditor.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        _hlEditor.setStaticCursorEnabled(_appSettings.isStaticCursorEnabled());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Do not need to send contents to accessibility
            _hlEditor.setImportantForAccessibility(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        }

        // Various settings
        setWrapState(isDisplayedAtMainActivity() || _appSettings.getDocumentWrapState(_document.path));
        updateMenuToggleStates(0);

        // ---------------------------------------------------------
        _document.resetChangeTracking(); // Force next reload in onResume

        final Runnable debounced = TextViewUtils.makeDebounced(500, () -> {
            checkTextChangeState();
            updateUndoRedoIconStates();
        });
        _hlEditor.addTextChangedListener(GsTextWatcherAdapter.after(s -> debounced.run()));
        _hlEditor.setOnDispatchKeyListener(this::onEditorKeyDown);

        // We set the keyboard to be hidden if it was hidden when we lost focus
        // This works well to preserve keyboard state.
        if (activity != null) {
            final Window window = activity.getWindow();
            // Setting via a window manager state is much more robust than using show/hide
            final int adjustResize = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
            final int unchanged = WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED | adjustResize;
            final int hidden = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN | adjustResize;
            final int shown = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE | adjustResize;

            _hlEditor.getViewTreeObserver().addOnWindowFocusChangeListener(hasFocus -> {
                if (hasFocus) {
                    // Restore old state
                    _hlEditor.postDelayed(() -> window.setSoftInputMode(unchanged), 500);
                } else {
                    final Boolean isOpen = TextViewUtils.isImeOpen(_hlEditor);
                    if (isOpen != null) {
                        window.setSoftInputMode(isOpen ? shown : hidden);
                    }
                }
            });
        }

    }

    @Override
    protected void onFragmentFirstTimeVisible() {
        final Bundle args = getArguments();
        final boolean hasLineNumber = args != null && args.containsKey(Document.EXTRA_FILE_LINE_NUMBER);
        final int targetSelection;
        if (hasLineNumber) {
            final int lineNumber = args.getInt(Document.EXTRA_FILE_LINE_NUMBER);
            targetSelection = lineNumber >= 0
                    ? TextViewUtils.getIndexFromLineOffset(_hlEditor.getText(), lineNumber, 0)
                    : _hlEditor.length();
        } else {
            targetSelection = _appSettings.getLastEditPosition(_document.path, _hlEditor.length());
        }

        if (_webView != null) {
            final int lastViewHeight = _appSettings.getLastViewHeight(_document.path, 0);
            final int lastViewScrollY = _appSettings.getLastViewScrollY(_document.path, 0);
            if (lastViewScrollY > 0 && lastViewHeight == _webView.getHeight()) {
                _verticalScrollView.post(() -> _webView.scrollTo(0, lastViewScrollY));
            }
        }

        _hlEditor.recomputeHighlighting();
        // Defer initial placement until after the highlight-triggered reflow work has run.
        _hlEditor.post(() -> {
            if (!hasLineNumber) {
                final int lastEditHeight = _appSettings.getLastEditHeight(_document.path, 0);
                if (lastEditHeight > 0 && lastEditHeight == _verticalScrollView.getHeight()) {
                    final int lastEditScrollY = _appSettings.getLastEditScrollY(_document.path, 0);
                    _hlEditor.setSelection(targetSelection);
                    _verticalScrollView.scrollTo(0, lastEditScrollY);
                    return;
                }
            }
            _hlEditor.post(() -> TextViewUtils.setSelectionAndShow(_hlEditor, targetSelection));
        });

        // Fade in to hide initial jank
        _hlEditor.post(() -> _hlEditor.animate().alpha(1).setDuration(250).start());
        setupHighlightingScrollRestore();
    }

    private void setupHighlightingScrollRestore() {
        _hlEditor.setScrollCallbacks(
                () -> new int[]{
                        _horizontalScrollView != null ? _horizontalScrollView.getScrollX() : 0,
                        _verticalScrollView != null ? _verticalScrollView.getScrollY() : 0
                },
                (x, y) -> {
                    if (_horizontalScrollView != null) {
                        _horizontalScrollView.scrollTo(x, 0);
                    }
                    if (_verticalScrollView != null) {
                        _verticalScrollView.scrollTo(0, y);
                    }
                }
        );
    }

    @Override
    public void onResume() {
        if (_webView != null) {
            _webView.onResume();
        }
        loadDocument();
        // 批次4：文件锁——登记打开并启动心跳（未配置服务器则静默）；
        // 其他设备占用时弹提示
        net.gsantner.markor.sync.LockClient.get().setCallback((relPath, holders) -> {
            final android.app.Activity a = getActivity();
            if (a != null) {
                android.widget.Toast.makeText(a,
                        getString(R.string.file_opened_elsewhere, holders),
                        android.widget.Toast.LENGTH_LONG).show();
            }
        });
        net.gsantner.markor.sync.LockClient.get().open(_appSettings, _document.file,
                net.gsantner.markor.sync.SyncManager.get().getDeviceId());
        if (_editTextUndoRedoHelper != null && _editTextUndoRedoHelper.getTextView() != _hlEditor) {
            _editTextUndoRedoHelper.setTextView(_hlEditor);
        }
        super.onResume();
    }

    @Override
    public void onPause() {
        saveDocument(false); // auto-save
        net.gsantner.markor.sync.LockClient.get().close();   // 批次4：保存/离开后注销文件锁
        if (_webView != null) {
            _webView.onPause();
            _appSettings.setLastViewScrollY(_document.path, _webView.getScrollY());
            _appSettings.setLastViewHeight(_document.path, _webView.getHeight());
        }
        _appSettings.addRecentFile(_document.file);
        _appSettings.setDocumentPreviewState(_document.path, _isPreviewVisible);
        _appSettings.setLastEditPosition(_document.path, TextViewUtils.getSelection(_hlEditor)[0]);
        _appSettings.setLastEditScrollY(_document.path, _verticalScrollView.getScrollY());
        _appSettings.setLastEditHeight(_document.path, _verticalScrollView.getHeight());
        if (_document.path.equals(_appSettings.getTodoFile().getAbsolutePath())) {
            TodoWidgetProvider.updateTodoWidgets();
        }
        super.onPause();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putSerializable(SAVESTATE_DOCUMENT, _document);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.document__edit__menu, menu);
        _cu.tintMenuItems(menu, true, _cu.rcolor(getContext(), R.color.dark__primary_text));
        _cu.setSubMenuIconsVisibility(menu, true);

        final boolean isExperimentalFeaturesEnabled = _appSettings.isExperimentalFeaturesEnabled();
        final boolean isText = !_document.isBinaryFileNoTextLoading();

        menu.findItem(R.id.action_undo).setVisible(isText && _appSettings.isEditorHistoryEnabled());
        menu.findItem(R.id.action_redo).setVisible(isText && _appSettings.isEditorHistoryEnabled());
        menu.findItem(R.id.action_send_debug_log).setVisible(MainActivity.IS_DEBUG_ENABLED && !isDisplayedAtMainActivity() && !_isPreviewVisible);

        // Undo / Redo / Save (keep visible, but deactivated and tinted grey if not executable)
        _undoMenuItem = menu.findItem(R.id.action_undo).setVisible(isText && !_isPreviewVisible);
        _redoMenuItem = menu.findItem(R.id.action_redo).setVisible(isText && !_isPreviewVisible);
        _saveMenuItem = menu.findItem(R.id.action_save).setVisible(isText && !_isPreviewVisible);

        // Edit / Preview switch
        menu.findItem(R.id.action_edit).setVisible(isText && _isPreviewVisible);
        menu.findItem(R.id.action_preview).setVisible(isText && !_isPreviewVisible);
        final MenuItem searchMenuItem = menu.findItem(R.id.action_search);
        searchMenuItem.setVisible(isText && !_isPreviewVisible);
        if (_format != null && _format.getActions().isSearchActive()) {
            searchMenuItem.setTitle(R.string.close);
            _cu.tintDrawable(searchMenuItem.getIcon(), _cu.rcolor(getContext(), R.color.accent));
        }
        menu.findItem(R.id.action_search_view).setVisible(isText && _isPreviewVisible);
        menu.findItem(R.id.submenu_format_selection).setVisible(isText && !_isPreviewVisible);
        menu.findItem(R.id.submenu_share).setVisible(isText);
        menu.findItem(R.id.submenu_tools).setVisible(isText);
        menu.findItem(R.id.submenu_per_file_settings).setVisible(isText);

        menu.findItem(R.id.action_share_pdf).setVisible(true);
        menu.findItem(R.id.action_share_image).setVisible(true);
        menu.findItem(R.id.action_load_epub).setVisible(isExperimentalFeaturesEnabled);

        // Setup SearchView for view-mode
        setupSearchView((SearchView) menu.findItem(R.id.action_search_view).getActionView());

        // Set various initial states
        updateMenuToggleStates(_document.getFormat());
        checkTextChangeState();
        updateUndoRedoIconStates();
    }

    public void showMoreOptionsMenu() {
        FragmentActivity fragmentActivity = getActivity();
        if (fragmentActivity != null) {
            fragmentActivity.openOptionsMenu();
        }
    }

    /**
     * Receive key press from DocumentEditAndViewFragment.
     * But it cannot receive some key events (e.g. Ctrl, Enter, Directional Pad Up/Down/Left/Right, ...)
     *
     * @param keyCode the key code from DocumentEditAndViewFragment
     * @param event   the key event from DocumentEditAndViewFragment
     * @return {@code false} if the key press event was not be handled, {@code true} if it was consumed here.
     */
    @Override
    public boolean onReceiveKeyPress(int keyCode, KeyEvent event) {
        if (_format != null && _format.getActions().onKeyPress(this, keyCode, event, this)) {
            return true;
        }
        return super.onReceiveKeyPress(keyCode, event);
    }

    /**
     * Receive key press from HighlightingEditor.
     * It can receive the key events (e.g. Ctrl, Enter, Directional Pad Up/Down/Left/Right, ...)
     * that cannot be received from DocumentEditAndViewFragment.
     *
     * @param keyCode the key code from HighlightingEditor
     * @param event   the key event from HighlightingEditor
     * @return {@code false} if the key press event was not be handled, {@code true} if it was consumed here.
     */
    private boolean onEditorKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            return _format != null && _format.getActions().onKeyPress(_hlEditor, keyCode, event, this);
        }
        return false;
    }

    /**
     * Receive key press from WebView.
     * To solve the problem that cannot capture key events when the listened object lost the focus,
     * and the WebView get focus in view-mode.
     *
     * @param keyCode the key code from WebView
     * @param event   the key event from WebView
     * @return {@code false} if the key press event was not be handled, {@code true} if it was consumed here.
     */
    private boolean onWebViewKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            return _format != null && _format.getActions().onKeyPress(_webView, keyCode, event, this);
        }
        return false;
    }

    private void updateUndoRedoIconStates() {
        Drawable d;
        final boolean canUndo = _editTextUndoRedoHelper != null && _editTextUndoRedoHelper.getCanUndo();
        if (_undoMenuItem != null && _undoMenuItem.isEnabled() != canUndo && (d = _undoMenuItem.setEnabled(canUndo).getIcon()) != null) {
            d.mutate().setAlpha(canUndo ? 255 : 40);
        }

        final boolean canRedo = _editTextUndoRedoHelper != null && _editTextUndoRedoHelper.getCanRedo();
        if (_redoMenuItem != null && _redoMenuItem.isEnabled() != canRedo && (d = _redoMenuItem.setEnabled(canRedo).getIcon()) != null) {
            d.mutate().setAlpha(canRedo ? 255 : 40);
        }
    }

    public boolean loadDocument() {
        if (isSdStatusBad() || isStateBad()) {
            errorClipText();
            return false;
        }

        // Only trigger the load process if constructing or file updated or force reload
        if (_document.hasFileChangedSinceLastLoad()) {

            String loaded = _document.loadContent(getContext());
            if (loaded == null) {
                errorClipText();
                return false;
            }

            // Markdown 一次性全文整理（补表格分隔行、闭合围栏等），幂等、宁少勿错
            if (_format != null && _format.getFormatId() == FormatRegistry.FORMAT_MARKDOWN) {
                loaded = MarkdownAutoFormat.organize(loaded);
            }
            final String content = loaded;

            if (!_document.isContentSame(_hlEditor.getText())) {
                _hlEditor.withAutoFormatDisabled(() -> _hlEditor.setTextKeepState(content));
            }

            checkTextChangeState();

            if (_isPreviewVisible) {
                updateViewModeText();
            }

            return true;
        }
        return false;
    }

    public void undo() {
        if (_editTextUndoRedoHelper != null && _editTextUndoRedoHelper.getCanUndo()) {
            _hlEditor.withAutoFormatDisabled(_editTextUndoRedoHelper::undo);
            updateUndoRedoIconStates();
        }
    }

    public void redo() {
        if (_editTextUndoRedoHelper != null && _editTextUndoRedoHelper.getCanRedo()) {
            _hlEditor.withAutoFormatDisabled(_editTextUndoRedoHelper::redo);
            updateUndoRedoIconStates();
        }
    }

    public void reload() {
        if (_document != null) {
            _document.resetChangeTracking(); // Force next load
            if (loadDocument()) {
                Toast.makeText(getActivity(), "✔", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Let the editor get focus or clear the webView focus.
     */
    public void focus() {
        if (isViewModeVisibility()) {
            if (_webView != null && _webView.isFocused()) {
                _webView.clearFocus();
                View view = getView();
                if (view != null) {
                    view.requestFocus();
                }
            }
        } else if (_hlEditor != null) {
            _hlEditor.requestFocus();
        }
    }

    public void print() {
        MenuItem menuItem = getFragmentMenu().findItem(R.id.action_share_pdf);
        if (menuItem != null) {
            onOptionsItemSelected(menuItem);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull final MenuItem item) {
        final Activity activity = getActivity();
        if (activity == null) {
            return true;
        }

        final int itemId = item.getItemId();
        switch (itemId) {
            case R.id.action_undo: {
                undo();
                return true;
            }
            case R.id.action_redo: {
                redo();
                return true;
            }
            case R.id.action_save: {
                saveDocument(true);
                return true;
            }
            case R.id.action_reload: {
                reload();
                return true;
            }
            case R.id.action_preview: {
                setViewModeVisibility(true);
                return true;
            }
            case R.id.action_edit: {
                setViewModeVisibility(false);
                return true;
            }
            case R.id.action_preview_edit_toggle: {
                togglePreview();
                return true;
            }
            case R.id.action_share_path: {
                _cu.shareText(getActivity(), _document.file.getAbsolutePath(), GsContextUtils.MIME_TEXT_PLAIN);
                return true;
            }
            case R.id.action_share_text: {
                if (saveDocument(false)) {
                    _cu.shareText(getActivity(), getTextString(), GsContextUtils.MIME_TEXT_PLAIN);
                }
                return true;
            }
            case R.id.action_share_file: {
                if (saveDocument(false)) {
                    _cu.shareStream(getActivity(), _document.file, GsContextUtils.MIME_TEXT_PLAIN);
                }
                return true;
            }
            case R.id.action_share_html:
            case R.id.action_share_html_source: {
                if (saveDocument(false)) {
                    TextConverterBase converter = FormatRegistry.getFormat(_document.getFormat(), activity, _document).getConverter();
                    _cu.shareText(getActivity(),
                            converter.convertMarkup(getTextString(), getActivity(), false, _lineNumbersView.isLineNumbersEnabled(), _document.file),
                            "text/" + (item.getItemId() == R.id.action_share_html ? "html" : "plain")
                    );
                }
                return true;
            }
            case R.id.action_share_calendar_event: {
                if (saveDocument(false)) {
                    if (!_cu.createCalendarAppointment(getActivity(), _document.title, getTextString(), null)) {
                        Toast.makeText(activity, R.string.no_calendar_app_is_installed, Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }
            case R.id.action_share_screenshot:
            case R.id.action_share_image:
            case R.id.action_share_pdf: {
                _appSettings.getSetWebViewFulldrawing(true);
                if (saveDocument(false)) {
                    _nextConvertToPrintMode = true;
                    setViewModeVisibility(true);
                    Toast.makeText(activity, R.string.please_wait, Toast.LENGTH_LONG).show();
                    if (_webView != null) {
                        _webView.postDelayed(() -> {
                            if (itemId == R.id.action_share_pdf) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                                    _cu.printOrCreatePdfFromWebview(_webView, _document, getTextString().contains("beamer\n"));
                                }
                            } else {
                                Bitmap bmp = _cu.getBitmapFromWebView(_webView, itemId == R.id.action_share_image);
                                _cu.shareImage(getContext(), bmp, null);
                            }
                        }, 7000);
                    }
                }

                return true;
            }
            case R.string.action_format_auto: {
                // "自动"格式：清除手动覆盖，按扩展名识别并立即生效
                _appSettings.setDocumentFormat(_document.path, FormatRegistry.FORMAT_UNKNOWN);
                applyTextFormat(FormatRegistry.detectFormat(_document.file));
                return true;
            }
            case R.string.action_format_wikitext:
            case R.string.action_format_keyvalue:
            case R.string.action_format_todotxt:
            case R.string.action_format_csv:
            case R.string.action_format_plaintext:
            case R.string.action_format_asciidoc:
            case R.string.action_format_orgmode:
            case R.string.action_format_embedbinary:
            case R.string.action_format_markdown: {
                // 手动指定格式：立即对该文档生效
                _document.setFormat(itemId);
                applyTextFormat(itemId);
                _appSettings.setDocumentFormat(_document.path, _document.getFormat());
                return true;
            }
            case R.id.action_search: {
                setViewModeVisibility(false);
                _format.getActions().onSearch();
                return true;
            }
            case R.id.action_send_debug_log: {
                final String text = AppSettings.getDebugLog() + "\n\n------------------------\n\n\n\n" + Document.getMaskedContent(getTextString());
                _cu.draftEmail(getActivity(), "Debug Log " + getString(R.string.app_name_real), text, "debug@localhost.lan");
                return true;
            }
            case R.id.action_load_epub: {
                MarkorFileBrowserFactory.showFileDialog(new GsFileBrowserOptions.SelectionListenerAdapter() {
                                                            @Override
                                                            public void onFsViewerSelected(String request, File file, final Integer lineNumber) {
                                                                _hlEditor.setText(GsCoolExperimentalStuff.convertEpubToText(file, getString(R.string.page)));
                                                            }

                                                            @Override
                                                            public void onFsViewerConfig(GsFileBrowserOptions.Options dopt) {
                                                                dopt.titleText = R.string.select;
                                                            }
                                                        }, getParentFragmentManager(), activity,
                        (context, file) -> file != null && file.getAbsolutePath().toLowerCase().endsWith(".epub")
                );
                return true;
            }
            case R.id.action_speed_read: {
                GsCoolExperimentalStuff.showSpeedReadDialog(activity, getTextString());
                return true;
            }
            case R.id.action_wrap_words: {
                final boolean newState = !isWrapped();
                _appSettings.setDocumentWrapState(_document.path, newState);
                setWrapState(newState);
                if (_isPreviewVisible && _webView != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    _webView.evaluateJavascript("setWrapWords('" + newState + "');", null);
                }
                updateMenuToggleStates(0);
                return true;
            }
            case R.id.action_line_numbers: {
                final boolean newState = !_lineNumbersView.isLineNumbersEnabled();
                _appSettings.setDocumentLineNumbersEnabled(_document.path, newState);
                _lineNumbersView.setLineNumbersEnabled(newState);
                if (_isPreviewVisible && _webView != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    _webView.evaluateJavascript("setLineNumbers('" + newState + "');", null);
                }
                updateMenuToggleStates(0);
                return true;
            }
            case R.id.action_enable_highlighting: {
                final boolean newState = !_hlEditor.getHighlightingEnabled();
                _hlEditor.setHighlightingEnabled(newState);
                if (_lineNumbersView.isLineNumbersEnabled()) {
                    // The line height may be changed, so need to refresh line numbers
                    final int delay = newState ? 1000 : 200;
                    _hlEditor.postDelayed(() -> _lineNumbersView.refresh(), delay);
                    _hlEditor.postDelayed(() -> _lineNumbersView.refresh(), delay + 1000);
                }
                _appSettings.setDocumentHighlightState(_document.path, newState);
                updateMenuToggleStates(0);
                return true;
            }
            case R.id.action_enable_auto_format: {
                final boolean newState = !_hlEditor.getAutoFormatEnabled();
                _hlEditor.setAutoFormatEnabled(newState);
                _appSettings.setDocumentAutoFormatEnabled(_document.path, newState);
                updateMenuToggleStates(0);
                return true;
            }
            case R.id.action_info: {
                if (saveDocument(false)) { // In order to have the correct info displayed
                    FileInfoDialog.show(_document.file, getParentFragmentManager());
                }
                return true;
            }
            case R.id.action_set_font_size: {
                final int current = _isPreviewVisible ? _appSettings.getDocumentViewFontSize(_document.path) : _appSettings.getDocumentFontSize(_document.path);
                MarkorDialogFactory.showFontSizeDialog(activity, current, (newSize) -> {
                    if (_isPreviewVisible) {
                        if (_webView != null) {
                            _webView.getSettings().setTextZoom((int) (newSize * VIEW_FONT_SCALE));
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && _lineNumbersView.isLineNumbersEnabled()) {
                                _webView.evaluateJavascript("refreshLineNumbers();", null);
                            }
                        }
                        _appSettings.setDocumentViewFontSize(_document.path, newSize);
                    } else {
                        _hlEditor.setTextSize(TypedValue.COMPLEX_UNIT_SP, (float) newSize);
                        _appSettings.setDocumentFontSize(_document.path, newSize);
                    }
                });
                return true;
            }
            case R.id.action_show_file_browser: {
                // Delay because I want menu to close before we open the file browser
                _hlEditor.postDelayed(() -> MainActivity.launch(activity, _document.file, false), 250);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

    public void checkTextChangeState() {
        final boolean isTextChanged = !_document.isContentSame(_hlEditor.getText());
        Drawable d;

        if (_saveMenuItem != null && _saveMenuItem.isEnabled() != isTextChanged && (d = _saveMenuItem.setEnabled(isTextChanged).getIcon()) != null) {
            d.mutate().setAlpha(isTextChanged ? 255 : 40);
        }
    }

    public boolean isUnsaved() {
        return _saveMenuItem != null && _saveMenuItem.isEnabled();
    }

    @Override
    public void applyTextFormat(final int textFormatId) {
        final Activity activity = getActivity();
        if (activity == null) {
            return;
        }
        _format = FormatRegistry.getFormat(textFormatId, activity, _document);
        _document.setFormat(_format.getFormatId());
        _hlEditor.setHighlighter(_format.getHighlighter());
        _hlEditor.setAutoFormatters(_format.getAutoFormatInputFilter(), _format.getAutoFormatTextWatcher());
        _hlEditor.setAutoFormatEnabled(_appSettings.getDocumentAutoFormatEnabled(_document.path));

        _format.getActions()
                .setDocument(_document)
                .setUiReferences(activity, _hlEditor, _webView)
                .initTextSearch(this)
                .recreateActionButtons(_textActionsBar, _isPreviewVisible ? ActionButtonBase.ActionItem.DisplayMode.VIEW : ActionButtonBase.ActionItem.DisplayMode.EDIT);
        updateMenuToggleStates(_format.getFormatId());
        setActionBarVisibility();

        // 选择/识别为 Markdown 时，对当前文本一次性整理（加载时 loadDocument 也会整理）
        if (_format.getFormatId() == FormatRegistry.FORMAT_MARKDOWN) {
            final String text = _hlEditor.getText().toString();
            final String fixed = MarkdownAutoFormat.organize(text);
            if (!fixed.equals(text)) {
                _hlEditor.withAutoFormatDisabled(() -> _hlEditor.setTextKeepState(fixed));
            }
        }
        updateOutlineFabVisibility();
    }

    private void setActionBarVisibility() {
        final View view = getView();
        if (view == null) {
            return;
        }

        final View parent = view.findViewById(R.id.document__fragment__edit__text_actions_bar__scrolling_parent);
        if (parent == null) {
            return;
        }

        final View bar = view.findViewById(R.id.document__fragment__edit__text_actions_bar);
        if (bar != null && _verticalScrollView != null) {
            final boolean visible = _format.getActions().loadActionBarVisible() && _textActionsBar.getChildCount() > 0;
            parent.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * Setup SearchView from OptionsMenu for view-mode.
     *
     * @param searchView the SearchView form OptionsMenu
     */
    private void setupSearchView(SearchView searchView) {
        if (searchView == null) {
            return;
        }

        searchView.setQueryHint(getString(R.string.search));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            private Runnable searchTask;
            private String searchText = "";

            private boolean search(String text) {
                if (_webView == null) {
                    return false;
                }
                if (searchTask == null) {
                    searchTask = TextViewUtils.makeDebounced(_webView.getHandler(), 500, () -> _webView.findAllAsync(searchText));
                }

                searchText = text;
                searchTask.run();
                return true;
            }

            @Override
            public boolean onQueryTextSubmit(String query) {
                if (_webView != null) {
                    _webView.findNext(true);
                    return true;
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String text) {
                return search(text);
            }
        });
        if (searchView.getTag(R.id.action_search_view) == null) {
            searchView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override
                public void onViewAttachedToWindow(@NonNull View v) {
                }

                @Override
                public void onViewDetachedFromWindow(@NonNull View v) {
                    // Clear search when SearchView is closed abnormally, e.g. switch from QuickNote to To-Do when SearchView is opened
                    if (searchView.getQuery().length() > 0) {
                        searchView.setQuery("", false); // This will make onQueryTextChange be called back
                    }
                    if (!searchView.isIconified()) {
                        searchView.setIconified(true);
                    }
                }
            });
            searchView.setTag(R.id.action_search_view, Boolean.TRUE);
        }

        // Because SearchView doesn't provide a public API to add custom buttons
        // We must get the searchPlate (the layout containing the text field and close button) from SearchView
        // This approach is more robust than reflection
        ViewGroup searchPlate = searchView.findViewById(androidx.appcompat.R.id.search_plate);
        if (searchPlate == null) {
            // Ensure that SearchView is always available even if getting searchPlate fails
            searchView.setSubmitButtonEnabled(true);
            return;
        }

        final GsCallback.r0<ViewGroup.LayoutParams> makeLayoutParams = () -> {
            final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.gravity = Gravity.CENTER;
            return params;
        };

        Context searchViewContext = searchView.getContext();
        LinearLayout linearLayout = searchPlate.findViewWithTag("markor_search_nav_controls");
        TextView resultTextView;
        ImageButton previousButton;
        ImageButton nextButton;
        if (linearLayout == null) {
            linearLayout = new LinearLayout(searchViewContext);
            linearLayout.setTag("markor_search_nav_controls");
            linearLayout.setLayoutParams(makeLayoutParams.callback());

            // Add search result TextView
            resultTextView = new TextView(searchViewContext);
            resultTextView.setTag("markor_search_nav_result");
            LinearLayout.LayoutParams textViewLayoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
            );
            textViewLayoutParams.setMarginEnd(30);
            resultTextView.setLayoutParams(textViewLayoutParams);
            resultTextView.setGravity(Gravity.CENTER);
            resultTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            linearLayout.addView(resultTextView);

            // Add previous match Button
            previousButton = new ImageButton(searchViewContext);
            previousButton.setImageResource(R.drawable.ic_baseline_keyboard_arrow_up_24);
            previousButton.setLayoutParams(makeLayoutParams.callback());
            previousButton.setPadding(24, 24, 24, 24);
            TextViewUtils.setSelectableItemBackgroundBorderless(previousButton, searchViewContext);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                previousButton.setTooltipText(getString(R.string.previous_match));
            }
            linearLayout.addView(previousButton);

            // Add next match Button
            nextButton = new ImageButton(searchViewContext);
            nextButton.setImageResource(R.drawable.ic_baseline_keyboard_arrow_down_24);
            nextButton.setLayoutParams(makeLayoutParams.callback());
            nextButton.setPadding(24, 24, 24, 24);
            TextViewUtils.setSelectableItemBackgroundBorderless(nextButton, searchViewContext);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nextButton.setTooltipText(getString(R.string.next_match));
            }
            linearLayout.addView(nextButton);

            // Apply to SearchView
            searchPlate.addView(linearLayout, 1);
        } else {
            resultTextView = linearLayout.findViewWithTag("markor_search_nav_result");
            previousButton = (ImageButton) linearLayout.getChildAt(1);
            nextButton = (ImageButton) linearLayout.getChildAt(2);
        }
        _searchResultTextView = resultTextView;

        // Set listeners
        previousButton.setOnClickListener(v -> {
            if (_webView != null) {
                _webView.findNext(false);
            }
        });
        nextButton.setOnClickListener(v -> {
            if (_webView != null) {
                _webView.findNext(true);
            }
        });
        bindWebViewSearchListener();
    }

    private void bindWebViewSearchListener() {
        if (_webView == null || _searchResultTextView == null) {
            return;
        }
        _webView.setFindListener((activeMatchOrdinal, numberOfMatches, isDoneCounting) -> {
            if (isDoneCounting) {
                String searchResult = "";
                if (numberOfMatches > 0) {
                    searchResult = (activeMatchOrdinal + 1) + "/" + numberOfMatches;
                }
                _searchResultTextView.setText(searchResult);
            }
        });
    }

    /**
     * Show/close SearchView for view-mode.
     */
    public void toggleSearchView(boolean show) {
        SearchView searchView = (SearchView) getFragmentMenu().findItem(R.id.action_search_view).getActionView();
        if (searchView != null) {
            if (searchView.isIconified()) {
                if (show) {
                    searchView.setIconified(false);
                }
            } else {
                if (!show) {
                    searchView.setIconified(true);
                }
            }
        }
    }

    public boolean isSearchViewIconified() {
        SearchView searchView = (SearchView) getFragmentMenu().findItem(R.id.action_search_view).getActionView();
        if (searchView == null) {
            return true;
        } else {
            return searchView.isIconified();
        }
    }

    private void updateMenuToggleStates(final int selectedFormatActionId) {
        MenuItem mi;
        if ((mi = _fragmentMenu.findItem(R.id.action_wrap_words)) != null) {
            mi.setChecked(isWrapped());
        }
        if ((mi = _fragmentMenu.findItem(R.id.action_enable_highlighting)) != null) {
            mi.setChecked(_hlEditor.getHighlightingEnabled());
        }
        if ((mi = _fragmentMenu.findItem(R.id.action_line_numbers)) != null) {
            mi.setChecked(_lineNumbersView.isLineNumbersEnabled());
        }
        if ((mi = _fragmentMenu.findItem(R.id.action_enable_auto_format)) != null) {
            mi.setChecked(_hlEditor.getAutoFormatEnabled());
        }

        final SubMenu su;
        if (selectedFormatActionId != 0 && (mi = _fragmentMenu.findItem(R.id.submenu_format_selection)) != null && (su = mi.getSubMenu()) != null) {
            // 无手动格式覆盖时勾选"自动"，否则勾选指定格式（同组单选自动互斥）
            final boolean isAuto = _appSettings.getDocumentFormat(_document.path, FormatRegistry.FORMAT_UNKNOWN) == FormatRegistry.FORMAT_UNKNOWN;
            final int checkedFormatId = isAuto ? R.string.action_format_auto : selectedFormatActionId;
            for (int i = 0; i < su.size(); i++) {
                if ((mi = su.getItem(i)).getItemId() == checkedFormatId) {
                    mi.setChecked(true);
                    break;
                }
            }
        }
    }

    private boolean isWrapped() {
        return _horizontalScrollView == null || _hlEditor.getParent() != _horizontalScrollView;
    }

    private ViewGroup.LayoutParams makeLinearLayoutChildParams() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
    }

    private ViewGroup.LayoutParams makeScrollViewChildParams() {
        return new ScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void setWrapState(final boolean wrap) {
        _hlEditor.setHorizontallyScrolling(!wrap);
        final Context context = getContext();
        if (context != null && _hlEditor != null && isWrapped() != wrap) {

            _hlEditor.setAlpha(0);

            final int[] sel = TextViewUtils.getSelection(_hlEditor);
            final boolean hlEnabled = _hlEditor.setHighlightingEnabled(false);

            if (_horizontalScrollView == null) {
                _horizontalScrollView = new HorizontalScrollView(context);
                _horizontalScrollView.setFillViewport(true);
            }

            if (wrap) {
                _horizontalScrollView.removeView(_hlEditor);
                _editorHolder.removeView(_horizontalScrollView);
                _hlEditor.setLayoutParams(makeLinearLayoutChildParams());
                _editorHolder.addView(_hlEditor, 1);
            } else {
                _editorHolder.removeView(_hlEditor);
                _hlEditor.setLayoutParams(makeScrollViewChildParams());
                _horizontalScrollView.addView(_hlEditor);
                _horizontalScrollView.setLayoutParams(makeLinearLayoutChildParams());
                _editorHolder.addView(_horizontalScrollView, 1);
            }

            _hlEditor.requestLayout();

            _hlEditor.setHighlightingEnabled(hlEnabled);
            _hlEditor.post(() -> {
                TextViewUtils.setSelectionAndShow(_hlEditor, sel);
                _hlEditor.post(() -> _hlEditor.animate().alpha(1).setDuration(400).start());
            });
        }
    }

    @Override
    public String getFragmentTag() {
        return FRAGMENT_TAG;
    }

    public void errorClipText() {
        final String text = getTextString();
        if (!TextUtils.isEmpty(text)) {
            Context context = getContext();
            context = context == null ? ApplicationObject.get().getApplicationContext() : context;
            new MarkorContextUtils(context).setClipboard(getContext(), text);
        }
        // Always show error message
        Toast.makeText(getContext(), getString(R.string.error_could_not_open_file) + " " + getDocument().file, Toast.LENGTH_LONG).show();
        Log.i(DocumentEditAndViewFragment.class.getName(), "Triggering error text clipping");
    }

    public boolean isSdStatusBad() {
        if (_cu.isUnderStorageAccessFolder(getContext(), _document.file, false) &&
                _cu.getStorageAccessFrameworkTreeUri(getContext()) == null) {
            _cu.showMountSdDialog(getActivity());
            return true;
        }
        return false;
    }

    // Checks document state if things aren't in a good state
    public boolean isStateBad() {
        return (_document == null ||
                _hlEditor == null ||
                _appSettings == null ||
                !_cu.canWriteFile(getContext(), _document.file, false, true));
    }

    // Save the file; 写冲突不做客户端检查，由 Syncthing 的 .sync-conflict 文件兜底
    public boolean saveDocument(final boolean forceSaveEmpty) {
        final Activity activity = getActivity();
        if (activity == null || isSdStatusBad() || isStateBad()) {
            errorClipText();
            return false;
        }

        // Document is written iff writable && content has changed
        final CharSequence text = _hlEditor.getText();
        if (!_document.isContentSame(text)) {
            final int minLength = GsContextUtils.TEXT_FILE_OVERWRITE_MIN_TEXT_LENGTH;
            if (!forceSaveEmpty && text != null && text.length() < minLength) {
                final String message = activity.getString(R.string.wont_save_min_length, minLength);
                Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                return true;
            }
            if (_document.saveContent(getActivity(), text, _cu, forceSaveEmpty)) {
                checkTextChangeState();
                return true;
            } else {
                errorClipText();
                return false; // Failure only if saveContent somehow fails
            }
        } else {
            return true; // Report success if text not changed
        }
    }

    private boolean isDisplayedAtMainActivity() {
        return getActivity() instanceof MainActivity;
    }

    public void updateViewModeText() {
        if (_webView == null) {
            return;
        }
        // Don't let text to view mode crash app
        try {
            _format.getConverter().convertMarkupShowInWebView(_document, getTextString(), getActivity(), _webView, _nextConvertToPrintMode, _lineNumbersView.isLineNumbersEnabled());
        } catch (OutOfMemoryError e) {
            _format.getConverter().convertMarkupShowInWebView(_document, "updateViewModeText getTextString(): OutOfMemory  " + e, getActivity(), _webView, _nextConvertToPrintMode, _lineNumbersView.isLineNumbersEnabled());
        }
    }

    public void setViewModeVisibility(final boolean show) {
        setViewModeVisibility(show, true);
        if (!show) {
            _hlEditor.requestFocus();
        }
    }

    public void togglePreview() {
        setViewModeVisibility(!_isPreviewVisible);
    }

    public boolean isViewModeVisibility() {
        return _isPreviewVisible;
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    private void setupWebViewIfNeeded(final Activity activity) {
        if (_webView == null) {
            _webView = (WebView) _webViewStub.inflate();
            _webView.setWebChromeClient(new GsWebViewChromeClient(_webView, activity, activity.findViewById(R.id.document__fragment_fullscreen_overlay)));
            _webView.addJavascriptInterface(this, "Android");
            _webView.setBackgroundColor(Color.TRANSPARENT);
            WebSettings webSettings = _webView.getSettings();
            webSettings.setBuiltInZoomControls(true);
            webSettings.setDisplayZoomControls(false);
            webSettings.setTextZoom((int) (_appSettings.getDocumentViewFontSize(_document.path) * VIEW_FONT_SCALE));
            webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
            webSettings.setDatabaseEnabled(true);
            webSettings.setGeolocationEnabled(false);
            webSettings.setJavaScriptEnabled(true);
            webSettings.setDomStorageEnabled(true);
            webSettings.setAllowContentAccess(true);
            webSettings.setAllowFileAccess(true);
            webSettings.setAllowFileAccessFromFileURLs(false);
            webSettings.setAllowUniversalAccessFromFileURLs(false);
            webSettings.setMediaPlaybackRequiresUserGesture(false);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && BuildConfig.IS_TEST_BUILD && BuildConfig.DEBUG) {
                WebView.setWebContentsDebuggingEnabled(true); // Inspect on computer Chromium browser: chrome://inspect/#devices
            }

            _webViewClient = new MarkorWebViewClient(_webView, activity);
            _webView.setWebViewClient(_webViewClient);

            if (_webView instanceof DraggableScrollbarWebView) {
                ((DraggableScrollbarWebView) _webView).setOnDispatchKeyListener(this::onWebViewKeyDown);
            }

            // For showing and copying link address in view-mode
            _webView.setOnLongClickListener(v -> {
                WebView.HitTestResult hitResult = _webView.getHitTestResult();
                if (hitResult.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                    final String url = hitResult.getExtra();
                    if (url != null) {
                        Snackbar snackbar = Snackbar.make(_webView, url, Snackbar.LENGTH_LONG).setAction(getString(R.string.copy), view -> {
                            Context context = getContext();
                            _cu.setClipboard(context, url);
                            Toast.makeText(context, getString(R.string.link_copied), Toast.LENGTH_SHORT).show();
                        });
                        snackbar.setAnchorView(_textActionsBar);
                        snackbar.show();
                        return true;
                    }
                }
                return false;
            });
        }
        if (_format != null) {
            _format.getActions().setUiReferences(activity, _hlEditor, _webView);
        }
        bindWebViewSearchListener();
    }

    @SuppressLint({"AddJavascriptInterface", "SetJavaScriptEnabled"})
    public void setViewModeVisibility(boolean show, final boolean animate) {
        final Activity activity = getActivity();
        if (activity == null) {
            return;
        }

        if (show && _format != null) {
            _format.getActions().hideTextSearchUi();
        }

        show |= _document.isBinaryFileNoTextLoading();
        _format.getActions().recreateActionButtons(_textActionsBar, show ? ActionButtonBase.ActionItem.DisplayMode.VIEW : ActionButtonBase.ActionItem.DisplayMode.EDIT);
        if (show) {
            setupWebViewIfNeeded(activity);
            updateViewModeText();
            _cu.showSoftKeyboard(activity, false, _hlEditor);
            _hlEditor.clearFocus();
            _hlEditor.postDelayed(() -> _cu.showSoftKeyboard(activity, false, _hlEditor), 300);
            GsContextUtils.fadeInOut(_webView, _verticalScrollView, animate);
        } else {
            if (_webView != null) {
                _webViewClient.setRestoreScrollY(_webView.getScrollY());
            }
            GsContextUtils.fadeInOut(_verticalScrollView, _webView, animate);
        }

        _nextConvertToPrintMode = false;
        _isPreviewVisible = show;
        updateOutlineFabVisibility();

        setActionBarVisibility();
        ((AppCompatActivity) activity).supportInvalidateOptionsMenu();
    }

    // 批次5：大纲悬浮按钮仅在 Markdown 预览模式可见
    private void updateOutlineFabVisibility() {
        if (_outlineFab != null) {
            final boolean show = _isPreviewVisible
                    && _format != null
                    && _format.getFormatId() == FormatRegistry.FORMAT_MARKDOWN;
            _outlineFab.setVisibility(show ? View.VISIBLE : View.GONE);
        }
    }

    // Callback from view-mode/javascript
    @SuppressWarnings("unused")
    @JavascriptInterface
    public void webViewJavascriptCallback(final String[] jsArgs) {
        final String[] args = (jsArgs == null || jsArgs.length == 0 || jsArgs[0] == null) ? new String[0] : jsArgs;
        final String type = args.length == 0 || TextUtils.isEmpty(args[0]) ? "" : args[0];
        if (type.equalsIgnoreCase("toast") && args.length == 2) {
            Toast.makeText(getActivity(), args[1], Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onToolbarClicked(View v) {
        if (_format != null) {
            _format.getActions().runTitleClick();
        }
    }

    @Override
    protected boolean onToolbarLongClicked(View v) {
        if (isVisible() && isResumed()) {
            _format.getActions().runJumpBottomTopAction(_isPreviewVisible ? ActionButtonBase.ActionItem.DisplayMode.VIEW : ActionButtonBase.ActionItem.DisplayMode.EDIT);
            return true;
        }
        return false;
    }

    @Override
    public void onDestroyView() {
        net.gsantner.markor.sync.LockClient.get().close();   // 批次4：兜底注销文件锁
        if (_webView != null) {
            try {
                _webView.loadUrl("about:blank");
                _webView.destroy();
            } catch (Exception ignored) {
            }
        }
        _webView = null;
        _webViewClient = null;
        _searchResultTextView = null;
        if (_hlEditor != null) {
            _hlEditor.setScrollCallbacks(null, null);
        }
        if (_format != null) {
            _format.getActions().setUiReferences(getActivity(), _hlEditor, null);
        }
        super.onDestroyView();
    }

    public Document getDocument() {
        return _document;
    }

    public HighlightingEditor getEditor() {
        return _hlEditor;
    }

    public String getTextString() {
        final CharSequence text = _hlEditor != null ? _hlEditor.getText() : null;
        return text != null ? text.toString() : "";
    }
}
