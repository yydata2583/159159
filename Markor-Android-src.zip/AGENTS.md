# AGENTS.md — Markor Android（手机端）· AI 工作入口

> 项目知识库入口：**文档由 AI 维护**（用户提需求 → AI 写代码 → AI 更新文档与需求记录）。AI 读完本文件即可开工，不必重读全部源码。
> 服务器端知识库在同级 `server/AGENTS.md`；PC 端在 `Markor V2.17.0/AGENTS.md`（Qt/C++）。

## 0. 30 秒速览

| 项 | 值 |
|---|---|
| 项目 | Markor Android **定制分支**（基于 gsantner/markor，Apache 2.0），单模块 `:app` |
| 语言/构建 | Java + Gradle/AGP；productFlavors：`flavorDefault` / `flavorAtest` / `flavorGplay` |
| 同步 | **内置 Syncthing v2.1.6**（与 PC/NAS 三端版本一致，原生 `libsyncthing.so` 子进程），**仅应用前台运行** |
| 拓扑 | **星型**：只连同步服务器（NAS），与 PC 不互连；无中继/自动发现/引擎自升级 |
| 文件锁 | `LockClient`：对接服务器 lockserver（open/30s心跳/close），"已被其他设备打开"提示 |
| 服务器信息 | **一律默认空、不写死**；连接成功/失败均弹窗提示 |
| 同步根目录 | 笔记本目录（默认 `/storage/emulated/0/Markor`，与 PC/NAS 结构一致） |
| 三端结构 | `Markor/{QuickNote.md, To-Do.md, Journal/, Snippets/, file/}` |

## 1. 代码地图（改哪里找哪里）

| 位置 | 内容 |
|---|---|
| `sync/SyncManager.java` | 内置同步：引擎启停、REST 配置（星型）、连接探测弹窗、仅前台生命周期；`getGuiUrl()`/`restartEngine()`（GUI 联动） |
| `sync/SyncWebGuiActivity.java` | 同步管理页：应用内 WebView 打开 Web GUI；拦截 `/rest/system/restart|shutdown` 由应用代为执行 |
| `sync/LockClient.java` | 文件锁客户端（open/heartbeat/close、占用提示回调） |
| `activity/MarkorBaseActivity.java` | Activity 基类；`onCreate` 挂接 `SyncManager.get().attach(this)` |
| `activity/SettingsActivity.java` | 设置页；`pref_key__sync_*` 变更 → 重应用同步配置；`pref_key__sync_open_gui` 点击 → 打开同步管理页 |
| `activity/DocumentEditAndViewFragment.java` | 编辑/预览；`onResume` 登记文件锁、`onPause/onDestroyView` 注销；大纲原生 FAB（`updateOutlineFabVisibility()`） |
| `format/OutlineInjector.java` | 预览大纲抽屉（JS/CSS 注入 WebView）；"大纲滚动→正文跟随"（`follow()`）；开关经 `window.__mkOutlineToggle` 供原生 FAB 调用 |
| `model/AppSettings.java` | 设置门面（`GsSharedPreferencesPropertyBackend`）；`isSyncEnabled/getSyncServer*` |
| `res/xml/preferences_master.xml` | 设置界面结构（同步 PreferenceCategory） |
| `res/values/string-not_translatable.xml` | **pref key 定义处**（translatable=false） |
| `res/values/strings.xml` + `values-zh-rCN/strings.xml` | UI 文案（英文+简中成对） |
| `web/`、`format/markdown/MarkdownTextConverter.java` | 预览 WebView 与渲染管线 |

## 2. 同步机制（本分支核心）

```
前台(任一 Activity onStart) → SyncManager.startIfEnabled()
  → 引擎缺失(libsyncthing.so) → 停用 + 弹窗提示（不崩溃）
  → serve --home=<filesDir>/syncthing --gui-address=127.0.0.1:8385 --gui-apikey=<随机>
  → 轮询 rest/system/status 取 myID → applyConfig():
      devices: 仅服务器设备（不设 introducer）；addresses=[服务器同步地址]
      folders: markor-vault = 笔记本目录（每次取当前设置）
      options: relaysEnabled/globalAnnounce/localAnnounce=false，autoUpgradeIntervalH=0
      gui: 127.0.0.1:8385, tls=false
  → 轮询 rest/system/connections 看服务器 connected → 弹窗成功/失败
全部 Activity onStop(退后台) → stop()
```

锁协议（服务器 README §五）：`POST /api/v1/open|heartbeat|close`，Bearer API Key，
`{device_id, device_name, vault_id:"markor-vault", path:<笔记本内相对路径>}`，
返回 `holders`=其他设备占用者 → 弹"该文件已被其他设备打开"。服务器地址/API Key 空则静默禁用。

## 3. 红线（Do / Don't）

- **等用户通知才编译/构建**（需求随时变化）。只做代码修改 + 人工自查。
- **服务器信息不写死**：默认空串，禁止具体 IP/域名/端口/密钥常量（127.0.0.1 除外）。
- **星型不可破坏**：设备表只有服务器、introducer 不设、发现/中继关、引擎 `autoUpgradeIntervalH=0`。
- **同步只在前台**：Activity 计数，退后台必须停引擎。
- **连接结果必须弹窗**（成功/失败/信息不全）。
- **UI 文案双语成对**；pref key 放 `string-not_translatable.xml`。
- 不引入第三方依赖（HTTP 用 HttpURLConnection、JSON 用 org.json）。
- Java 8 语法、4 空格、沿用 Gs* 基类与 AppSettings 门面风格。

## 4. 构建（未通知不要执行）

`./gradlew assembleFlavorDefaultRelease`（需 Android SDK）。
⚠️ 内置同步运行期需要 `app/src/main/jniLibs/<abi>/libsyncthing.so`
（syncthing 安卓二进制，交叉编译或取自 Syncthing-Fork；MPL-2.0 许可需随附声明）。
缺失时同步自动停用并提示，不影响其他功能。

## 5. 维护协议

代码动了文档跟着动（本文件 §1/§5 与服务器 `README-server.md`）；决策写 ADR
（PC `docs/decisions.md` 或本文件 §6 追加）；不确定标 ⚠️ 待核对，宁少勿错。

## 6. 变更日志（供 AI 续写）

- 2026-10 批次3：预览大纲抽屉面板（OutlineInjector）。
- 2026-10 批次4：内置同步（仅前台）+ LockClient + 设置页同步项 + 大纲滚动跟随；
  同步引擎查找兼容 `bin\` 布局（PC"路径错位"同源问题）；审计确认无应用更新功能。
- 2026-10 批次5（2026-10-17）：
  - **大纲入口按钮原生化**：注入 DOM 的 `position:fixed` 悬浮按钮在 WebView 捏合缩放后会
    相对布局视口定位、随内容滚动跑出屏幕。改为原生 `ImageButton`
    （`document__fragment__edit.xml` 的 `document__fragment__view__outline_fab`，
    背景 `drawable/outline_fab_background.xml` 主题自适应圆形底板，图标 `ic_list_black_24dp`
    着色 `primary_text`），点击调 `window.__mkOutlineToggle()`（OutlineInjector 暴露）；
    仅 Markdown 预览可见（`DocumentEditAndViewFragment.updateOutlineFabVisibility()`，
    在 `setViewModeVisibility`/`applyTextFormat` 末尾刷新）。注入面板 DOM/CSS 中的按钮已移除，
    面板 header 56px padding 保留给原生 FAB 让位。
  - **同步管理页（应用内打开 Web GUI）**：设置→同步 新增"同步管理"入口
    （`pref_key__sync_open_gui`）→ `sync/SyncWebGuiActivity`（布局 `sync_webgui_activity.xml`）
    以应用内 WebView 打开 `http://127.0.0.1:8385`（参考 syncthing-android 做法，不用外部浏览器）。
    引擎未就绪时轮询等待（1s×30 上限）再 loadUrl；未启用同步/服务器信息空缺时弹提示并退出；
    外链一律 `ACTION_VIEW` 交外部浏览器。
  - **GUI 重启/关闭与应用联动**：引擎以 `serve` 模式运行（无 monitor 进程），GUI 原生重启会
    退死进程。WebViewClient `shouldInterceptRequest`（String 旧签名，全 API 生效且能拦 POST）
    拦截 `/rest/system/restart`→`SyncManager.restartEngine()`（销毁进程重新拉起），
    `/rest/system/shutdown`→`stop()`+提示+退出页面；两者返回合成 200 空 JSON 使 GUI 正常走流程。
    配套改动：`launch()` 的 apiKey 改为幂等生成（仅空时新建），`stop()` 清空——引擎内重启保持
    原 key，已打开的 GUI 页面按原 key 轮询即可自动恢复。
  - 已知行为：GUI 内"关闭"后返回设置页会按"仅前台运行"策略再次拉起引擎（符合产品策略，
    不是 bug）。注意 `values/strings.xml` 中批次4 同步文案为中文（历史遗留），新增文案已按
    红线双语成对（en 默认 + zh-rCN）。
  - **本机首次编译记录（2026-10-17，BUILD SUCCESSFUL）**：
    1. 构建脚本 `build.gradle` 在配置期执行 `git rev-parse HEAD`/`git log`（getGitHash 等），
       本目录非 git 仓库会直接构建失败（exit 128）。处理：本地 `git init` + 一次空提交
       （`git -c user.name=… -c user.email=… commit --allow-empty`）即可，不动源码；后续构建沿用。
    2. 直连 `dl.google.com`（google()/maven.google.com）在本机 SYN 无响应会让依赖解析挂死；
       已将 buildscript/allprojects 两处直连 Google 源注释掉，Google Maven 工件由
       `maven.aliyun.com/repository/google` 完整代理（jitpack/mavenCentral 直连正常）。
    3. PowerShell 调 gradlew 不要传 `-Dprop=value`（会被拆词误识别为任务名）；限 CPU 用
       `.\gradlew.bat assembleFlavorDefaultRelease --max-workers=2 --console=plain`。
    4. 产物：`app/build/outputs/apk/flavorDefault/release/net.gsantner.markor-v*-flavorDefault-release.apk`
       （**已配置正式签名，见第 5 点**；配置签名前产物带 `-unsigned` 后缀。另有 Java 8
       source/target 过时警告、flexmark 缺 javax.swing 类的 R8 警告，均不影响构建）。
  - **release 签名配置（2026-10-17）**：密钥库为工作区根目录
    `c:\Users\Administrator\Desktop\Markor\apk-signing.jks`（PKCS12、RSA4096、alias=`mimo`、
    CN=MiMo；口令见同级 `KEYS-README.txt`，与 exe 签名 pfx 相互独立勿混用）。
    凭据放 `markor-android/keystore.properties`（storeFile=`../apk-signing.jks`，已加
    `.gitignore`，不入库）；`app/build.gradle` 读该文件生成 `signingConfigs.release` 并挂到
    `buildTypes.release`（文件缺失时退化为 null，不影响他人无库构建）。AGP 输出文件名随之变为
    `...-release.apk`；apksigner 验证 **v1+v2+v3 全部 true**（signingConfig 显式
    `enableV1Signing/enableV2Signing/enableV3Signing true`——用户要求三个签名方案全开：
    v1 覆盖 minSdk 18 老机型、v2 覆盖 Android 7+、v3 覆盖 Android 9+ 密钥轮换绑定；
    v3.1/v3.2/v4 为 false 属正常未启用），证书 SHA-256 `4c438ba3…0edf45`。
  - **发布部署约定**：签名产物复制为 `Markor-2.17.0.apk`（跟随 versionName 命名），
    同时放两个目录（与 PC 安装包一致）：①工作区根目录 `c:\Users\Administrator\Desktop\Markor\`
    ②`D:\synchronize\`，覆盖旧版并保证三处 SHA-256 一致；删除根目录旧的
    `Markor-2.17.0.apk.idsig`（apksigner 增量安装缓存，对应旧包，新包无此文件）。
  - **踩坑：后台运行的 gradlew 被终止会写坏中间产物**。一次后台构建在
    R8（`minifyFlavorDefaultReleaseWithR8`）阶段被杀，
    `app/build/intermediates/legacy_multidex_aapt_derived_proguard_rules/flavorDefaultRelease/processFlavorDefaultReleaseResources/manifest_keep.txt`
    被写成 129 字节全 0x00，重跑 R8 报 `Compilation failed to complete, position: offset 0,
    line 1, column 1`。删掉 `legacy_multidex_aapt_derived_proguard_rules` 目录增量重建即恢复；
    长构建优先前台执行。
