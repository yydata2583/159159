# 架构说明（architecture.md）— Markor Android

> 覆盖：App 整体架构、预览渲染管线、大纲面板、同步/锁子系统、生命周期、定制点与原生差异。

## 1. 整体结构（gsantner/markor 定制分支）

```
ApplicationObject (MultiDexApplication, 单例容器)
└─ MarkorBaseActivity（所有 Activity 基类；onCreate 挂接 SyncManager 生命周期）
   ├─ MainActivity          主界面（文件浏览/入口）
   ├─ DocumentActivity      文档容器（编辑/预览 Fragment）
   ├─ SettingsActivity      设置（PreferenceFragment，preferences_master.xml）
   ├─ MoreFragment / MoreInfoFragment   更多/关于
   └─ …（IntroActivity、ShareInto、Widget 等原生组件）
核心层：
   model/    AppSettings（设置门面）· Document（文档模型）
   format/   FormatRegistry + 各格式 ActionButtons/Highlighter/Converter
             OutlineInjector（预览大纲面板，定制）
   sync/     SyncManager（内置 Syncthing）· LockClient（文件锁）（均为定制新增）
   web/      MarkorWebViewClient · DraggableScrollbarWebView（预览 WebView）
   frontend/ 对话框/文件浏览器/搜索 等 UI 组件
   opoc/     作者通用工具库（Gs* 前缀，勿随意改）
```

## 2. 预览渲染管线

```
编辑态 _hlEditor（语法高亮编辑器）
  └─ DocumentEditAndViewFragment.saveDocument / loadDocument
预览态 _webView（WebView）
  └─ format/*/XxxTextConverter.convertMarkupShowInWebView
       · Markdown：MarkdownTextConverter → HTML（含 Mermaid/公式/表格渲染）
       · 注入 OutlineInjector.head()（CSS+JS）+ initCall()（onload 初始化）
       · 记录/恢复滚动位置（setLastViewScrollY）
```
- 预览每次加载是**全新 JS 上下文**：大纲面板与标题树随之重建、默认收起（不残留旧文档数据）。
- 大纲面板（批次3）：JS 动态构建 DOM（`mkoutline-` 前缀，z-index 置顶、与正文隔离），
  从渲染 DOM 提取 H1–H4（排除 Markor 自动 TOC 与面板自身）。

## 3. 大纲交互（批次3 + 批次4）

| 行为 | 实现 |
|---|---|
| 点击条目 | `jump(idx)`：平滑滚动到标题 → **自动收起面板** |
| **滚动大纲列表** | `followFromList()`（rAF 节流）→ 找列表视口顶部最近条目 → `follow(idx)`：高亮 + 正文平滑滚动到该标题，**不收起面板** |
| 正文滚动 | `spy()`（ScrollSpy，rAF 节流）：只更新高亮，**不滚动大纲列表**（防回环，见文件内注释） |
| 文档高度变化 | `refresh()` 重建偏移缓存（图片/Mermaid 异步渲染后） |

## 4. 同步子系统（sync/SyncManager.java）

**仅前台运行**：ActivityLifecycleCallbacks 计数（onActivityStarted/onActivityStopped），
全部 Activity 离开前台（计数归零）→ `stop()` 销毁引擎进程。

```
startIfEnabled():
  服务器信息不完整（设备ID/同步地址为空）→ 弹窗提示，不起引擎
  引擎缺失(nativeLibraryDir/libsyncthing.so) → 弹窗提示，停用（不崩溃）
  启动: serve --home=<filesDir>/syncthing --gui-address=127.0.0.1:8385
        --gui-apikey=<随机UUID> --no-browser --no-console --log-file=…
  轮询 rest/system/status（1.5s×40）拿 myID → applyConfig()（幂等，设置变更可重跑）:
    devices: 仅服务器设备（不设 introducer）；addresses=[服务器同步地址]
    folders: markor-vault = 笔记本目录（每次取当前设置 + mkdirs）
    options: relaysEnabled/globalAnnounce/localAnnounce=false、autoUpgradeIntervalH=0
    gui: 127.0.0.1:8385、tls=false、apiKey
  → checkServerConnection()：rest/system/connections 轮询（3s×10）
    服务器 connected → 弹"已连接到同步服务器"；超时/失败/信息不全 → 弹警告
```

## 5. 文件锁（sync/LockClient.java）

```
onResume → LockClient.open(笔记本相对路径) + 30s 心跳
onPause / onDestroyView → close()
POST <服务器地址>/api/v1/open|heartbeat|close，Header: Bearer <API Key>
返回 holders（其他设备占用者）→ Toast "该文件已被其他设备打开：…"
服务器地址或 API Key 为空 → 静默禁用（不发请求）
```
锁只是提示；写冲突仍由 Syncthing `.sync-conflict-*` 兜底。

## 6. 生命周期与关键约束

- **同步只在前台**：后台即停（产品要求）；无前台服务/常驻通知。
- **弹窗只在有前台 Activity 时弹**（WeakReference<Activity>，防泄漏）。
- 设置变更（`pref_key__sync_*`）→ `startIfEnabled()` 重应用配置并重探测连接。
- 预览 HTML 注入内容每次重建，任何"跨次加载"状态都不可靠（设计如此）。

## 7. 已知限制 / 待办

- ⚠️ `libsyncthing.so` 不在仓库内（二进制分发），部署时需自行放入 jniLibs；
- AsciiDoc/Org/Wiki 等格式走各自 Converter（原生能力），未做深度定制；
- 锁提示为 Toast（非弹窗），如需强交互可升级为 AlertDialog（新 ADR）。
