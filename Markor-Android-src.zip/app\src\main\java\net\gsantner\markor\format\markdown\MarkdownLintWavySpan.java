/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 *#########################################################*/
package net.gsantner.markor.format.markdown;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.text.style.LineBackgroundSpan;

/**
 * Markdown lint 专用的红色波浪下划线 Span（Android 无公开波浪 CharacterStyle，自绘实现）。
 * 仅负责绘制，不影响排版（不实现 UpdateLayout），可作为动态 span 随视口增删。
 */
public class MarkdownLintWavySpan implements LineBackgroundSpan {

    // 深红色，alpha 约 0.9
    private static final int WAVE_COLOR = 0xE6FF3B30;

    private final Paint _paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int _start;
    private final int _end;
    private final float _wavelength;   // 波长，约 6dp
    private final float _amplitude;    // 振幅，约 1.5dp
    private final float _offsetBelowBaseline; // 波中线距 baseline，约 4dp

    public MarkdownLintWavySpan(final int start, final int end, final float density) {
        _start = start;
        _end = end;
        _wavelength = 6f * density;
        _amplitude = 1.5f * density;
        _offsetBelowBaseline = 4f * density;
        _paint.setStyle(Paint.Style.STROKE);
        _paint.setStrokeWidth(Math.max(1f, density)); // 线宽 1dp
        _paint.setColor(WAVE_COLOR);
    }

    @Override
    public void drawBackground(final Canvas canvas, final Paint paint, final int left, final int right,
                               final int top, final int baseline, final int bottom,
                               final CharSequence text, final int lineStart, final int lineEnd,
                               final int lineNumber) {
        // LineBackgroundSpan 按整行回调，这里裁剪到本 span 与该行的重叠区间
        final int s = Math.max(_start, lineStart);
        final int e = Math.min(_end, lineEnd);
        if (s >= e) {
            return;
        }

        // 用行首到区间两端的文字测量宽度，定位问题字符的实际 x 范围
        final float x0 = left + paint.measureText(text, lineStart, s);
        final float x1 = left + paint.measureText(text, lineStart, e);
        final float centerY = baseline + _offsetBelowBaseline;

        // 沿中线画正弦波（每 1/6 波长采样一个点，抗锯齿下足够平滑）
        final Path path = new Path();
        path.moveTo(x0, centerY);
        final float step = _wavelength / 6f;
        float x = x0;
        while (x < x1) {
            x = Math.min(x + step, x1);
            final double angle = 2.0 * Math.PI * (x - x0) / _wavelength;
            final float y = centerY + (float) (_amplitude * Math.sin(angle));
            path.lineTo(x, y);
        }
        canvas.drawPath(path, _paint);
    }
}
