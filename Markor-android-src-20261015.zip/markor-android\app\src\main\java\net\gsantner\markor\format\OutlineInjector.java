/*#######################################################
 *
 *   License of this file: Apache 2.0
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
#########################################################*/
package net.gsantner.markor.format;

import android.content.Context;

import net.gsantner.markor.R;
import net.gsantner.opoc.util.GsContextUtils;

/**
 * 批次3：预览窗口文档大纲面板（仅 Markdown 预览注入）。
 * <p>
 * 自包含的注入片段，不依赖任何外部 JS/CSS 资源：
 * <ul>
 * <li>{@link #head()}：放入 HTML &lt;head&gt; 的样式与脚本，定义 {@code mkOutlineInit(dark,title,empty)}。
 *     面板 DOM 由 JS 在初始化时动态创建并挂到 body 末尾，与正文隔离、z-index 置顶。</li>
 * <li>{@link #initCall(Context, boolean)}：放入 body onload 回调中执行的初始化调用，
 *     深色标志与文案由 Java 按当前夜间模式与 locale 传入。</li>
 * </ul>
 * 预览每次重新加载 HTML 都是全新的 JS 上下文，面板与标题树随之重建、默认收起，不残留旧文档数据。
 */
public final class OutlineInjector {

    // 左侧抽屉式大纲面板：悬浮按钮 + 半透明遮罩 + 滑出面板，全部 mkoutline- 前缀避免冲突
    private static final String CSS = ""
            + "<style type='text/css'>"
            + ".mkoutline{position:fixed;z-index:99997;top:0;left:0;right:0;bottom:0;pointer-events:none;font-family:sans-serif;-webkit-user-select:none;user-select:none;}"
            + ".mkoutline__scrim{position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.32);opacity:0;transition:opacity .22s;pointer-events:none;}"
            + ".mkoutline.is-open .mkoutline__scrim{opacity:1;pointer-events:auto;}"
            + ".mkoutline__panel{position:absolute;top:0;bottom:0;left:0;box-sizing:border-box;width:75vw;max-width:280px;background:#ffffff;color:#222222;box-shadow:0 0 14px rgba(0,0,0,.28);transform:translateX(-103%);transition:transform .22s ease;display:flex;flex-direction:column;pointer-events:auto;}"
            + ".mkoutline.is-open .mkoutline__panel{transform:translateX(0);}"
            + ".mkoutline.is-rtl .mkoutline__panel{left:auto;right:0;transform:translateX(103%);}"
            + ".mkoutline.is-rtl.is-open .mkoutline__panel{transform:translateX(0);}"
            + ".mkoutline__header{flex:none;padding:12px 16px 12px 56px;font-size:16px;font-weight:bold;border-bottom:1px solid #dddddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}"
            + ".mkoutline.is-rtl .mkoutline__header{padding:12px 56px 12px 16px;}"
            + ".mkoutline__list{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;}"
            + ".mkoutline__item{padding:9px 12px 9px 14px;font-size:14px;line-height:1.35;border-left:3px solid transparent;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer;}"
            + ".mkoutline.is-rtl .mkoutline__item{border-left:none;border-right:3px solid transparent;}"
            + ".mkoutline__item.is-active{background:rgba(66,133,244,.18);border-left-color:#4285f4;color:#1967d2;}"
            + ".mkoutline.is-rtl .mkoutline__item.is-active{border-right-color:#4285f4;}"
            + ".mkoutline__empty{padding:20px 16px;font-size:14px;color:#999999;}"
            + ".mkoutline__fab{position:absolute;top:10px;left:10px;width:40px;height:40px;padding:0;border:none;border-radius:50%;background:#ffffff;color:#333333;font-size:19px;line-height:40px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.32);pointer-events:auto;cursor:pointer;z-index:3;}"
            + ".mkoutline.is-rtl .mkoutline__fab{left:auto;right:10px;}"
            + ".mkoutline--dark .mkoutline__panel{background:#373737;color:#eeeeee;border-color:#555555;}"
            + ".mkoutline--dark .mkoutline__header{border-bottom-color:#555555;}"
            + ".mkoutline--dark .mkoutline__fab{background:#4a4a4a;color:#eeeeee;}"
            + ".mkoutline--dark .mkoutline__empty{color:#aaaaaa;}"
            + ".mkoutline--dark .mkoutline__item.is-active{color:#8ab4f8;}"
            // 标题锚点滚动时预留一点顶部间距（对 TOC/脚注跳转同样友好）
            + "body h1,body h2,body h3,body h4{scroll-margin-top:12px;}"
            // 打印/导出 PDF 时不出现面板与按钮
            + "@media print{.mkoutline{display:none!important;}}"
            + "</style>";

    // 大纲面板脚本：标题树构建、平滑跳转后自动收起、rAF 节流的 ScrollSpy
    private static final String JS = ""
            + "<script>"
            + "window.mkOutlineInit=function(dark,titleText,emptyText){"
            + "if(window.__mkOutline){return;}window.__mkOutline=true;"
            + "var doc=document,win=window;"
            + "var rtl=!!(doc.body&&win.getComputedStyle(doc.body).direction==='rtl');"
            // ---- 构建面板 DOM（与正文隔离）----
            + "var root=doc.createElement('div');"
            + "root.className='mkoutline'+(dark?' mkoutline--dark':'')+(rtl?' is-rtl':'');"
            + "root.innerHTML='<div class=\"mkoutline__scrim\"></div>'"
            + "+'<aside class=\"mkoutline__panel\">'"
            + "+'<div class=\"mkoutline__header\"></div><nav class=\"mkoutline__list\"></nav></aside>'"
            + "+'<button type=\"button\" class=\"mkoutline__fab\">&#9776;</button>';"
            + "var scrim=root.querySelector('.mkoutline__scrim'),"
            + "panel=root.querySelector('.mkoutline__panel'),"
            + "fab=root.querySelector('.mkoutline__fab'),"
            + "header=root.querySelector('.mkoutline__header'),"
            + "list=root.querySelector('.mkoutline__list');"
            + "header.textContent=titleText;"
            + "fab.setAttribute('aria-label',titleText);"
            + "doc.body.appendChild(root);"
            // ---- 从渲染 DOM 提取 h1-h4（排除 Markor 自动 TOC 区块与面板自身）----
            + "var nodes=doc.body.querySelectorAll('h1,h2,h3,h4'),items=[],minLevel=4,i,h,t,lv;"
            + "for(i=0;i<nodes.length;i++){h=nodes[i];"
            + "if(h.closest&&(h.closest('.markor-table-of-contents')||h.closest('.mkoutline'))){continue;}"
            + "t=(h.textContent||'').replace(/\\s+/g,' ').trim();"
            + "if(!t){continue;}"
            + "lv=parseInt(h.tagName.charAt(1),10);"
            + "if(lv<minLevel){minLevel=lv;}"
            + "items.push({el:h,level:lv,text:t});}"
            // ---- 一次性生成多级缩进条目（100+ 标题也不卡）----
            + "var entries=[];"
            + "if(items.length===0){"
            + "var empty=doc.createElement('div');empty.className='mkoutline__empty';"
            + "empty.textContent=emptyText;list.appendChild(empty);"
            + "}else{"
            + "for(i=0;i<items.length;i++){(function(idx){"
            + "var it=items[idx],e=doc.createElement('div');"
            + "e.className='mkoutline__item';"
            + "var pad=8+(it.level-minLevel)*14;"
            + "if(rtl){e.style.paddingRight=pad+'px';}else{e.style.paddingLeft=pad+'px';}"
            + "e.textContent=it.text;"
            + "e.addEventListener('click',function(){jump(idx);});"
            + "list.appendChild(e);entries.push(e);})(i);}"
            + "}"
            // ---- 展开/收起 ----
            + "var opened=false,current=-1,tops=[],docHeight=0,pending=false,OFFSET=14;"
            + "function refresh(){tops=[];docHeight=doc.documentElement.scrollHeight;"
            + "for(var k=0;k<items.length;k++){var r=items[k].el.getBoundingClientRect();tops.push(r.top+win.pageYOffset);}}"
            + "function setActive(idx){"
            + "if(idx===current){return;}"
            + "if(current>=0&&entries[current]){entries[current].classList.remove('is-active');}"
            + "current=idx;"
            + "if(idx>=0&&entries[idx]){entries[idx].classList.add('is-active');}"
            // ScrollSpy 只负责高亮，不滚动大纲面板，避免滑正文时大纲被带着动
            + "}"
            + "function spy(){if(items.length===0){return;}"
            // 文档高度变化（图片/Mermaid 等异步渲染）时自动重建偏移缓存
            + "if(docHeight!==doc.documentElement.scrollHeight){refresh();}"
            + "var y=win.pageYOffset+OFFSET,idx=-1;"
            + "for(var k=0;k<tops.length;k++){if(tops[k]<=y){idx=k;}else{break;}}"
            + "setActive(idx);}"
            + "var raf=win.requestAnimationFrame||function(cb){return setTimeout(cb,16);};"
            + "win.addEventListener('scroll',function(){if(pending){return;}pending=true;"
            + "raf(function(){pending=false;spy();});},false);"
            + "win.addEventListener('resize',refresh);"
            + "win.addEventListener('load',refresh);"
            + "setTimeout(refresh,400);setTimeout(refresh,1500);"
            // ---- 跳转：平滑滚动到标题，随后自动收起 ----
            + "function jump(idx){var el=items[idx].el;"
            + "try{el.scrollIntoView({behavior:'smooth',block:'start'});}"
            + "catch(e){var r=el.getBoundingClientRect();win.scrollTo(0,win.pageYOffset+r.top-OFFSET);}"
            + "close();}"
            + "function open(){opened=true;root.classList.add('is-open');"
            + "panel.setAttribute('aria-hidden','false');refresh();spy();}"
            + "function close(){opened=false;root.classList.remove('is-open');"
            + "panel.setAttribute('aria-hidden','true');}"
            + "fab.addEventListener('click',function(e){e.stopPropagation();if(opened){close();}else{open();}});"
            + "scrim.addEventListener('click',close);"
            + "};"
            + "</script>";

    private OutlineInjector() {
    }

    /**
     * 放入预览 HTML head 的样式与脚本（无外部资源依赖）。
     */
    public static String head() {
        return CSS + JS;
    }

    /**
     * body onload 时执行的初始化调用。深色模式与预览模板的判定保持一致：
     * 系统夜间模式且非导出亮模式（打印/PDF）时为深色。
     *
     * @param exportInLightMode 对应 convertMarkup 的 lightMode 参数（true=导出亮模式）
     */
    public static String initCall(final Context context, final boolean exportInLightMode) {
        final boolean dark = GsContextUtils.instance.isDarkModeEnabled(context) && !exportInLightMode;
        return "mkOutlineInit(" + dark + ","
                + jsString(context.getString(R.string.outline_panel_title)) + ","
                + jsString(context.getString(R.string.outline_empty)) + ");";
    }

    /**
     * 转成安全的 JS 单引号字符串字面量。
     */
    private static String jsString(final String text) {
        return "'" + text
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\r", " ")
                .replace("\n", " ") + "'";
    }
}
