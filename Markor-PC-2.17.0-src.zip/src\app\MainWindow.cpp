#include "MainWindow.h"
#include "AppSettings.h"
#include "ThemeManager.h"

#include "sidebar/FileSidebar.h"
#include "sidebar/OutlinePanel.h"
#include "editor/EditorWidget.h"
#include "editor/FormatActions.h"
#include "editor/TodoTxtActions.h"
#include "preview/PreviewWidget.h"
#include "search/SearchDialog.h"
#include "core/MarkdownConverter.h"
#include "ui/SettingsDialog.h"
#include "ui/MoreDialog.h"
#include "ui/TodoTxtFilterDialog.h"
#include "core/FormatDetector.h"

#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QFileDialog>
#include <QMessageBox>
#include <QTimer>
#include <QCloseEvent>
#include <QPixmap>
#include <QSplitter>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QAction>
#include <QActionGroup>
#include <QStandardPaths>
#include <QDesktopServices>
#include <QUrl>
#include <QApplication>
#include <QClipboard>
#include <QMimeData>
#include <QPrinter>
#include <QTextDocument>
#include <QPageSize>
#include <QFileInfo>
#include <QIcon>
#include <QPointer>
#include <QTextBlock>
#include <QTextCursor>
#include <QVector>
#include <QPair>
#include "sync/SyncManager.h"
#include "sync/LockClient.h"
#include <QScrollBar>
#include <QComboBox>
#include <QToolButton>
#include <QSignalBlocker>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QTimer>

// Format action codes
enum Fmt {
    F_Bold, F_Italic, F_Strike, F_Code, F_Heading, F_Quote,
    F_BulletList, F_OrderedList, F_CheckList, F_HR,
    F_Link, F_Image, F_Indent, F_Deindent
};


MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle(tr("Markor - Markdown"));
    setWindowIcon(QIcon(QStringLiteral(":/icon/markor_512.png")));
    resize(1280, 820);

    buildMenus();
    buildToolBar();
    buildStatusBar();

    // 内容层：[文件侧边栏] [文档标签区（每页：编辑区 | 大纲面板 | 预览区）]
    auto* central = new QWidget(this);
    auto* centralLay = new QHBoxLayout(central);
    centralLay->setContentsMargins(0, 0, 0, 0);
    centralLay->setSpacing(0);

    // 文件侧边栏主窗口级：固定最左缘，不随文档标签切换（S1.8/S1.9/S4.3）
    _fileSidebar = new FileSidebar(central);
    centralLay->addWidget(_fileSidebar);

    // Central: tabbed editor area
    _tabs = new QTabWidget(central);
    _tabs->setTabsClosable(true);
    _tabs->setMovable(true);
    _tabs->setDocumentMode(true);
    centralLay->addWidget(_tabs, 1);
    connect(_tabs, &QTabWidget::tabCloseRequested, this, &MainWindow::closeTab);
    connect(_tabs, &QTabWidget::currentChanged, this, [this](int) {
        syncPreview();
        updateFormatCombo();
        updateLintStatus(currentEditor());   // 状态栏错误提示跟随当前页
        // 文件侧边栏高亮跟随当前文档（仅改选中，不重置 Tab/宽度等自身状态）
        if (auto* e = currentEditor())
            _fileSidebar->setCurrentPath(e->filePath());
    });
    setCentralWidget(central);

    // 文件侧边栏信号
    connect(_fileSidebar, &FileSidebar::fileActivated, this, &MainWindow::openFilePath);
    connect(_fileSidebar, &FileSidebar::openInNewTab, this, &MainWindow::openInNewTab);
    connect(_fileSidebar, &FileSidebar::toggleFavorite, this, [this](const QString& p) {
        AppSettings::instance().toggleFavorite(p);
        statusBar()->showMessage(AppSettings::instance().isFavorite(p)
            ? tr("已收藏 %1").arg(p) : tr("已取消收藏 %1").arg(p), 2500);
    });
    connect(_fileSidebar, &FileSidebar::statusMessage,
            statusBar(), [this](const QString& m) { statusBar()->showMessage(m, 3000); });

    // Restore state
    AppSettings& s = AppSettings::instance();
    // 主题默认跟随系统深/浅色；关闭跟随时用保存的具体主题
    applyTheme(s.followSystemTheme() ? ThemeManager::systemThemeId() : s.theme());
    if (!s.windowGeometry().isEmpty()) restoreGeometry(s.windowGeometry());
    if (!s.windowState().isEmpty()) restoreState(s.windowState());

    _fileSidebar->setRootPath(s.vaultDir());

    // 启动恢复上次退出时仍打开的标签页；无会话记录才开空白欢迎页
    const QStringList session = s.sessionFiles();
    int restored = 0;
    for (const QString& p : session) {
        if (p.isEmpty() || !QFileInfo::exists(p))
            continue;   // 文件已被删除/移动，静默跳过
        createPage(p);
        ++restored;
    }
    if (restored == 0) {
        newDocument();
    } else {
        const int savedIdx = s.sessionCurrentIndex();
        const int idx = (savedIdx >= 0 && savedIdx < restored) ? savedIdx : 0;
        _tabs->setCurrentIndex(idx);
        ensureUnnamedTabAtEnd();   // 会话标签之后补一个未命名标签
    }

    // Sync subsystem (embedded Syncthing)
    connect(&SyncManager::instance(), &SyncManager::statusMessage, this,
            [this](const QString& m) { statusBar()->showMessage(m, 8000); });
    // 连接同步服务器成功/失败都要弹窗提示（用户要求）
    connect(&SyncManager::instance(), &SyncManager::serverConnectionResult, this,
            [this](bool ok, const QString& msg) {
        if (ok)
            QMessageBox::information(this, tr("同步服务器"), msg);
        else
            QMessageBox::warning(this, tr("同步服务器"), msg);
    });
    connect(&SyncManager::instance(), &SyncManager::deviceIdReady,
            &LockClient::instance(), &LockClient::setDeviceId);
    // 文件锁：其他设备已打开同名文件时弹提示（服务器 lockserver API）；
    // 同时记录到 _heldElsewhere，退出时据此再提醒一次
    connect(&LockClient::instance(), &LockClient::fileHeldElsewhere, this,
            [this](const QString& p, const QString& holders) {
        _heldElsewhere.insert(QDir::cleanPath(QFileInfo(p).absoluteFilePath()).toLower());
        QMessageBox::warning(this, tr("文件已在其他设备打开"),
                             tr("文件 %1 正被其他设备打开：%2").arg(p, holders));
    });
    connect(&LockClient::instance(), &LockClient::statusMessage,
            statusBar(), [this](const QString& m) { statusBar()->showMessage(m, 4000); });

    applySyncSettings();
}

void MainWindow::exportScreenshot(const QString& path)
{
    // Grab the window and save as PNG (used for UI capture / documentation).
    QPixmap px = grab();
    px.save(path, "PNG");
}

// ---------------- Menu ----------------
void MainWindow::buildMenus()
{
    QMenu* fileMenu = menuBar()->addMenu(tr("文件(&F)"));
    fileMenu->addAction(tr("新建文档(&N)"), QKeySequence::New, this, &MainWindow::newDocument);
    fileMenu->addAction(tr("打开(&O)…"), QKeySequence::Open, this, &MainWindow::openFile);
    fileMenu->addSeparator();
    fileMenu->addAction(tr("保存(&S)"), QKeySequence::Save, this, &MainWindow::saveCurrent);
    fileMenu->addAction(tr("另存为(&A)…"), QKeySequence::SaveAs, this, &MainWindow::saveCurrentAs);
    fileMenu->addAction(tr("刷新(&R)"), QKeySequence::Refresh, this, &MainWindow::refreshCurrent);
    fileMenu->addSeparator();
    QMenu* exportMenu = fileMenu->addMenu(tr("导出 / 分享(&E)"));
    exportMenu->addAction(tr("导出 HTML…"), this, &MainWindow::exportHtml);
    exportMenu->addAction(tr("导出 PDF…"), this, &MainWindow::exportPdf);
    exportMenu->addSeparator();
    exportMenu->addAction(tr("复制 HTML 源码"), this, &MainWindow::copyHtmlSource);
    exportMenu->addAction(tr("复制富文本预览"), this, &MainWindow::copyRichText);
    exportMenu->addAction(tr("复制纯文本"), this, &MainWindow::copyPlainText);
    fileMenu->addSeparator();
    fileMenu->addAction(tr("退出(&X)"), QKeySequence::Quit, this, &QWidget::close);

    QMenu* editMenu = menuBar()->addMenu(tr("编辑(&E)"));
    editMenu->addAction(tr("撤销"), QKeySequence::Undo, [this]() {
        if (auto* e = currentEditor()) e->undo();
    });
    editMenu->addAction(tr("重做"), QKeySequence::Redo, [this]() {
        if (auto* e = currentEditor()) e->redo();
    });
    editMenu->addSeparator();
    editMenu->addAction(tr("查找 / 替换(&F)…"), QKeySequence::Find, this, &MainWindow::findInFile);

    QMenu* formatMenu = menuBar()->addMenu(tr("格式(&M)"));
    auto addFmt = [this, formatMenu](const QString& text, Fmt code,
                                     const QKeySequence& sc = QKeySequence()) {
        QAction* a = formatMenu->addAction(text);
        a->setData(static_cast<int>(code));
        if (!sc.isEmpty())
            a->setShortcut(sc);   // 窗口级快捷键：菜单不可见时也生效
        connect(a, &QAction::triggered, this, &MainWindow::applyFormatAction);
    };
    addFmt(tr("加粗"), F_Bold, QKeySequence(QStringLiteral("Ctrl+B")));
    addFmt(tr("斜体"), F_Italic, QKeySequence(QStringLiteral("Ctrl+I")));
    addFmt(tr("删除线"), F_Strike, QKeySequence(QStringLiteral("Alt+Shift+5")));
    addFmt(tr("行内代码"), F_Code, QKeySequence(QStringLiteral("Ctrl+Shift+`")));
    addFmt(tr("标题"), F_Heading, QKeySequence(QStringLiteral("Ctrl+H")));
    addFmt(tr("引用"), F_Quote, QKeySequence(QStringLiteral("Ctrl+Shift+Q")));
    addFmt(tr("项目符号列表"), F_BulletList, QKeySequence(QStringLiteral("Ctrl+Shift+]")));
    addFmt(tr("有序列表"), F_OrderedList, QKeySequence(QStringLiteral("Ctrl+Shift+[")));
    addFmt(tr("任务清单"), F_CheckList, QKeySequence(QStringLiteral("Ctrl+Shift+C")));
    addFmt(tr("水平分割线"), F_HR, QKeySequence(QStringLiteral("Ctrl+-")));
    addFmt(tr("插入链接"), F_Link, QKeySequence(QStringLiteral("Ctrl+K")));
    addFmt(tr("插入图片"), F_Image, QKeySequence(QStringLiteral("Ctrl+Shift+I")));
    addFmt(tr("增加缩进"), F_Indent, QKeySequence(QStringLiteral("Ctrl+]")));
    addFmt(tr("减少缩进"), F_Deindent, QKeySequence(QStringLiteral("Ctrl+[")));
    formatMenu->addSeparator();
    formatMenu->addAction(tr("整理 Markdown 文档"), QKeySequence(QStringLiteral("Ctrl+Alt+T")),
                          this, &MainWindow::tidyCurrentMarkdown);

    // Todo.txt task operations
    QMenu* todoMenu = menuBar()->addMenu(tr("任务(&K)"));
    auto addTodo = [this, todoMenu](const QString& text, const QKeySequence& sc,
                                    void (*fn)(EditorWidget*)) {
        QAction* a = todoMenu->addAction(text, sc);
        connect(a, &QAction::triggered, this, [this, fn]() {
            if (auto* e = currentEditor()) fn(e);
        });
    };
    addTodo(tr("切换完成"), QKeySequence(QStringLiteral("Ctrl+D")), TodoTxtActions::toggleDone);
    addTodo(tr("优先级循环 A→B→C→无"), QKeySequence(QStringLiteral("Ctrl+P")), TodoTxtActions::cyclePriority);

    QMenu* priMenu = todoMenu->addMenu(tr("设置优先级"));
    for (const char p : { 'A', 'B', 'C' }) {
        QAction* a = priMenu->addAction(QStringLiteral("(%1)").arg(p));
        connect(a, &QAction::triggered, this, [this, p]() {
            if (auto* e = currentEditor()) TodoTxtActions::setPriority(e, QChar(p));
        });
    }
    priMenu->addSeparator();
    QAction* clearPri = priMenu->addAction(tr("清除优先级"));
    connect(clearPri, &QAction::triggered, this, [this]() {
        if (auto* e = currentEditor()) TodoTxtActions::setPriority(e, QChar());
    });

    todoMenu->addSeparator();
    addTodo(tr("插入今日日期"), QKeySequence(QStringLiteral("Ctrl+Shift+D")), TodoTxtActions::insertToday);
    addTodo(tr("追加今日日期"), QKeySequence(), TodoTxtActions::appendToday);
    addTodo(tr("设置截止日期 due:…"), QKeySequence(), TodoTxtActions::setDueDate);
    todoMenu->addSeparator();
    addTodo(tr("归档已完成到 done.txt"), QKeySequence(), TodoTxtActions::archiveDone);
    addTodo(tr("按优先级排序"), QKeySequence(), TodoTxtActions::sortByPriority);
    todoMenu->addSeparator();
    todoMenu->addAction(tr("过滤器…"), QKeySequence(QStringLiteral("Ctrl+Shift+F")), this, [this]() {
        TodoTxtFilterDialog dlg(currentEditor(), this);
        dlg.exec();
    });

    QMenu* viewMenu = menuBar()->addMenu(tr("视图(&V)"));
    QAction* previewAct = viewMenu->addAction(tr("预览面板"));
    previewAct->setCheckable(true);
    previewAct->setChecked(_previewVisible);
    connect(previewAct, &QAction::toggled, this, &MainWindow::togglePreview);

    QMenu* themeMenu = viewMenu->addMenu(tr("主题(&T)"));
    QActionGroup* themeGroup = new QActionGroup(this);
    themeGroup->setExclusive(true);
    for (const auto& p : ThemeManager::availableThemes()) {
        QAction* a = themeMenu->addAction(p.second);
        a->setCheckable(true);
        a->setData(p.first);
        a->setActionGroup(themeGroup);
        if (p.first == AppSettings::instance().theme())
            a->setChecked(true);
        connect(a, &QAction::triggered, this, [this, a]() {
            // 手动选具体主题即取消"跟随系统"，并持久化所选主题
            AppSettings::instance().setFollowSystemTheme(false);
            AppSettings::instance().setTheme(a->data().toString());
            applyTheme(a->data().toString());
        });
    }
    themeMenu->addSeparator();
    themeMenu->addAction(tr("循环切换主题"), QKeySequence(QStringLiteral("Ctrl+Shift+T")),
                         this, &MainWindow::cycleTheme);

    QMenu* toolsMenu = menuBar()->addMenu(tr("工具(&T)"));
    toolsMenu->addAction(tr("设置(&S)…"), this, &MainWindow::showSettings);
    toolsMenu->addAction(tr("更多(&M)…"), this, &MainWindow::showMore);

    QMenu* helpMenu = menuBar()->addMenu(tr("帮助(&H)"));
    helpMenu->addAction(tr("关于(&A)…"), this, &MainWindow::about);

    // 撤回/前进文字按钮：放在菜单栏末尾（帮助菜单之后）的角落容器里。
    // 走编辑器自管理的快照历史（见 EditorWidget），而非 QTextDocument 撤销栈。
    auto* histBox = new QWidget(this);
    histBox->setObjectName(QStringLiteral("HistoryButtons"));
    auto* histLay = new QHBoxLayout(histBox);
    histLay->setContentsMargins(0, 0, 6, 0);
    histLay->setSpacing(2);
    auto* backBtn = new QToolButton(histBox);
    backBtn->setObjectName(QStringLiteral("HistoryBackButton"));
    backBtn->setText(tr("撤回"));
    backBtn->setAutoRaise(true);
    backBtn->setToolButtonStyle(Qt::ToolButtonTextOnly);
    auto* fwdBtn = new QToolButton(histBox);
    fwdBtn->setObjectName(QStringLiteral("HistoryForwardButton"));
    fwdBtn->setText(tr("前进"));
    fwdBtn->setAutoRaise(true);
    fwdBtn->setToolButtonStyle(Qt::ToolButtonTextOnly);
    histLay->addWidget(backBtn);
    histLay->addWidget(fwdBtn);
    menuBar()->setCornerWidget(histBox, Qt::TopRightCorner);
    connect(backBtn, &QToolButton::clicked, this, &MainWindow::historyBack);
    connect(fwdBtn, &QToolButton::clicked, this, &MainWindow::historyForward);
}

// ---------------- Toolbar ----------------
void MainWindow::buildToolBar()
{
    QToolBar* tb = addToolBar(tr("格式工具栏"));
    tb->setObjectName(QStringLiteral("FormatToolBar"));
    tb->setMovable(false);
    tb->setIconSize(QSize(18, 18));

    auto add = [this, tb](const QString& text, Fmt code,
                          const QString& sc = QString()) {
        QAction* a = tb->addAction(text);
        a->setData(static_cast<int>(code));
        // 悬停提示带上快捷键；快捷键本体在格式菜单 QAction 上（窗口级）
        a->setToolTip(sc.isEmpty() ? text : tr("%1  (%2)").arg(text, sc));
        connect(a, &QAction::triggered, this, &MainWindow::applyFormatAction);
    };
    add(tr("B 加粗"), F_Bold, QStringLiteral("Ctrl+B"));
    add(tr("I 斜体"), F_Italic, QStringLiteral("Ctrl+I"));
    add(tr("S 删除线"), F_Strike, QStringLiteral("Alt+Shift+5"));
    add(tr("<> 代码"), F_Code, QStringLiteral("Ctrl+Shift+`"));
    add(tr("- 分割线"), F_HR, QStringLiteral("Ctrl+-"));   // 水平分割线 ---
    tb->addSeparator();
    add(tr("H 标题"), F_Heading, QStringLiteral("Ctrl+H"));
    add(tr("❯ 引用"), F_Quote, QStringLiteral("Ctrl+Shift+Q"));
    tb->addSeparator();
    add(tr("• 列表"), F_BulletList, QStringLiteral("Ctrl+Shift+]"));
    add(tr("1. 有序"), F_OrderedList, QStringLiteral("Ctrl+Shift+["));
    add(tr("☑ 任务"), F_CheckList, QStringLiteral("Ctrl+Shift+C"));
    tb->addSeparator();
    add(tr("🔗 链接"), F_Link, QStringLiteral("Ctrl+K"));
    add(tr("🖼 图片"), F_Image, QStringLiteral("Ctrl+Shift+I"));
    tb->addSeparator();
    add(tr("⇥ 缩进"), F_Indent, QStringLiteral("Ctrl+]"));
    add(tr("⇤ 反缩进"), F_Deindent, QStringLiteral("Ctrl+["));
    tb->addSeparator();

    // 格式选择："自动"按文件扩展名识别（FormatDetector），也可手动指定格式
    tb->addWidget(new QLabel(tr("格式："), tb));
    _formatCombo = new QComboBox(tb);
    _formatCombo->setObjectName(QStringLiteral("FormatCombo"));
    _formatCombo->setToolTip(tr("文档格式；“自动”按文件扩展名识别"));
    _formatCombo->addItem(tr("自动"), -1);
    for (TextFormat f : { TextFormat::Markdown, TextFormat::TodoTxt, TextFormat::PlainText,
                          TextFormat::AsciiDoc, TextFormat::OrgMode, TextFormat::WikiText,
                          TextFormat::Csv, TextFormat::KeyValue,
                          TextFormat::Html, TextFormat::Code })
        _formatCombo->addItem(FormatDetector::name(f), static_cast<int>(f));
    tb->addWidget(_formatCombo);
    connect(_formatCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::onFormatComboChanged);
    QAction* tidyAct = tb->addAction(tr("🧹 整理"));
    tidyAct->setToolTip(tr("一次性整理 Markdown（补表格分隔行/闭合代码围栏/规范分隔线与复选框等）"));
    connect(tidyAct, &QAction::triggered, this, &MainWindow::tidyCurrentMarkdown);
}

void MainWindow::buildStatusBar()
{
    statusBar()->showMessage(tr("就绪"));
    // 左侧常驻：当前文档第一条格式错误（行号+原因+正确写法），点击跳转出错行
    _lintLabel = new QLabel(this);
    _lintLabel->setTextFormat(Qt::RichText);
    _lintLabel->setOpenExternalLinks(false);
    _lintLabel->setCursor(Qt::PointingHandCursor);
    _lintLabel->setVisible(false);
    connect(_lintLabel, &QLabel::linkActivated, this, [this](const QString&) {
        if (auto* e = currentEditor(); e && e->lintLine() > 0)
            e->gotoLine(e->lintLine());
    });
    statusBar()->addWidget(_lintLabel);
}

void MainWindow::updateLintStatus(EditorWidget* e)
{
    if (!_lintLabel)
        return;
    if (!e || e->lintLine() <= 0) {
        _lintLabel->clear();
        _lintLabel->setVisible(false);
        return;
    }
    _lintLabel->setText(
        tr("<a href=\"#goto\" style=\"color:#c0392b;text-decoration:none;\">"
           "⚠ 第 %1 行：%2 —— 正确写法：%3</a>")
            .arg(e->lintLine())
            .arg(e->lintReason().toHtmlEscaped(), e->lintFix().toHtmlEscaped()));
    _lintLabel->setToolTip(tr("点击跳转到第 %1 行").arg(e->lintLine()));
    _lintLabel->setVisible(true);
}

// ---------------- Pages ----------------
EditorWidget* MainWindow::createPage(const QString& path)
{
    auto* page = new QWidget(this);
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(2, 2, 2, 2);

    auto* split = new QSplitter(Qt::Horizontal, page);
    split->setObjectName(QStringLiteral("EditorPreviewSplitter"));
    auto* editor = new EditorWidget(split);

    // 右侧容器：大纲面板（固定宽度、自带把手） + 预览区（拉伸占满）
    auto* rightBox = new QWidget(split);
    auto* rightLay = new QHBoxLayout(rightBox);
    rightLay->setContentsMargins(0, 0, 0, 0);
    rightLay->setSpacing(0);
    auto* outline = new OutlinePanel(rightBox);
    auto* preview = new PreviewWidget(rightBox);
    rightLay->addWidget(outline);
    rightLay->addWidget(preview, 1);

    split->addWidget(editor);
    split->addWidget(rightBox);
    // 拖分割条=按宽度重排而非缩放：两区各保留最小宽度，比例随窗口伸缩
    editor->setMinimumWidth(200);
    preview->setMinimumWidth(200);
    split->setStretchFactor(0, 3);
    split->setStretchFactor(1, 2);
    // 分割位置持久化（所有页共用一份）
    const QByteArray splitState = AppSettings::instance().splitterState();
    if (!splitState.isEmpty())
        split->restoreState(splitState);
    // 拖拽停止 300ms 后落盘，避免每次 moved 都写配置
    auto* splitSaveTimer = new QTimer(split);
    splitSaveTimer->setSingleShot(true);
    splitSaveTimer->setInterval(300);
    connect(split, &QSplitter::splitterMoved, splitSaveTimer,
            QOverload<>::of(&QTimer::start));
    connect(splitSaveTimer, &QTimer::timeout, this, [split]() {
        AppSettings::instance().setSplitterState(split->saveState());
    });

    layout->addWidget(split);

    QString title = path.isEmpty() ? tr("未命名") : QFileInfo(path).fileName();
    int idx = _tabs->addTab(page, title);
    _tabs->setCurrentIndex(idx);

    // Wiring
    connect(editor, &EditorWidget::dirtyChanged, this, [this, page](bool dirty) {
        int i = _tabs->indexOf(page);
        if (i < 0) return;
        QString t = _tabs->tabText(i);
        if (dirty && !t.endsWith(QLatin1Char('*')))
            _tabs->setTabText(i, t + QLatin1Char('*'));
        else if (!dirty && t.endsWith(QLatin1Char('*')))
            _tabs->setTabText(i, t.left(t.size() - 1));
    });
    connect(editor, &EditorWidget::textChanged, this, &MainWindow::syncPreview);
    connect(editor, &EditorWidget::statusMessage, this, &MainWindow::showToast);
    // 预览 Ctrl+滚轮调字号的当前值提示（窗口中心浮层）
    connect(preview, &PreviewWidget::statusMessage, this, &MainWindow::showToast);
    // 格式错误诊断：高亮器 → 编辑器转发 → 状态栏（仅当前页刷新显示）
    connect(editor, &EditorWidget::lintIssueChanged, this,
            [this, editor = QPointer<EditorWidget>(editor)](int, const QString&, const QString&) {
        if (editor && editor == currentEditor())
            updateLintStatus(editor);
    });

    // Theme-aware refresh. Guard with QPointer: the page (and therefore the
    // editor/preview) can be destroyed while the ThemeManager outlives it.
    connect(&ThemeManager::instance(), &ThemeManager::themeChanged, this,
            [editor = QPointer<EditorWidget>(editor),
             preview = QPointer<PreviewWidget>(preview)]() {
        if (editor) editor->refreshFormat();
        if (preview) preview->refreshTheme();
    });

    // 滚动同步（规范 1.1，严格单向）：
    //  编辑区滚动 -> 预览 43% 参考点平滑跟随（帧驱动，受"预览跟随编辑"开关控制）。
    //  预览滚动/点击不回推编辑器；大纲/目录点击仅滚动预览。
    connect(editor->verticalScrollBar(), &QScrollBar::valueChanged, this,
            [editor, preview = QPointer<PreviewWidget>(preview)](int) {
        if (editor->isProgrammaticScroll())
            return;
        if (!AppSettings::instance().previewFollowEditor() || !preview)
            return;
        // 边界：编辑器到顶 → 预览到顶；到底 → 预览到底（与参考实现一致）
        QScrollBar* esb = editor->verticalScrollBar();
        if (esb->value() <= 2) {
            preview->followEditorEdge(false);
            return;
        }
        const int eMax = esb->maximum();
        if (eMax > 0 && esb->value() >= eMax - 2) {
            preview->followEditorEdge(true);
            return;
        }
        // 43% 视口参考点：编辑器视口 43% 高度处的源行，对到预览视口同比例
        // 位置（块内插值），帧驱动平滑追随（与参考实现 REF=12.5/29 一致）
        constexpr qreal kRef = 12.5 / 29.0;
        const qreal refLineF = editor->sourceLineFAtViewportY(
            editor->viewport()->height() * kRef);
        preview->followSourceLineF(refLineF, kRef);
    });

    // 编辑输入实时预览（与参考 code.html 一致）：
    //  每次输入把光标源行递给预览（防抖合并，以最后一次为准）；渲染时由
    //  PreviewWidget 自行决定——光标行在预览视口内保持像素不动（防跳），
    //  在视口外（尾部新内容/预览被滚走）对齐到中部。光标纯移动不触发
    //  textChanged，不跟随；不在这里做几何判断（每键 O(n) 遍历是卡顿主因）。
    connect(editor, &EditorWidget::textChanged, this,
            [editor, preview = QPointer<PreviewWidget>(preview)]() {
        if (!AppSettings::instance().previewFollowEditor() || !preview)
            return;
        // 锚点比例取光标在编辑器视口中的垂直位置：编辑器里光标在哪，
        // 预览对齐时就把光标行放在对应的位置，跳跃更温和（不再固定 0.5）
        preview->alignNextRender(editor->cursorSourceLineF(),
                                 editor->cursorViewportRatio());
    });

    // 大纲面板绑定本页编辑器/预览（随标签走，每文档各一套：S2.4/S2.5）
    outline->bind(editor, preview);

    if (!path.isEmpty()) {
        if (editor->loadFile(path)) {
            preview->setFormat(FormatDetector::detect(path));
            preview->setSourcePath(path);   // HTML 文件浏览器级预览按此路径导航
            AppSettings::instance().addRecent(path);
            LockClient::instance().open(path);   // 文件锁登记（未配置服务器则静默）
        } else {
            QMessageBox::warning(this, tr("打开失败"),
                                 tr("无法读取文件：\n%1").arg(path));
        }
    } else {
        // 新建文档默认 Markdown（未命名.md，保存时自动补扩展名）
        editor->setFormatAuto(false);
        editor->applyFormat(TextFormat::Markdown);
    }
    // 文档载入后立即解析一次大纲（编辑器变更后再走 400ms 防抖）
    outline->refreshNow();
    return editor;
}

EditorWidget* MainWindow::currentEditor() const
{
    QWidget* page = _tabs->currentWidget();
    return page ? page->findChild<EditorWidget*>() : nullptr;
}

PreviewWidget* MainWindow::currentPreview() const
{
    QWidget* page = _tabs->currentWidget();
    return page ? page->findChild<PreviewWidget*>() : nullptr;
}

int MainWindow::indexOfPath(const QString& path) const
{
    for (int i = 0; i < _tabs->count(); ++i) {
        QWidget* page = _tabs->widget(i);
        auto* e = page ? page->findChild<EditorWidget*>() : nullptr;
        if (e && e->filePath() == path)
            return i;
    }
    return -1;
}

void MainWindow::ensureUnnamedTabAtEnd()
{
    // 找到第一个未命名标签（无文件路径）
    int unnamedIdx = -1;
    for (int i = 0; i < _tabs->count(); ++i) {
        auto* e = _tabs->widget(i)
                      ? _tabs->widget(i)->findChild<EditorWidget*>() : nullptr;
        if (e && e->filePath().isEmpty()) {
            unnamedIdx = i;
            break;
        }
    }
    if (unnamedIdx < 0) {
        newDocument();   // 没有未命名标签则新建一个（会追加到末尾）
        return;
    }
    const int last = _tabs->count() - 1;
    if (unnamedIdx != last)
        _tabs->tabBar()->moveTab(unnamedIdx, last);   // 移到最右，不改变当前页
}

void MainWindow::showToast(const QString& text)
{
    if (!_toastLabel) {
        _toastLabel = new QLabel();   // 顶层浮层：不挂父，避免被主窗口裁掉
        _toastLabel->setWindowFlags(
            Qt::Tool | Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
        _toastLabel->setAttribute(Qt::WA_ShowWithoutActivating);
        _toastLabel->setAlignment(Qt::AlignCenter);
        _toastTimer = new QTimer(this);
        _toastTimer->setSingleShot(true);
        connect(_toastTimer, &QTimer::timeout, _toastLabel, &QLabel::hide);
    }
    // 每次显示都按当前皮肤取色（与各主题 QMenu 配色一致）
    const QString& t = ThemeManager::instance().current();
    QString bg, fg, border;
    if (t == QStringLiteral("dark")) {
        bg = QStringLiteral("#2a2f36"); fg = QStringLiteral("#e4e6eb");
        border = QStringLiteral("#444a52");
    } else if (t == QStringLiteral("sakura")) {
        bg = QStringLiteral("#ffffff"); fg = QStringLiteral("#b2607e");
        border = QStringLiteral("#f2b8c6");
    } else {
        bg = QStringLiteral("#ffffff"); fg = QStringLiteral("#1c1e21");
        border = QStringLiteral("#c4cad2");
    }
    _toastLabel->setStyleSheet(QStringLiteral(
        "background-color: %1; color: %2; border: 1px solid %3;"
        " border-radius: 10px; padding: 12px 26px; font-size: 15px;")
        .arg(bg, fg, border));
    _toastLabel->setText(text);
    _toastLabel->adjustSize();
    // 窗口正中心（全局坐标）
    const QPoint c = mapToGlobal(rect().center());
    _toastLabel->move(c - _toastLabel->rect().center());
    _toastLabel->show();
    _toastLabel->raise();
    _toastTimer->start(1400);
}

void MainWindow::syncPreview()
{
    auto* e = currentEditor();
    auto* p = currentPreview();
    if (e && p) {
        p->setMarkdown(e->toPlainText());
        p->setFormat(e->format());
    }
}

// ---------------- File actions ----------------
void MainWindow::newDocument()
{
    createPage(QString());
    syncPreview();
    _fileSidebar->setCurrentPath(QString());   // 未命名文档清除文件高亮
    ensureUnnamedTabAtEnd();
}

void MainWindow::openFile()
{
    QString path = QFileDialog::getOpenFileName(this, tr("打开文档"),
                                                AppSettings::instance().vaultDir(),
                                                FormatDetector::fileFilter());
    if (!path.isEmpty())
        openFilePath(path);
}

void MainWindow::openFilePath(const QString& path)
{
    int existing = indexOfPath(path);
    if (existing >= 0) {
        _tabs->setCurrentIndex(existing);   // currentChanged 内会更新侧边栏高亮
    } else {
        createPage(path);
        syncPreview();
        _fileSidebar->setCurrentPath(path);
        ensureUnnamedTabAtEnd();   // 未命名标签自动归到最右侧
    }
}

void MainWindow::openInNewTab(const QString& path)
{
    createPage(path);
    syncPreview();
    _fileSidebar->setCurrentPath(path);
    ensureUnnamedTabAtEnd();
}

void MainWindow::saveCurrent()
{
    auto* e = currentEditor();
    if (!e) return;
    if (e->filePath().isEmpty()) {
        saveCurrentAs();
        return;
    }
    // 写冲突不再做占用检查，交给 Syncthing 的 .sync-conflict 文件兜底
    if (e->saveFile()) {
        statusBar()->showMessage(tr("已保存"), 2000);
        // 保存后注销文件锁（服务器协议：关闭/保存后注销）
        LockClient::instance().close();
        // HTML 文件：保存后让 WebView2 重新加载，浏览器预览跟随最新内容
        if (auto* p = currentPreview())
            p->reloadHtmlPreview();
    } else {
        QMessageBox::warning(this, tr("保存失败"),
                             tr("无法写入文件：\n%1").arg(e->filePath()));
    }
}

bool MainWindow::saveCurrentAs()
{
    auto* e = currentEditor();
    if (!e) return false;
    // 新建文档首次保存：默认文件名"未命名.md"，默认按 Markdown 识别
    QString start = AppSettings::instance().vaultDir();
    if (e->filePath().isEmpty())
        start += QLatin1Char('/') + tr("未命名.md");
    QString path = QFileDialog::getSaveFileName(this, tr("另存为"), start,
                                                FormatDetector::fileFilter());
    if (path.isEmpty())
        return false;   // user cancelled
    if (QFileInfo(path).suffix().isEmpty())
        path += QStringLiteral(".md");
    if (!e->saveFile(path)) {
        QMessageBox::warning(this, tr("保存失败"), tr("无法写入文件：\n%1").arg(path));
        return false;
    }
    // 首次保存后恢复"按扩展名自动识别"，并按实际扩展名刷新格式
    e->setFormatAuto(true);
    e->refreshFormat();
    int i = _tabs->currentIndex();
    _tabs->setTabText(i, QFileInfo(path).fileName());
    AppSettings::instance().addRecent(path);
    syncPreview();
    // 首次另存后绑定磁盘路径：HTML 文件预览改按新路径浏览器级渲染
    if (auto* p = currentPreview()) {
        p->setSourcePath(path);
        p->reloadHtmlPreview();
    }
    _fileSidebar->setCurrentPath(path);   // 首次另存后文件树定位到新文件
    LockClient::instance().close();       // 保存后注销文件锁
    return true;
}

void MainWindow::refreshCurrent()
{
    auto* e = currentEditor();
    if (!e)
        return;

    // 有未保存更改：确定=保存后刷新；放弃=直接刷新；取消=关闭窗口不刷新
    if (e->isDirty()) {
        auto btn = QMessageBox::question(this, tr("未保存的更改"),
                                         tr("当前文档有未保存的更改，是否保存后刷新？"),
                                         QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (btn == QMessageBox::Cancel)
            return;
        if (btn == QMessageBox::Save) {
            const bool saved = e->filePath().isEmpty() ? saveCurrentAs() : e->saveFile();
            if (!saved)
                return;   // 保存失败或取消"另存为"：中止刷新
        }
        // Discard：放弃更改，继续刷新
    }

    // 从磁盘重新载入（外部/Syncthing 可能已更新文件）；未命名文档无磁盘源
    if (!e->filePath().isEmpty()) {
        if (!e->loadFile(e->filePath())) {
            QMessageBox::warning(this, tr("刷新失败"),
                                 tr("无法读取文件：\n%1").arg(e->filePath()));
            return;
        }
    }
    syncPreview();
    // HTML 文件：磁盘内容已重载，浏览器预览同步重载
    if (auto* p = currentPreview())
        p->reloadHtmlPreview();
    // loadFile() 抑制了信号，大纲需手动重新解析
    if (auto* page = _tabs->currentWidget())
        if (auto* outline = page->findChild<OutlinePanel*>())
            outline->refreshNow();
    statusBar()->showMessage(tr("已刷新"), 2000);
}

// ---------------- Sync ----------------
void MainWindow::applySyncSettings()
{
    SyncManager::instance().startIfEnabled();
}

// Returns false when the user cancelled or the save failed, so callers must
// abort whatever flow prompted the save (closing a tab / quitting).
bool MainWindow::promptSaveEditor(EditorWidget* e)
{
    auto btn = QMessageBox::question(this, tr("未保存的更改"),
                                     tr("文档尚未保存，是否保存？"),
                                     QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    if (btn == QMessageBox::Discard)
        return true;
    if (btn == QMessageBox::Cancel)
        return false;
    if (e->filePath().isEmpty())
        return saveCurrentAs();
    if (!e->saveFile()) {
        QMessageBox::warning(this, tr("保存失败"),
                             tr("无法写入文件：\n%1").arg(e->filePath()));
        return false;
    }
    return true;
}

void MainWindow::closeTab(int index)
{
    QWidget* page = _tabs->widget(index);
    auto* e = page ? page->findChild<EditorWidget*>() : nullptr;
    if (e && e->isDirty()) {
        _tabs->setCurrentIndex(index);
        if (!promptSaveEditor(e))
            return;
    }
    QWidget* closingCurrent = _tabs->currentWidget();
    _tabs->removeTab(index);
    if (page) page->deleteLater();
    if (page == closingCurrent)
        LockClient::instance().close();   // 关闭标签时注销文件锁
    // 关闭后仍保证最右侧有一个未命名标签
    ensureUnnamedTabAtEnd();
}

// ---------------- Format actions ----------------
void MainWindow::applyFormatAction()
{
    auto* e = currentEditor();
    if (!e) return;
    QAction* a = qobject_cast<QAction*>(sender());
    if (!a) return;
    switch (static_cast<Fmt>(a->data().toInt())) {
    case F_Bold:       FormatActions::bold(e); break;
    case F_Italic:     FormatActions::italic(e); break;
    case F_Strike:     FormatActions::strikeout(e); break;
    case F_Code:       FormatActions::inlineCode(e); break;
    case F_Heading:    FormatActions::heading(e); break;
    case F_Quote:      FormatActions::blockquote(e); break;
    case F_BulletList: FormatActions::bulletList(e); break;
    case F_OrderedList:FormatActions::orderedList(e); break;
    case F_CheckList:  FormatActions::checkboxList(e); break;
    case F_HR:         FormatActions::horizontalRule(e); break;
    case F_Link:       FormatActions::insertLink(e); break;
    case F_Image:      FormatActions::insertImage(e); break;
    case F_Indent:     FormatActions::indent(e); break;
    case F_Deindent:   FormatActions::deindent(e); break;
    }
    syncPreview();
}

// 格式下拉："自动"按扩展名识别（FormatDetector），否则用手动指定的格式
void MainWindow::onFormatComboChanged(int index)
{
    auto* e = currentEditor();
    if (!e || !_formatCombo)
        return;
    const int data = _formatCombo->itemData(index).toInt();
    if (data < 0) {
        e->setFormatAuto(true);
        e->refreshFormat();
    } else {
        e->setFormatAuto(false);
        e->applyFormat(static_cast<TextFormat>(data));
    }
    syncPreview();
}

// 标签切换时把格式下拉同步为当前文档的格式/自动状态
void MainWindow::updateFormatCombo()
{
    auto* e = currentEditor();
    if (!e || !_formatCombo)
        return;
    const QSignalBlocker blocker(_formatCombo);
    int idx = e->isFormatAuto() ? 0 : _formatCombo->findData(static_cast<int>(e->format()));
    _formatCombo->setCurrentIndex(idx < 0 ? 0 : idx);
}

void MainWindow::tidyCurrentMarkdown()
{
    auto* e = currentEditor();
    if (!e)
        return;
    if (!FormatDetector::isMarkdownFamily(e->format())) {
        statusBar()->showMessage(tr("仅 Markdown 系文档支持自动整理"), 3000);
        return;
    }
    if (FormatActions::tidyMarkdown(e)) {
        syncPreview();
        statusBar()->showMessage(tr("已整理 Markdown 文档"), 3000);
    } else {
        statusBar()->showMessage(tr("未发现需要整理的内容"), 3000);
    }
}

void MainWindow::historyBack()
{
    if (auto* e = currentEditor())
        e->undoSnapshot();
}

void MainWindow::historyForward()
{
    if (auto* e = currentEditor())
        e->redoSnapshot();
}

void MainWindow::findInFile()
{
    if (!_searchDialog) {
        _searchDialog = new SearchDialog(currentEditor(),
                                         AppSettings::instance().vaultDir(), this);
        connect(_searchDialog, &SearchDialog::openFileAt,
                this, &MainWindow::openFileAtLine);
    } else {
        // Re-bind to the current editor instead of destroying/recreating the
        // dialog every time.
        _searchDialog->setEditor(currentEditor());
    }
    _searchDialog->show();
    _searchDialog->raise();
    _searchDialog->activateWindow();
}

void MainWindow::openFileAtLine(const QString& path, int line)
{
    openFilePath(path);
    auto* e = currentEditor();
    if (e && e->filePath() == path && line > 0) {
        QTextBlock block = e->document()->findBlockByNumber(line - 1);
        if (block.isValid()) {
            QTextCursor c(block);
            e->setTextCursor(c);
            e->centerCursor();
        }
    }
}

// ---------------- Export / share ----------------
QString MainWindow::currentHtmlDocument() const
{
    // Route through the preview pipeline so Mermaid / math blocks are rendered
    // as embedded images instead of being dumped as raw source.
    if (auto* p = currentPreview())
        return p->toHtmlDocument();
    if (auto* e = currentEditor())
        return MarkdownConverter::toHtmlDocument(e->toPlainText(),
                                                 ThemeManager::instance().isDark());
    return QString();
}

QString MainWindow::currentHtmlWithResources(QVector<QPair<QString, QPixmap>>* resources) const
{
    if (auto* p = currentPreview())
        return p->toHtmlWithResources(resources);
    if (auto* e = currentEditor())
        return MarkdownConverter::toHtmlDocument(e->toPlainText(),
                                                 ThemeManager::instance().isDark());
    return QString();
}

void MainWindow::exportHtml()
{
    auto* e = currentEditor();
    if (!e) return;
    QString suggested = e->filePath().isEmpty()
        ? QStringLiteral("export.html")
        : e->filePath().section(QLatin1Char('.'), 0, -2) + QStringLiteral(".html");
    QString path = QFileDialog::getSaveFileName(this, tr("导出 HTML"), suggested,
                                                tr("HTML 文件 (*.html *.htm)"));
    if (path.isEmpty()) return;
    if (exportHtmlTo(path))
        statusBar()->showMessage(tr("已导出 HTML：%1").arg(path), 3000);
    else
        QMessageBox::warning(this, tr("导出失败"), tr("无法写入 %1").arg(path));
}

bool MainWindow::exportHtmlTo(const QString& path)
{
    auto* e = currentEditor();
    if (!e) return false;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text))
        return false;
    QTextStream out(&f);
    out.setEncoding(QStringConverter::Utf8);
    out << currentHtmlDocument();
    f.close();
    return true;
}

void MainWindow::exportPdf()
{
    auto* e = currentEditor();
    if (!e) return;
    QString suggested = e->filePath().isEmpty()
        ? QStringLiteral("export.pdf")
        : e->filePath().section(QLatin1Char('.'), 0, -2) + QStringLiteral(".pdf");
    QString path = QFileDialog::getSaveFileName(this, tr("导出 PDF"), suggested,
                                                tr("PDF 文件 (*.pdf)"));
    if (path.isEmpty()) return;
    if (exportPdfTo(path))
        statusBar()->showMessage(tr("已导出 PDF：%1").arg(path), 3000);
    else
        QMessageBox::warning(this, tr("导出失败"), tr("无法写入 %1").arg(path));
}

bool MainWindow::exportPdfTo(const QString& path)
{
    auto* e = currentEditor();
    if (!e) return false;

    QVector<QPair<QString, QPixmap>> resources;
    QTextDocument doc;
    doc.setHtml(currentHtmlWithResources(&resources));
    // Register rendered Mermaid / math images as document resources so the
    // names referenced by <img src="..."> resolve when printing.
    for (const auto& r : resources)
        doc.addResource(QTextDocument::ImageResource, QUrl(r.first), r.second);

    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName(path);
    printer.setPageSize(QPageSize::A4);
    printer.setPageMargins(QMarginsF(15, 15, 15, 15), QPageLayout::Millimeter);
    doc.print(&printer);
    return QFile::exists(path);
}

void MainWindow::copyHtmlSource()
{
    auto* e = currentEditor();
    if (!e) return;
    QApplication::clipboard()->setText(currentHtmlDocument());
    statusBar()->showMessage(tr("已复制 HTML 源码到剪贴板"), 2500);
}

void MainWindow::copyRichText()
{
    auto* e = currentEditor();
    if (!e) return;
    QMimeData* md = new QMimeData;
    md->setHtml(MarkdownConverter::toHtmlFragment(e->toPlainText()));
    md->setText(e->toPlainText());
    QApplication::clipboard()->setMimeData(md);
    statusBar()->showMessage(tr("已复制富文本到剪贴板"), 2500);
}

void MainWindow::copyPlainText()
{
    auto* e = currentEditor();
    if (!e) return;
    QApplication::clipboard()->setText(e->toPlainText());
    statusBar()->showMessage(tr("已复制纯文本到剪贴板"), 2500);
}

// ---------------- View / theme ----------------
void MainWindow::togglePreview(bool on)
{
    _previewVisible = on;
    for (int i = 0; i < _tabs->count(); ++i) {
        QWidget* page = _tabs->widget(i);
        if (auto* p = page ? page->findChild<PreviewWidget*>() : nullptr)
            p->setVisible(on);
    }
}

void MainWindow::cycleTheme()
{
    const auto themes = ThemeManager::availableThemes();
    int cur = 0;
    for (int i = 0; i < themes.size(); ++i)
        if (themes[i].first == ThemeManager::instance().current())
            cur = i;
    int next = (cur + 1) % themes.size();
    AppSettings::instance().setTheme(themes[next].first);
    applyTheme(themes[next].first);
}

void MainWindow::setThemeFromSettings(const QString& themeId)
{
    applyTheme(themeId);
}

void MainWindow::applyTheme(const QString& themeId)
{
    ThemeManager::instance().apply(themeId);

    // Refresh theme-dependent menu checks
    if (auto* themeMenu = menuBar()->findChild<QMenu*>()) {
        Q_UNUSED(themeMenu);
    }
    statusBar()->showMessage(tr("主题：%1").arg(ThemeManager::displayName(themeId)), 2000);
    syncPreview();
}

void MainWindow::applyEditorSettings()
{
    AppSettings& s = AppSettings::instance();
    for (int i = 0; i < _tabs->count(); ++i) {
        auto* e = _tabs->widget(i) ? _tabs->widget(i)->findChild<EditorWidget*>() : nullptr;
        if (!e) continue;
        QFont f = e->font();
        f.setFamily(s.editorFontFamily());
        f.setPointSize(s.editorFontSize());
        e->setFont(f);
        e->updateLineNumberFont();   // 行号字号随内容字号同步
        e->setLineWrapMode(s.wordWrap() ? EditorWidget::WidgetWidth : EditorWidget::NoWrap);
        e->setLineNumbersVisible(s.lineNumbers());
        e->setHighlightEnabled(s.syntaxHighlighting());
    }
}

void MainWindow::showSettings()
{
    SettingsDialog dlg(this);
    connect(&dlg, &SettingsDialog::themeChanged, this, &MainWindow::applyTheme);
    connect(&dlg, &SettingsDialog::editorSettingsChanged, this, &MainWindow::applyEditorSettings);
    // 软换行/预览设置变更：即时重渲染所有页的预览
    connect(&dlg, &SettingsDialog::previewSettingsChanged, this, [this]() {
        for (int i = 0; i < _tabs->count(); ++i) {
            QWidget* page = _tabs->widget(i);
            if (auto* p = page ? page->findChild<PreviewWidget*>() : nullptr)
                p->refreshSettings();
        }
    });
    connect(&dlg, &SettingsDialog::vaultChanged, this, [this](const QString& dir) {
        _fileSidebar->setRootPath(dir);
    });
    connect(&dlg, &SettingsDialog::syncSettingsChanged, this, &MainWindow::applySyncSettings);
    dlg.exec();
}

void MainWindow::showMore()
{
    MoreDialog dlg(this);
    connect(&dlg, &MoreDialog::openSettingsRequested, this, &MainWindow::showSettings);
    connect(&dlg, &MoreDialog::openChangelogRequested, this, &MainWindow::showChangelog);
    dlg.exec();
}

void MainWindow::showChangelog()
{
    QMessageBox::information(this, tr("更新日志"),
        tr("Markor for Windows v2.17.0\n\n"
           "· 从 Android 版 Markor 移植\n"
           "· Markdown / Todo.txt 编辑与语法高亮\n"
           "· 实时预览、HTML 导出\n"
           "· 文件库管理、搜索、收藏\n"
           "· 浅色 / 深色 / 樱花 主题\n"));
}

void MainWindow::about()
{
    QMessageBox::about(this, tr("关于 Markor"),
        tr("<h3>Markor for Windows</h3>"
           "<p>版本：v2.17.0</p>"
           "<p>Markdown 与 Todo.txt 文本编辑器。</p>"
           "<p>移植自开源项目 Markor（Apache License 2.0）。</p>"));
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    // 1) 退出前锁文件冲突提醒：其他设备已打开的本页文件需要用户确认
    QStringList heldOpen;
    for (int i = 0; i < _tabs->count(); ++i) {
        auto* e = _tabs->widget(i)
                      ? _tabs->widget(i)->findChild<EditorWidget*>() : nullptr;
        if (!e || e->filePath().isEmpty())
            continue;
        const QString key =
            QDir::cleanPath(QFileInfo(e->filePath()).absoluteFilePath()).toLower();
        if (_heldElsewhere.contains(key))
            heldOpen << e->filePath();
    }
    if (!heldOpen.isEmpty()) {
        const auto btn = QMessageBox::warning(
            this, tr("文件已在其他设备打开"),
            tr("以下文件正被其他设备打开，继续退出可能产生冲突：\n%1\n\n仍要退出吗？")
                .arg(heldOpen.join(QLatin1Char('\n'))),
            QMessageBox::Yes | QMessageBox::No);
        if (btn == QMessageBox::No) {
            event->ignore();
            return;
        }
    }

    // 2) 关闭时保存所有已打开文件（不再逐个询问保存/放弃）
    for (int i = 0; i < _tabs->count(); ++i) {
        auto* e = _tabs->widget(i)
                      ? _tabs->widget(i)->findChild<EditorWidget*>() : nullptr;
        if (!e || !e->isDirty())
            continue;
        _tabs->setCurrentIndex(i);   // 另存为对话框以本页为父窗口
        const bool saved = e->filePath().isEmpty() ? saveCurrentAs() : e->saveFile();
        if (!saved) {
            QMessageBox::warning(this, tr("保存失败"),
                                 tr("文件 %1 未能保存，已取消退出。")
                                     .arg(e->filePath().isEmpty()
                                              ? tr("(未命名)") : e->filePath()));
            event->ignore();
            return;
        }
    }

    AppSettings& s = AppSettings::instance();
    LockClient::instance().close();
    SyncManager::instance().stop();
    // 记住当前页分割条位置
    if (auto* sp = _tabs->currentWidget()
            ? _tabs->currentWidget()->findChild<QSplitter*>() : nullptr)
        s.setSplitterState(sp->saveState());
    // 3) 记住退出时仍打开的标签页（未命名/无路径页不恢复），下次启动原样还原
    QStringList openPaths;
    int currentNamedIdx = -1;   // 当前页在"已命名页序列"中的位置（-1=当前页未命名）
    for (int i = 0; i < _tabs->count(); ++i) {
        auto* e = _tabs->widget(i)
                      ? _tabs->widget(i)->findChild<EditorWidget*>() : nullptr;
        const QString p = e ? e->filePath() : QString();
        if (p.isEmpty())
            continue;
        if (i == _tabs->currentIndex())
            currentNamedIdx = openPaths.size();
        openPaths << p;
    }
    s.setSessionFiles(openPaths);
    s.setSessionCurrentIndex(currentNamedIdx);

    s.setWindowGeometry(saveGeometry());
    s.setWindowState(saveState());
    s.sync();
    event->accept();
}
