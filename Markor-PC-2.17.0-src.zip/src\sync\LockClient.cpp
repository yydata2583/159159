#include "LockClient.h"
#include "app/AppSettings.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QTimer>
#include <QDir>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QHostInfo>

namespace {
constexpr const char* kVaultId = "markor-vault";   // 三端约定
constexpr int kHeartbeatMs = 30000;                // 服务器 70s 无心跳过期
}

LockClient& LockClient::instance()
{
    static LockClient c;
    return c;
}

LockClient::LockClient(QObject* parent)
    : QObject(parent)
{
    _nam = new QNetworkAccessManager(this);
    _heartbeat = new QTimer(this);
    _heartbeat->setInterval(kHeartbeatMs);
    connect(_heartbeat, &QTimer::timeout, this, [this]() {
        if (!_currentRelPath.isEmpty())
            post(QStringLiteral("/api/v1/heartbeat"), currentBody(), true);
    });
}

void LockClient::setDeviceId(const QString& id)
{
    _deviceId = id;
}

QString LockClient::relPath(const QString& absPath) const
{
    const QDir vault(AppSettings::instance().vaultDir());
    QString rel = vault.relativeFilePath(absPath);
    if (rel.startsWith(QLatin1String("../")) || rel.isEmpty())
        rel = QFileInfo(absPath).fileName();
    return QDir::fromNativeSeparators(rel);
}

QString LockClient::currentBody() const
{
    const AppSettings& s = AppSettings::instance();
    const QString name = s.syncDeviceName().trimmed().isEmpty()
                             ? QHostInfo::localHostName()
                             : s.syncDeviceName().trimmed();
    QJsonObject o;
    o.insert(QStringLiteral("device_id"), _deviceId.isEmpty() ? name : _deviceId);
    o.insert(QStringLiteral("device_name"), name);
    o.insert(QStringLiteral("vault_id"), QString::fromLatin1(kVaultId));
    o.insert(QStringLiteral("path"), _currentRelPath);
    return QString::fromUtf8(QJsonDocument(o).toJson(QJsonDocument::Compact));
}

void LockClient::open(const QString& absPath)
{
    const AppSettings& s = AppSettings::instance();
    if (s.syncServerApi().trimmed().isEmpty() || s.syncServerApiKey().isEmpty())
        return;   // 未配置服务器：静默禁用
    _currentRelPath = relPath(absPath);
    post(QStringLiteral("/api/v1/open"), currentBody(), true);
    if (!_heartbeat->isActive())
        _heartbeat->start();
}

void LockClient::close()
{
    _heartbeat->stop();
    if (_currentRelPath.isEmpty())
        return;
    post(QStringLiteral("/api/v1/close"), currentBody(), false);
    _currentRelPath.clear();
}

void LockClient::post(const QString& api, const QString& jsonBody, bool notifyHolders)
{
    const AppSettings& s = AppSettings::instance();
    const QString base = s.syncServerApi().trimmed();
    if (base.isEmpty())
        return;
    QNetworkRequest req(QUrl(base + api));
    req.setRawHeader("Content-Type", "application/json");
    req.setRawHeader("Authorization",
                     QByteArray("Bearer ") + s.syncServerApiKey().toUtf8());
    req.setTransferTimeout(5000);

    QNetworkReply* r = _nam->post(req, jsonBody.toUtf8());
    connect(r, &QNetworkReply::finished, this, [this, r, notifyHolders]() {
        r->deleteLater();
        if (r->error() != QNetworkReply::NoError) {
            emit statusMessage(tr("文件锁服务请求失败：%1").arg(r->errorString()));
            return;
        }
        const QJsonObject obj = QJsonDocument::fromJson(r->readAll()).object();
        if (!notifyHolders)
            return;
        const QJsonArray holders = obj.value(QLatin1String("holders")).toArray();
        if (holders.isEmpty())
            return;
        QStringList names;
        for (const QJsonValue& v : holders) {
            const QJsonObject h = v.toObject();
            const QString n = h.value(QLatin1String("device_name")).toString();
            names << (n.isEmpty() ? h.value(QLatin1String("device_id")).toString().left(7)
                                  : n);
        }
        emit fileHeldElsewhere(_currentRelPath, names.join(QStringLiteral("、")));
    });
}
