#include "Document.h"
#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QTextStream>

Document::Document(const QString& path)
{
    setPath(path);
}

void Document::setPath(const QString& path)
{
    _path = path;
    _format = FormatDetector::detect(path);
}

QString Document::fileName() const
{
    return QFileInfo(_path).fileName();
}

QString Document::dirPath() const
{
    return QFileInfo(_path).absolutePath();
}

bool Document::exists() const
{
    return QFileInfo::exists(_path);
}

bool Document::isWritable() const
{
    QFileInfo fi(_path);
    return fi.exists() ? fi.isWritable() : QFileInfo(fi.absolutePath()).isWritable();
}

bool Document::load()
{
    // Content loading is handled by the editor; existence check only.
    return exists();
}

bool Document::save() const
{
    // Actual content persistence is managed by EditorWidget to keep dirty
    // state authoritative. This helper just validates writability.
    return isWritable();
}
