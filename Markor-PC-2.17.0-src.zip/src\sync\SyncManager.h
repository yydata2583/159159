#pragma once
#include <QObject>
#include <QString>

class QProcess;
class QNetworkAccessManager;
class QTimer;
class QNetworkRequest;

// Runs the bundled syncthing.exe as a hidden child process and configures it
// through its local REST API.  Sync is only active while the application is
// running (started on demand, stopped on exit / when disabled).
//
// 拓扑（星型）：本机只与配置的"同步服务器"（NAS 存储节点）连接，
// 设备之间（PC ↔ 手机）不直连：不引入其他设备（introducer 关闭）、
// 关闭全局/本地发现与中继，仅走显式配置的服务器地址。
//
// 管理界面：http://127.0.0.1:8385（明文 HTTP，仅本机；启动参数
// --gui-address=127.0.0.1:8385 不能带 scheme/尾斜杠，且配置里 tls=false，
// 否则浏览器 http:// 打不开——旧版 18384 打不开即此因）。
//
// 不做"更新同步版本"：配置里 autoUpgradeIntervalH=0 显式关闭引擎自升级。
class SyncManager : public QObject {
    Q_OBJECT
public:
    static SyncManager& instance();

    void startIfEnabled();   // safe to call repeatedly / on settings change
    void stop();
    bool running() const { return _ready; }
    QString deviceId() const { return _myId; }

    // 连接服务器探测：轮询 rest/system/connections 看服务器设备是否已连接。
    // 结果经 serverConnectionResult 上抛（成功/失败均需弹窗提示，由 UI 层负责）。
    void checkServerConnection();

signals:
    void deviceIdReady(const QString& id);
    void statusMessage(const QString& msg);
    void serverConnectionResult(bool ok, const QString& message);

private:
    explicit SyncManager(QObject* parent = nullptr);
    ~SyncManager() override;
    void launch();
    void pollStatus();
    void applyConfig();
    void pollServerConnection();
    QNetworkRequest makeRequest(const QString& path) const;

    QProcess* _proc = nullptr;
    QNetworkAccessManager* _nam = nullptr;
    QTimer* _pollTimer = nullptr;
    QTimer* _connTimer = nullptr;
    QString _apiKey;
    QString _home;
    QString _myId;
    int _tries = 0;
    int _connTries = 0;
    bool _ready = false;
    bool _configApplied = false;
};
