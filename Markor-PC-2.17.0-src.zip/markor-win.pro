QT       += core gui widgets printsupport concurrent network
CONFIG   += c++17
TARGET     = MarkorWin
TEMPLATE   = app

# Sources
SOURCES += \
    src/main.cpp \
    src/app/MainWindow.cpp \
    src/app/AppSettings.cpp \
    src/app/ThemeManager.cpp \
    src/core/Document.cpp \
    src/core/FormatDetector.cpp \
    src/core/MarkdownConverter.cpp \
    src/core/TodoTxt.cpp \
    src/editor/EditorWidget.cpp \
    src/editor/LineNumberArea.cpp \
    src/editor/MarkdownHighlighter.cpp \
    src/editor/TodoTxtHighlighter.cpp \
    src/editor/FormatActions.cpp \
    src/editor/TodoTxtActions.cpp \
    src/preview/PreviewWidget.cpp \
    src/preview/HtmlPreviewView.cpp \
    src/sidebar/FileSidebar.cpp \
    src/sidebar/OutlinePanel.cpp \
    src/sidebar/SidebarHandle.cpp \
    src/browser/FileBrowserWidget.cpp \
    src/search/SearchDialog.cpp \
    src/sync/SyncManager.cpp \
    src/sync/LockClient.cpp \
    src/render/MathRenderer.cpp \
    src/render/MermaidRenderer.cpp \
    src/ui/SettingsDialog.cpp \
    src/ui/MoreDialog.cpp \
    src/ui/TodoTxtFilterDialog.cpp

HEADERS += \
    src/app/MainWindow.h \
    src/app/AppSettings.h \
    src/app/ThemeManager.h \
    src/core/Document.h \
    src/core/FormatDetector.h \
    src/core/MarkdownConverter.h \
    src/core/TodoTxt.h \
    src/editor/EditorWidget.h \
    src/editor/LineNumberArea.h \
    src/editor/MarkdownHighlighter.h \
    src/editor/TodoTxtHighlighter.h \
    src/editor/FormatActions.h \
    src/editor/TodoTxtActions.h \
    src/preview/PreviewWidget.h \
    src/preview/HtmlPreviewView.h \
    src/sidebar/FileSidebar.h \
    src/sidebar/OutlinePanel.h \
    src/sidebar/SidebarHandle.h \
    src/browser/FileBrowserWidget.h \
    src/search/SearchDialog.h \
    src/sync/SyncManager.h \
    src/sync/LockClient.h \
    src/render/MathRenderer.h \
    src/render/MermaidRenderer.h \
    src/ui/SettingsDialog.h \
    src/ui/MoreDialog.h \
    src/ui/TodoTxtFilterDialog.h

INCLUDEPATH += src

RESOURCES += resources/resources.qrc

win32 {
    TARGET = MarkorWin
    RC_FILE = resources/app.rc
    CONFIG += windows

    # WebView2（Windows 自带 Edge 内核）：HTML 文件浏览器级预览
    # 头文件/导入库随工程内置，运行期需 WebView2Loader.dll 位于 exe 同目录
    WEBVIEW2_DIR = $$PWD/third_party/webview2
    INCLUDEPATH += $$WEBVIEW2_DIR/include
    LIBS += $$WEBVIEW2_DIR/lib/x64/WebView2Loader.dll.lib
    QMAKE_POST_LINK += $$quote(cmd /c copy /y \"$$shell_path($$WEBVIEW2_DIR/bin/x64/WebView2Loader.dll)\" \"$$shell_path($$OUT_PWD)\" >nul)
}

VERSION = 2.17.0
