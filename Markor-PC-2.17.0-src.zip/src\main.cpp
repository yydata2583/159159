#include <QApplication>
#include <QCommandLineParser>
#include <QCommandLineOption>
#include <QIcon>
#include <QPalette>
#include <QTimer>
#include <QTranslator>

#include "app/MainWindow.h"
#include "app/AppSettings.h"
#include "app/ThemeManager.h"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("Markor"));
    QApplication::setApplicationDisplayName(QStringLiteral("Markor"));
    QApplication::setApplicationVersion(QStringLiteral("2.17.0"));
    QApplication::setOrganizationName(QStringLiteral("Markor"));
    app.setWindowIcon(QIcon(QStringLiteral(":/icon/markor_512.png")));

    // Localise Qt built-in strings (standard dialog buttons like
    // "Save"/"Cancel" would otherwise show up in English).
    QTranslator* qtBaseTrans = new QTranslator(&app);
    if (qtBaseTrans->load(QStringLiteral("qtbase_zh_CN"), QStringLiteral(":/i18n")))
        app.installTranslator(qtBaseTrans);
    QTranslator* qtTrans = new QTranslator(&app);
    if (qtTrans->load(QStringLiteral("qt_zh_CN"), QStringLiteral(":/i18n")))
        app.installTranslator(qtTrans);

    // Apply saved theme before building any widgets.
    AppSettings& settings = AppSettings::instance();
    QString theme = settings.theme();
    if (settings.followSystemTheme())
        theme = ThemeManager::systemThemeId();
    ThemeManager::instance().apply(theme);

    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("Markor - Markdown editor for Windows"));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument(QStringLiteral("file"),
                                 QStringLiteral("Document to open"),
                                 QStringLiteral("[file]"));
    QCommandLineOption screenshotOpt(QStringList() << "screenshot",
                                     QStringLiteral("Save a screenshot of the window to <file> and exit"),
                                     QStringLiteral("file"));
    parser.addOption(screenshotOpt);
    QCommandLineOption exportHtmlOpt(QStringList() << "export-html",
                                     QStringLiteral("Export the opened document to <html file> and exit"),
                                     QStringLiteral("file"));
    parser.addOption(exportHtmlOpt);
    QCommandLineOption exportPdfOpt(QStringList() << "export-pdf",
                                    QStringLiteral("Export the opened document to <pdf file> and exit"),
                                    QStringLiteral("file"));
    parser.addOption(exportPdfOpt);
    parser.process(app);

    MainWindow window;
    const QStringList args = parser.positionalArguments();
    window.show();
    if (!args.isEmpty())
        window.openFilePath(args.first());
    if (parser.isSet(exportHtmlOpt)) {
        window.exportHtmlTo(parser.value(exportHtmlOpt));
        QTimer::singleShot(300, &QApplication::quit);
    }
    if (parser.isSet(exportPdfOpt)) {
        window.exportPdfTo(parser.value(exportPdfOpt));
        QTimer::singleShot(300, &QApplication::quit);
    }
    if (parser.isSet(screenshotOpt)) {
        const QString out = parser.value(screenshotOpt);
        QTimer::singleShot(500, [&window, out]() {
            window.exportScreenshot(out);
            QApplication::quit();
        });
    }
    return app.exec();
}
