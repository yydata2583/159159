# 数据模型（data-model.md）

> 覆盖：文件格式识别、Todo.txt 语法与过滤表达式、文档模型、转换器输出结构、高亮状态机、**QSettings 全键表**、同步配置、内部数据结构。

---

## 1. 文本格式 `TextFormat`（core/FormatDetector.h）

```cpp
enum class TextFormat {
    Markdown, TodoTxt, PlainText, AsciiDoc, OrgMode, WikiText,
    Csv, KeyValue, Html, Code, Unknown };
```

### 1.1 扩展名 → 格式（`FormatDetector::detect`）

| 格式 | 扩展名 |
|---|---|
| Markdown | `md` `markdown` `mdown` `mkd` `mdwn` |
| TodoTxt | `todo`；`txt` 中文件名为 **`todo.txt` / `done.txt` / `*.todo.txt`** 者 |
| PlainText | `txt`（其余）+ 一切未识别扩展名 |
| AsciiDoc | `adoc` `asciidoc` `asc` |
| OrgMode | `org` |
| WikiText | `wiki` `mediawiki` |
| Csv | `csv` `tsv` |
| KeyValue | `json` `yaml` `yml` `ini` `properties` `conf` `toml` |
| Html | `html` `htm` `xhtml` `xml` `svg` `xsl` `xslt` `vue` `svelte` |
| Code | `css scss less sass js mjs cjs jsx ts tsx py pyw rb php pl pm lua go rs c h cpp cc cxx hpp hxx cs java kt kts swift scala dart groovy gradle sh bash zsh bat cmd ps1 psm1 sql r m mm asm s lisp clj hs erl ex exs tex cmake mk make dockerfile gitignore env proto graphql gql` |

辅助谓词：
- `highlightable(fmt)`：除 PlainText/Unknown 外都有高亮器；
- `isMarkdownFamily(fmt)`：**仅 `Markdown`** 为 true —— 智能回车/自动整理只对它生效；
- `fileFilter()`：文件对话框过滤器串（"All supported" 优先）。

### 1.2 格式 → 行为矩阵

| 行为 | MD | TodoTxt | AsciiDoc/Org/Wiki | CSV/KV | Html | Code | Plain |
|---|---|---|---|---|---|---|---|
| 专用高亮器 | Markdown(+lint) | TodoTxt | 共享源码高亮 | 源码高亮 | 源码高亮(HTML 模式) | 源码高亮 | 无 |
| 格式动作记号 | `**` `*` `~~` `` ` `` `#` `>` `-` | —（用 TodoTxtActions） | 各自语法（§4） | — | — | — | 同 MD 记号（fallback） |
| 富文本预览 | ✅ | ❌ | ❌ | ❌ | ✅ WebView2 | ❌ | ❌ |
| 智能回车/整理 | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

---

## 2. Todo.txt 任务语法（core/TodoTxt.cpp）

### 2.1 行语法（解析顺序固定）

```
[x ][(P)][yyyy-MM-dd ][yyyy-MM-dd ]描述文本（含 +项目 @上下文 key:value 标签）
 │    │      │           │
 │    │      │           └─ 仅已完成任务的第二个日期 = 创建日期
 │    │      └─ 未完成: 创建日期；已完成: 第一个日期 = 完成日期
 │    └─ 优先级 (A)–(Z)
 └─ 完成标记（后跟空格）
```

解析规则（`TodoTxtTask::parse`）：
- `x ` 前缀 → done；随后最多消费 **2 个**前导 `yyyy-MM-dd` 日期；
- done 行：日期[0]=完成日期、日期[1]=创建日期；未完成行：日期[0]=创建日期；
- 描述中全局提取：`\+([^\s]+)` → projects、`@([^\s]+)` → contexts、`(\w+):([^\s]+)` → tags（保留整段 `key:value`）；
- `value(key)` 从 tags 里取 `key:` 前缀项的值（如 `due:2026-01-01`）；
- **序列化 `line()` 直接返回 `_raw`（原始行）**——`setDone()/setPriority()/setDescription()` 只改内存字段，不会自动重排原文。需要落盘时由 `TodoTxtActions` 直接按行文本正则改写（注意这一设计差异！）。

### 2.2 行为层（editor/TodoTxtActions.cpp）对行的改写规则

| 动作 | 改写 |
|---|---|
| `toggleDone` | 完成：行首加 `x yyyy-MM-dd `；重开：删除 `^x\s+(日期\s+)?` |
| `cyclePriority` | A→B→C→无→A；优先级插在 `x [date] ` 之后；先 `stripPriority` 再插入 |
| `setPriority(p)` | 同上显式设置/清除 |
| `insertToday` / `appendToday` | 光标处插入 / 行尾追加 `yyyy-MM-dd` |
| `setDueDate` | 替换/添加 `due:yyyy-MM-dd`（弹窗校验日期） |
| `archiveDone` | 所有 `x ` 开头行移出，**追加**到同目录 `done.txt`（UTF-8，Append）；未保存文件拒绝执行 |
| `sortByPriority` | 活跃在前（按优先级），已完成在后（按完成日期）；空行丢弃 |

---

## 3. Todo.txt 过滤表达式（`TodoTxtFilter::matches`）

```
token 语法：
  文本子串        → 对整行做 contains 匹配
  +project        → 项目匹配
  @context        → 上下文匹配
  pri:A           → 优先级匹配（大写化后比较单字符）
  done | undone | open → 完成状态
  key:value       → 标签值精确匹配（如 due:2026-01-01）
  -<token>        → 对任意 token 取反
多 token 以空白分隔，**AND 语义**；空过滤串 = 全部匹配；大小写敏感可选（默认不敏感）。
```

---

## 4. 文档模型与转换器数据结构

### 4.1 `Document`（core/Document.h）
薄封装：`_path` + `_format`；`load()/save()`（UTF-8）、`exists()/isWritable()`、`fileName()/dirPath()`。⚠️ 编辑器当前**直接**按路径读写（`EditorWidget::loadFile/saveFile`），Document 类为语义层预留。

### 4.2 `MarkdownConverter`（core/MarkdownConverter.h）

```cpp
struct ConvertOptions { bool softBreaks = true; };   // 单换行→<br>（Markor 风格）
struct BlockInfo { int srcLine; bool isTable; bool isPre; QString slug; };
QString toHtmlFragment(md, options = {}, QVector<BlockInfo>* blocks = nullptr);
QString toHtmlDocument(md, bool darkTheme, options = {});
QString wrapHtmlDocument(bodyHtml, bool darkTheme, int fontPx = 15, bool withScripts = false);
```

- 输出 HTML 的**每个块级元素**注入 `data-src-line="源行号(1 起)"`；
- `blocks` 与输出块序 **一一对应**（预览滚动映射的生命线，勿破坏顺序）；
- `slug`：标题锚点 id（仅标题块），供大纲/锚点跳转；
- `wrapHtmlDocument(fontPx, withScripts)`：`withScripts=true` 附加"复制按钮/任务勾选/平滑锚点"脚本——**仅供浏览器导出**；
- 合规范围 = CommonMark 0.31.2 + GFM（表格/任务列表/删除线/自动链接）+ YAML front-matter 透传；已知 3 条差异见 architecture §11。

### 4.3 `EditorWidget::Snapshot`
```cpp
struct Snapshot { QString text; int cursor; };  // 快照历史条目（上限 50，400ms 停顿存档）
```

### 4.4 `PreviewWidget::Elem`（源行映射条目）
```cpp
struct Elem { int srcLine; bool isTable; bool isPre; QString slug;
              QTextBlock block; QTextTable* table; };
```
与 `BlockInfo` + QTextDocument 根级子元素对齐；`_mappingValid=false` 时降级比例估算。

### 4.5 `MarkdownHighlighter` 块状态机
```
setCurrentBlockState:
  0 StateNormal    普通文本
  1 StateTableRow  表格分隔行/数据行
  2 StateOrphanPipe 缺分隔行的管道文本（仅首行告警）
  3 StateTableHead 合法表头行（下一行是分隔行）
  围栏状态: 1000+开围栏反引号长度 | 2000+开围栏波浪线长度（≥1000 判定在围栏内）
```

### 4.6 `OutlinePanel::Heading`
```cpp
struct Heading { QString text; QString slug; int level; /*1..4*/ int line; };
```

---

## 5. QSettings 全键表 ⭐（`AppSettings`，唯一持久化入口）

- 后端：`QSettings(IniFormat, UserScope, "Markor", "MarkorWin")`
- 位置：Windows `%APPDATA%\Markor\MarkorWin.ini`
- 读写：全部经 `AppSettings::instance()`；结束时 `sync()`

| 键 | 类型 | 默认值 | 含义 / 范围 |
|---|---|---|---|
| `appearance/theme` | QString | `"light"` | `light` / `dark` / `sakura` |
| `appearance/followSystem` | bool | `true` | 启动按系统深浅色；手动选主题会置 false |
| `editor/fontFamily` | QString | `"Consolas"` | 编辑器字体 |
| `editor/fontSize` | int | `12` | 字号 pt |
| `editor/wordWrap` | bool | `true` | 自动换行 |
| `editor/lineNumbers` | bool | `true` | 行号显示 |
| `editor/syntaxHighlighting` | bool | `true` | 语法高亮 |
| `preview/followEditor` | bool | `true` | 预览跟随编辑滚动 |
| `preview/softBreaks` | bool | `true` | 单换行渲染为 `<br>` |
| `preview/fontSize` | int | `15` | 预览正文字号 px（Ctrl+滚轮） |
| `files/vaultDir` | QString | `文档目录/Markor` | 文档库根目录 |
| `files/favorites` | QStringList | 空 | 收藏路径（toggleFavorite 头插/移除） |
| `files/recents` | QStringList | 空 | 最近文件，**上限 20**（addRecent 头插去重，超限删尾）；变更发 `recentsChanged()` |
| `window/geometry` | QByteArray | 空 | `saveGeometry()` |
| `window/state` | QByteArray | 空 | `saveState()`（工具栏/停靠） |
| `window/splitterState` | QByteArray | 空 | 编辑/预览分割条（所有页共用一份；拖拽停 300ms 落盘） |
| `sidebar/fileVisible` | bool | `true` | 文件侧边栏展开 |
| `sidebar/fileWidth` | int | `240` | 侧边栏内容宽（钳制 180–420；<110 释放即自动收起） |
| `sidebar/fileTab` | int | `0` | 0=最近 1=文件 |
| `sidebar/outlineDefaultExpanded` | bool | `true` | 大纲默认展开（设置项） |
| `sidebar/outlineExpanded` | bool | *(缺省=取默认)* | 大纲**手动**状态，覆盖默认值 |
| `sidebar/outlineWidth` | int | `200` | 大纲内容宽（180–220） |
| `sync/enabled` | bool | `false` | 启用同步（仅软件运行期间生效） |
| `sync/deviceName` | QString | `QHostInfo::localHostName()` | 本机设备名 |
| `sync/serverDeviceId` | QString | **空** | 服务器（NAS）Syncthing 设备 ID（旧键 `sync/nasDeviceId` 兼容读取） |
| `sync/serverSyncAddress` | QString | **空** | 服务器同步地址，如 `tcp://IP:22000`（旧 relay 键已废弃） |
| `sync/serverApi` | QString | **空** | 服务器锁 API 地址，如 `http://IP:8910` |
| `sync/serverApiKey` | QString | **空** | 锁 API 密钥（Bearer） |

> 产品要求：**服务器信息一律默认为空、不写死**；连接服务器成功/失败都弹窗提示。

---

## 6. 同步子系统数据（sync/SyncManager.cpp + LockClient.cpp）

| 项 | 值 |
|---|---|
| 引擎 | `syncthing.exe`（查找：exe 同目录 → `bin\` 子目录，兼容安装包布局；缺失→弹窗提示并停用） |
| home | `%LOCALAPPDATA%\Markor\MarkorWin\syncthing`（`AppLocalDataLocation/syncthing`） |
| 日志 | `<home>/syncthing.log` |
| GUI/API | `http://127.0.0.1:8385`（**host:port 形式启动**、`gui.tls=false` 明文），API Key=每次运行随机 UUID |
| 轮询 | `rest/system/status` 每 1.5s × 40 次拿 `myID` |
| 连接探测 | `rest/system/connections` 每 3s × 10 次，看服务器设备 `connected` → 弹窗成功/失败 |
| 共享文件夹 | id=`markor-vault`，label=`Markor`，path=**当前** `files/vaultDir`（mkpath；每次应用重取，修路径错位），devices=[本机, 服务器] |
| 服务器设备 | name=`markor-server`，`compression=metadata`，`addresses=[sync/serverSyncAddress]`（空→`["dynamic"]`），**无 introducer** |
| 选项 | `relaysEnabled=false`、`globalAnnounceEnabled=false`、`localAnnounceEnabled=false`、`autoUpgradeIntervalH=0`（无自升级） |
| 文件锁 | lockserver API：open/heartbeat(30s)/close，Bearer `sync/serverApiKey`，vault_id=`markor-vault`，path=vault 相对路径 |
| 冲突 | 锁只做提示；真正的写冲突由 Syncthing `.sync-conflict-*` 文件兜底 |

---

## 7. 其他数据约定

| 项 | 约定 |
|---|---|
| 文件编码 | 一律 UTF-8（读写 `QTextStream::setEncoding(Utf8)`） |
| 行号体系 | 源行号 **1 起**；编辑器块号 + 1 = 源行号 |
| 日期格式 | todo.txt 一律 `yyyy-MM-dd`（`QDate::fromString` 严格匹配） |
| 归档文件 | `done.txt`（与 todo.txt 同目录，追加写） |
| 新建文档 | 标题"未命名"，默认 Markdown；无扩展名保存时补 `.md` |
| 脏标记 | `_cleanText` 基线对比（载入/保存时更新），非 `isModified()` |
| 主题色 | 唯一来源 `ThemeManager` 取色函数（见 architecture §6） |
| 图片内嵌 | 屏幕/HTML 导出 = data URI；PDF 导出 = 具名资源 + `QTextDocument::addResource` |
| 版本号 | `2.17.0`（`main.cpp` setApplicationVersion、`resources/app.rc`、`CMakeLists project(VERSION)`、`markor-win.pro VERSION`——**四处同步改**） |
