#pragma once
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QRegularExpression>

class QTextDocument;

// Syntax highlighter for todo.txt: priority (A), +projects, @contexts,
// key:value tags, completion 'x' and dates.
class TodoTxtHighlighter : public QSyntaxHighlighter {
    Q_OBJECT
public:
    explicit TodoTxtHighlighter(QTextDocument* parent = nullptr);
    void refreshFormats();

protected:
    void highlightBlock(const QString& text) override;

private:
    QRegularExpression _priA, _priB, _priC, _project, _context, _tag, _done, _date;
    QTextCharFormat _fPriA, _fPriB, _fPriC, _fProject, _fContext, _fTag, _fDone, _fDate;
    void buildRules();
};
