#pragma once
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QRegularExpression>
#include <QVector>
#include <QString>

class QTextDocument;

// 通用源码高亮：关键字 / 字符串 / 数字 / 注释；HTML/XML 模式额外高亮标签名、
// 属性名与实体引用。关键字集为跨语言合并的超集，注释风格按文件扩展名族选择。
// 颜色取自 ThemeManager，随主题变化由 EditorWidget 重建实例刷新。
class SourceCodeHighlighter : public QSyntaxHighlighter {
    Q_OBJECT
public:
    explicit SourceCodeHighlighter(QTextDocument* parent = nullptr);

    // 按文件扩展名选择语言族（注释风格、块注释语法、是否 HTML 模式）
    void setExtension(const QString& ext);

    // 主题变化后重取颜色并重刷（可选，EditorWidget 通常直接重建实例）
    void refreshFormats();

protected:
    void highlightBlock(const QString& text) override;

private:
    struct Rule {
        QRegularExpression pattern;
        QTextCharFormat format;
    };

    void rebuild();
    void buildCodeRules();
    void buildHtmlRules();

    QString _ext;
    bool _htmlMode = false;
    bool _hashComment = false;   // # 起始的行注释（py/sh/yaml...）
    bool _dashComment = false;   // -- 起始的行注释（sql/lua）
    bool _semiComment = false;   // ; 起始的行注释（asm/lisp）
    bool _pctComment = false;    // % 起始的行注释（tex/matlab/erlang）
    bool _cppBlockComment = false; // /* ... */ 块注释

    QVector<Rule> _rules;
    QRegularExpression _blockCommentStart;
    QRegularExpression _blockCommentEnd;
    QRegularExpression _htmlCommentStart;
    QRegularExpression _htmlCommentEnd;

    QTextCharFormat _keyword, _number, _string, _comment, _tag, _attr, _entity;

    enum State { StateNormal = 0, StateBlockComment = 1, StateHtmlComment = 2 };
};
