#include "AppSettings.h"
#include <QStandardPaths>
#include <QDir>
#include <QFileInfo>
#include <QHostInfo>

namespace {
// 同一文件可能以不同大小写/分隔符写入最近列表（Windows 路径大小写不敏感），
// 统一成绝对路径小写做去重键，避免“最近”里出现同一文件的多个条目。
QString recentsKey(const QString& p)
{
    return QDir::cleanPath(QFileInfo(p).absoluteFilePath()).toLower();
}
}

AppSettings& AppSettings::instance()
{
    static AppSettings s;
    return s;
}

AppSettings::AppSettings(QObject* parent)
    : QObject(parent)
    , _s(QSettings::IniFormat, QSettings::UserScope, QStringLiteral("Markor"), QStringLiteral("MarkorWin"))
{
}

// --- Appearance ---
QString AppSettings::theme() const
{
    return _s.value(QStringLiteral("appearance/theme"), QStringLiteral("light")).toString();
}
void AppSettings::setTheme(const QString& theme)
{
    _s.setValue(QStringLiteral("appearance/theme"), theme);
}

bool AppSettings::followSystemTheme() const
{
    return _s.value(QStringLiteral("appearance/followSystem"), true).toBool();
}
void AppSettings::setFollowSystemTheme(bool on)
{
    _s.setValue(QStringLiteral("appearance/followSystem"), on);
}

QString AppSettings::editorFontFamily() const
{
    return _s.value(QStringLiteral("editor/fontFamily"), QStringLiteral("Consolas")).toString();
}
void AppSettings::setEditorFontFamily(const QString& family)
{
    _s.setValue(QStringLiteral("editor/fontFamily"), family);
}

int AppSettings::editorFontSize() const
{
    return _s.value(QStringLiteral("editor/fontSize"), 12).toInt();
}
void AppSettings::setEditorFontSize(int pt)
{
    _s.setValue(QStringLiteral("editor/fontSize"), pt);
}

// --- Editor behaviour ---
bool AppSettings::wordWrap() const
{
    return _s.value(QStringLiteral("editor/wordWrap"), true).toBool();
}
void AppSettings::setWordWrap(bool on)
{
    _s.setValue(QStringLiteral("editor/wordWrap"), on);
}

bool AppSettings::lineNumbers() const
{
    return _s.value(QStringLiteral("editor/lineNumbers"), true).toBool();
}
void AppSettings::setLineNumbers(bool on)
{
    _s.setValue(QStringLiteral("editor/lineNumbers"), on);
}

bool AppSettings::syntaxHighlighting() const
{
    return _s.value(QStringLiteral("editor/syntaxHighlighting"), true).toBool();
}
void AppSettings::setSyntaxHighlighting(bool on)
{
    _s.setValue(QStringLiteral("editor/syntaxHighlighting"), on);
}

bool AppSettings::previewFollowEditor() const
{
    // 默认开启：编辑区滚动时预览按内容跟随（可在设置中关闭）
    return _s.value(QStringLiteral("preview/followEditor"), true).toBool();
}
void AppSettings::setPreviewFollowEditor(bool on)
{
    _s.setValue(QStringLiteral("preview/followEditor"), on);
}

bool AppSettings::previewSoftBreaks() const
{
    return _s.value(QStringLiteral("preview/softBreaks"), true).toBool();
}
void AppSettings::setPreviewSoftBreaks(bool on)
{
    _s.setValue(QStringLiteral("preview/softBreaks"), on);
}

int AppSettings::previewFontSize() const
{
    return _s.value(QStringLiteral("preview/fontSize"), 15).toInt();
}
void AppSettings::setPreviewFontSize(int px)
{
    _s.setValue(QStringLiteral("preview/fontSize"), px);
}
QString AppSettings::previewFontFamily() const
{
    return _s.value(QStringLiteral("preview/fontFamily"),
                    QStringLiteral("Segoe UI")).toString();
}
void AppSettings::setPreviewFontFamily(const QString& family)
{
    _s.setValue(QStringLiteral("preview/fontFamily"), family);
}

// --- Files / vault ---
QString AppSettings::vaultDir() const
{
    QString def = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)
                  + QStringLiteral("/Markor");
    QString v = _s.value(QStringLiteral("files/vaultDir"), def).toString();
    return v;
}
void AppSettings::setVaultDir(const QString& dir)
{
    _s.setValue(QStringLiteral("files/vaultDir"), dir);
}

QStringList AppSettings::favorites() const
{
    return _s.value(QStringLiteral("files/favorites")).toStringList();
}
void AppSettings::setFavorites(const QStringList& paths)
{
    _s.setValue(QStringLiteral("files/favorites"), paths);
}
bool AppSettings::isFavorite(const QString& path) const
{
    return favorites().contains(path);
}
void AppSettings::toggleFavorite(const QString& path)
{
    QStringList f = favorites();
    if (f.contains(path))
        f.removeAll(path);
    else
        f.prepend(path);
    setFavorites(f);
}

QStringList AppSettings::recents() const
{
    const QStringList raw = _s.value(QStringLiteral("files/recents")).toStringList();
    QStringList out;
    QStringList keys;
    for (const QString& p : raw) {           // 显示层再去重一次，兼容历史脏数据
        const QString k = recentsKey(p);
        if (keys.contains(k))
            continue;
        keys.append(k);
        out.append(p);
    }
    return out;
}
void AppSettings::addRecent(const QString& path)
{
    const QString key = recentsKey(path);
    QStringList r;
    for (const QString& p : recents())
        if (recentsKey(p) != key)
            r.append(p);
    r.prepend(path);
    while (r.size() > 20)
        r.removeLast();
    _s.setValue(QStringLiteral("files/recents"), r);
    emit recentsChanged();
}
void AppSettings::renameRecent(const QString& oldPath, const QString& newPath)
{
    const QString key = recentsKey(oldPath);
    QStringList r = recents();
    bool found = false;
    for (QString& p : r) {
        if (recentsKey(p) == key) { p = newPath; found = true; }
    }
    if (!found)
        return;
    _s.setValue(QStringLiteral("files/recents"), r);
    emit recentsChanged();
}
void AppSettings::removeRecent(const QString& path)
{
    const QString key = recentsKey(path);
    const QStringList r0 = recents();
    QStringList r;
    bool found = false;
    for (const QString& p : r0) {
        if (recentsKey(p) == key) { found = true; continue; }
        r.append(p);
    }
    if (!found)
        return;
    _s.setValue(QStringLiteral("files/recents"), r);
    emit recentsChanged();
}
void AppSettings::clearRecents()
{
    _s.remove(QStringLiteral("files/recents"));
    emit recentsChanged();
}

QStringList AppSettings::sessionFiles() const
{
    return _s.value(QStringLiteral("session/files")).toStringList();
}
void AppSettings::setSessionFiles(const QStringList& paths)
{
    _s.setValue(QStringLiteral("session/files"), paths);
}
int AppSettings::sessionCurrentIndex() const
{
    return _s.value(QStringLiteral("session/currentIndex"), 0).toInt();
}
void AppSettings::setSessionCurrentIndex(int idx)
{
    _s.setValue(QStringLiteral("session/currentIndex"), idx);
}

// --- Window ---
// --- Sync (embedded Syncthing; no lock client) ---
bool AppSettings::syncEnabled() const
{
    return _s.value(QStringLiteral("sync/enabled"), false).toBool();
}
void AppSettings::setSyncEnabled(bool on)
{
    _s.setValue(QStringLiteral("sync/enabled"), on);
}

QString AppSettings::syncDeviceName() const
{
    return _s.value(QStringLiteral("sync/deviceName"),
                    QHostInfo::localHostName()).toString();
}
void AppSettings::setSyncDeviceName(const QString& name)
{
    _s.setValue(QStringLiteral("sync/deviceName"), name);
}

QString AppSettings::syncServerDeviceId() const
{
    // 兼容旧键 sync/nasDeviceId（历史版本），其余服务器信息默认一律为空
    QString v = _s.value(QStringLiteral("sync/serverDeviceId")).toString();
    if (v.isEmpty())
        v = _s.value(QStringLiteral("sync/nasDeviceId")).toString();
    return v;
}
void AppSettings::setSyncServerDeviceId(const QString& id)
{
    _s.setValue(QStringLiteral("sync/serverDeviceId"), id);
}

QString AppSettings::syncServerSyncAddress() const
{
    return _s.value(QStringLiteral("sync/serverSyncAddress")).toString();
}
void AppSettings::setSyncServerSyncAddress(const QString& addr)
{
    _s.setValue(QStringLiteral("sync/serverSyncAddress"), addr);
}

QString AppSettings::syncServerApi() const
{
    return _s.value(QStringLiteral("sync/serverApi")).toString();
}
void AppSettings::setSyncServerApi(const QString& url)
{
    _s.setValue(QStringLiteral("sync/serverApi"), url);
}

QString AppSettings::syncServerApiKey() const
{
    return _s.value(QStringLiteral("sync/serverApiKey")).toString();
}
void AppSettings::setSyncServerApiKey(const QString& key)
{
    _s.setValue(QStringLiteral("sync/serverApiKey"), key);
}

QByteArray AppSettings::windowGeometry() const
{
    return _s.value(QStringLiteral("window/geometry")).toByteArray();
}
void AppSettings::setWindowGeometry(const QByteArray& g)
{
    _s.setValue(QStringLiteral("window/geometry"), g);
}
QByteArray AppSettings::windowState() const
{
    return _s.value(QStringLiteral("window/state")).toByteArray();
}
void AppSettings::setWindowState(const QByteArray& s)
{
    _s.setValue(QStringLiteral("window/state"), s);
}

QByteArray AppSettings::splitterState() const
{
    return _s.value(QStringLiteral("window/splitterState")).toByteArray();
}
void AppSettings::setSplitterState(const QByteArray& s)
{
    _s.setValue(QStringLiteral("window/splitterState"), s);
}

// --- 双侧边栏（批次2） ---
bool AppSettings::fileSidebarVisible() const
{
    return _s.value(QStringLiteral("sidebar/fileVisible"), true).toBool();
}
void AppSettings::setFileSidebarVisible(bool on)
{
    _s.setValue(QStringLiteral("sidebar/fileVisible"), on);
}

int AppSettings::fileSidebarWidth() const
{
    return _s.value(QStringLiteral("sidebar/fileWidth"), 240).toInt();
}
void AppSettings::setFileSidebarWidth(int px)
{
    _s.setValue(QStringLiteral("sidebar/fileWidth"), px);
}

int AppSettings::fileSidebarTab() const
{
    return _s.value(QStringLiteral("sidebar/fileTab"), 0).toInt();
}
void AppSettings::setFileSidebarTab(int tab)
{
    _s.setValue(QStringLiteral("sidebar/fileTab"), tab);
}

bool AppSettings::outlineDefaultExpanded() const
{
    return _s.value(QStringLiteral("sidebar/outlineDefaultExpanded"), true).toBool();
}
void AppSettings::setOutlineDefaultExpanded(bool on)
{
    _s.setValue(QStringLiteral("sidebar/outlineDefaultExpanded"), on);
}

bool AppSettings::outlineExpanded() const
{
    // 手动展开/收起状态优先；从未手动操作则取设置里的默认值
    if (_s.contains(QStringLiteral("sidebar/outlineExpanded")))
        return _s.value(QStringLiteral("sidebar/outlineExpanded")).toBool();
    return outlineDefaultExpanded();
}
void AppSettings::setOutlineExpanded(bool on)
{
    _s.setValue(QStringLiteral("sidebar/outlineExpanded"), on);
}

int AppSettings::outlineWidth() const
{
    return _s.value(QStringLiteral("sidebar/outlineWidth"), 200).toInt();
}

bool AppSettings::outlineAutoCollapse() const
{
    return _s.value(QStringLiteral("sidebar/outlineAutoCollapse"), true).toBool();
}
void AppSettings::setOutlineAutoCollapse(bool on)
{
    _s.setValue(QStringLiteral("sidebar/outlineAutoCollapse"), on);
}
void AppSettings::setOutlineWidth(int px)
{
    _s.setValue(QStringLiteral("sidebar/outlineWidth"), px);
}

void AppSettings::sync()
{
    _s.sync();
}
