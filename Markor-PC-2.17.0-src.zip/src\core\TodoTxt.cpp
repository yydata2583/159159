#include "TodoTxt.h"
#include <QRegularExpression>

static QDate parseDate(const QString& s)
{
    return QDate::fromString(s, QStringLiteral("yyyy-MM-dd"));
}

TodoTxtTask::TodoTxtTask(const QString& line)
{
    parse(line);
}

void TodoTxtTask::setLine(const QString& line)
{
    parse(line);
}

void TodoTxtTask::parse(const QString& line)
{
    _raw = line;
    _done = false;
    _priority = QChar();
    _completionDate = QDate();
    _creationDate = QDate();
    _projects.clear();
    _contexts.clear();
    _tags.clear();

    QString rest = line.trimmed();

    // completed marker
    if (rest.startsWith(QStringLiteral("x "))) {
        _done = true;
        rest = rest.mid(2).trimmed();
    }

    // priority (A) .. may follow 'x '
    static const QRegularExpression priRe(QStringLiteral("^\\(([A-Z])\\)\\s+"));
    QRegularExpressionMatch pm = priRe.match(rest);
    if (pm.hasMatch()) {
        _priority = pm.captured(1).at(0);
        rest = rest.mid(pm.captured(0).size());
    }

    // dates: completion date then creation date (for done tasks)
    static const QRegularExpression dateRe(QStringLiteral("^(\\d{4}-\\d{2}-\\d{2})\\s+"));
    QStringList dates;
    while (true) {
        QRegularExpressionMatch dm = dateRe.match(rest);
        if (!dm.hasMatch()) break;
        dates << dm.captured(1);
        rest = rest.mid(dm.captured(0).size());
        if (dates.size() >= 2) break;
    }
    if (_done) {
        if (dates.size() >= 1) _completionDate = parseDate(dates[0]);
        if (dates.size() >= 2) _creationDate = parseDate(dates[1]);
    } else {
        if (dates.size() >= 1) _creationDate = parseDate(dates[0]);
    }

    // remaining is description; extract +project @context key:value
    _description = rest;

    static const QRegularExpression projRe(QStringLiteral("\\+([^\\s]+)"));
    QRegularExpressionMatchIterator pit = projRe.globalMatch(rest);
    while (pit.hasNext()) _projects << pit.next().captured(1);

    static const QRegularExpression ctxRe(QStringLiteral("@([^\\s]+)"));
    QRegularExpressionMatchIterator cit = ctxRe.globalMatch(rest);
    while (cit.hasNext()) _contexts << cit.next().captured(1);

    static const QRegularExpression tagRe(QStringLiteral("(\\w+):([^\\s]+)"));
    QRegularExpressionMatchIterator tit = tagRe.globalMatch(rest);
    while (tit.hasNext()) _tags << tit.next().captured(0);
}

QString TodoTxtTask::line() const
{
    return _raw;
}

QString TodoTxtTask::description() const
{
    return _description;
}

void TodoTxtTask::setDescription(const QString& d)
{
    _description = d;
}

bool TodoTxtTask::isDone() const { return _done; }
QChar TodoTxtTask::priority() const { return _priority; }
QDate TodoTxtTask::completionDate() const { return _completionDate; }
QDate TodoTxtTask::creationDate() const { return _creationDate; }
QStringList TodoTxtTask::projects() const { return _projects; }
QStringList TodoTxtTask::contexts() const { return _contexts; }
QStringList TodoTxtTask::tags() const { return _tags; }

void TodoTxtTask::setDone(bool done)
{
    _done = done;
    if (done && !_completionDate.isValid())
        _completionDate = QDate::currentDate();
    if (!done)
        _completionDate = QDate();
}

void TodoTxtTask::setPriority(QChar p)
{
    _priority = p;
}

QString TodoTxtTask::value(const QString& key) const
{
    const QString prefix = key + QLatin1Char(':');
    for (const QString& t : _tags) {
        if (t.startsWith(prefix))
            return t.mid(prefix.size());
    }
    return QString();
}

TodoTxtTask TodoTxtTask::fromParts(bool done, QChar priority, const QString& description)
{
    TodoTxtTask t;
    t._done = done;
    t._priority = priority;
    t._description = description;
    if (done) t._completionDate = QDate::currentDate();
    t._creationDate = QDate::currentDate();
    return t;
}

namespace TodoTxtFilter {

bool matches(const TodoTxtTask& task, const QString& filter, bool caseSensitive)
{
    const QString f = filter.trimmed();
    if (f.isEmpty()) return true;

    const Qt::CaseSensitivity cs = caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive;
    const QStringList tokens = f.split(QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);

    // AND semantics across tokens
    for (const QString& raw : tokens) {
        bool neg = raw.startsWith(QLatin1Char('-'));
        QString tok = neg ? raw.mid(1) : raw;
        bool ok = false;

        if (tok.compare(QStringLiteral("done"), cs) == 0) {
            ok = task.isDone();
        } else if (tok.compare(QStringLiteral("undone"), cs) == 0
                   || tok.compare(QStringLiteral("open"), cs) == 0) {
            ok = !task.isDone();
        } else if (tok.startsWith(QStringLiteral("pri:"), cs)) {
            QString pri = tok.mid(4).toUpper();
            ok = (!pri.isEmpty()) && task.priority() == pri.at(0);
        } else if (tok.startsWith(QLatin1Char('+'))) {
            ok = task.projects().contains(tok.mid(1), cs);
        } else if (tok.startsWith(QLatin1Char('@'))) {
            ok = task.contexts().contains(tok.mid(1), cs);
        } else if (tok.contains(QLatin1Char(':'))) {
            QStringList kv = tok.split(QLatin1Char(':'));
            ok = task.value(kv[0]).compare(kv[1], cs) == 0;
        } else {
            ok = task.line().contains(tok, cs);
        }

        if (neg) ok = !ok;
        if (!ok) return false;
    }
    return true;
}

} // namespace TodoTxtFilter
