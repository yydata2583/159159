#pragma once
#include <QDialog>

class QComboBox;
class QSpinBox;
class QCheckBox;
class QFontComboBox;

// Application settings: appearance (theme incl. Sakura), editor behaviour,
// font and vault location.
class SettingsDialog : public QDialog {
    Q_OBJECT
public:
    explicit SettingsDialog(QWidget* parent = nullptr);

signals:
    void themeChanged(const QString& themeId);
    void editorSettingsChanged();
    void previewSettingsChanged();   // 预览相关设置（跟随/软换行）变更
    void vaultChanged(const QString& dir);
    void syncSettingsChanged();

private slots:
    void applyAndClose();
    void browseVault();

protected:
    // 字号框获得焦点（点击/Tab 进入）时立即显示 Ctrl+滚轮提示，
    // 不必等待鼠标悬停延迟
    bool eventFilter(QObject* obj, QEvent* event) override;

private:
    QComboBox* _themeCombo;
    QFontComboBox* _fontCombo;
    QSpinBox* _fontSize;
    QCheckBox* _wordWrap;
    QCheckBox* _lineNumbers;
    QCheckBox* _highlighting;
    QCheckBox* _followSystem;
    QCheckBox* _previewFollow;
    QCheckBox* _previewSoftBreaks;
    QComboBox* _outlineDefault;   // 大纲面板默认展开/收起
    QFontComboBox* _previewFontCombo;  // 预览窗口字体
    QSpinBox* _previewFontSize;        // 预览窗口字号（px，10~28 与 Ctrl+滚轮一致）
    class QLineEdit* _vaultEdit;
    // Sync (embedded Syncthing + lock client; star topology)
    QCheckBox* _syncEnabled;
    class QLineEdit* _syncDeviceName;
    class QLineEdit* _syncServerId;      // 服务器设备 ID（默认空）
    class QLineEdit* _syncServerAddr;    // Syncthing 服务器地址 tcp://… （发现服务器）
    class QLineEdit* _syncServerApi;     // 服务器地址 http://…:8910 （锁文件监听地址）
    class QLineEdit* _syncServerApiKey;  // API Key（锁文件 Bearer Key，提示已打开窗口）
};
