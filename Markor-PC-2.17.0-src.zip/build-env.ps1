# Markor build environment - MSVC 14.44.35207 + Windows SDK 10.0.26100.0 + Qt 6.8.3
# Must be dot-sourced: . .\build-env.ps1
$ErrorActionPreference = 'Continue'

$vsRoot  = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools'
$msvc    = "$vsRoot\VC\Tools\MSVC\14.44.35207"
$sdkRoot = 'C:\Program Files (x86)\Windows Kits\10'
$sdkVer  = '10.0.26100.0'
$qt      = 'C:\Qt\6.8.3\msvc2022_64'
$cmakeB  = 'C:\Users\Administrator\AppData\Local\Microsoft\WinGet\Packages\Kitware.CMake_Microsoft.Winget.Source_8wekyb3d8bbwe\cmake-4.4.4-windows-x86_64\bin'
$ninjaB  = "$vsRoot\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja"

$env:PATH  = "$msvc\bin\Hostx64\x64;$qt\bin;$sdkRoot\bin\$sdkVer\x64;$cmakeB;$ninjaB;$env:PATH"
$env:INCLUDE = "$msvc\include;$sdkRoot\Include\$sdkVer\ucrt;$sdkRoot\Include\$sdkVer\um;$sdkRoot\Include\$sdkVer\shared;$sdkRoot\Include\$sdkVer\winrt"
$env:LIB     = "$msvc\lib\x64;$sdkRoot\Lib\$sdkVer\ucrt\x64;$sdkRoot\Lib\$sdkVer\um\x64"
$env:VCINSTALLDIR = "$vsRoot\"
