#pragma once
#include <QPixmap>
#include <QColor>
#include <QString>

// Lightweight LaTeX math renderer (KaTeX-style subset) drawn with QPainter.
// Supports: variables/digits/operators, superscript/subscript, \frac, \sqrt,
// Greek letters, common operators (sum/int/prod/infty/le/ge/ne/to/pm/...),
// \left \right fences and named symbols. Unknown commands degrade to text.
namespace MathRenderer {
    // Render an expression to a pixmap at the given point size.
    QPixmap render(const QString& latex, int pointSize,
                   const QColor& fg, const QColor& bg = Qt::transparent);
}
