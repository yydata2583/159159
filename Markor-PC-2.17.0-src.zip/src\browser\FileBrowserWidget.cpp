#include "FileBrowserWidget.h"
#include "app/AppSettings.h"

#include <QVBoxLayout>
#include <QMenu>
#include <QContextMenuEvent>
#include <QAbstractItemView>
#include <QFile>
#include <QInputDialog>
#include <QMessageBox>
#include <QDir>
#include <QLabel>
#include <QDialog>
#include <QCheckBox>
#include <QDialogButtonBox>
#include <QPushButton>

FileBrowserWidget::FileBrowserWidget(QWidget* parent)
    : QWidget(parent)
{
    // 紧凑树：无标题栏（嵌入文件侧边栏的「文件」Tab）；新建/刷新走右键菜单
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(2, 2, 2, 2);

    _model = new QFileSystemModel(this);
    _model->setFilter(QDir::AllDirs | QDir::Files | QDir::NoDotAndDotDot);
    _model->setNameFilterDisables(false);
    _model->setNameFilters({QStringLiteral("*.md"), QStringLiteral("*.markdown"),
                            QStringLiteral("*.txt"), QStringLiteral("*.todo"),
                            QStringLiteral("*.adoc"), QStringLiteral("*.org"),
                            QStringLiteral("*.wiki"), QStringLiteral("*.csv"),
                            QStringLiteral("*.json"), QStringLiteral("*.yaml"),
                            QStringLiteral("*.yml"), QStringLiteral("*.ini")});

    _tree = new QTreeView(this);
    _tree->setModel(_model);
    _tree->setAnimated(true);
    _tree->setSortingEnabled(true);
    _tree->sortByColumn(0, Qt::AscendingOrder);
    _tree->setHeaderHidden(true);
    // 重命名统一走右键菜单，避免慢双击误触发行内编辑
    _tree->setEditTriggers(QAbstractItemView::NoEditTriggers);
    _tree->setMinimumWidth(0);   // 侧边栏拖拽/收起时允许压缩
    for (int i = 1; i < _model->columnCount(); ++i)
        _tree->hideColumn(i);

    // 单击文件即打开（S1.7）；目录的折叠/展开仍由 QTreeView 默认行为处理
    connect(_tree, &QTreeView::clicked, this, &FileBrowserWidget::onClicked);

    layout->addWidget(_tree);
}

void FileBrowserWidget::setRootPath(const QString& path)
{
    _rootPath = path;
    QDir().mkpath(path);
    QModelIndex root = _model->setRootPath(path);
    _tree->setRootIndex(root);
}

QString FileBrowserWidget::rootPath() const
{
    return _rootPath;
}

void FileBrowserWidget::refresh()
{
    _model->setRootPath(QString());
    _model->setRootPath(_rootPath);
}

void FileBrowserWidget::onClicked(const QModelIndex& index)
{
    if (_model->isDir(index))
        return;
    emit fileActivated(_model->filePath(index));
}

void FileBrowserWidget::selectPath(const QString& path)
{
    if (path.isEmpty() || !QFile::exists(path)) {
        _tree->clearSelection();
        return;
    }
    QModelIndex idx = _model->index(path);
    if (!idx.isValid())
        return;
    // 逐级展开父目录，否则目标行不可见、无法滚动到位
    QModelIndex p = idx.parent();
    while (p.isValid()) {
        _tree->setExpanded(p, true);
        p = p.parent();
    }
    _tree->setCurrentIndex(idx);
    _tree->scrollTo(idx, QAbstractItemView::PositionAtCenter);
}

void FileBrowserWidget::newDocument()
{
    bool ok = false;
    QString name = QInputDialog::getText(this, tr("新建文档"),
                                         tr("文件名（含扩展名）："),
                                         QLineEdit::Normal,
                                         QStringLiteral("untitled.md"), &ok);
    if (!ok || name.trimmed().isEmpty())
        return;
    QDir dir(_model->filePath(_tree->currentIndex()));
    if (!dir.exists()) dir.setPath(_rootPath);
    QString path = dir.filePath(name.trimmed());
    if (QFile::exists(path)) {
        QMessageBox::warning(this, tr("存在同名文件"), tr("该文件已存在。"));
        return;
    }
    QFile f(path);
    if (f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        f.close();
        refresh();
        emit fileActivated(path);
        emit statusMessage(tr("已创建 %1").arg(path));
    }
}

void FileBrowserWidget::newFolder()
{
    bool ok = false;
    QString name = QInputDialog::getText(this, tr("新建文件夹"), tr("文件夹名称："),
                                         QLineEdit::Normal, QString(), &ok);
    if (!ok || name.trimmed().isEmpty())
        return;
    QDir dir(_model->filePath(_tree->currentIndex()));
    if (!dir.exists()) dir.setPath(_rootPath);
    dir.mkpath(name.trimmed());
    refresh();
}

void FileBrowserWidget::renameSelected()
{
    QModelIndex idx = _tree->currentIndex();
    if (!idx.isValid()) return;
    // 行内编辑：QFileSystemModel 自带重命名逻辑，编辑器提交时自动执行
    // 磁盘改名并刷新视图，无需弹窗（NoEditTriggers 只禁用双击/F2，
    // 程序调用 edit() 仍然有效）
    _tree->edit(idx);
}

void FileBrowserWidget::deleteSelected()
{
    QModelIndex idx = _tree->currentIndex();
    if (!idx.isValid()) return;
    const QString path = _model->filePath(idx);
    const QString name = _model->fileName(idx);

    // Delete dialog: file name + round checkbox (delete source / only clear recent list)
    QDialog dlg(this);
    dlg.setWindowTitle(tr("删除确认"));
    auto* lay = new QVBoxLayout(&dlg);
    auto* lbl = new QLabel(tr("确定删除“%1”吗？").arg(name), &dlg);
    lbl->setWordWrap(true);
    lay->addWidget(lbl);
    auto* delSource = new QCheckBox(tr("同时删除源文件（不勾选仅从最近列表移除）"), &dlg);
    delSource->setChecked(true);
    lay->addWidget(delSource);
    auto* btns = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    btns->button(QDialogButtonBox::Ok)->setText(tr("确定"));
    btns->button(QDialogButtonBox::Cancel)->setText(tr("取消"));
    lay->addWidget(btns);
    connect(btns, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    connect(btns, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    if (dlg.exec() != QDialog::Accepted)
        return;

    // Recent-list entry is always cleared
    AppSettings::instance().removeRecent(path);

    if (delSource->isChecked()) {
        const bool ok = _model->isDir(idx) ? QDir(path).removeRecursively() : QFile::remove(path);
        if (ok) {
            refresh();
            emit statusMessage(tr("已删除 %1").arg(name));
        } else {
            QMessageBox::warning(this, tr("删除失败"), tr("无法删除 %1").arg(path));
        }
    } else {
        emit statusMessage(tr("已从最近列表移除 %1").arg(name));
    }
}

void FileBrowserWidget::favoriteSelected()
{
    QModelIndex idx = _tree->currentIndex();
    if (!idx.isValid() || _model->isDir(idx)) return;
    emit toggleFavorite(_model->filePath(idx));
}

void FileBrowserWidget::contextMenuEvent(QContextMenuEvent* event)
{
    QModelIndex idx = _tree->indexAt(_tree->mapFromParent(event->pos()));
    if (idx.isValid()) _tree->setCurrentIndex(idx);

    QMenu menu(this);
    QAction* open = menu.addAction(tr("打开"));
    QAction* openTab = menu.addAction(tr("在新标签页打开"));
    menu.addSeparator();
    QAction* fav = menu.addAction(tr("收藏/取消收藏"));
    QAction* rename = menu.addAction(tr("重命名"));
    QAction* del = menu.addAction(tr("删除"));
    menu.addSeparator();
    QAction* newDoc = menu.addAction(tr("新建文档"));
    QAction* newDir = menu.addAction(tr("新建文件夹"));
    QAction* refreshAct = menu.addAction(tr("刷新"));

    QAction* chosen = menu.exec(event->globalPos());
    if (chosen == open && idx.isValid() && !_model->isDir(idx))
        emit fileActivated(_model->filePath(idx));
    else if (chosen == openTab && idx.isValid() && !_model->isDir(idx))
        emit openInNewTab(_model->filePath(idx));
    else if (chosen == fav) favoriteSelected();
    else if (chosen == rename) renameSelected();
    else if (chosen == del) deleteSelected();
    else if (chosen == newDoc) newDocument();
    else if (chosen == newDir) newFolder();
    else if (chosen == refreshAct) refresh();
}
