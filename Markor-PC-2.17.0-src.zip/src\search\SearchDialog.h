#pragma once
#include <QDialog>
#include <QLineEdit>
#include <QCheckBox>
#include <QListWidget>
#include <QPushButton>
#include <QLabel>
#include <QPointer>

class EditorWidget;

// Search & replace dialog: in-file find/replace plus a whole-vault text search
// whose results can be opened in the editor.
class SearchDialog : public QDialog {
    Q_OBJECT
public:
    explicit SearchDialog(EditorWidget* editor, const QString& vaultDir, QWidget* parent = nullptr);

    // Rebind to the editor of the currently active tab. Tabs may be closed
    // while this modeless dialog stays open; a null pointer is safe.
    void setEditor(EditorWidget* editor) { _editor = editor; }
    void setVaultDir(const QString& dir) { _vaultDir = dir; }

signals:
    void openFileAt(const QString& path, int line);

private slots:
    void findNext();
    void findPrev();
    void doReplace();
    void doReplaceAll();
    void searchVault();

private:
    void showFindToast(const QString& msg);   // 非干预提示浮条，自动消失

    QPointer<EditorWidget> _editor;
    QString _vaultDir;
    QLineEdit* _findEdit;
    QLineEdit* _replaceEdit;
    QCheckBox* _caseSensitive;
    QCheckBox* _regex;
    QListWidget* _results;
    QPushButton* _findNextBtn;
    QPushButton* _vaultSearchBtn = nullptr;
    QLabel* _toast = nullptr;
};
