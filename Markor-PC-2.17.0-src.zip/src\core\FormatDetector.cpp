#include "FormatDetector.h"
#include <QFileInfo>
#include <QSet>

namespace FormatDetector {

TextFormat detect(const QString& path)
{
    const QString ext = QFileInfo(path).suffix().toLower();

    if (ext == "md" || ext == "markdown" || ext == "mdown" || ext == "mkd" || ext == "mdwn")
        return TextFormat::Markdown;
    if (ext == "txt") {
        // todo.txt convention: file named exactly todo.txt / done.txt or *.todo.txt
        const QString base = QFileInfo(path).fileName().toLower();
        if (base == "todo.txt" || base == "done.txt" || base.endsWith(".todo.txt"))
            return TextFormat::TodoTxt;
        return TextFormat::PlainText;
    }
    if (ext == "todo")
        return TextFormat::TodoTxt;
    if (ext == "adoc" || ext == "asciidoc" || ext == "asc")
        return TextFormat::AsciiDoc;
    if (ext == "org")
        return TextFormat::OrgMode;
    if (ext == "wiki" || ext == "mediawiki")
        return TextFormat::WikiText;
    if (ext == "csv" || ext == "tsv")
        return TextFormat::Csv;
    if (ext == "json" || ext == "yaml" || ext == "yml" || ext == "ini" || ext == "properties" || ext == "conf" || ext == "toml")
        return TextFormat::KeyValue;

    // HTML / XML 家族
    if (ext == "html" || ext == "htm" || ext == "xhtml" || ext == "xml" || ext == "svg"
        || ext == "xsl" || ext == "xslt" || ext == "vue" || ext == "svelte")
        return TextFormat::Html;

    // 通用源码（按语言高亮；扩展名不在表内时归为纯文本）
    static const QSet<QString> codeExt = {
        "css", "scss", "less", "sass", "js", "mjs", "cjs", "jsx", "ts", "tsx",
        "py", "pyw", "rb", "php", "pl", "pm", "lua", "go", "rs", "c", "h",
        "cpp", "cc", "cxx", "hpp", "hxx", "cs", "java", "kt", "kts", "swift",
        "scala", "dart", "groovy", "gradle", "sh", "bash", "zsh", "bat", "cmd",
        "ps1", "psm1", "sql", "r", "m", "mm", "asm", "s", "lisp", "clj", "hs",
        "erl", "ex", "exs", "tex", "cmake", "mk", "make", "dockerfile",
        "gitignore", "env", "proto", "graphql", "gql"
    };
    if (codeExt.contains(ext))
        return TextFormat::Code;

    return TextFormat::PlainText;
}

QString name(TextFormat fmt)
{
    switch (fmt) {
    case TextFormat::Markdown:  return QStringLiteral("Markdown");
    case TextFormat::TodoTxt:   return QStringLiteral("Todo.txt");
    case TextFormat::PlainText: return QStringLiteral("Plain text");
    case TextFormat::AsciiDoc:  return QStringLiteral("AsciiDoc");
    case TextFormat::OrgMode:   return QStringLiteral("Org mode");
    case TextFormat::WikiText:  return QStringLiteral("WikiText");
    case TextFormat::Csv:       return QStringLiteral("CSV");
    case TextFormat::KeyValue:  return QStringLiteral("Key-Value");
    case TextFormat::Html:      return QStringLiteral("HTML");
    case TextFormat::Code:      return QStringLiteral("Source code");
    default:                    return QStringLiteral("Plain text");
    }
}

QString fileFilter()
{
    return QStringLiteral(
        "All supported (*.md *.markdown *.txt *.todo *.adoc *.asciidoc *.asc *.org "
        "*.wiki *.csv *.tsv *.json *.yaml *.yml *.ini *.conf *.toml "
        "*.html *.htm *.xml *.svg *.css *.js *.ts *.py *.rb *.php *.go *.rs *.c *.h *.cpp "
        "*.hpp *.cs *.java *.kt *.swift *.sh *.bat *.ps1 *.sql);;"
        "Markdown (*.md *.markdown *.mdown *.mkd);;"
        "Todo.txt (*.txt *.todo);;"
        "Plain text (*.txt);;"
        "HTML / XML (*.html *.htm *.xhtml *.xml *.svg *.vue);;"
        "Source code (*.css *.scss *.js *.ts *.jsx *.tsx *.py *.rb *.php *.go *.rs "
        "*.c *.h *.cpp *.hpp *.cs *.java *.kt *.swift *.sh *.bat *.ps1 *.sql *.lua *.pl *.r);;"
        "AsciiDoc (*.adoc *.asciidoc *.asc);;"
        "Org mode (*.org);;"
        "WikiText (*.wiki);;"
        "CSV (*.csv *.tsv);;"
        "Key-Value (*.json *.yaml *.yml *.ini *.conf *.toml);;"
        "All files (*.*)");
}

bool highlightable(TextFormat fmt)
{
    switch (fmt) {
    case TextFormat::Markdown:
    case TextFormat::TodoTxt:
    case TextFormat::AsciiDoc:
    case TextFormat::OrgMode:
    case TextFormat::WikiText:
    case TextFormat::Csv:
    case TextFormat::KeyValue:
    case TextFormat::Html:
    case TextFormat::Code:
        return true;
    default:
        return false;
    }
}

bool isMarkdownFamily(TextFormat fmt)
{
    // Markdown 系：语法补全/整理只对 Markdown 生效，其他格式不插入 MD 记号
    return fmt == TextFormat::Markdown;
}

} // namespace FormatDetector
