#pragma once
#include <QWidget>
#include <QString>

class QTextBrowser;
class QVBoxLayout;

// HTML 文件的浏览器级预览：在本组件内宿主 Windows 自带的 WebView2（Edge 内核），
// 直接执行页面的 JavaScript / 现代 CSS，渲染效果与在浏览器打开一致。
//
// 说明：WebView2 是 Windows 系统组件（Qt 官方未提供封装），仅用于预览窗格渲染，
// 不是把整个应用包成网页壳。运行期需要系统已安装 WebView2 运行时（Win10/11 通常
// 预装）；若运行时缺失，组件自动降级为"源码只读展示"并给出提示。
class HtmlPreviewView : public QWidget {
    Q_OBJECT
public:
    explicit HtmlPreviewView(QWidget* parent = nullptr);
    ~HtmlPreviewView() override;

    // WebView2 已就绪（可执行 JavaScript 的浏览器级渲染）
    bool isAvailable() const;
    // 初始化是否已出结果（成功或失败）
    bool isResolved() const;
    // 当前已指定的导航目标（本地文件路径；内存文本模式为空）
    QString currentTarget() const;

    // 打开本地文件（浏览器级渲染，相对资源按文件所在目录解析）
    void openFile(const QString& filePath);
    // 渲染内存中的 HTML 文本（未保存的新文档；相对资源无法解析）
    void setHtmlSource(const QString& html);
    // 重新加载当前页面（保存 / 手动刷新后调用）
    void reload();

signals:
    // 初始化结果确定（成功或失败）时发出
    void resolved();

protected:
    void resizeEvent(QResizeEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void hideEvent(QHideEvent* event) override;

private:
    struct Impl;
    Impl* d = nullptr;

    void ensureEnvironment();
    void updateBounds();
    void applyPendingNavigation();
    void showFallbackNotice();
};
