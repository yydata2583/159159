# 需求与变更记录（CHANGELOG.md）— Markor PC 端

> **本文档由 AI 维护。** 工作方式：**用户提需求 → AI 写代码 → AI 同步更新本记录**。
> 每条需求记录：原始诉求、实现方案、涉及文件、日期。以后 AI 接手先看这里，不用重读代码。
> 维护规则见 [README.md](README.md)；技术决策细节见 [decisions.md](decisions.md)。

## 需求追溯表

| 日期 | 需求（用户原始诉求摘要） | 实现 | 涉及文件 |
|---|---|---|---|
| 10-14 | "预览内容跟随编辑不完美，有的不跟随，要很完美的自动跟随每一行"（附 AI 建议：逐行测量+块内插值+等比偏移） | 逐行像素映射 + 块内插值：每预览元素记 `spanLines`，互逆映射 `docYForSourceLine/sourceLineForDocY`；编辑器 `firstVisibleSourceLineF()` 小数行；双向同步全程小数源行 | `EditorWidget.{h,cpp}` `PreviewWidget.{h,cpp}` `MainWindow.cpp` |
| 10-15 | ①手机端内置同步（仅前台） | （手机端实现，见其 CHANGELOG） | — |
| 10-15 | ②不需要"更新同步版本"，有更新功能就删 | 审计：无应用更新功能可删；Syncthing 引擎 `autoUpgradeIntervalH=0` | `SyncManager.cpp` |
| 10-15 | ③服务器信息不写死、默认空；连接成功/失败都要弹窗 | 设置四项默认空；`serverConnectionResult` 驱动 `QMessageBox` 三态弹窗 | `AppSettings.*` `SettingsDialog.*` `MainWindow.cpp` `SyncManager.*` |
| 10-15 | ④PC 同步管理地址 18384 打不开，改 8385；仅软件运行期同步；有 BUG"路径错位" | 根因三重：引擎查找路径 vs installer 安装路径不一致（**"路径错位"实锤**）+ `--gui-address` 带 scheme/斜杠 + GUI 默认 HTTPS。修复：两级查找（根目录/bin/）、`127.0.0.1:8385`、`gui.tls=false`；同步随应用启停 | `SyncManager.cpp` `build/installer.iss`(注释) |
| 10-15 | ⑤PC/手机只连服务器、不互连；删中继、加服务器地址 | 星型：introducer 移除、发现/中继全关、新增"服务器同步地址"设置、删中继设置 | `SyncManager.cpp` `AppSettings.*` `SettingsDialog.*` |
| 10-15 | ⑥审查三端代码 | 用户后指示取消；过程中顺手修 2 个 BUG（锁服务单值覆盖、弹窗信号时序） | `lockserver/main.py` `MainWindow.cpp` |
| 10-15 | ⑦下载保存手机+服务器源码 | 已入库并配知识库 | — |
| 10-15 | ⑧手机：大纲滚动时预览跟随滚动 | （手机端实现） | — |
| 10-15 | ⑨先做完上一轮再做本轮；**等通知才编译** | 遵守：全程未编译（仅括号/XML 静态自查） | — |
| 10-16 | "输入有卡顿，不流畅"（附 Web 参考：渲染前保存位置→渲染后恢复；输入时 render(false) 只保持位置） | 输入渲染管线重做：像素保存/恢复 + 按需精确布局 + postProcess 批量化 + Mermaid/公式位图 LRU 缓存 + 防抖 300ms；650ms→299ms（ADR-020/021） | `PreviewWidget.{h,cpp}` `MainWindow.cpp` |
| 10-16 | "高亮缓存（内容没变就跳过）+ 防抖 300ms" | 编辑器高亮块级备忘录（文本+前块状态+主题哈希，ADR-022）；防抖 300ms | `MarkdownHighlighter.cpp` `PreviewWidget.cpp` |
| 10-16 | "怎么跟随输入没有了？" | 输入跟随重构：光标行在预览视口内（15%~85% 迟滞区间）只保位置，出视口才对齐到**动态比例**（光标在编辑器视口的比例，非固定 50%）；空/短文档贴顶；图片加载 150ms 重校准（`alignNextRender` 一次性 API） | `MainWindow.cpp` `PreviewWidget.{h,cpp}` `EditorWidget.{h,cpp}` |
| 10-17 | "clamp 夹住了.txt"（末尾对齐被 clamp 贴底露半行） | 底部 25vh 留白**尾部空白块常驻**（否决 setFrameFormat 反复增删，ADR-023）；"到底"目标取含留白的 maxScroll 且取前先 documentSize() | `PreviewWidget.cpp` |
| 10-17 | "markora-block-align-fix.md"（块内子锚点精准对齐） | SubAnchor 子锚点直接测量：表格行/列表项/代码 5 行组/引用段，>3 行才拆、失配回退整块（ADR-024） | `PreviewWidget.{h,cpp}` |
| 10-17 | "3 个小风险 + 补充验收项.md" | ①留白常驻 ②td padding 改读 `QTextTableFormat::cellPadding()` ③代码逐行锚点改 5 行组 | `PreviewWidget.cpp` |
| 10-17 | "查找：循环查找，回卷时弹窗提示"→"提示不能干预查找，自动关闭" | 查找循环回卷（EditorWidget::find 重构+wrapped 出参）；提示用自动消失浮条（1.5s、不抢焦点、点击穿透），否决 QMessageBox | `EditorWidget.{h,cpp}` `SearchDialog.{h,cpp}` |
| 10-17 | "格式加快捷键" + "前 4 个格式光标不在中间" + "回车自动跳过格式外"→"只跳出不换行" | 14 个格式快捷键（Ctrl+B/I/H/K、Alt+Shift+5 等，Typora 惯例）；空选区插标记光标落中间；回车在 `**x**` 内只跳出闭合标记不换行，再按才换行 | `MainWindow.cpp` `FormatActions.cpp` `EditorWidget.cpp` |
| 10-17 | "工具栏悬停显示快捷键；显示分割线"（实指**水平分割线按钮**上工具栏） | 工具栏 6 段分组 + 三主题补 `QToolBar::separator` 样式（**坑：无样式时默认渲染与背景同色=不可见**）；`- 分割线`按钮（Ctrl+-）；tooltip 带快捷键 | `MainWindow.cpp` `resources/theme/*.qss` |
| 10-17 | "标题左侧加紫色竖条" | 内联位图模拟（Qt 不支持块级 border-left，ADR-025）；**当日被 ADR-028 取代** | `PreviewWidget.cpp` `MarkdownConverter.cpp`（`%A` 占位符） |
| 10-17 | "标题不要竖线了，改为底部边框"（给出 h1/h2 参考 CSS：1px solid var(--border)、1.9em/1.5em、.67em/.75em 上边距、.28em/.25em 底内边距）→ 首版位图方案"没有看到边框" | 移除 h1~h6 左侧竖条位图注入；CSS 按参考改 h1/h2 底部 1px 边框（导出 HTML 生效）。Qt 预览不渲染块级 border-bottom：首版 `<br><img width=100%>` 位图失败（转换器闭合标签 `</h1 >` 带空格正则零匹配 + Qt 不支持 img 百分比宽度）；最终改为子类化 QTextBrowser 重写 paintEvent（`PreviewBrowser`，基类绘制后回调 `paintHeadingBorders`），按标题块实时布局矩形叠加 1px 横线（宽度自适应、不进文档模型、不影响块配对）；中途踩坑：在外部事件过滤器里手动 watched->event() 拦 Paint 会绕过 QAbstractScrollArea 自身过滤器导致文档内容全不绘制（只剩线）。底线 y 几何五轮修正：①减 bottomMargin 误判 h2 贴字 ②改 naturalTextRect+0.43/0.40em 又太远（线落在 margin 中央像平均分隔）③系数回归 CSS padding-bottom 原值（半行距不参与 border 定位）④用户验收后把 padding 改 .12/.10em、margin-bottom 加大到 .75/.7em（线贴标题、与正文拉开，先浏览器等效页验收再编译）。仅 h1/h2，h3~h6 无装饰（ADR-028，Supersedes ADR-025） | `PreviewWidget.{h,cpp}` `MarkdownConverter.cpp` |
| 10-17 | "最近、文件页右键增加重命名，直接在文件名上改" | 最近列表：右键重命名→行内编辑→QFile::rename+renameRecent 原位替换（新增 AppSettings::renameRecent）；文件树：`_tree->edit(idx)` 行内编辑（QFileSystemModel 自动改磁盘名，否决 QInputDialog 弹窗） | `FileSidebar.cpp` `FileBrowserWidget.cpp` `AppSettings.{h,cpp}` |
| 10-17 | "设置-预览窗口添加字体和字号"+"编辑窗口 Ctrl+滚轮调字体"+"字号框悬停提示 Ctrl+滚轮"+"字号框回车为什么打开文档库" | ①预览窗口组新增字体（QFontComboBox）+字号（10~28px）设置项，AppSettings 新增 previewFontFamily，wrapHtmlDocument 加 fontFamily 参数（CSS `font-family:'%F'`），预览重渲染即时生效 ②EditorWidget 新增 wheelEvent：Ctrl+滚轮 ±1pt（8~40 与设置范围一致）实时持久化并刷新行号槽宽 ③两个字号框加悬停提示 ④**回车 bug 根因：对话框未指定默认按钮时，创建顺序最靠前的 autoDefault 按钮（"浏览…"）成为默认按钮**，字号框回车等于点击它；修复：browse/cancel 关 autoDefault，确定 setDefault(true) | `SettingsDialog.{h,cpp}` `AppSettings.{h,cpp}` `EditorWidget.{h,cpp}` `MarkdownConverter.{h,cpp}` `PreviewWidget.cpp` |
| 10-17 | "行号与内容字体无法垂直居中 + 行号字号固定不随内容变化" → "字号20时有的错位有的正常" | ①新增 `EditorWidget::updateLineNumberFont()`：行号字体 = 内容字体 - 2pt（下限 6pt），同字体族；在构造函数、`setFontPointSize`、`applyEditorSettings` 中调用，保证 Ctrl+滚轮/设置改字号时行号同步缩放 ②`lineNumberAreaWidth()` 改用 `_lineNumberArea->fontMetrics()` ③绘制改**首行基线对齐**：取 `block.layout()->lineAt(0).ascent()` 得到内容首行真实基线，`painter.drawText(x, baseline, number)` 让行号基线与之重合。**首版用 `Qt::AlignVCenter` 在整块高度内居中，遇到 `↓` 等触发更高回退字体/软换行的行（块高变大）时行号跑到两行中间造成错位；改用基线对齐后，无论该行块高如何变化都与同行文字对齐** ④实测 12pt/20pt 及含 `&#x20;`/`↓` 混合行均对齐 | `EditorWidget.{h,cpp}` `MainWindow.cpp` |
| 10-17 | "打开没有文件时显示空的未命名，打开文件把未命名移到最右；重启恢复后也要未命名在最后" + "Ctrl+滚轮调字号提示改到窗口正中心；到默认值后面带（默认值）" + "浮层适配皮肤" | ①`ensureUnnamedTabAtEnd()`：找首个空 filePath 标签，无则 `newDocument()`，有则 `QTabBar::moveTab(idx, last)` 移到最右（不切当前页）；在 `newDocument/openFilePath/openInNewTab/closeTab` 与会话恢复分支末尾调用，保证"文件1 文件2 文件3 未命名"顺序，重启恢复后同样补到末尾 ②字号提示改走 `MainWindow::showToast`：顶层 `QLabel`（`Qt::Tool|FramelessWindowHint|WindowStaysOnTopHint`，不挂父避免被裁），`mapToGlobal(rect().center())` 居中，1400ms 自动消失；`EditorWidget/PreviewWidget` 的 `statusMessage` 信号改接 `showToast` 而非状态栏 ③默认值后缀：编辑器 12pt、预览 15px 时追加 `  （默认值）` ④皮肤适配：每次 `showToast` 按 `ThemeManager::current()` 取浅/深/樱三套配色（与 QMenu 一致） | `MainWindow.{h,cpp}` `EditorWidget.cpp` `PreviewWidget.cpp` |
| 10-17 | "点击字号框没有提示/去句号/适配皮肤"+"快捷调节要显示字号"+"软件内部版本号 0.0.0.0"+"重启后已打开文件丢失" | ①字号框 eventFilter 聚焦即 QToolTip::showText，提示去掉句号；三套 qss 增加 QToolTip 规则（浅/深/樱配色）②编辑区 Ctrl+滚轮 emit statusMessage 显示"字号：N pt"，PreviewWidget 新增 statusMessage 信号显示"预览字号：N px"（createPage 接状态栏）③**0.0.0.0 根因：iss 未设 VersionInfoVersion，AppVersion 只写 ProductVersion，setup.exe 的 FileVersion 为空（资源管理器显示 0.0.0.0）**；补 VersionInfoVersion/Company/Description，实测 setup.exe FileVersion=2.17.0.0 ④会话恢复：AppSettings 新增 session/files、session/currentIndex；closeEvent 自动保存后收集已命名标签（未命名不恢复，索引按已命名序列记）；启动时逐页 createPage 恢复（缺失文件静默跳过），无会话才开欢迎页。已实测带文件关闭→无参启动标签与内容完整还原 | `SettingsDialog.{h,cpp}` `*.qss×3` `EditorWidget.cpp` `PreviewWidget.{h,cpp}` `MainWindow.cpp` `AppSettings.{h,cpp}` `installer.iss` |

## 答疑记录（用户问 → 结论）

| 问题 | 结论 |
|---|---|
| "按设备多持有者会不会和原生同步冲突？" | 不冲突：锁=提示层（内存登记），同步=Syncthing 内容交换，写冲突仍靠 `.sync-conflict-*`；多持有者才让"已被其他设备打开"提示生效 |
| "API Key 同步原生没有吧？怎么申请？" | 对，是**锁服务**的共享口令，无申请流程：自生成（如 `openssl rand -hex 32`）→ 服务端与三端填一致 |
| "同步端口？客户端生成登记文件夹？" | 数据 22000/TCP+UDP；锁 8910；GUI 8385。引擎 home 目录（config.xml/index-vault/证书）= 登记数据，不参与同步 |
| "官方安卓端怎么同步的？非二进制？" | 官方（Syncthing-Fork）也是打包 syncthing 原生二进制（libsyncthing.so）+ REST 配置，与我们同构；纯 Java 实现不存在 |
| "路径错位"到底指什么 | 另一 AI 提供的实锤：代码找 `<exe目录>\syncthing.exe`，installer 装到 `<exe目录>\bin\` → 引擎从未启动。已修两级查找 |

## 变更日志

- **2026-10-14**：知识库初建（AGENTS.md + docs/ 六篇）；滚动同步逐行化（ADR-016）。
- **2026-10-15**：同步体系整改（ADR-017 星型 / 018 端口8385 / 019 锁客户端）；新增 `LockClient.{h,cpp}`；
  引擎查找兼容 `bin\` 布局（"路径错位"修复）；文档更正根因（architecture §7.3）。
- **2026-10-16**：输入性能与跟随重构（ADR-020 渲染保位置 / 021 postProcess 批量 / 022 高亮备忘录）；
  输入跟随动态比例+迟滞区间；Mermaid/公式位图 LRU 缓存（上限 384 张）。
- **2026-10-17**：底部 25vh 留白常驻（ADR-023）；子锚点直接测量（ADR-024）；标题紫色竖条位图模拟（ADR-025）；
  格式快捷键 14 个 + 回车跳出格式；查找循环+浮条提示；工具栏分组分割线+`- 分割线`按钮；
  最近/文件页行内重命名（新增 `AppSettings::renameRecent`）；
  预览调色板取自 ThemeManager（ADR-026）：皮肤切换预览同步、预览标题色=编辑区标题色；删除编辑区当前行蓝色高亮条（用户要求，highlightCurrentLine 仅保留 todo.txt 过滤器高亮）。
