#pragma once
#include <QObject>
#include <QString>
#include <QStringList>
#include <QSettings>

// Application-wide persistent settings (theme, fonts, vault, favorites, recents).
class AppSettings : public QObject {
    Q_OBJECT
public:
    static AppSettings& instance();

    // --- Appearance ---
    QString theme() const;                 // "light" | "dark" | "sakura"
    void setTheme(const QString& theme);
    bool followSystemTheme() const;
    void setFollowSystemTheme(bool on);

    QString editorFontFamily() const;
    void setEditorFontFamily(const QString& family);
    int editorFontSize() const;
    void setEditorFontSize(int pt);

    // --- Editor behaviour ---
    bool wordWrap() const;
    void setWordWrap(bool on);
    bool lineNumbers() const;
    void setLineNumbers(bool on);
    bool syntaxHighlighting() const;
    void setSyntaxHighlighting(bool on);
    bool previewFollowEditor() const;      // 预览跟随编辑窗口滚动
    void setPreviewFollowEditor(bool on);
    bool previewSoftBreaks() const;        // 软换行（单换行）渲染为换行
    void setPreviewSoftBreaks(bool on);
    int previewFontSize() const;           // 预览正文字号（Ctrl+滚轮缩放，px）
    void setPreviewFontSize(int px);
    QString previewFontFamily() const;     // 预览正文字体族（默认 Segoe UI）
    void setPreviewFontFamily(const QString& family);

    // --- Files / vault ---
    QString vaultDir() const;
    void setVaultDir(const QString& dir);

    QStringList favorites() const;
    void setFavorites(const QStringList& paths);
    void toggleFavorite(const QString& path);
    bool isFavorite(const QString& path) const;

    QStringList recents() const;
    void addRecent(const QString& path);
    void removeRecent(const QString& path);
    void renameRecent(const QString& oldPath, const QString& newPath);   // 原位替换，不打乱顺序
    void clearRecents();

    // 上次退出时仍打开的标签页（按标签顺序），用于启动时恢复会话
    QStringList sessionFiles() const;
    void setSessionFiles(const QStringList& paths);
    int sessionCurrentIndex() const;
    void setSessionCurrentIndex(int idx);

signals:
    void recentsChanged();

public:
    // --- Sync (embedded Syncthing + lock client) ---
    // 星型拓扑：本机只与同步服务器连接，设备之间不直连。
    // 服务器信息一律默认为空（不写死），由用户在设置中填写。
    bool syncEnabled() const;
    void setSyncEnabled(bool on);
    QString syncDeviceName() const;            // 本机设备名称
    void setSyncDeviceName(const QString& name);
    QString syncServerDeviceId() const;        // 同步服务器（NAS）的 Syncthing 设备 ID
    void setSyncServerDeviceId(const QString& id);
    QString syncServerSyncAddress() const;     // 服务器同步地址（监听地址），如 tcp://host:22000
    void setSyncServerSyncAddress(const QString& addr);
    QString syncServerApi() const;             // 服务器文件锁 API 地址，如 http://host:8910
    void setSyncServerApi(const QString& url);
    QString syncServerApiKey() const;          // 文件锁 API 密钥（Bearer）
    void setSyncServerApiKey(const QString& key);

    // --- Window ---
    QByteArray windowGeometry() const;
    void setWindowGeometry(const QByteArray& g);
    QByteArray windowState() const;
    void setWindowState(const QByteArray& s);
    QByteArray splitterState() const;      // 编辑区/预览区分割条位置
    void setSplitterState(const QByteArray& s);

    // --- 双侧边栏（批次2） ---
    // 文件侧边栏：展开状态/宽度/最近|文件 Tab
    bool fileSidebarVisible() const;
    void setFileSidebarVisible(bool on);
    int fileSidebarWidth() const;          // 内容宽度（不含把手）
    void setFileSidebarWidth(int px);
    int fileSidebarTab() const;            // 0=最近 1=文件
    void setFileSidebarTab(int tab);
    // 大纲面板：默认展开（设置项）+ 上次手动状态（覆盖默认）
    bool outlineDefaultExpanded() const;
    void setOutlineDefaultExpanded(bool on);
    bool outlineExpanded() const;          // 无手动记录时回退默认值
    void setOutlineExpanded(bool on);
    int outlineWidth() const;              // 内容宽度（180–220）
    void setOutlineWidth(int px);
    // 大纲自动收起：开启时点击大纲跳转后面板自动收起
    bool outlineAutoCollapse() const;
    void setOutlineAutoCollapse(bool on);

    void sync();

private:
    explicit AppSettings(QObject* parent = nullptr);
    QSettings _s;
};
