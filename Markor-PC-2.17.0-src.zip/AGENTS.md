# AGENTS.md — Markor for Windows · AI 工作入口

> **这是一份"项目知识库"入口文件。****文档由 AI 维护**（用户提需求 → AI 写代码 → AI 更新文档与需求记录）。 目标：任何 AI 接手本项目时，**读完本文件 + `docs/` 即可开工，不必重读全部源码**。
> 知识库由 AI 持续维护（维护规则见 [docs/README.md](docs/README.md)）。

---

## 0. 30 秒速览

| 项 | 值 |
|---|---|
| 项目 | Markor for Windows **v2.17.0** — Markdown / Todo.txt 桌面编辑器 |
| 渊源 | 移植自 Android 开源项目 [gsantner/markor](https://github.com/gsantner/markor)（Apache 2.0） |
| 技术栈 | **Qt 6 (Widgets) + C++17**，无 QtWebEngine、无第三方渲染引擎 |
| 平台 | Windows 10/11（x64，MSVC 或 MinGW） |
| 构建 | CMake ≥ 3.16（主）/ qmake（备），双轨并存 |
| 产物 | `MarkorWin.exe`（`WIN32` GUI 可执行） |
| 入口 | `src/main.cpp` → `MainWindow` |
| 配置 | `QSettings` INI：`%APPDATA%/Markor/MarkorWin.ini` |
| 文档库 | 默认 `%USERPROFILE%/Documents/Markor`（可在设置中改） |
| 特色 | 自研 Markdown→HTML 转换器（逐行像素滚动映射）、原生渲染 Mermaid/KaTeX、WebView2 浏览器级 HTML 预览、双侧边栏、三主题（浅/深/樱花）、内嵌 Syncthing 星型同步 + 文件锁客户端 |

**它不是**：网页壳应用、Electron、VS Code 插件。它是纯 Qt Widgets 桌面程序。

---

## 1. 新 AI 上手顺序（照做即可）

1. **本文件**（架构直觉 + 红线）
2. `docs/architecture.md` — 分层、数据流、渲染管线、滚动同步（**最重要**）
3. `docs/directory.md` — 每个文件干什么（改哪里找哪里）
4. 需要改数据/设置时 → `docs/data-model.md`
6. 需要查接口时 → `docs/api-index.md`
7. 动手改代码前 → `docs/conventions.md`（含"新增功能 checklist"）
8. 做技术选型/大改前 → `docs/decisions.md`（**先看是否已有 ADR，别推翻既定决策而不记录**）
9. 深入具体实现时再读对应 `.cpp`；原始文档 `BUILD.md`（环境）、`FEATURE_MAP.md`（功能矩阵）、`THEMES.md`（主题）仍然有效，与 `docs/` 互补

**读码优先级**：`src/app/MainWindow.cpp`（全局接线）> `src/core/*`（数据与转换）> `src/preview/PreviewWidget.cpp`（渲染管线）> 其余按需。

---

## 2. 项目红线（Do / Don't）

### 必须做
- **新增/删除源文件时同时登记两处构建脚本**：`CMakeLists.txt` 的 `APP_SOURCES` **和** `markor-win.pro` 的 `SOURCES/HEADERS`。漏一处 = 另一种构建方式悄悄坏掉。
- **UI 文案用中文**，且必须包 `tr()`（`Q_OBJECT` 类内）。
- **所有文本文件 UTF-8** 读写（`QTextStream::setEncoding(Utf8)`）。
- **设置只经 `AppSettings`**（单例封装 `QSettings`），不要在别处直接 new `QSettings`。
- **主题颜色只经 `ThemeManager`** 取（高亮器/预览/渲染器全部从它取色），不要硬编码新颜色。
- 改动会影响文档行为时（新设置项、新格式、新快捷键、新 ADR），**同步更新 `docs/` 对应文件**。
- 涉及 Markdown 语义的改动，参考 `MarkdownConverter.cpp` 顶部 "COMMONMARK-TODO" 注释与 `MarkdownHighlighter.h` 的 lint 规则清单。

### 不要做
- **不要引入 QtWebEngine / 外部渲染服务 / 网络依赖**（图表、公式都是 QPainter 原生画的；HTML 预览走系统 WebView2）。这是刻意的轻量决策（ADR-001/006）。
- **不要在滚动同步里用 `QSignalBlocker`**，必须用 `_programmaticScroll` 标志（ADR-004，注释里明确写了原因）。
- **不要给非 Markdown 格式插入 Markdown 记号**——格式相关动作必须走 `FormatActions::markupFor()` 的按格式分支；"自动整理/智能回车"仅对 `TextFormat::Markdown` 生效（`FormatDetector::isMarkdownFamily()`）。
- **不要执行/信任仓库内脚本的外部副作用**；`build-env.ps1` 是作者本机路径的构建环境脚本（含具体用户名/版本号），**仅作参考，改机器要重写路径**。
- **"更多/关于" 菜单禁止添加**：开源协议、社交/社区、项目团队、帮助、评价本应用（产品需求明确排除，见 ADR-012）。
- **同步必须保持星型拓扑**（ADR-017）：设备只连服务器、设备之间不互连——不得开启 introducer/自动发现/中继；引擎 `autoUpgradeIntervalH=0`（产品不要"更新同步版本"）。
- **同步服务器信息一律默认为空、不写死**（ADR-019）：代码里禁止出现具体 IP/域名/密钥；连接服务器成功/失败都必须弹窗提示。
- **同步仅在软件运行期间生效**：随应用启停，不做后台驻留。
- 预览区任务勾选框**只做视觉切换，不写回文件**（ADR-013）。

---

## 3. 架构一句话 + 一张图

**一句话**：`MainWindow` 承载 `[文件侧边栏 | 标签页(每页: 编辑器 ⇄ 大纲面板 ⇄ 预览)]`，编辑器文本经**自研 MarkdownConverter** 变成带 `data-src-line` 的 HTML 交给 `QTextBrowser`，实现**源行级双向滚动同步**；HTML 文件则交给系统 WebView2 浏览器级渲染；Mermaid/KaTeX 由 QPainter 原生渲染成图片内嵌。

```
main.cpp ──► MainWindow
              ├─ FileSidebar(主窗口级) ─ FileBrowserWidget(QFileSystemModel 文件树) + 最近列表
              ├─ QTabWidget（多标签，可关闭/拖动）
              │    └─ 每页 QSplitter:
              │         EditorWidget(QPlainTextEdit + LineNumberArea + Highlighter)
              │         │  └─ FormatActions / TodoTxtActions（行/选区操作）
              │         └─ 右侧容器: OutlinePanel(每页一套) + PreviewWidget
              │              PreviewWidget = QStackedWidget
              │                ├─ QTextBrowser ← MarkdownConverter + MathRenderer + MermaidRenderer
              │                └─ HtmlPreviewView ← WebView2（HTML 文件，缺失则降级源码展示）
              ├─ SearchDialog（非模态，可跨标签重绑）
              ├─ SettingsDialog / MoreDialog / TodoTxtFilterDialog
              ├─ AppSettings(单例,QSettings) · ThemeManager(单例,qss+调色板) · SyncManager(单例,Syncthing)
```

细节（数据流、防回环、渲染管线）→ **docs/architecture.md**。

---

## 4. 构建速查

```bat
:: 环境（作者实测组合）: MSVC 14.44 + Win SDK 10.0.26100 + Qt 6.8.3 msvc2022_64 + CMake 4.x + Ninja
. .\build-env.ps1                    :: 仅参考：路径是作者机器的，需按需修改

cmake -S . -B build -DCMAKE_PREFIX_PATH=C:\Qt\6.8.3\msvc2022_64
cmake --build build --config Release
:: 产物: build\Release\MarkorWin.exe（MinGW 无 config 子目录）
:: POST_BUILD 自动复制 WebView2Loader.dll 到 exe 同目录
```

- 依赖：Qt6 Widgets / PrintSupport / Concurrent / Network；Windows 上链接 `WebView2Loader.dll.lib`（已内置于 `third_party/webview2/`）。
- 部署：`windeployqt MarkorWin.exe` 后连同 `WebView2Loader.dll` 分发；运行机器需装 **WebView2 运行时**（Win10/11 通常预装，缺失时 HTML 预览降级）。
- 内嵌 Syncthing（可选功能）：`syncthing.exe` 需放在 exe 同目录。

## 5. 运行期 CLI（可用于自动化回归）

```
MarkorWin.exe [file]              打开文档
  --screenshot <png>              截主窗口并退出（UI 回归）
  --export-html <html>            导出 HTML 后退出（渲染回归）
  --export-pdf  <pdf>             导出 PDF 后退出
```

## 6. 快捷键总表

| 快捷键 | 动作 | 位置 |
|---|---|---|
| Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+Shift+S | 新建 / 打开 / 保存 / 另存为 | 文件菜单 |
| Ctrl+F | 查找/替换（含全库搜索） | 编辑菜单 |
| Ctrl+Z / Ctrl+Y | 撤销 / 重做（QTextDocument 栈） | 编辑菜单 |
| Ctrl+Alt+T | 整理 Markdown 文档 | 格式菜单 |
| Ctrl+D | 切换任务完成 | 任务菜单 |
| Ctrl+P | 优先级循环 A→B→C→无 | 任务菜单 |
| Ctrl+Shift+D | 插入今日日期 | 任务菜单 |
| Ctrl+Shift+F | Todo.txt 过滤器 | 任务菜单 |
| Ctrl+Shift+T | 循环切换主题 | 视图菜单 |
| 菜单栏右上角「撤回/前进」按钮 | 快照式历史（400ms 输入停顿存档，上限 50 条） | 菜单栏角落 |

> 菜单全结构见 docs/conventions.md。

---

## 7. 知识库维护协议（AI 必读）

**每次改动代码后，问自己：哪个文档因此过时了？** 然后立刻更新。规则全文见 [docs/README.md](docs/README.md)，摘要：

| 改动类型 | 必须更新 |
|---|---|
| 新增/删除/重命名源文件 | `docs/directory.md`、构建脚本两处 |
| 公开接口（类/函数/信号）变化 | `docs/api-index.md` |
| 新设置项 / 文件格式 / 数据结构 | `docs/data-model.md` |
| 架构、数据流、渲染、同步变化 | `docs/architecture.md` |
| 技术选型、推翻旧做法 | `docs/decisions.md` **新增一条 ADR**（不删旧的，可标 Superseded） |
| 快捷键 / 菜单 / 构建 / 打包变化 | `docs/conventions.md` |
| 功能完成度变化 | `FEATURE_MAP.md` |

文档与代码冲突时，**以代码为准**，并把文档改对（顺手记一条教训）。
