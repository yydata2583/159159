#include "FormatActions.h"
#include "EditorWidget.h"
#include <QTextCursor>
#include <QTextBlock>
#include <QTextDocument>
#include <QRegularExpression>

namespace {

// Per-format markup tokens. Wrap = symmetric markers; heading/bullet are line
// prefixes; link/image are rendered from templates in the helper functions.
struct Markup {
    QString boldL, boldR;
    QString italicL, italicR;
    QString strikeL, strikeR;
    QString codeL, codeR;
    QString quotePrefix;
    QString bullet;
    QString orderedSuffix;   // e.g. ". " (asciidoc) or ". " (md) or "# " (wiki)
    QString headingToken;    // repeated per level, e.g. "#" / "=" / "*"
    bool headingTrailing;    // wiki closes heading with same token
};

Markup markupFor(TextFormat f)
{
    switch (f) {
    case TextFormat::AsciiDoc:
        return { QStringLiteral("*"), QStringLiteral("*"),
                 QStringLiteral("_"), QStringLiteral("_"),
                 QStringLiteral("[.line-through]#"), QStringLiteral("#"),
                 QStringLiteral("`"), QStringLiteral("`"),
                 QStringLiteral(": "), QStringLiteral("- "),
                 QStringLiteral(". "), QStringLiteral("="), false };
    case TextFormat::OrgMode:
        return { QStringLiteral("*"), QStringLiteral("*"),
                 QStringLiteral("/"), QStringLiteral("/"),
                 QStringLiteral("+"), QStringLiteral("+"),
                 QStringLiteral("~"), QStringLiteral("~"),
                 QStringLiteral(": "), QStringLiteral("- "),
                 QStringLiteral(". "), QStringLiteral("*"), false };
    case TextFormat::WikiText:
        return { QStringLiteral("'''"), QStringLiteral("'''"),
                 QStringLiteral("''"), QStringLiteral("''"),
                 QStringLiteral("<s>"), QStringLiteral("</s>"),
                 QStringLiteral("<code>"), QStringLiteral("</code>"),
                 QStringLiteral(": "), QStringLiteral("* "),
                 QStringLiteral("# "), QStringLiteral("="), true };
    default: // Markdown + plain fallback
        return { QStringLiteral("**"), QStringLiteral("**"),
                 QStringLiteral("*"), QStringLiteral("*"),
                 QStringLiteral("~~"), QStringLiteral("~~"),
                 QStringLiteral("`"), QStringLiteral("`"),
                 QStringLiteral("> "), QStringLiteral("- "),
                 QStringLiteral(". "), QStringLiteral("#"), false };
    }
}

QString linkFor(TextFormat f, const QString& text, const QString& url)
{
    switch (f) {
    case TextFormat::AsciiDoc:  return QStringLiteral("%1[%2]").arg(url, text);
    case TextFormat::OrgMode:   return QStringLiteral("[[%1][%2]]").arg(url, text);
    case TextFormat::WikiText:  return QStringLiteral("[[%1|%2]]").arg(url, text);
    default:                    return QStringLiteral("[%1](%2)").arg(text, url);
    }
}

QString imageFor(TextFormat f, const QString& alt, const QString& src)
{
    switch (f) {
    case TextFormat::AsciiDoc:  return QStringLiteral("image:%1[%2]").arg(src, alt);
    case TextFormat::OrgMode:   return QStringLiteral("[[%1]]").arg(src);
    case TextFormat::WikiText:  return QStringLiteral("[[File:%1|%2]]").arg(src, alt);
    default:                    return QStringLiteral("![%1](%2)").arg(alt, src);
    }
}

QString hrFor(TextFormat f)
{
    switch (f) {
    case TextFormat::AsciiDoc:  return QStringLiteral("\n''' \n");
    case TextFormat::OrgMode:   return QStringLiteral("\n-----\n");
    case TextFormat::WikiText:  return QStringLiteral("\n----\n");
    default:                    return QStringLiteral("\n---\n");
    }
}

void wrapSelection(EditorWidget* ed, const QString& l, const QString& r)
{
    QTextCursor c = ed->textCursor();
    QString sel = c.selectedText();
    if (sel.startsWith(l) && sel.endsWith(r) && sel.size() >= l.size() + r.size()) {
        sel = sel.mid(l.size(), sel.size() - l.size() - r.size());
        c.insertText(sel);
    } else {
        c.insertText(l + sel + r);
        // 无选中内容时把光标移到左右标记中间，方便直接输入：**光标在这里**
        if (sel.isEmpty() && !r.isEmpty())
            c.movePosition(QTextCursor::Left, QTextCursor::MoveAnchor, r.size());
    }
    ed->setTextCursor(c);
}

void prefixSelectedLines(EditorWidget* ed, const QString& prefix, bool numbered = false,
                         const QString& numSuffix = QStringLiteral(". "))
{
    QTextCursor c = ed->textCursor();
    int start = c.selectionStart();
    int end = c.selectionEnd();
    c.setPosition(start);
    c.setPosition(end, QTextCursor::KeepAnchor);

    QString sel = c.selectedText();
    QStringList lines = sel.split(QChar(0x2029));
    for (int i = 0; i < lines.size(); ++i) {
        QString p = numbered ? (QString::number(i + 1) + numSuffix) : prefix;
        lines[i] = p + lines[i];
    }
    c.insertText(lines.join(QChar(0x2029)));
}

// Build the heading line for the current block at a given level.
QString headingLine(const Markup& m, int level, const QString& rest)
{
    QString tok = m.headingToken.repeated(level);
    if (m.headingTrailing)
        return tok + QLatin1Char(' ') + rest + QLatin1Char(' ') + tok;
    if (m.headingToken == QStringLiteral("="))
        return tok + QLatin1Char(' ') + rest;      // asciidoc: "= Title"
    return tok + QLatin1Char(' ') + rest;          // markdown / org: "# Title"
}

} // namespace

// ---------------- Markdown 智能回车 / 文档整理的行级辅助 ----------------
namespace {

int mdLeadSpaces(const QString& s)
{
    int n = 0;
    while (n < s.size() && s[n] == QLatin1Char(' '))
        ++n;
    return n;
}

// 代码围栏行（<=3 空格 + 至少 3 个相同的 ` 或 ~）。
// ch=围栏字符，count=字符数，info=开围栏后的信息串（闭围栏必须为空）。
bool mdFenceLine(const QString& line, QChar& ch, int& count, QString& info)
{
    const int p = mdLeadSpaces(line);
    if (p > 3 || p >= line.size())
        return false;
    const QChar c = line[p];
    if (c != QLatin1Char('`') && c != QLatin1Char('~'))
        return false;
    int n = 0;
    while (p + n < line.size() && line[p + n] == c)
        ++n;
    if (n < 3)
        return false;
    ch = c;
    count = n;
    info = line.mid(p + n).trimmed();
    return true;
}

int mdUnescapedPipes(const QString& s)
{
    int n = 0;
    for (int i = 0; i < s.size(); ++i) {
        if (s[i] == QLatin1Char('\\') && i + 1 < s.size()) {
            ++i;
            continue;
        }
        if (s[i] == QLatin1Char('|'))
            ++n;
    }
    return n;
}

// 表格分隔行：仅含 | - : 与空白，且至少有一个 -
bool mdIsDelimRow(const QString& s)
{
    const QString t = s.trimmed();
    if (!t.contains(QLatin1Char('|')) || !t.contains(QLatin1Char('-')))
        return false;
    for (QChar c : t)
        if (c != QLatin1Char('|') && c != QLatin1Char('-')
            && c != QLatin1Char(':') && !c.isSpace())
            return false;
    return true;
}

int mdTableCols(const QString& header)
{
    const QString t = header.trimmed();
    int cols = mdUnescapedPipes(t) + 1;
    if (t.startsWith(QLatin1Char('|')))
        --cols;
    if (t.endsWith(QLatin1Char('|')))
        --cols;
    return qMax(1, cols);
}

QString mdMakeDelim(const QString& header)
{
    const QString t = header.trimmed();
    const int cols = mdTableCols(t);
    QString d;
    if (t.startsWith(QLatin1Char('|'))) {
        for (int i = 0; i < cols; ++i)
            d += QStringLiteral("|---");
        d += QLatin1Char('|');
    } else {
        for (int i = 0; i < cols; ++i)
            d += (i == 0 ? QStringLiteral("---") : QStringLiteral("|---"));
    }
    return d;
}

struct MdListItem {
    QString indent;
    QString marker;          // "-" / "*" / "+" / "1." / "1)"
    bool ordered = false;
    int number = 0;
    QChar suffix;            // 有序列表的 '.' 或 ')'
    bool hasBox = false;
    bool boxChecked = false;
    QString rest;            // 复选框/标记之后的正文
};

bool mdListItem(const QString& s, MdListItem& item)
{
    static const QRegularExpression re(
        QStringLiteral("^( *)([-*+]|\\d{1,9}[.)])([ \\t]+)(.*)$"));
    const QRegularExpressionMatch m = re.match(s);
    if (!m.hasMatch())
        return false;
    item.indent = m.captured(1);
    item.marker = m.captured(2);
    item.rest = m.captured(4);
    if (item.marker[0].isDigit()) {
        item.ordered = true;
        item.suffix = item.marker[item.marker.size() - 1];
        item.number = item.marker.left(item.marker.size() - 1).toInt();
    }
    static const QRegularExpression boxRe(
        QStringLiteral("^\\[([ xX])\\](?:[ \\t]+(.*))?$"));
    const QRegularExpressionMatch bm = boxRe.match(item.rest);
    if (bm.hasMatch()) {
        item.hasBox = true;
        item.boxChecked = (bm.captured(1).toLower() == QLatin1String("x"));
        item.rest = bm.captured(2);
    }
    return true;
}

// 扫描 current 之前的块，判断该行是否处于未闭合代码围栏内
bool mdInsideFenceBefore(const QTextBlock& current)
{
    bool inFence = false;
    QChar fenceCh;
    for (QTextBlock b = current.document()->begin();
         b.isValid() && b != current; b = b.next()) {
        QChar ch;
        int cnt = 0;
        QString info;
        if (mdFenceLine(b.text(), ch, cnt, info)) {
            if (!inFence) {
                inFence = true;
                fenceCh = ch;
            } else if (ch == fenceCh && info.isEmpty()) {
                inFence = false;
            }
        }
    }
    return inFence;
}

} // namespace

namespace FormatActions {

void toggleSurround(EditorWidget* ed, const QString& marker)
{
    wrapSelection(ed, marker, marker);
}

void bold(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    wrapSelection(ed, m.boldL, m.boldR);
}
void italic(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    wrapSelection(ed, m.italicL, m.italicR);
}
void strikeout(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    wrapSelection(ed, m.strikeL, m.strikeR);
}
void inlineCode(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    wrapSelection(ed, m.codeL, m.codeR);
}

void heading(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    QTextCursor c = ed->textCursor();
    c.movePosition(QTextCursor::StartOfBlock);
    QString block = c.block().text();

    // Detect an existing heading prefix for this format.
    QRegularExpression headRe(QStringLiteral("^(%1{1,6})\\s").arg(QRegularExpression::escape(m.headingToken)));
    QRegularExpressionMatch match = headRe.match(block);
    int level = 0;
    QString rest = block;
    if (match.hasMatch()) {
        level = match.captured(1).size();
        rest = block.mid(match.captured(0).size());
        // wiki trailing token
        if (m.headingTrailing) {
            QString trailer = QStringLiteral(" %1").arg(QString(m.headingToken.at(0)).repeated(level));
            if (rest.endsWith(trailer))
                rest.chop(trailer.size());
        }
    }
    level = (level % 6) + 1;   // cycle 1..6

    c.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor);
    c.insertText(headingLine(m, level, rest.trimmed()));
}

void blockquote(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    prefixSelectedLines(ed, m.quotePrefix);
}

void bulletList(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    prefixSelectedLines(ed, m.bullet);
}

void orderedList(EditorWidget* ed)
{
    Markup m = markupFor(ed->format());
    prefixSelectedLines(ed, QString(), true, m.orderedSuffix);
}

void checkboxList(EditorWidget* ed)
{
    TextFormat f = ed->format();
    if (f == TextFormat::OrgMode)
        prefixSelectedLines(ed, QStringLiteral("- [ ] "));
    else if (f == TextFormat::AsciiDoc)
        prefixSelectedLines(ed, QStringLiteral("* [ ] "));
    else
        prefixSelectedLines(ed, QStringLiteral("- [ ] "));
}

void horizontalRule(EditorWidget* ed)
{
    ed->textCursor().insertText(hrFor(ed->format()));
}

void insertLink(EditorWidget* ed)
{
    TextFormat f = ed->format();
    QTextCursor c = ed->textCursor();
    QString sel = c.selectedText();
    QString text = sel.isEmpty() ? QStringLiteral("link text") : sel;
    c.insertText(linkFor(f, text, QStringLiteral("https://")));
}

void insertImage(EditorWidget* ed)
{
    TextFormat f = ed->format();
    QTextCursor c = ed->textCursor();
    QString sel = c.selectedText();
    QString alt = sel.isEmpty() ? QStringLiteral("alt") : sel;
    c.insertText(imageFor(f, alt, QStringLiteral("image.png")));
}

void indent(EditorWidget* ed)
{
    prefixSelectedLines(ed, QStringLiteral("    "));
}

void deindent(EditorWidget* ed)
{
    QTextCursor c = ed->textCursor();
    int start = c.selectionStart();
    int end = c.selectionEnd();
    c.setPosition(start);
    c.setPosition(end, QTextCursor::KeepAnchor);
    QString sel = c.selectedText();
    QStringList lines = sel.split(QChar(0x2029));
    for (QString& l : lines) {
        if (l.startsWith(QStringLiteral("    ")))
            l = l.mid(4);
        else if (l.startsWith(QLatin1Char('\t')))
            l = l.mid(1);
    }
    c.insertText(lines.join(QChar(0x2029)));
}

bool handleSmartReturn(EditorWidget* ed)
{
    if (!ed || !FormatDetector::isMarkdownFamily(ed->format()))
        return false;

    QTextCursor c = ed->textCursor();
    if (c.hasSelection())
        return false;                       // 选中态走默认换行，避免破坏选区
    const QTextBlock block = c.block();
    const QString line = block.text();
    if (c.positionInBlock() != line.size())
        return false;                       // 仅在行尾回车时自动补全

    // 代码围栏：开围栏行回车 -> 插入空行 + 同字符闭围栏，光标停在中间；
    // 已处于围栏内或本行本就是闭围栏 -> 普通换行。
    QChar fch;
    int fcnt = 0;
    QString finfo;
    const bool lineIsFence = mdFenceLine(line, fch, fcnt, finfo);
    const bool insideFence = mdInsideFenceBefore(block);
    if (lineIsFence && !insideFence) {
        const QString indent = line.left(mdLeadSpaces(line));
        const QString closer = QString(fch).repeated(fcnt);
        c.insertText(QStringLiteral("\n%1%2\n").arg(indent, closer));
        c.movePosition(QTextCursor::Up);    // 回到围栏中间的空行
        ed->setTextCursor(c);
        return true;
    }
    if (insideFence)
        return false;

    // 表格表头行（>=2 个未转义竖线，自身不是分隔行，下一行也不是）-> 补 |---| 分隔行
    if (mdUnescapedPipes(line) >= 2 && !mdIsDelimRow(line)) {
        const QTextBlock nb = block.next();
        const QString next = nb.isValid() ? nb.text() : QString();
        if (!mdIsDelimRow(next)) {
            c.insertText(QStringLiteral("\n%1\n").arg(mdMakeDelim(line)));
            ed->setTextCursor(c);           // 光标落在分隔行后的空数据行
            return true;
        }
    }

    // 列表项：空项回车清除本项标记；非空项续行（有序递增、复选框续为未勾选）
    MdListItem item;
    if (mdListItem(line, item)) {
        if (item.rest.trimmed().isEmpty()) {
            QTextCursor dc(c);
            dc.movePosition(QTextCursor::StartOfBlock);
            dc.setPosition(c.position(), QTextCursor::KeepAnchor);
            dc.removeSelectedText();        // 仅删标记，留下空白普通行
            ed->setTextCursor(dc);
            return true;
        }
        QString cont = item.indent;
        if (item.ordered)
            cont += QString::number(item.number + 1) + item.suffix;
        else
            cont += item.marker;
        cont += QLatin1Char(' ');
        if (item.hasBox)
            cont += QStringLiteral("[ ] ");
        c.insertText(QLatin1Char('\n') + cont);
        ed->setTextCursor(c);
        return true;
    }

    // ATX 标题行：默认回车本就不会续上 # 前缀，走默认行为即可
    return false;
}

bool tidyMarkdown(EditorWidget* ed)
{
    if (!ed || !FormatDetector::isMarkdownFamily(ed->format()))
        return false;

    const QString original = ed->toPlainText();
    const QStringList lines = original.split(QLatin1Char('\n'));
    QStringList out;
    out.reserve(lines.size() + 4);

    bool changed = false;
    bool inFence = false;
    QChar fenceCh;

    // 分隔线：3+ 个相同的 - / _ / *（可夹空白）统一为 ---
    static const QRegularExpression hrRe(
        QStringLiteral("^ {0,3}([-_*])(?:[ \\t]*\\1){2,}[ \\t]*$"));
    // 复选框列表：标记统一为 '-'，框内统一为 [ ] / [x]
    static const QRegularExpression boxRe(
        QStringLiteral("^( *)([-*+])[ \\t]*\\[[ \\t]*([xX]?)[ \\t]*\\](.*)$"));

    for (int i = 0; i < lines.size(); ++i) {
        const QString line = lines[i];

        QChar ch;
        int cnt = 0;
        QString info;
        if (mdFenceLine(line, ch, cnt, info)) {
            if (!inFence) {
                inFence = true;
                fenceCh = ch;
            } else if (ch == fenceCh && info.isEmpty()) {
                inFence = false;
            }
            out.append(line);
            continue;
        }
        if (inFence) {
            out.append(line);
            continue;
        }

        QString fixed = line;

        const QRegularExpressionMatch hm = hrRe.match(line);
        if (hm.hasMatch() && line.trimmed() != QStringLiteral("---"))
            fixed = QStringLiteral("---");

        const QRegularExpressionMatch bm = boxRe.match(line);
        if (bm.hasMatch()) {
            QString rest = bm.captured(4);
            if (!rest.isEmpty()
                && !rest.startsWith(QLatin1Char(' '))
                && !rest.startsWith(QLatin1Char('\t'))) {
                rest.prepend(QLatin1Char(' '));
            }
            fixed = bm.captured(1)
                    + QStringLiteral("- [")
                    + (bm.captured(3).toLower() == QLatin1String("x")
                           ? QLatin1Char('x') : QLatin1Char(' '))
                    + QLatin1Char(']') + rest;
        }

        out.append(fixed);
        if (fixed != line)
            changed = true;

        // 缺表格分隔行：当前行为管道段首行（上一行非管道行）、下一行有内容
        // 且还不是分隔行时补一行（与 highlighter 的疑似表格告警对应）
        if (mdUnescapedPipes(line) >= 2 && !mdIsDelimRow(line)) {
            bool prevIsPipe = false;
            for (int k = i - 1; k >= 0; --k) {
                if (lines[k].trimmed().isEmpty())
                    break;
                prevIsPipe = (mdUnescapedPipes(lines[k]) >= 2) || mdIsDelimRow(lines[k]);
                break;
            }
            const QString next = (i + 1 < lines.size()) ? lines[i + 1] : QString();
            if (!prevIsPipe && !next.trimmed().isEmpty()
                && !mdIsDelimRow(next)) {
                out.append(mdMakeDelim(line));
                changed = true;
            }
        }
    }

    // 文档结束仍在围栏内：补同字符闭围栏
    if (inFence) {
        if (!out.isEmpty() && !out.last().isEmpty())
            out.append(QString());
        out.append(QString(fenceCh).repeated(3));
        changed = true;
    }

    if (!changed)
        return false;
    const QString result = out.join(QLatin1Char('\n'));
    if (result == original)
        return false;

    QTextCursor c(ed->document());
    c.beginEditBlock();
    c.select(QTextCursor::Document);
    c.insertText(result);
    c.endEditBlock();
    return true;
}

} // namespace FormatActions
