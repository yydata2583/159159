#pragma once
#include <QString>

// Text formats supported by Markor, mapped from file extension / content.
enum class TextFormat {
    Markdown,
    TodoTxt,
    PlainText,
    AsciiDoc,
    OrgMode,
    WikiText,
    Csv,
    KeyValue,
    Html,        // HTML / XML 家族：标签高亮
    Code,        // 通用源码（按扩展名选语言关键字集）
    Unknown
};

namespace FormatDetector {
    // Detect format from file path (extension based).
    TextFormat detect(const QString& path);

    // Human readable name of a format.
    QString name(TextFormat fmt);

    // File dialog filter string covering all supported formats.
    QString fileFilter();

    // True if this format has a dedicated syntax highlighter.
    bool highlightable(TextFormat fmt);

    // True for Markdown-family formats: Markdown syntax auto-completion and
    // the whole-document tidy only apply to these.
    bool isMarkdownFamily(TextFormat fmt);
}
