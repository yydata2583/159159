#pragma once

#include <QString>
#include <QStringList>
#include <QVector>

// 纯 C++ 词法高亮器（开发文档「方案 B」）：
// 零外部依赖、纯函数、可重入；供预览 HTML 着色与编辑器围栏代码块着色共用。
namespace CodeLexer {

enum class TokenType {
    Plain, Keyword, Type, Function, String, Comment, Number,
    Operator, Preprocessor, Tag, Attribute, Value, Punctuation
};

struct Token {
    int start = 0;
    int length = 0;
    TokenType type = TokenType::Plain;
};

// fenceInfo（如 "cpp"、"python"、"js x"、""）归一化为语言键；未知返回空串。
QString detectLanguage(const QString& fenceInfo);

// 受支持语言键的固定顺序表（索引稳定，含索引 0 的空串 = 未知/纯文本）。
QStringList languageKeys();

// 语言键 -> 索引（未知返回 0）；索引 -> 语言键（越界返回空串）。
int languageIndex(const QString& langKey);
QString languageAt(int index);

// 按语言键切 token；未知/空语言返回空（由调用方按 Plain 处理）。
QVector<Token> tokenize(const QString& code, const QString& langKey);

} // namespace CodeLexer
