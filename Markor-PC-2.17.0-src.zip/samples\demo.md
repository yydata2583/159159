# 樱花主题演示 · Markor

这是一段 **Markdown** 演示文本，用于展示 *语法高亮* 与 ~~删除线~~、`行内代码` 的渲染效果。

## 功能清单

- [x] 深色 / 浅色 / **樱花** 主题
- [x] Markdown 语法高亮
- [x] 实时预览
- [ ] 更多特性开发中

## 代码示例

```cpp
#include <QApplication>
int main(int argc, char** argv) {
    QApplication app(argc, argv);
    return app.exec();
}
```

> 这是一段引用文字，用于展示引用块样式。
> 樱花飘落，粉白相间。

### 表格

| 主题 | 背景 | 强调色 |
|------|------|--------|
| 浅色 | #ffffff | #3574f0 |
| 深色 | #1e2127 | #3574f0 |
| 樱花 | #fff5f7 | #f2608f |

---

[Markor 项目](https://github.com/gsantner/markor) · `v2.17.0`
