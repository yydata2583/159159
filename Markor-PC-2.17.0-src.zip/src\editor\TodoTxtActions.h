#pragma once
#include <QChar>

class EditorWidget;

// Todo.txt task operations, mirroring Markor's TodoTxtActionButtons.
// Line-scoped operations act on the line at the cursor; document-scoped
// operations (archive, sort) act on the whole buffer.
namespace TodoTxtActions {
    // Toggle "x " completion marker (+ completion date) on the current line.
    void toggleDone(EditorWidget* ed);

    // Cycle priority on the current line: (A) -> (B) -> (C) -> none -> (A).
    void cyclePriority(EditorWidget* ed);

    // Set an explicit priority ('A'..'Z', or null/0 to clear) on the current line.
    void setPriority(EditorWidget* ed, QChar p);

    // Insert today's date (yyyy-MM-dd) at the cursor.
    void insertToday(EditorWidget* ed);

    // Append today's date to the end of the current line if not already present.
    void appendToday(EditorWidget* ed);

    // Set / replace the due:yyyy-MM-dd tag on the current line (prompts for date).
    void setDueDate(EditorWidget* ed);

    // Move all completed ("x ...") tasks to done.txt next to the current file.
    void archiveDone(EditorWidget* ed);

    // Sort tasks: active first (by priority), then completed (by completion date).
    void sortByPriority(EditorWidget* ed);
}
