#include "SettingsDialog.h"
#include "app/AppSettings.h"
#include "app/ThemeManager.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QLabel>
#include <QComboBox>
#include <QSpinBox>
#include <QCheckBox>
#include <QFontComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QFileDialog>
#include <QSignalBlocker>
#include <QEvent>
#include <QToolTip>

SettingsDialog::SettingsDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("设置"));
    resize(520, 600);

    AppSettings& s = AppSettings::instance();
    auto* root = new QVBoxLayout(this);

    // --- Appearance ---
    auto* appearance = new QGroupBox(tr("外观"), this);
    auto* aForm = new QFormLayout(appearance);

    _themeCombo = new QComboBox(appearance);
    for (const auto& p : ThemeManager::availableThemes())
        _themeCombo->addItem(p.second, p.first);
    int idx = _themeCombo->findData(s.theme());
    _themeCombo->setCurrentIndex(idx < 0 ? 0 : idx);
    aForm->addRow(tr("主题："), _themeCombo);

    _followSystem = new QCheckBox(tr("跟随系统深/浅色"), appearance);
    _followSystem->setChecked(s.followSystemTheme());
    aForm->addRow(QString(), _followSystem);

    // 联动：手动选具体主题（如樱花）即取消"跟随系统"；
    // 勾选"跟随系统"时主题下拉显示系统当前值（保持可选，便于一键改为具体主题）。
    auto syncThemeUi = [this](bool followSystem) {
        if (followSystem) {
            const QSignalBlocker b(_themeCombo);
            const int i = _themeCombo->findData(ThemeManager::systemThemeId());
            if (i >= 0)
                _themeCombo->setCurrentIndex(i);
        }
    };
    syncThemeUi(_followSystem->isChecked());
    connect(_followSystem, &QCheckBox::toggled, this, [syncThemeUi](bool checked) {
        syncThemeUi(checked);
    });
    connect(_themeCombo, &QComboBox::currentIndexChanged, this, [this](int) {
        if (_followSystem->isChecked()) {
            const QSignalBlocker b(_followSystem);
            _followSystem->setChecked(false);
        }
    });
    root->addWidget(appearance);

    // --- Editor ---
    auto* editor = new QGroupBox(tr("编辑器"), this);
    auto* eForm = new QFormLayout(editor);

    _fontCombo = new QFontComboBox(editor);
    _fontCombo->setCurrentFont(QFont(s.editorFontFamily()));
    eForm->addRow(tr("字体："), _fontCombo);

    _fontSize = new QSpinBox(editor);
    _fontSize->setRange(8, 40);
    _fontSize->setValue(s.editorFontSize());
    _fontSize->setToolTip(tr("编辑器窗口里按住 Ctrl + 鼠标滚轮可直接调节字号"));
    _fontSize->installEventFilter(this);
    eForm->addRow(tr("字号："), _fontSize);

    _wordWrap = new QCheckBox(tr("自动换行"), editor);
    _wordWrap->setChecked(s.wordWrap());
    _lineNumbers = new QCheckBox(tr("显示行号"), editor);
    _lineNumbers->setChecked(s.lineNumbers());
    _highlighting = new QCheckBox(tr("语法高亮"), editor);
    _highlighting->setChecked(s.syntaxHighlighting());
    eForm->addRow(QString(), _wordWrap);
    eForm->addRow(QString(), _lineNumbers);
    eForm->addRow(QString(), _highlighting);

    _previewFollow = new QCheckBox(tr("预览跟随编辑窗口"), editor);
    _previewFollow->setChecked(s.previewFollowEditor());
    eForm->addRow(QString(), _previewFollow);

    _previewSoftBreaks = new QCheckBox(tr("软换行显示为换行（单换行即换行）"), editor);
    _previewSoftBreaks->setChecked(s.previewSoftBreaks());
    _previewSoftBreaks->setToolTip(tr("开启时段落内单换行渲染为换行；关闭则按 CommonMark 以空格连接。"));
    eForm->addRow(QString(), _previewSoftBreaks);
    // 勾选即时生效：立即持久化并通知所有预览重渲染
    connect(_previewSoftBreaks, &QCheckBox::toggled, this, [this](bool on) {
        AppSettings::instance().setPreviewSoftBreaks(on);
        emit previewSettingsChanged();
    });
    root->addWidget(editor);

    // --- 预览窗口（字体/字号 + 大纲面板行为） ---
    auto* sidebar = new QGroupBox(tr("预览窗口"), this);
    auto* sbForm = new QFormLayout(sidebar);

    _previewFontCombo = new QFontComboBox(sidebar);
    _previewFontCombo->setCurrentFont(QFont(s.previewFontFamily()));
    sbForm->addRow(tr("字体："), _previewFontCombo);

    _previewFontSize = new QSpinBox(sidebar);
    _previewFontSize->setRange(10, 28);
    _previewFontSize->setSuffix(tr(" px"));
    _previewFontSize->setValue(s.previewFontSize());
    _previewFontSize->setToolTip(tr("预览窗口里按住 Ctrl + 鼠标滚轮可直接调节字号"));
    _previewFontSize->installEventFilter(this);
    sbForm->addRow(tr("字号："), _previewFontSize);

    _outlineDefault = new QComboBox(sidebar);
    _outlineDefault->addItem(tr("开启"), true);
    _outlineDefault->addItem(tr("关闭"), false);
    _outlineDefault->setCurrentIndex(s.outlineAutoCollapse() ? 0 : 1);
    _outlineDefault->setToolTip(tr("开启后，点击大纲章节跳转预览时大纲面板自动收起；关闭则保持展开。"));
    sbForm->addRow(tr("大纲自动收起："), _outlineDefault);
    root->addWidget(sidebar);

    // --- Vault ---
    auto* vault = new QGroupBox(tr("文档库位置"), this);
    auto* vForm = new QFormLayout(vault);
    _vaultEdit = new QLineEdit(s.vaultDir(), vault);
    auto* browse = new QPushButton(tr("浏览…"), vault);
    browse->setProperty("secondary", true);
    // 回车误开文档库的根因：未指定默认按钮时，创建顺序最靠前的
    // autoDefault 按钮（就是这个"浏览…"）会成为对话框默认按钮，
    // 在字号框等控件里按回车等于点了它。关掉它的 autoDefault。
    browse->setAutoDefault(false);
    auto* vRow = new QHBoxLayout();
    vRow->addWidget(_vaultEdit);
    vRow->addWidget(browse);
    vForm->addRow(tr("路径："), vRow);
    root->addWidget(vault);

    // --- Sync（星型拓扑：只连服务器；服务器信息默认为空，不写死）---
    auto* sync = new QGroupBox(tr("多端同步（内嵌 Syncthing）"), this);
    auto* sForm = new QFormLayout(sync);

    _syncEnabled = new QCheckBox(tr("启用同步（仅软件运行期间生效）"), sync);
    _syncEnabled->setChecked(s.syncEnabled());
    sForm->addRow(QString(), _syncEnabled);

    _syncDeviceName = new QLineEdit(s.syncDeviceName(), sync);
    sForm->addRow(tr("本机名称："), _syncDeviceName);

    _syncServerId = new QLineEdit(s.syncServerDeviceId(), sync);
    _syncServerId->setPlaceholderText(tr("同步服务器的 Syncthing 设备 ID"));
    sForm->addRow(tr("服务器设备 ID："), _syncServerId);

    _syncServerAddr = new QLineEdit(s.syncServerSyncAddress(), sync);
    _syncServerAddr->setPlaceholderText(tr("tcp://服务器IP:22000 或留空用自动发现"));
    sForm->addRow(tr("Syncthing 服务器地址："), _syncServerAddr);

    _syncServerApi = new QLineEdit(s.syncServerApi(), sync);
    _syncServerApi->setPlaceholderText(tr("http://服务器IP:8910"));
    sForm->addRow(tr("服务器地址（监听地址）："), _syncServerApi);

    _syncServerApiKey = new QLineEdit(s.syncServerApiKey(), sync);
    _syncServerApiKey->setEchoMode(QLineEdit::Password);
    _syncServerApiKey->setPlaceholderText(tr("锁文件服务 Bearer Key"));
    sForm->addRow(tr("API Key（锁文件，提示已打开窗口）："), _syncServerApiKey);

    root->addWidget(sync);

    root->addStretch();

    // --- Buttons ---
    auto* btns = new QHBoxLayout();
    btns->addStretch();
    auto* cancel = new QPushButton(tr("取消"), this);
    cancel->setProperty("secondary", true);
    cancel->setAutoDefault(false);
    auto* ok = new QPushButton(tr("确定"), this);
    ok->setDefault(true);   // 回车显式走"确定"
    btns->addWidget(cancel);
    btns->addWidget(ok);
    root->addLayout(btns);

    connect(browse, &QPushButton::clicked, this, &SettingsDialog::browseVault);
    connect(cancel, &QPushButton::clicked, this, &QDialog::reject);
    connect(ok, &QPushButton::clicked, this, &SettingsDialog::applyAndClose);
}

void SettingsDialog::browseVault()
{
    QString dir = QFileDialog::getExistingDirectory(this, tr("选择文档库文件夹"),
                                                    _vaultEdit->text());
    if (!dir.isEmpty())
        _vaultEdit->setText(dir);
}

bool SettingsDialog::eventFilter(QObject* obj, QEvent* event)
{
    // 点击/Tab 进入字号框立即弹出提示（位置：控件下沿）
    if (event->type() == QEvent::FocusIn
        && (obj == _fontSize || obj == _previewFontSize)) {
        auto* sb = qobject_cast<QWidget*>(obj);
        const QPoint p = sb->mapToGlobal(QPoint(0, sb->height() + 2));
        QToolTip::showText(p, sb->toolTip(), sb);
    }
    return QDialog::eventFilter(obj, event);
}

void SettingsDialog::applyAndClose()
{
    AppSettings& s = AppSettings::instance();
    const QString themeId = _themeCombo->currentData().toString();
    const bool themeDirty = (themeId != s.theme());
    const bool followDirty = (_followSystem->isChecked() != s.followSystemTheme());
    const QString oldVault = s.vaultDir();
    const QString newVault = _vaultEdit->text().trimmed();

    s.setTheme(themeId);
    s.setFollowSystemTheme(_followSystem->isChecked());
    s.setEditorFontFamily(_fontCombo->currentFont().family());
    s.setEditorFontSize(_fontSize->value());
    s.setWordWrap(_wordWrap->isChecked());
    s.setLineNumbers(_lineNumbers->isChecked());
    s.setSyntaxHighlighting(_highlighting->isChecked());
    s.setPreviewFollowEditor(_previewFollow->isChecked());
    s.setPreviewSoftBreaks(_previewSoftBreaks->isChecked());
    s.setOutlineAutoCollapse(_outlineDefault->currentData().toBool());
    s.setPreviewFontFamily(_previewFontCombo->currentFont().family());
    s.setPreviewFontSize(_previewFontSize->value());
    if (!newVault.isEmpty() && newVault != oldVault)
        s.setVaultDir(newVault);
    const bool syncDirty = (s.syncEnabled() != _syncEnabled->isChecked())
        || (s.syncDeviceName() != _syncDeviceName->text().trimmed())
        || (s.syncServerDeviceId() != _syncServerId->text().trimmed())
        || (s.syncServerSyncAddress() != _syncServerAddr->text().trimmed())
        || (s.syncServerApi() != _syncServerApi->text().trimmed())
        || (s.syncServerApiKey() != _syncServerApiKey->text());
    s.setSyncEnabled(_syncEnabled->isChecked());
    s.setSyncDeviceName(_syncDeviceName->text().trimmed());
    s.setSyncServerDeviceId(_syncServerId->text().trimmed());
    s.setSyncServerSyncAddress(_syncServerAddr->text().trimmed());
    s.setSyncServerApi(_syncServerApi->text().trimmed());
    s.setSyncServerApiKey(_syncServerApiKey->text());
    s.sync();

    if (themeDirty || followDirty)
        emit themeChanged(_followSystem->isChecked() ? ThemeManager::systemThemeId() : themeId);
    emit editorSettingsChanged();
    emit previewSettingsChanged();
    if (!newVault.isEmpty() && newVault != oldVault)
        emit vaultChanged(newVault);
    if (syncDirty)
        emit syncSettingsChanged();

    accept();
}
