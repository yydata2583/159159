# 架构说明（architecture.md）

> 目标：读完本文件即可理解整个程序的运行时结构与数据流，不必读源码。
> 覆盖：分层、对象图、渲染管线、双向滚动同步、撤销体系、主题体系、同步子系统、入口流程、已知限制。

---

## 1. 分层

```
┌─────────────────────────────────────────────────────────────────┐
│ 入口层   src/main.cpp：QApplication、i18n、主题预应用、CLI 解析      │
├─────────────────────────────────────────────────────────────────┤
│ 组装层   src/app/MainWindow：菜单/工具栏/状态栏/标签页/信号接线      │
├──────────────┬───────────────────────┬──────────────────────────┤
│ 交互层        │ 领域层                 │ 基础设施层                 │
│ editor/      │ core/                  │ app/AppSettings（QSettings）│
│ preview/     │  Document 格式化       │ app/ThemeManager（qss+色板）│
│ sidebar/     │  FormatDetector        │ sync/SyncManager（Syncthing）│
│ browser/     │  MarkdownConverter     │ render/（Math/Mermaid 画图）│
│ search/      │  TodoTxt（任务模型）    │ resources/（qss/图标/i18n） │
│ ui/（对话框） │                        │ third_party/webview2       │
└──────────────┴───────────────────────┴──────────────────────────┘
```

依赖方向：交互层 → 领域层 → 基础设施层（单向）；`core/` 不依赖任何 UI 类（可独立测试）。

---

## 2. 运行时对象图

```
QApplication
└─ MainWindow (QMainWindow)
   ├─ QMenuBar（含角落按钮 HistoryButtons: 撤回/前进）
   ├─ QToolBar "FormatToolBar"（14 个格式动作 + 格式下拉 FormatCombo + 🧹整理）
   ├─ QStatusBar（状态消息：保存/主题/同步/归档等）
   ├─ central: QHBoxLayout
   │   ├─ FileSidebar（主窗口级，固定最左缘，不随标签切换）
   │   │   ├─ QTabBar「最近 | 文件」→ QStackedWidget
   │   │   │   ├─ 最近: QListWidget（AppSettings::recents()，20 条）
   │   │   │   └─ 文件: FileBrowserWidget（QTreeView + QFileSystemModel）
   │   │   └─ SidebarHandle（右缘 8px 把手：单击收展/拖拽调宽）
   │   └─ QTabWidget _tabs（可关闭、可拖动、documentMode）
   │       └─ 每页 QWidget = QVBoxLayout → QSplitter "EditorPreviewSplitter"
   │           ├─ EditorWidget（QPlainTextEdit + LineNumberArea + Highlighter）
   │           └─ rightBox = QHBoxLayout
   │               ├─ OutlinePanel（每页一套：QTreeWidget + SidebarHandle）
   │               └─ PreviewWidget（QStackedWidget）
   │                   ├─ QTextBrowser（Markdown 等富文本预览）
   │                   └─ HtmlPreviewView（WebView2，仅 HTML 文件）
   ├─ SearchDialog（非模态单例窗口，跨标签重绑）
   └─ SyncManager::instance()（隐藏子进程 syncthing.exe）
```

**关键点**
- 一个**文档标签页** = 编辑器 + 大纲 + 预览三件套，创建于 `MainWindow::createPage()`；同路径文件重复打开只切换已有标签（`indexOfPath`）。
- `FileSidebar` 是**主窗口级单实例**（批次2 设计）；`OutlinePanel` 是**每页各一套**。
- 页销毁时编辑器/预览可能先于 `ThemeManager`/`SyncManager` 消亡，因此它们的连接一律用 `QPointer` 保护（见 `createPage` 注释）。

---

## 3. 渲染管线（预览 / 导出共用）

**入口数据**：`EditorWidget::toPlainText()`（纯文本）+ `TextFormat`。

### 3.1 Markdown 系（QTextBrowser 路径）

```
markdown 文本
  │  PreviewWidget::buildRichBody()（PreviewWidget.cpp 顶部，静态函数）
  │   ① 分段：正文段 / ```mermaid 围栏 / $…$·$$…$$ 公式段
  │   ② 正文段 → MarkdownConverter::toHtmlFragment(md, opts, &blocks)
  │        · 每个块级标签注入 data-src-line="源行号(1起)"
  │        · 同步产出 QVector<BlockInfo>（srcLine / isTable / isPre / slug）
  │   ③ mermaid 段 → MermaidRenderer::render() → QPixmap
  │        · embedImages=true（屏幕预览）→ data URI 内嵌 <img>
  │        · embedImages=false（PDF 导出）→ 具名资源 <img src="mermaid-N">
  │   ④ 公式段 → MathRenderer::render() → QPixmap（同上两种嵌入方式）
  │   ⑤ 拼接 body → MarkdownConverter::wrapHtmlDocument(body, dark, fontPx, scripts)
  ▼
QTextBrowser::setHtml()
  │  postProcessDocument(blocks)：把 QTextDocument 根级子元素（块/表格）
  │  与 BlockInfo 一一对应成 QVector<Elem>，供滚动映射；对不上时降级为比例估算
  ▼
屏幕呈现（主题 CSS 来自 ThemeManager 色值 + wrapHtmlDocument 的模板）
```

- **预览更新触发**：编辑器 `textChanged` → `MainWindow::syncPreview()` → `PreviewWidget::setMarkdown()` → `scheduleRender()`（防抖定时器）→ `renderNow()`。避免每个按键全量重渲染。
- **选项**：`preview/softBreaks`（单换行渲染为 `<br>`，Markor 风格，默认开）；`preview/fontSize`（正文字号 px，Ctrl+滚轮缩放）。
- **导出复用同管线**：
  - HTML 导出 = `PreviewWidget::toHtmlDocument()`（图表/公式以 data URI 内嵌，含复制按钮等脚本）。
  - PDF 导出 = `toHtmlWithResources(&resources)` → `QTextDocument::addResource(ImageResource)` → `QPrinter`(A4, 15mm 边距) 打印。
  - 复制富文本 = `MarkdownConverter::toHtmlFragment()`（不带图表内嵌）。

### 3.2 HTML / XML 文件（WebView2 路径）

```
TextFormat::Html 且文件已保存 → HtmlPreviewView::openFile(路径)
  ├─ WebView2 环境可用：Edge 内核渲染（执行 JS/现代 CSS），相对资源按文件目录解析
  └─ 运行时缺失/初始化失败：降级为 QTextBrowser 源码只读展示 + 提示
未保存的新 HTML 文档 → setHtmlSource(内存文本)（相对资源无法解析）
保存/刷新后 → reloadHtmlPreview()
```

`PreviewWidget` 内部 `QStackedWidget` 按 `isHtmlMode()` 在两套视图间切换。

### 3.3 原生渲染器（无外部引擎）

| 渲染器 | 支持范围 | 不支持 |
|---|---|---|
| `MermaidRenderer` | flowchart/graph（节点、边、标签、基本形状、TD/LR）、sequenceDiagram（参与者、箭头、注释） | 其他图种 → `canRender()` false，调用方回落为代码块 |
| `MathRenderer` | KaTeX 子集：变量/数字/运算符、上下标、`\frac`、`\sqrt`、希腊字母、`\sum \int \prod \infty \le \ge \ne \to \pm`、`\left \right` 围栏、命名符号 | 未知命令降级为普通文本 |

两者都输出 `QPixmap`，颜色取自 `ThemeManager`（fg/bg/dark 参数），因此**主题切换自动联动**。

---

## 4. 双向滚动同步（源行级，本项目核心机制）

**目标**：编辑器滚动 → 预览**43% 参考点平滑**跟随（帧驱动）；预览点击 → 编辑器定位到源行。大纲/锚点跳转走"该源行最后一个元素"的跳转语义。

### 4.1 行号约定
- 编辑器：`QPlainTextEdit` 的块号 + 1 = 源行号（`EditorWidget::firstVisibleSourceLine()`）。
- **小数源行**（`xxxSourceLineF()`）：整数部分 = 首可见源行，小数部分 = 该行被滚出视口顶部的高度比例（块内像素比例）。双向同步全程使用小数源行，保证连续无跳变。
- 编辑器参考点：`EditorWidget::sourceLineFAtViewportY(y)` 取视口内像素 y 对应的源行（含块内比例），供 43% 参考点跟随。
- 预览：HTML 块级元素带 `data-src-line`；每元素附 `spanLines`（覆盖的源行数，与下个元素行号之差，末块算到文末）。
- 大纲：`OutlinePanel::parseHeadings()` 从编辑器纯文本解析 H1–H4（**跳过代码围栏**），记录源行号。

### 4.2 逐行像素映射表（块内插值）
预览侧两张互逆的映射函数（`PreviewWidget`）：
```
docYForSourceLine(lineF):   源行(小数) -> 文档 Y
    定位覆盖该行的元素（同源行多元素取首个），
    y = rect.top() + (lineF - srcLine)/spanLines * rect.height()
sourceLineForDocY(y):       文档 Y -> 源行(小数)   （上式的逆，供 ScrollSpy/重渲染锚定）
```
> 例：一个 3 行段落在预览中占 120px，则第 2 行（行内偏移 0）对应段落顶部+40px——编辑器滚到段落中间，预览也停在段落中间，不再是“跳到段落开头卡住不动”。

### 4.3 帧驱动平滑滚动（预览侧）
`PreviewWidget` 内置 16ms 定时器（`_smoothTimer`），每帧向目标滚动位置靠近 30%（指数缓出，与参考网页实现一致）：
```
startSmoothTo(y)   设定目标（动画中仅更新目标值，不重启定时器）；置 _programmaticScroll
smoothTick()       value += (target - value) * 0.30；|diff| < 0.5 时归位并 stopSmooth()
stopSmooth()       停定时器、清标志；用户滚轮/点按预览、重渲染、即时定位均触发
```
QPropertyAnimation 方案已废弃（原 `_scrollAnim` 删除）。目标位置实时更新，滚动跟随手感与参考实现一致。

### 4.4 数据流
```
编辑器滚动条 valueChanged
  → if (editor->isProgrammaticScroll()) return;          // 防回环
  → if (!AppSettings::previewFollowEditor()) return;     // 开关（默认开）
  → 到顶/到底边界：preview->followEditorEdge(到底?)
  → preview->followSourceLineF(43%处源行, 12.5/29)       // 43% 参考点，帧驱动平滑

预览点击正文块（eventFilter 捕获；预览滚动不回推编辑器）
  → emit sourceLineRequested(块的源行) → editor->scrollToSourceLine(line)
  → 预览滚动条 valueChanged → topSourceLineF() → _lastTopLineF（重渲染/resize 重锚）
  → emit currentTopSourceLineChanged(⌊lineF⌋) → OutlinePanel ScrollSpy

大纲点击/锚点点击 → scrollToSourceLine(line, smooth=true) → jumpToSourceLine(line)
  → 取该源行**最后一个**元素（heading 在 DOM 靠后，避开手写 TOC 行号重叠）
  → startSmoothTo(elemRect.top - 12)
```

### 4.5 防回环：为什么用标志而不是 QSignalBlocker
程序滚动也会触发 `valueChanged`。若用 `QSignalBlocker`，另一侧的视口联动信号会被一并吞掉，导致联动失效。因此**两侧各持有 `_programmaticScroll` 布尔**，槽函数开头自行判断返回（详见 `MainWindow::createPage` 内长注释、EditorWidget/PreviewWidget 头注释）。

### 4.6 降级
QTextBrowser 块计数与转换器块序不一致时（典型：多块级子标签的原生 HTML 块），`postProcessDocument` 的 `_mappingValid=false`，滚动映射降级为**按行数比例估算**（`scrollToSourceLineF` 兜底分支）。不会崩，只是不准。

> 注：块↔源行对齐早已不是“块计数一一对应”，而是**文本锚定**（每个文档块取前 12 个非空白字符作特征串，在源文本中向后查找命中行，未命中继承上行保持单调，见 `postProcessDocument` 长注释）；逐行插值建立在这层对齐之上。

### 4.7 锚点（手写目录 `#fragment`）匹配
`handleAnchorClick` 三级匹配：① slug 精确匹配（反向遍历，heading DOM 靠后优先）；② `normalizeAnchorText` 归一化匹配（小写、全角→半角、中文数字↔阿拉伯数字、去分隔符——容忍 `#三syncthing-文件同步` 对 `#3syncthing-文件同步` 这类编号写法差异）；③ `sourceLineForFragment` 按转换器同规则（slugFor + 同序去重）重算源码标题 slug 直接定位源行。全部落 `jumpToElem/jumpToSourceLine`（元素矩形顶 -12px，帧驱动平滑）。无效锚点静默（P11.4）。

---

## 5. 撤销 / 历史：双轨并存（易混淆，注意）

| 轨道 | 实现 | 入口 | 用途 |
|---|---|---|---|
| 标准撤销/重做 | `QTextDocument` undo stack | 菜单"编辑→撤销/重做"（Ctrl+Z/Y） | 细粒度输入撤销 |
| 快照式撤回/前进 | `EditorWidget::_history`（文本+光标快照） | 菜单栏右上角"撤回/前进"按钮 | 粗粒度回溯 |

快照轨道细节：输入停顿约 **400ms**（`_historyTimer`）存一条快照，**上限 50 条**（`_historyIndex` 游标）。存在的原因：`QTextDocument` **没有公开 `setUndoLimit`**，Qt 内建栈不可控（ADR-003）。`resetSnapshotHistory()` 在载入新文件时清空。

---

## 6. 主题体系（ThemeManager）

`apply(theme)` 做四件事：
1. `qApp->setStyleSheet()` — 加载 `resources/theme/{light,dark,sakura}.qss`；
2. 改写 `QPalette` — 让原生对话框配色匹配（Window/Base/Text/Highlight）；
3. 标题栏着色 — `dwmapi`（`DwmSetWindowAttribute`，仅 `Q_OS_WIN`），通过 `eventFilter` 对每个新 `Show` 的顶层窗口生效；
4. `emit themeChanged(theme)` → 各页编辑器 `refreshFormat()`（重建高亮器取色）+ 预览 `refreshTheme()`（重渲染）。

**颜色出口**：`editorBg/editorFg/lineNumberFg/highlightBg` + Markdown 语法 9 色（heading/emphasis/strong/code/link/quote/list/hr/strike）。三个高亮器、两个渲染器、预览 CSS 全部从这里取色 → **加主题只改这里 + qss**。

**跟随系统**：`followSystemTheme=true`（默认）时启动按 `QPalette::Window` 亮度判定 light/dark（`systemThemeId()`，阈值 lightness<128）；用户手动选具体主题会**自动关闭跟随**并持久化。

---

## 7. 同步子系统（SyncManager + LockClient）

**定位**：可选功能。**星型拓扑**——本机只与"同步服务器"（NAS 存储节点）连接，
PC 与手机之间**不直连**（设备列表只有服务器、introducer 关闭、全局/本地发现关闭、无中继）。
同步仅在**软件运行期间**生效（启动时拉起、退出时停止）；不做"更新同步版本"（引擎
`autoUpgradeIntervalH=0` 关闭自升级，ADR-019）。

### 7.1 内嵌 Syncthing（SyncManager）
```
设置 sync/enabled=true 且服务器信息完整（设备ID+同步地址均非空；默认全空，缺填弹窗提示）
  → 启动内嵌 syncthing.exe（查找顺序：程序根目录 → bin\ 子目录；开发/安装布局不同，
    installer.iss 装到 {app}\bin——“路径错位”即旧代码只找根目录导致引擎永远找不到）：
      serve --home=%LOCALAPPDATA%/…/syncthing
             --gui-address=127.0.0.1:8385      ← host:port 形式（带 scheme/尾斜杠会解析失败）
             --gui-apikey=<随机UUID> --no-browser --no-console --log-file=<home>/syncthing.log
  → 每 1.5s GET rest/system/status（≤40 次）拿 myID → ready → applyConfig()（幂等、可重复应用）：
      · devices: 仅服务器设备（sync/serverDeviceId，name=markor-server，
        addresses=[sync/serverSyncAddress]（空则 dynamic），introducer 删除）
      · folders: id=markor-vault，path=**当前** vaultDir（每次应用都取当前值+mkpath；
        加固项：旧版启动时一次性落配置，改文档库后同步的不是所见目录）
      · options: relaysEnabled=false、globalAnnounceEnabled=false、
        localAnnounceEnabled=false、autoUpgradeIntervalH=0、清掉 relay:// 监听地址
      · gui: 127.0.0.1:8385、tls=false、apiKey
  → PUT rest/config → checkServerConnection()：每 3s GET rest/system/connections
      （≤10 次），服务器设备 connected → serverConnectionResult(true,…)
      超时/失败 → serverConnectionResult(false,…)
  → MainWindow 收到信号一律 **QMessageBox 弹窗**（成功 information / 失败 warning）。
关闭/退出 → stop()：terminate→(3s)→kill。
```

### 7.2 文件锁客户端（LockClient）
对接服务器 lockserver API（协议见服务器 README §五）：
```
打开文档 → POST /api/v1/open   {device_id,device_name,vault_id:"markor-vault",path:<vault 相对路径>}
每 30s    → POST /api/v1/heartbeat（70s 无心跳服务器过期）
保存/关标签/退出 → POST /api/v1/close
返回 holders 非空 → fileHeldElsewhere 信号 → MainWindow 弹"文件已在其他设备打开"。
服务器地址(sync/serverApi) 或 API Key(sync/serverApiKey) 为空 → 静默禁用（不发请求）。
```

### 7.3 "18384 打不开"与"路径错位"的真正根因（含实锤）
1. **路径错位（主因）**：`installer.iss` 把 `syncthing.exe` 装到 `{app}\bin\`（开发构建同为
   `build\bin\`），而代码只找 `applicationDirPath()/syncthing.exe` → **引擎根本没被启动**，
   任何端口都无监听，状态栏报"未找到同步引擎"。已修：根目录与 `bin\` 两级查找。
2. 旧代码 `--gui-address=http://127.0.0.1:18384/` **带 scheme 与尾斜杠**，Syncthing 只接受
   `host:port` → 即使引擎启动，监听配置解析也会失败。
3. GUI **默认 HTTPS 自签证书**，浏览器 `http://` 访问必失败。
修复：两级查找 + `--gui-address=127.0.0.1:8385` + 配置 `gui.tls=false` → 引擎能起、浏览器直接可开。

## 8. 入口与 CLI 流程（main.cpp）

```
QApplication
 ├─ setApplicationName/DisplayName("Markor")、Version("2.17.0")、Organization("Markor")
 ├─ 安装 Qt 翻译器 qtbase_zh_CN / qt_zh_CN（资源 :/i18n）
 ├─ 【在建任何窗口之前】应用主题（followSystem ? systemThemeId : saved theme）
 ├─ QCommandLineParser: [file]、--screenshot、--export-html、--export-pdf
 ├─ MainWindow::show() → 构造时: 建 UI → 恢复 geometry/state → FileSidebar 指向 vault
 │                        → 开一个"未命名"标签 → applySyncSettings()
 ├─ 有位置参数 → openFilePath()
 └─ 导出/截图选项 → 执行后 QTimer 300~500ms 退出（留给渲染完成的时间）
```

> CLI 导出用途：自动化回归（渲染/截图）。注意 `--screenshot` 截 500ms 时刻的窗口。

---

## 9. 格式系统

- `FormatDetector::detect(path)` 按**扩展名**判定 `TextFormat`（`.txt` 特判：`todo.txt`/`done.txt`/`*.todo.txt` → TodoTxt）。完整映射表 → data-model.md §1。
- 工具栏"格式"下拉可**手动覆盖**（选"自动"恢复按扩展名识别）。新建未命名文档默认 Markdown，首次"另存为"后恢复自动识别。
- **同一套编辑器**服务所有格式；差异全部收敛在三处：
  1. 高亮器选择：`MarkdownHighlighter` / `TodoTxtHighlighter` / `SourceCodeHighlighter`（含 HTML 模式）/ 无；
  2. 格式化记号：`FormatActions::markupFor()` 按格式表（Markdown/AsciiDoc/Org/Wiki）；
  3. 预览渲染：目前**只有 Markdown 系渲染富文本**；HTML 文件走 WebView2；其余格式编辑器即所见。

---

## 10. Markdown 合规与 lint（高亮层的"红色波浪线"）

`MarkdownHighlighter` 兼做语法高亮 + **6 类 lint 诊断**（对应作者的 compliance-test 场景，见头文件注释）：
1. 未闭合 `**` / `*` 强调定界符；
2. 未闭合 ` ``` ` / `~~~` 围栏；
3. 表格缺 `|---|` 分隔行、表格紧贴正文无空行；
4. 列表续行缩进不足；
5. ATX 标题 `#` 后缺空格；
6. 结尾围栏带语言标注：仍正确闭合，仅警告标注部分。

实现要点：块状态机（`BlockState`：Normal/TableRow/OrphanPipe/TableHead；围栏状态编码为 `1000+反引号长度` / `2000+波浪线长度`）；跨块失效后 `scheduleRefresh()` 合并为**一次全量重刷**（`_rehighlightGuard` 防递归）。

`FormatActions::tidyMarkdown()`（Ctrl+Alt+T）则是**一次性修复器**：补表格分隔行、闭合未闭合围栏、裸标题补 `#`、连续 `---` 规范化、待办行规范为 `- [ ]/- [x]`。原则：**宁少勿错**。

---

## 11. 已知限制 / TODO（勿当作 bug 重复分析）

来自 `MarkdownConverter.cpp` 头注释（COMMONMARK-TODO）：
1. `[id]:` 引用定义在 Mermaid/公式分段两侧不可见（`buildRichBody` 分段转换所致）；
2. 引用块内部**不做二次块解析**（列表/代码/多段落嵌套在 `>` 内不递归）；
3. 多块级子标签的原生 HTML 块在 QTextBrowser 中块计数不可预测 → 源行映射降级（§4.5）。

其他：
- AsciiDoc/OrgMode/WikiText/CSV/KeyValue **只有识别 + 格式感知动作**，无专用高亮/渲染（FEATURE_MAP 🟡）。
- 预览任务勾选**不写回文件**（视觉切换）。
- PlantUML、zip 备份、逐文件设置、语言切换：未实现（FEATURE_MAP ❌）。
- 写冲突不做文件占用检查（`saveCurrent` 注释），交给 Syncthing `.sync-conflict`。

---

## 12. 模块间信号速查（接线都在 MainWindow::createPage / buildMenus）

| 信号 | 发出方 | 消费方 | 语义 |
|---|---|---|---|
| `EditorWidget::textChanged` | 编辑器 | `MainWindow::syncPreview` | 预览重渲染 |
| `EditorWidget::dirtyChanged(bool)` | 编辑器 | 标签页标题加/去 `*` | 脏标记 |
| `EditorWidget::statusMessage` | 编辑器 | 状态栏 | 一次性提示 |
| `PreviewWidget::sourceLineRequested(int)` | 预览 | 编辑器 `scrollToSourceLine` | 反向定位 |
| `PreviewWidget::currentTopSourceLineChanged(int)` | 预览 | `OutlinePanel::setActiveSourceLine` | ScrollSpy |
| `OutlinePanel::headingActivated(int)` | 大纲 | （绑定页内）滚动到源行 | 大纲跳转 |
| `FileSidebar::fileActivated/openInNewTab/toggleFavorite` | 侧边栏 | MainWindow | 打开/新标签/收藏 |
| `AppSettings::recentsChanged()` | 设置 | `FileSidebar::rebuildRecents` | 最近列表刷新 |
| `ThemeManager::themeChanged(QString)` | 主题 | 每页 editor/preview（QPointer 保护） | 重取色重渲染 |
| `SyncManager::statusMessage / deviceIdReady` | 同步 | 状态栏 | 同步状态 |
| `SettingsDialog::themeChanged/editorSettingsChanged/previewSettingsChanged/vaultChanged/syncSettingsChanged` | 设置对话框 | MainWindow 各自应用 | 即时生效 |
