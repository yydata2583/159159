#include "TodoTxtFilterDialog.h"
#include "editor/EditorWidget.h"
#include "core/TodoTxt.h"
#include "app/ThemeManager.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QLineEdit>
#include <QComboBox>
#include <QCheckBox>
#include <QLabel>
#include <QPushButton>
#include <QRegularExpression>

TodoTxtFilterDialog::TodoTxtFilterDialog(EditorWidget* editor, QWidget* parent)
    : QDialog(parent)
    , _editor(editor)
{
    setWindowTitle(tr("Todo.txt 过滤器"));
    resize(520, 260);

    auto* root = new QVBoxLayout(this);

    auto* form = new QFormLayout();
    _expr = new QLineEdit(this);
    _expr->setPlaceholderText(tr("例如：+work @home pri:A due:2025 done  （- 前缀表示排除）"));
    form->addRow(tr("过滤表达式："), _expr);

    _quickFilters = new QComboBox(this);
    _quickFilters->setEditable(false);
    _quickFilters->setToolTip(tr("从当前文档中提取的项目 / 上下文，点击快速填入"));
    form->addRow(tr("快捷过滤："), _quickFilters);
    root->addLayout(form);

    auto* opts = new QHBoxLayout();
    _caseSensitive = new QCheckBox(tr("区分大小写"), this);
    opts->addWidget(_caseSensitive);
    opts->addStretch();
    root->addLayout(opts);

    _stats = new QLabel(tr("未应用过滤"), this);
    _stats->setObjectName(QStringLiteral("HeaderSub"));
    root->addWidget(_stats);

    auto* btns = new QHBoxLayout();
    auto* refresh = new QPushButton(tr("刷新快捷项"), this);
    refresh->setProperty("secondary", true);
    auto* clear = new QPushButton(tr("清除"), this);
    clear->setProperty("secondary", true);
    auto* apply = new QPushButton(tr("应用高亮"), this);
    btns->addWidget(refresh);
    btns->addStretch();
    btns->addWidget(clear);
    btns->addWidget(apply);
    root->addLayout(btns);
    root->addStretch();

    connect(apply, &QPushButton::clicked, this, &TodoTxtFilterDialog::applyFilter);
    connect(clear, &QPushButton::clicked, this, &TodoTxtFilterDialog::clearFilter);
    connect(refresh, &QPushButton::clicked, this, &TodoTxtFilterDialog::refreshQuickFilters);
    connect(_expr, &QLineEdit::returnPressed, this, &TodoTxtFilterDialog::applyFilter);
    connect(_quickFilters, &QComboBox::currentTextChanged, this, [this](const QString& t) {
        if (!t.isEmpty()) _expr->setText(t);
    });

    refreshQuickFilters();
}

void TodoTxtFilterDialog::refreshQuickFilters()
{
    _quickFilters->clear();
    if (!_editor)
        return;
    const QStringList lines = _editor->toPlainText().split(QLatin1Char('\n'));
    QStringList items;
    for (const QString& line : lines) {
        TodoTxtTask task(line);
        for (const QString& p : task.projects()) {
            const QString t = QStringLiteral("+") + p;
            if (!items.contains(t)) items << t;
        }
        for (const QString& c : task.contexts()) {
            const QString t = QStringLiteral("@") + c;
            if (!items.contains(t)) items << t;
        }
    }
    items.sort();
    _quickFilters->addItems(items);
}

int TodoTxtFilterDialog::matchCount(const QString& expr, bool* ok)
{
    if (!_editor) { *ok = false; return 0; }
    const bool cs = _caseSensitive->isChecked();
    const QStringList lines = _editor->toPlainText().split(QLatin1Char('\n'));
    int n = 0;
    for (const QString& line : lines) {
        TodoTxtTask task(line);
        if (TodoTxtFilter::matches(task, expr, cs))
            ++n;
    }
    *ok = true;
    return n;
}

void TodoTxtFilterDialog::applyFilter()
{
    if (!_editor)
        return;
    const QString expr = _expr->text().trimmed();
    const bool cs = _caseSensitive->isChecked();

    // Determine matching block numbers for highlighting.
    const QStringList lines = _editor->toPlainText().split(QLatin1Char('\n'));
    QList<int> blocks;
    int total = 0;
    for (int i = 0; i < lines.size(); ++i) {
        if (lines[i].trimmed().isEmpty())
            continue;
        ++total;
        TodoTxtTask task(lines[i]);
        if (TodoTxtFilter::matches(task, expr, cs))
            blocks.append(i);
    }

    QColor color = ThemeManager::instance().isDark()
                       ? QColor("#2c4a7c") : QColor("#ffe0a0");
    _editor->setFilterBlocks(blocks, color);

    _stats->setText(tr("匹配 %1 / %2 条任务").arg(blocks.size()).arg(total));
}

void TodoTxtFilterDialog::clearFilter()
{
    if (_editor)
        _editor->clearFilter();
    _expr->clear();
    _stats->setText(tr("已清除过滤"));
}
