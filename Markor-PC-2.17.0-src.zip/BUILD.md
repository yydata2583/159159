# Markor for Windows — 开发/编译环境

> 项目类型：**Qt 6 / C++17 / Widgets**（含 PrintSupport 用于导出 PDF）。
> **不需要** QtWebEngine（图表/公式用原生 QPainter 渲染，部署更轻）。
> HTML 文件的预览区使用 **Windows 自带的 WebView2（Edge 内核）** 做浏览器级渲染
> （执行页面 JavaScript / 现代 CSS）；头文件与导入库内置在 `third_party/webview2/`，
> 运行期仅需 `WebView2Loader.dll` 位于 exe 同目录，并要求系统已安装 WebView2 运行时
> （Win10/11 通常预装）。缺失运行时则自动降级为源码展示。
> 工程根目录即为 PC 端源码（含 CMakeLists.txt + markor-win.pro），Android 源码在同级 `markor-android/`。

---

## 一、需要安装的软件

| 软件 | 版本要求 | 用途 | 获取 |
|------|---------|------|------|
| **Qt 6** | ≥ 6.5（推荐 6.5.x / 6.7.x，本机实测 **6.8.3 MSVC 2022 64-bit**） | GUI 框架（Widgets + PrintSupport） | Qt Online Installer 或 vcpkg |
| **C++ 编译器** | MinGW 11+ 或 MSVC 2019/2022 | 编译 | MinGW 随 Qt 自带；MSVC 装 VS Build Tools |
| **CMake** | ≥ 3.16 | 构建（也可用 qmake） | cmake.org 或随 Qt Creator |
| **Qt Creator**（可选但推荐） | 随 Qt | IDE + 一键构建/调试 | 随 Qt 安装 |

C++ 标准：**C++17**（`CONFIG += c++17` / `CMAKE_CXX_STANDARD 17`）。

---

## 二、最简推荐方案（Qt Online Installer）

1. 下载 **Qt Online Installer**（qt.io 下载页 → "Download Qt"）。
2. 安装时勾选：
   - **Qt 6.x.x** → 组件 **MinGW 64-bit**（含 Widgets、PrintSupport）
   - **MinGW** 工具链（Qt 自带，无需另装）
   - **Qt Creator**（可选）
   - **CMake**（Qt 安装器里可选，或单独装）
3. 完成后 Qt 目录形如 `C:\Qt\6.7.2\mingw_64`。

---

## 三、编译

### 方式 A：Qt Creator（最简单）
1. 打开 Qt Creator → **打开文件或项目** → 选 `CMakeLists.txt`（或 `markor-win.pro`）。
2. 选 Kit（如 `Desktop Qt 6.7.2 MinGW 64-bit`）。
3. 点 **构建 ▶**（Ctrl+R 运行）。

### 方式 B：命令行 + CMake
```bat
cmake -S . -B build -DCMAKE_PREFIX_PATH=C:\Qt\6.8.3\msvc2022_64
cmake --build build --config Release
:: 产物: build\MarkorWin.exe
```

### 方式 C：命令行 + qmake
```bat
C:\Qt\6.8.3\msvc2022_64\bin\qmake.exe markor-win.pro
nmake release              :: MSVC 用 nmake / jom；MinGW 用 mingw32-make
:: 产物: release\MarkorWin.exe（与 CMake 路径不同，按 CMake 构建为准）
```

---

## 四、命令行参数（运行期）

```
MarkorWin.exe [file]                 打开指定文档
  --screenshot <png>                 截取主窗口并退出
  --export-html <html>               将打开的文档导出为 HTML 后退出
  --export-pdf  <pdf>                将打开的文档导出为 PDF 后退出
```

---

## 五、打包分发（可选）

在目标机器无需装 Qt，用 `windeployqt` 打包依赖（CMake + MSVC 构建）：
```bat
C:\Qt\6.8.3\msvc2022_64\bin\windeployqt.exe build\MarkorWin.exe
```
会把所需 Qt DLL/插件拷到 exe 旁，即可分发。应用图标（`.ico`）与版本信息（v2.17.0）
已由 `resources/app.rc` 嵌入 exe。

### 5.1 Syncthing 子进程二进制（同步引擎）

PC 端内嵌 Syncthing 作为隐藏子进程（见 `src/sync/SyncManager.cpp`）。
**版本固定：Syncthing v2.1.6 "Hafnium Hornet"**（与 NAS 端、手机端一致）。

- **下载源**：<https://github.com/syncthing/syncthing/releases> → `syncthing-windows-amd64-v2.1.6.zip`
- **本地存档**：`build/syncthing-windows-amd64-v2.1.6.zip`（11.43 MB，已随仓库携带，含 release.sig 签名）
- **放置路径**：`build/bin/syncthing.exe`（与 installer.iss 的 `[Files]` 段对应；如需重放：解压 zip 取 `syncthing-windows-amd64-v2.1.6/syncthing.exe` 放入）
- **为什么不在仓库里**：第三方闭源二进制，exe ~26 MB、zip ~11 MB，各端独立分发
- **参考**：NAS 端 `docker-compose.yml` 锁定 `syncthing/syncthing:v2.1.6`，手机端后续裁剪 `libsyncthing.so` 也基于同版本源码

### 5.2 ⚠️ windeployqt 不会自动拷 VC++ 运行时（MSVC 工具链）

这是 Qt 官方已知行为——windeployqt 假设目标机器已装 **Microsoft Visual C++ Redistributable 2015-2022**。
独立分发的 setup 里必须手动拷贝以下三个文件到 exe 旁：

```
msvcp140.dll
vcruntime140.dll
vcruntime140_1.dll
```

来源路径（VS 2022 Build Tools 默认安装）：
```
C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Redist\MSVC\14.44.35207\x64\Microsoft.VC143.CRT\
```

installer.iss 的 `[Files]` 段已包含这三个文件（`Source: "{#BuildDir}\*.dll"; DestDir: "{app}"` 通配匹配）。

---

## 六、代码结构（改哪里）

```
src/main.cpp              入口 / 命令行
src/app/                  主窗口、设置、主题
src/core/                 文档、格式识别、Markdown转换、Todo.txt 模型
src/editor/               编辑器、语法高亮、格式化动作
src/render/               Mermaid 图表 / KaTeX 公式 渲染器
src/preview/              实时预览
src/browser/              文件树
src/search/               搜索
src/ui/                   设置/更多/过滤器 对话框
resources/theme/*.qss     浅色/深色/樱花 主题样式
```

改主题 → `resources/theme/*.qss` + `src/app/ThemeManager.cpp`；
加功能 → 对应子目录，登记进 `CMakeLists.txt` 与 `markor-win.pro`（两处都要加）。
