#pragma once
#include <QPixmap>
#include <QColor>
#include <QString>

// Lightweight Mermaid diagram renderer drawn with QPainter (no web engine).
// Supported diagram kinds:
//   - flowchart / graph   (nodes, edges, labels, basic shapes, TD & LR)
//   - sequenceDiagram     (participants, arrows, notes)
// Unsupported kinds return a null pixmap (caller falls back to code block).
namespace MermaidRenderer {
    bool canRender(const QString& code);
    QPixmap render(const QString& code, int maxWidth,
                   const QColor& fg, const QColor& bg, bool dark);
}
