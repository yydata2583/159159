#pragma once
#include <QString>
#include "FormatDetector.h"

// A single text document backed by a file on disk.
class Document {
public:
    Document() = default;
    explicit Document(const QString& path);

    bool load();
    bool save() const;

    bool exists() const;
    bool isWritable() const;

    QString path() const { return _path; }
    QString fileName() const;
    QString dirPath() const;
    TextFormat format() const { return _format; }

    void setPath(const QString& path);

private:
    QString _path;
    TextFormat _format = TextFormat::PlainText;
};
