#pragma once
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QRegularExpression>
#include <QVector>
#include <QHash>
#include "core/CodeLexer.h"

class QTextDocument;

// Markdown 语法高亮 + 合规 lint（红色波浪线）。
// 颜色取自 ThemeManager 以跟随主题；lint 规则对应 compliance-test：
//   1) 未闭合的 ** / * 强调定界符（10-errorhint 场景1）
//   2) 未闭合的 ``` / ~~~ 代码围栏（10-errorhint 场景2）
//   3) 疑似表格缺少 |---| 分隔行、表格紧贴正文无空行（02-table 场景2/9）
//   4) 列表续行缩进不足（10-errorhint 场景4）
//   5) ATX 标题 # 后缺少空格（03-heading 场景5）
//   6) 结尾围栏带语言标注：警告标注部分但仍正确闭合（验收标准 4.1.2）
class MarkdownHighlighter : public QSyntaxHighlighter {
    Q_OBJECT
public:
    explicit MarkdownHighlighter(QTextDocument* parent = nullptr);

    // Re-read colors from the current theme (call on theme change).
    void refreshFormats();

signals:
    // 格式错误诊断：line 为 1 起行号；line<=0 表示当前无问题（应清空提示条）。
    void lintIssueChanged(int line, const QString& reason, const QString& fix);

protected:
    void highlightBlock(const QString& text) override;

private:
    struct Rule {
        QRegularExpression pattern;
        QTextCharFormat format;
    };
    QVector<Rule> _rules;

    QTextCharFormat _heading, _emphasis, _strong, _strike, _code, _link, _quote, _list, _hr;
    QTextCharFormat _lintWarn;          // 红色波浪线（lint 诊断）
    // 围栏代码块内容的 token 格式（颜色取自 ThemeManager）
    QTextCharFormat _codePlain;
    QTextCharFormat _tokKeyword, _tokType, _tokFunction, _tokString, _tokComment,
                    _tokNumber, _tokOperator, _tokPunctuation, _tokPreprocessor,
                    _tokTag, _tokAttribute, _tokValue;
    QTextCharFormat tokenFormat(CodeLexer::TokenType t) const;

    bool _rehighlightGuard = false;     // 正在执行批量重刷，禁止递归
    bool _refreshPending = false;       // 已排队一次批量重刷
    bool _lintEmitPending = false;      // 已排队一次诊断 emit
    // 每个块最新的诊断（块号 -> 原因/写法），由 highlightBlock 重建
    struct LintDiag { QString reason; QString fix; int start = 0; };
    QHash<int, LintDiag> _diags;

    // 块级高亮备忘录：块高亮输出是 (文本, 前块状态, 主题) 的纯函数，
    // 三者均未变的块在整篇重刷时直接恢复格式，跳过正则与代码词法分析
    struct FormatRange { int start; int len; QTextCharFormat fmt; };
    struct MemoEntry {
        QString text;
        int prevState = -2;
        int newState = 0;
        qint64 epoch = 0;               // 主题刷新时 bump，作废旧格式
        QVector<FormatRange> ranges;
    };
    QHash<int, MemoEntry> _memo;        // 块号 -> 备忘录
    QVector<FormatRange> _recording;    // 慢路径本次 setFormat 记录
    qint64 _memoEpoch = 0;
    void record(int start, int len, const QTextCharFormat& fmt);

    void buildRules();
    void scheduleRefresh();            // 跨块 lint 失效后合并为一次全量重刷
    void scheduleLintEmit();           // 合并成一次 lintIssueChanged emit

    // 块状态（setCurrentBlockState）
    enum BlockState {
        StateNormal    = 0,   // 普通文本
        StateTableRow  = 1,   // 表格分隔行/数据行
        StateOrphanPipe= 2,   // 缺分隔行的管道文本（仅首行告警）
        StateTableHead = 3    // 合法表头行（下一行是分隔行）
    };
    // 围栏状态不走本枚举：由 fenceStateFor 编码为
    //   base(反引号 1000000 / 波浪线 2000000) + langIndex * 10000 + openLen
    // lintFence 以 isFenceState() 判定（嵌套围栏需比较长度）。解码助手见 .cpp。

    bool lintFence(const QString& text, int prevState);
    void lintTableAndList(const QString& text, int prevState);
    void lintInlineAndHeading(const QString& text);
    void warnRange(int start, int len, const QString& reason, const QString& fix);

    static int leadColumns(const QString& s);
    static bool isHrLike(const QString& s);
    static bool isDelimiterRow(const QString& s);
    static int unescapedPipeCount(const QString& s);
    static bool matchListMarker(const QString& s, int& contentCol);
    static bool looksLikeBlockStart(const QString& s);
    static bool isFenceLine(const QString& s, QChar& ch, int& len, QString& rest);
};
