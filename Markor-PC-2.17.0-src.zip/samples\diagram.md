# 图表与公式演示

## 流程图 (Mermaid)

```mermaid
graph TD
    A[开始] --> B{是否完成?}
    B -->|是| C[导出 HTML]
    B -->|否| D[继续开发]
    D --> B
    C --> E[结束]
```

## 时序图 (Mermaid)

```mermaid
sequenceDiagram
    participant U as 用户
    participant A as 应用
    U->>A: 打开文档
    A-->>U: 显示内容
    U->>A: 导出 PDF
    A-->>U: 完成
```

## 数学公式 (KaTeX)

质能方程 $E = mc^2$ 与求和 $\sum_{i=1}^{n} i = \frac{n(n+1)}{2}$

$$\int_0^\infty e^{-x^2} dx = \frac{\sqrt{\pi}}{2}$$

一元二次方程 $x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$，希腊字母 $\alpha + \beta = \gamma$。
