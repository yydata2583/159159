#pragma once
#include <QMainWindow>
#include <QTabWidget>
#include <QSplitter>
#include <QPair>
#include <QVector>
#include <QSet>
#include <QPixmap>

class FileSidebar;
class EditorWidget;
class PreviewWidget;
class SearchDialog;
class QComboBox;
class QLabel;
class QTimer;

// Main application window: menu/tool/tab bars on top; content layer is
// [FileSidebar | editor | OutlinePanel | preview] (sidebar batch 2).
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

public slots:
    void openFilePath(const QString& path);
    void exportScreenshot(const QString& path);
    bool exportHtmlTo(const QString& path);
    bool exportPdfTo(const QString& path);

protected:
    void closeEvent(QCloseEvent* event) override;

private slots:
    // File
    void openFile();
    void openInNewTab(const QString& path);
    void newDocument();
    void saveCurrent();
    bool saveCurrentAs();
    void refreshCurrent();
    void closeTab(int index);
    // Edit / format
    void applyFormatAction();
    void onFormatComboChanged(int index);
    void tidyCurrentMarkdown();
    void historyBack();
    void historyForward();
    void findInFile();
    void openFileAtLine(const QString& path, int line);
    // Export / share
    void exportHtml();
    void exportPdf();
    void copyHtmlSource();
    void copyRichText();
    void copyPlainText();
    // View
    void togglePreview(bool on);
    void cycleTheme();
    void setThemeFromSettings(const QString& themeId);
    void showSettings();
    void showMore();
    void showChangelog();
    void about();

private:
    void buildMenus();
    void buildToolBar();
    void buildStatusBar();
    void applyTheme(const QString& themeId);
    void applyEditorSettings();
    bool promptSaveEditor(EditorWidget* e);
    // Sync (embedded Syncthing; write conflicts are resolved via
    // Syncthing .sync-conflict files, no lock client)
    void applySyncSettings();
    QString currentHtmlDocument() const;
    QString currentHtmlWithResources(QVector<QPair<QString, QPixmap>>* resources) const;
    EditorWidget* currentEditor() const;
    PreviewWidget* currentPreview() const;
    int indexOfPath(const QString& path) const;
    // 始终保留一个未命名标签在最右侧（打开文件/关闭标签后自动归位）
    void ensureUnnamedTabAtEnd();
    void syncPreview();
    void updateFormatCombo();
    // 状态栏格式错误提示：显示指定编辑器的第一条错误（nullptr/无错误则隐藏）
    void updateLintStatus(EditorWidget* e);
    // 窗口中心浮层提示（字号快捷调节等）
    void showToast(const QString& text);

    QTabWidget* _tabs;
    FileSidebar* _fileSidebar = nullptr;
    SearchDialog* _searchDialog = nullptr;
    QComboBox* _formatCombo = nullptr;   // 工具栏"格式"选择（含"自动"）
    QLabel* _lintLabel = nullptr;        // 状态栏左侧：第一条格式错误（可点击定位）
    QLabel* _toastLabel = nullptr;       // 窗口中心浮层提示
    QTimer* _toastTimer = nullptr;       // 浮层自动消失定时器
    bool _previewVisible = true;
    // 已被其他设备打开（锁服务上报）的文件路径集合：退出前据此弹窗提醒
    QSet<QString> _heldElsewhere;

    // Build a new editor+preview page and return its editor.
    class EditorWidget* createPage(const QString& path);
};
