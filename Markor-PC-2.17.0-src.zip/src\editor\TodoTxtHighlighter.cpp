#include "TodoTxtHighlighter.h"
#include "app/ThemeManager.h"

TodoTxtHighlighter::TodoTxtHighlighter(QTextDocument* parent)
    : QSyntaxHighlighter(parent)
{
    _priA = QRegularExpression(QStringLiteral("^\\(A\\)\\s"));
    _priB = QRegularExpression(QStringLiteral("^\\(B\\)\\s"));
    _priC = QRegularExpression(QStringLiteral("^\\([C-Z]\\)\\s"));
    _project = QRegularExpression(QStringLiteral("\\+[^\\s]+"));
    _context = QRegularExpression(QStringLiteral("@[^\\s]+"));
    _tag = QRegularExpression(QStringLiteral("\\b\\w+:[^\\s]+"));
    _done = QRegularExpression(QStringLiteral("^x\\s.*$"));
    _date = QRegularExpression(QStringLiteral("\\b\\d{4}-\\d{2}-\\d{2}\\b"));
    refreshFormats();
}

void TodoTxtHighlighter::refreshFormats()
{
    ThemeManager& t = ThemeManager::instance();

    _fPriA = QTextCharFormat(); _fPriA.setForeground(t.strikeColor()); _fPriA.setFontWeight(QFont::Bold);
    _fPriB = QTextCharFormat(); _fPriB.setForeground(t.strongColor()); _fPriB.setFontWeight(QFont::Bold);
    _fPriC = QTextCharFormat(); _fPriC.setForeground(t.listColor());   _fPriC.setFontWeight(QFont::Bold);
    _fProject = QTextCharFormat(); _fProject.setForeground(t.linkColor());
    _fContext = QTextCharFormat(); _fContext.setForeground(t.emphasisColor());
    _fTag = QTextCharFormat(); _fTag.setForeground(t.codeColor());
    _fDone = QTextCharFormat(); _fDone.setForeground(t.quoteColor()); _fDone.setFontStrikeOut(true);
    _fDate = QTextCharFormat(); _fDate.setForeground(t.hrColor());

    buildRules();
    rehighlight();
}

void TodoTxtHighlighter::buildRules() {}

void TodoTxtHighlighter::highlightBlock(const QString& text)
{
    auto mark = [&](const QRegularExpression& re, const QTextCharFormat& fmt) {
        QRegularExpressionMatchIterator it = re.globalMatch(text);
        while (it.hasNext()) {
            QRegularExpressionMatch m = it.next();
            setFormat(m.capturedStart(), m.capturedLength(), fmt);
        }
    };

    // done line takes precedence (strike whole line) then accents below
    if (_done.match(text).hasMatch()) {
        setFormat(0, text.length(), _fDone);
    } else {
        mark(_priA, _fPriA);
        mark(_priB, _fPriB);
        mark(_priC, _fPriC);
    }
    mark(_date, _fDate);
    mark(_project, _fProject);
    mark(_context, _fContext);
    mark(_tag, _fTag);
}
