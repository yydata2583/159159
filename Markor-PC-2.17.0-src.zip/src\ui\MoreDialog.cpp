#include "MoreDialog.h"
#include "app/AppSettings.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>

static QPushButton* makeRow(QWidget* parent, const QString& title, const QString& sub)
{
    auto* b = new QPushButton(parent);
    b->setProperty("secondary", true);
    b->setCursor(Qt::PointingHandCursor);
    b->setMinimumHeight(52);
    b->setText(title + (sub.isEmpty() ? QString() : QStringLiteral("\n") + sub));
    b->setStyleSheet(QStringLiteral("text-align:left; padding-left:14px;"));
    return b;
}

MoreDialog::MoreDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("更多"));
    resize(460, 420);

    auto* root = new QVBoxLayout(this);
    root->setSpacing(10);

    auto* title = new QLabel(tr("更多"), this);
    title->setObjectName(QStringLiteral("HeaderTitle"));
    root->addWidget(title);
    auto* sub = new QLabel(tr("Markor for Windows · v2.17.0"), this);
    sub->setObjectName(QStringLiteral("HeaderSub"));
    root->addWidget(sub);

    auto* line = new QFrame(this);
    line->setFrameShape(QFrame::HLine);
    root->addWidget(line);

    // Included entries (license / social / team / help / rate excluded by spec).
    auto* settings = makeRow(this, tr("设置"), tr("主题、编辑器、文档库"));
    auto* changelog = makeRow(this, tr("更新日志"), tr("查看版本变更"));
    auto* version = makeRow(this, tr("版本信息"), tr("Markor for Windows v2.17.0"));

    root->addWidget(settings);
    root->addWidget(changelog);
    root->addWidget(version);
    root->addStretch();

    auto* close = new QPushButton(tr("关闭"), this);
    close->setProperty("secondary", true);
    connect(close, &QPushButton::clicked, this, &QDialog::accept);
    root->addWidget(close, 0, Qt::AlignRight);

    connect(settings, &QPushButton::clicked, this, [this]() {
        emit openSettingsRequested();
        accept();
    });
    connect(changelog, &QPushButton::clicked, this, [this]() {
        emit openChangelogRequested();
    });
    connect(version, &QPushButton::clicked, this, [this]() {
        emit openChangelogRequested();
    });
}
