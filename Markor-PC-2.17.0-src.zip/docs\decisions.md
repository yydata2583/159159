# 决策记录（decisions.md / ADR）

> 每条 = 背景 / 决策 / 后果 / 替代方案。新增决策按序编号追加；**推翻旧决策不删改，只把旧条目标 `Superseded by ADR-0NN` 并链接**。
> 由 AI 维护（见 docs/README.md 协议）。

---

### ADR-001：不用 QtWebEngine，预览用 QTextBrowser + 自研转换（Accepted）
- **背景**：需要实时 Markdown 预览。Qt 生态常规方案是 QtWebEngine（Chromium），体积 100MB+ 且部署复杂。
- **决策**：用 `QTextBrowser`（富文本子集）+ 自研 `MarkdownConverter`；图表/公式由 QPainter 原生渲染为图片。
- **后果**：部署轻（BUILD.md 明言"不需要 QtWebEngine"）；代价是富文本子集限制（原生 HTML 块支持有限、块计数不可控），需 `postProcessDocument` 兜底映射。
- **替代方案**：QtWebEngine（否决：体积/依赖）、QTextDocument 直接 setMarkdown（Qt 6.4+，可控性与块映射不足）。

### ADR-002：自研 Markdown→HTML 转换器（Accepted）
- **背景**：预览/导出需要 **源行级** 映射（编辑器滚动 ↔ 预览定位），第三方转换器不产出源行信息。
- **决策**：`MarkdownConverter` 按行扫描、成块输出，每个块级标签注 `data-src-line`，同步产出 `BlockInfo` 序列与块序一一对应。目标合规 **CommonMark 0.31.2 + GFM**（表格/任务列表/删除线/自动链接/引用定义/YAML front-matter 透传）。
- **后果**：滚动同步精确可实现；维护成本集中在一个 72KB 文件；已知 3 条低优先级差异（architecture §11）。
- **替代方案**：接入 cmark/marked 等（否决：拿不到逐块源行 + 引入三方依赖）。

### ADR-003：撤销采用"QTextDocument 栈 + 自管快照历史"双轨（Accepted）
- **背景**：`QTextDocument` **没有公开 `setUndoLimit`**，内建撤销栈不可控；产品需要"撤回/前进"式的粗粒度回溯按钮。
- **决策**：细粒度 Ctrl+Z/Y 走 QTextDocument 栈；菜单栏右上角"撤回/前进"按钮走自管快照历史（输入停顿 400ms 存"文本+光标"，上限 50 条）。
- **后果**：用户有两级历史可用；代价是两套概念并存（文档中特别标注防混淆）。
- **替代方案**：只用 QTextDocument 栈（否决：无上限控制、无 UI 可控游标）。

### ADR-004：双向滚动同步防回环用 `_programmaticScroll` 标志，不用 QSignalBlocker（Accepted）
- **背景**：程序触发的滚动同样发 `valueChanged`，会造成编辑器↔预览互相回推死循环。
- **决策**：编辑器与预览各持 `_programmaticScroll` 布尔，槽函数开头自行 return。**明确禁止 QSignalBlocker**：它会把本侧视口联动信号一并吞掉，联动直接失效。
- **后果**：同步双向可用且可控（"预览跟随编辑"可单独关，反向定位始终开）；标志管理需小心成对设置/清除。
- **替代方案**：QSignalBlocker（否决，见上）、QTimer 去抖合并（可作补充但不解决回环本质）。

### ADR-005：HTML 文件预览用系统 WebView2，缺失自动降级（Accepted）
- **背景**：HTML/XML 文件需要浏览器级渲染（执行 JS / 现代 CSS）；QTextBrowser 做不到，QtWebEngine 不想引入。
- **决策**：预览窗格内嵌 **Windows 自带 WebView2（Edge 内核）**，SDK 头文件/导入库内置于 `third_party/webview2/`，运行期只依赖 `WebView2Loader.dll`（POST_BUILD 自动复制）+ 系统 WebView2 运行时（Win10/11 通常预装）。运行时缺失 → 降级为源码只读展示并提示。
- **后果**：浏览器级渲染 + 轻依赖；pImpl 封装 `HtmlPreviewView`，Win32 细节不出现在头文件。
- **替代方案**：QtWebEngine（否决）、调用外部浏览器打开（否决：脱离应用体验）。

### ADR-006：Mermaid / 数学公式用 QPainter 原生渲染（Accepted）
- **背景**：Mermaid 通常靠 JS 引擎、KaTeX/LaTeX 通常靠外部程序渲染。
- **决策**：`MermaidRenderer`（流程图 graph/flowchart + 时序图）与 `MathRenderer`（KaTeX 子集）直接用 QPainter 画 QPixmap；颜色随主题。不支持的图种 `canRender()` false → 回落代码块；未知公式命令 → 降级为文本。
- **后果**：零外部依赖、主题联动天然；覆盖范围是"常用子集"而非全量语法。
- **替代方案**：mermaid-cli/PlantUML 外部进程（否决：部署复杂、不可控延迟）、QtWebEngine（ADR-001 否决）。

### ADR-007：同步用内嵌 Syncthing，无文件锁客户端（Accepted）
- **背景**：需要把 vault 与 NAS 同步；上层产品要求"不引入锁客户端"。
- **决策**：`syncthing.exe`（exe 同目录）作隐藏子进程拉起，REST API 自动配置（注册 NAS 设备、共享 `markor-vault` 文件夹、开中继）；写冲突交给 Syncthing 的 `.sync-conflict-*` 文件，保存时不做占用检查。
- **后果**：开箱即 P2P 同步；同步冲突是"留文件"策略而非阻塞编辑。`syncthing.exe` 不存在则功能静默停用（状态栏提示）。
- **替代方案**：文件锁协议/中心服务器（否决：按产品需求排除）。

### ADR-008：双侧边栏布局——文件侧边栏全局、大纲面板每页（Accepted，"批次2"）
- **背景**：文件导航应跨文档常驻；大纲是文档相关视图。
- **决策**：`FileSidebar` 固定主窗口最左缘（最近|文件双 Tab），不随标签切换；`OutlinePanel` 每个标签页各一套（绑定该页 editor/preview）。两者共用 `SidebarHandle`（8px 把手：单击收展、拖拽调宽）。
- **后果**：状态全部进 `AppSettings::sidebar/*`（宽度/展开/Tab；大纲手动状态覆盖默认值）。
- **替代方案**：统一 QDockWidget（否决：视觉/动画定制差）。

### ADR-009：构建双轨 CMake + qmake（Accepted）
- **背景**：不同开发者/CI 环境工具链不同（Qt Creator 用户习惯 qmake）。
- **决策**：`CMakeLists.txt` 与 `markor-win.pro` 并存且**必须同步维护**（新源文件两处都登记）。
- **后果**：灵活性高，代价是重复登记——因此把"两处登记"写进 AGENTS.md 红线。
- **替代方案**：只留 CMake（可在未来收敛，届时新增 ADR）。

### ADR-010：主题颜色集中在 ThemeManager，qss 只管布局质感（Accepted）
- **背景**：高亮器、渲染器、预览 CSS 都需要主题色；颜色散落各处必然失联。
- **决策**：`ThemeManager` 是唯一色值出口（编辑器 4 色 + Markdown 语法 9 色），qss 管控件样式；`apply()` 同时改 QPalette、给 Win 原生标题栏着色（dwmapi）、广播 `themeChanged`。
- **后果**：新增主题 = 新 qss + qrc 登记 + ThemeManager 色分支（THEMES.md 有流程）。
- **替代方案**：每组件自读配置（否决：N 处失联风险）。

### ADR-011：Markdown 高亮器兼任 lint（红色波浪线）（Accepted）
- **背景**：产品需要写作期错误提示（compliance-test 10-errorhint / 02-table / 03-heading 场景）。
- **决策**：`MarkdownHighlighter` 在高亮同时做 6 类 lint：未闭合强调定界符、未闭合代码围栏、表格缺分隔行/贴正文、列表续行缩进不足、标题 `#` 后缺空格、结尾围栏带语言标注（仍正确闭合，仅警告）。跨块失效合并为一次全量重刷。
- **后果**：零额外组件；与"一次性整理器" `tidyMarkdown`（Ctrl+Alt+T）形成"提示 + 修复"闭环。
- **替代方案**：独立 lint 引擎（否决：过度设计）。

### ADR-012："更多/关于"排除项（Accepted，产品需求）
- **背景**：产品明确要求排除若干入口。
- **决策**：`MoreDialog` 仅保留 设置、更新日志；**开源协议、社交/社区、项目团队、帮助、评价本应用一律不加**；语言切换未实现。
- **后果**：加功能前先对照本条，别"顺手补全"。
- **替代方案**：—

### ADR-013：预览任务勾选框只做视觉切换，不写回文件（Accepted）
- **背景**：预览中点击 `- [ ]` 复选框，用户预期不一。
- **决策**：`PreviewWidget::tryToggleTaskBox()` 只切换显示状态，不修改源文本；编辑器才是唯一写入口。
- **后果**：避免预览交互意外改盘；如需写回，另立 ADR 并处理脏标记/撤销。
- **替代方案**：双向绑定写回（否决：改动面大）。

### ADR-014：格式识别"扩展名自动 + 工具栏手动覆盖"（Accepted）
- **背景**：`.txt` 可能是纯文本也可能是 todo.txt；用户偶尔需要强制指定格式。
- **决策**：默认 `FormatDetector::detect()` 按扩展名（`.txt` 特判 todo.txt/done.txt/*.todo.txt）；工具栏"格式"下拉可手动指定，选"自动"即恢复。新建文档默认 Markdown，首次另存后恢复自动。
- **后果**：格式状态存在 EditorWidget（`_formatAuto/_format`），标签切换时同步下拉。
- **替代方案**：内容嗅探（未采纳：误判率高；如做需新 ADR）。

### ADR-015：软换行默认开启（Markor 风格）（Accepted）
- **背景**：Markdown 单换行语义有争议（CommonMark 软换行=空格 vs 笔记类应用=换行）。
- **决策**：`ConvertOptions::softBreaks` 默认 true（段落内单换行渲染 `<br>`），设置项 `preview/softBreaks` 可关（关 = 严格 CommonMark）。
- **后果**：与 Android Markor 观感一致。
- **替代方案**：默认严格模式（否决：不符合移植目标）。

### ADR-016：预览跟随改为“逐行像素映射 + 块内插值”（Accepted，取代块级跟随）
- **背景**：编辑→预览跟随原为块级（预览元素 `data-src-line` → 定位到元素顶），一个段落/代码块/表格覆盖多行时，编辑器在块内滚动预览纹丝不动，块边界处又突然跳变，用户体感“有的不跟随”。
- **决策**：为每个预览元素记录 `spanLines`（覆盖源行数 = 与下个元素行号差，末块算到文末），建立互逆的逐行像素映射：`docYForSourceLine(源行小数) = rect.top() + (行内偏移)/spanLines * rect.height()`；编辑器侧提供 `firstVisibleSourceLineF()`（行号 + 行内像素比例），双向同步全程使用小数源行，连续无跳变。
- **后果**：段落中段↔预览中段逐像素对齐；重渲染/resize 后按小数锚点恢复；实现仅增加两个映射函数与一个字段，不动渲染管线。残留误差源：编辑器与预览的字高/行距不同，插值是等比近似而非字形级对齐（体感连续、无跳变）。
- **替代方案**：块级定位（旧方案，已取代）；按 QTextLayout 逐视觉行精确对齐（否决：预览的视觉行由 QTextBrowser 排版决定，需逐行测量成本高、收益边际）；用户引用的“逐行测量+插值+等比偏移”即本方案的插值部分。

### ADR-017：同步改为星型拓扑，去中继/自动发现/设备互引/引擎自升级（Accepted）
- **背景**：产品要求 PC、手机**只能与服务器连接同步，设备之间不能互连**；也不需要"更新同步版本"。旧实现 introducer=true + dynamic 地址 + 开中继，设备会互相发现/引入，且 Syncthing 默认自升级。
- **决策**：客户端设备表只有服务器设备（introducer 移除）、`addresses=[显式服务器同步地址]`、`globalAnnounce/localAnnounce/relaysEnabled=false`、`autoUpgradeIntervalH=0`；服务器端同步去掉 relaysrv 部署；服务器信息全部由用户配置（默认空，不写死）。
- **后果**：连通性完全取决于配置的服务器地址（跨网走 Tailscale/专网）；不能靠自动发现省配置。连接成功/失败均弹窗提示（产品要求）。
- **替代方案**：保留 dynamic 发现+仅靠设备表隔离（否决：同一局域网内仍可能直连，违反要求）。

### ADR-018：本机管理界面用 http://127.0.0.1:8385 明文（Accepted，修复"18384 打不开"）
- **背景**：用户反馈 PC 同步管理地址 127.0.0.1:18384 打不开。根因：①`--gui-address=http://127.0.0.1:18384/` 带 scheme/尾斜杠，Syncthing 只接受 `host:port`，监听配置解析失败；②GUI 默认 HTTPS 自签证书，`http://` 访问必失败；③syncthing.exe 缺失时本就无监听。
- **决策**：`--gui-address=127.0.0.1:8385`（host:port），配置 `gui.address=127.0.0.1:8385` + `gui.tls=false`，仅回环监听；管理入口 http://127.0.0.1:8385。
- **后果**：浏览器直接可开；明文仅限本机回环，无对外暴露面。
- **替代方案**：保留 HTTPS 自签（否决：浏览器告警/打不开的主因之一）。

### ADR-019：接入服务器文件锁 API（LockClient）+ 服务器信息默认空（Accepted）
- **背景**：服务器端 lockserver（README §五）为三端共用协议（打开提示/冲突检测）；PC 原先无锁客户端，且设置里的"服务器地址/API Key"无实际用途。产品要求：服务器信息不写死、默认空、连接成功与否都弹窗。
- **决策**：新增 `LockClient`（open/30s heartbeat/close，Bearer 鉴权，holders 非空弹"文件已在其他设备打开"）；服务器地址/密钥为空则整体静默禁用；`SyncManager::serverConnectionResult` 驱动连接成功/失败弹窗。
- **后果**：与服务器协议对齐（三端共用）；锁仅做提示，写冲突仍由 `.sync-conflict-*` 兜底。
- **替代方案**：继续无锁客户端（否决：与服务器设计不符，且"服务器地址"设置无用）。

### ADR-020：输入渲染管线"保位置 + 按需精确布局"（Accepted，2026-10-16）
- **背景**：用户反馈"输入卡顿、不流畅"。大文档（167KB/1608 块）实测每次按键渲染主线程阻塞 ~650ms：postProcess 逐行 `setBlockFormat` 198ms + 无条件 `documentSize()`/`setTextWidth±1` 强制整篇布局 ~330ms + textChanged 每键 O(n) 几何遍历。且 setHtml 复位滚动到 0 再跳回，产生可见闪跳。
- **决策**：普通输入渲染只做**像素保存/恢复**（`sb->setValue(qBound(min, savedPx, max))`），不做行同步；`documentSize()` 仅在两类场景调用——跟随动画恢复（resumeFollow）与输入跟随需要对齐落点（pending 分支）；大纲高亮/resize 锚点改 `QTimer::singleShot(0)` 延后到绘制后；防抖 150→200→300ms。渲染降至 ~299ms（其中 setHtml 211ms 为 Qt 固有）。
- **后果**：普通输入零整篇布局、视口纹丝不动；**坑：setHtml 后首轮布局是惰性的，`sb->maximum()` 可能未含尾部留白/新内容，取最大值前必须 `documentSize()`**（见 followEditorEdge）。
- **替代方案**：增量 DOM 替换/虚拟渲染（列入 docs 待办，中大改造）；Worker 高亮（否决：QSyntaxHighlighter 必须在文档线程）。

### ADR-021：postProcess 批量 setBlockFormat 用 QSignalBlocker+editBlock，禁调 markContentsDirty（Accepted，2026-10-16）
- **背景**：代码块自动断行需逐行 `QTextCursor::setBlockFormat`（大文档 ~5200 次文档编辑，198ms）。
- **决策**：先扫描 `_blocks` 是否存在 `nonBreakableLines()`，有才在**单个 `QSignalBlocker(doc)` + `beginEditBlock()/endEditBlock()`** 内批量改（198→22ms）。
- **后果**：**坑：初版在 endEditBlock 后加 `markContentsDirty(0, characterCount())`，强制整篇重排（51ms）；删除后 22ms**——块格式修改本身已脏布局，绘制时惰性重排即可。曾试 CSS `white-space:pre-wrap` 替代：Qt 导入器不映射为 nonBreakableLines 且 pre 块结构变化破坏 lanes↔BlockInfo 1:1 配对（MISMATCH 直接退比例映射），否决。
- **替代方案**：CSS pre-wrap（否决，见上）。

### ADR-022：编辑器高亮块级备忘录（Accepted，2026-10-16）
- **背景**：围栏/表格状态变化触发整篇 `rehighlight()` 级联，1608 块全量重跑 14 条正则+词法分析，打字卡顿主因之一。
- **决策**：按 Web 端"内容没变就跳过"思路做 Qt 版：块高亮输出是 `(文本, 前块状态, 主题)` 的纯函数，三者不变则直接恢复缓存的格式区间（含 lint 红波浪线），跳过全部正则；主题切换 epoch 失效；块数收缩一次性回收。
- **后果**：整篇重刷从 O(全文×规则) 降为 O(全文) 哈希比对。
- **替代方案**：Worker 线程高亮（否决：QSyntaxHighlighter 必须在文档线程）。

### ADR-023：底部留白用"尾部空白块常驻"，禁 setFrameFormat 反复增删（Accepted，2026-10-17）
- **背景**：修复"clamp 夹住了"（文档末尾对齐时目标 Y 超最大滚动值被夹贴底）需底部留白。初版在 4 个精确布局分支临时 `setFrameFormat` 加 60vh 底边距——普通渲染 setHtml 冲掉、对齐时加回，**总高反复跳变引起抖动**。
- **决策**：每次渲染固定插入一个 25vh（用户从 60vh 改）尾部空白块（`appendBottomSpacer`，`FixedHeight`），生命周期内常驻。插入在 postProcess 配对完成之后，不破坏 lanes↔BlockInfo 1:1；单块尾部插入只脏文末布局。**"到底"目标值必须取含留白的 `sb->maximum()`**（等价 Web `scrollHeight - clientHeight`），取前先 `documentSize()` 防惰性布局滞后。
- **后果**：clamp 范围恒定无切换抖动；末尾打字光标行落在 75% 处完整可见。
- **替代方案**：临时 setFrameFormat（否决：抖动）、内容底对齐视口底（否决：末行贴底露半行）。

### ADR-024：块内子锚点直接测量（Accepted，2026-10-17，实现 markora-block-align-fix.md）
- **背景**：整块"源码行比例→像素"推算在大表格/长代码块误差 30~50px。
- **决策**：Block 扩展 `SubAnchor{start,end,top,height,measured}`：表格逐行（QTextTable 首格，减 cellPadding——**优先读 `QTextTableFormat::cellPadding()`，取不到才回退 8+1px 常量，因 td padding 可被主题 CSS 改**）/列表按项起始行/代码每 5 行一组（相邻组顶相减，避免逐行测量开销；组内软换行误差 <2px）/引用按空行分段；**>3 行才拆**；几何测量按块惰性（首次使用才量该块）；任何数量失配→清空子锚点回退整块映射，绝不猜测。`docYForLineF` 与逆映射 `lineFForDocY` 同步走子锚点。
- **后果**：大表格行级精对（编辑器 45% ↔ 预览 47%）。
- **替代方案**：整块插值（旧方案，精度不足）。

### ADR-025：标题左侧竖条用内联位图模拟（**Superseded by ADR-028**，2026-10-17）

> **2026-10-17 已被 ADR-028 取代**：用户当日改需求为"标题不要竖线，h1/h2 改底部边框"。本方案的位图注入与 CSS border-left 规则已全部删除；"Qt 富文本不渲染块级 border-bottom"这一实测结论被 ADR-028 继承复用。

- **背景**：用户要求预览标题左侧加紫色竖条（参考 Web `border-left:5px solid var(--accent)`）。**坑：Qt 富文本不支持块级 `border-left`/`border-bottom`——CSS 写了从不渲染**（连原有的 h1/h2 border-bottom 也从未生效）。
- **决策**：setRichHtml 里正则给每个 `<hN>` 注入 `<img src="markor://hbarN">` 内联位图（宽 5/4/3/3/2/2px 递减、高按行高、右侧 8px 透明间隙），颜色用皮肤强调紫（浅 #8a3ffc/暗 #c3a6ff），addResource 注册。内联图不改变块结构，lanes↔BlockInfo 配对不受影响。导出 HTML 的 CSS 规则保留（`%A` 占位符），浏览器端正常呈现。
- **后果**：h1~h6 竖条可见；导出 HTML 同款。
- **替代方案**：QTextFormat::Border* 块属性（否决：即便支持也是整块四边框，无单侧）；表格包裹标题（否决：破坏 1:1 配对）。

### ADR-026：预览调色板整体取自 ThemeManager（Accepted，2026-10-17）
- **背景**：用户反馈"设置切樱花皮肤，预览没变"且要求"预览标题颜色与编辑区一致"。根因：`wrapHtmlDocument` 只收 `bool darkTheme`（樱花被当浅色渲染），且预览 CSS 从未给 h1-h6 设 color（继承正文色），而编辑区标题有主题色（headingColor：浅蓝/暗蓝紫/樱粉）。
- **决策**：新增 `MarkdownConverter::Palette` 九色纯值结构（bg/fg/codeBg/link/quote/border/strike/accent/heading），`wrapHtmlDocument` 加可选参 `const Palette*`（为空保持原亮暗默认，核心库不依赖 app 层）；ThemeManager 补 `codeBlockBg()`/`borderColor()` 访问器（颜色唯一权威仍在 ThemeManager）；预览、导出 HTML、复制 HTML 三路径统一 `paletteFromTheme()`；标题竖条位图色同步改 `emphasisColor()`。编辑区无需改（applyFormat 重建高亮器时已重读主题色）。
- **后果**：三套皮肤预览全部同步；预览/编辑标题同色；导出 HTML 跟随当前皮肤；默认参数保持旧行为。

### ADR-027：Windows"打开方式"显示名陈旧——清 MuiCache 而非改代码（Accepted，2026-10-17）
- **背景**：用户反馈右键"打开方式"里 Markor 条目带尾巴 "Markor - Markdown & Todo.txt editor for Windows"，要求删到 "Markor - Markdown"。排查：工程内无任何含 "Todo.txt editor" 的字符串；`resources/app.rc` 的 FileDescription 已是 "Markor - Markdown"；已安装 exe 与 build exe 的版本资源均正确。真正的来源是 Windows 外壳缓存 `HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache` 中 `<exe路径>.FriendlyAppName` 两条旧值——早期版本 FileDescription 带尾巴时被缓存，exe 更新后缓存不自动失效。
- **决策**：直接 `reg delete` 删除 MuiCache 中两条陈旧 FriendlyAppName 值（HKCU 无需管理员权限）。Windows 下次构建菜单时从 exe 当前 FileDescription 重建缓存。不改任何源码/资源/安装脚本。
- **教训**：
  1. "打开方式"菜单显示名的取值优先级：`Applications\<exe>` 下的 FriendlyAppName 注册值 > MuiCache 缓存 > exe 版本资源 FileDescription；改名后菜单仍旧字样时先查 MuiCache。
  2. 若 Explorer 内存中仍有缓存导致菜单未刷新，重启 Explorer（`Stop-Process -Name explorer -Force`，会自动重启外壳）或重新登录即可。
  3. 安装脚本 installer.iss 当前不写任何注册表项，"打开方式"关联（`HKCU\Software\Classes\Applications\MarkorWin.exe`）是用户手动选择产生的；如需正式注册 ProgID/Capabilities 属新需求，另行评估。
- **后果**：菜单显示恢复为 "Markor - Markdown"。

### ADR-028：标题去竖条改 h1/h2 底部边框——预览在视口 Paint 事件叠加绘制（Accepted，2026-10-17，Supersedes ADR-025）
- **背景**：用户改需求："标题不要竖线了，改为底部边框"，并给出参考 CSS：`.preview-content h1{font-size:1.9em;margin:.67em 0 .45em;padding-bottom:.28em;border-bottom:1px solid var(--border);scroll-margin-top:20px}`、h2 同构（1.5em / .75em / .4em / .25em）。h3~h6 参考中无装饰。
- **决策**：
  1. **CSS（`MarkdownConverter::wrapHtmlDocument`，预览与导出同源）**：删除 h1~h6 全部 `border-left` 规则（含 `%A` 强调色占位符的使用点；Palette.accent 字段保留，`%A` replace 变空操作）；h1/h2 按参考设置 font-size/margin/padding-bottom/`border-bottom:1px solid %8`/`scroll-margin-top:20px`（`%8`=Palette.border，即皮肤边框色，对应 var(--border)）；h3~h6 保留通用标题规则（行高/标题色/通用 margin），无任何装饰。
  2. **Qt 预览——最终方案：子类化 QTextBrowser 重写 paintEvent（`PreviewBrowser` + `PreviewWidget::paintHeadingBorders`）**。Qt 6.8.3 已核实：QTextBlockFormat 头文件中没有任何边框属性（单边/整框都没有，Qt 6.7 说的块边框只落在 QTextFrameFormat/TableCell 路径），CSS border-bottom 写了从不渲染（ADR-025 实测结论继续成立）。实现：cpp 匿名命名空间内定义 `class PreviewBrowser : public QTextBrowser`，`paintEvent` 先调基类（完成文档全部正常绘制），再回调 `paintHeadingBorders()` 在同一帧叠加底线；`_browser` 字段类型保持 `QTextBrowser*` 不变（is-a 替换，其余代码零改动）。绘制时遍历已配对的 `_blocks`，仅对 `kind==Heading && level∈{1,2}` 定位横线。**y 坐标（第五版，最终）**：取标题块 `QTextLayout` 最后一行的 `naturalTextRect().bottom()`（字体 ascent/descent 度量，紧贴真实文字）加布局位置换算到文档坐标，再加 padding-bottom 间隙——**y = layout.position().y() + lastLine.naturalTextRect().bottom() + 标题字号×{h1 .12, h2 .10} − 滚动条值**；系数即 CSS `padding-bottom` 原值（用户定稿 .12em/.10em，对应 CSS margin-bottom 同步调整为 h1 .75em、h2 .7em——线贴标题、与正文拉开）。x 仍取 blockBoundingRect 的 left/right 全宽；颜色 `ThemeManager::borderColor()`，1px 关抗锯齿；视口外的块跳过。
     - **踩坑（当日第四版，用户截图：线落在标题与正文间隙正中央，"像平均分隔"）**：第三版系数取 {.43,.40}（半行距 .15 + padding − .08 推算），多叠了一段间距，横线掉进 margin 区域中央，视觉上标题-线、线-正文等距。**浏览器盒模型结论：border 就在 content box 底边（≈baseline+descent，恰等于 naturalTextRect 底边）+ padding-bottom 处；line-height 撑出的半行距属于 line box，不进入 border 定位，不能叠加。** 系数回归 CSS padding-bottom 原值；随后用户把 padding 调到 .12/.10、margin-bottom 调大到 .75/.7 定稿（先出等效 HTML 在浏览器验收，再编译）。
     - **踩坑（当日第三版，用户截图 h2 线贴着文字）**：第二版用 `blockBoundingRect().bottom() − blockFormat().bottomMargin() + padding` 定位，误以为 blockBoundingRect 含块外边距。**实测结论：Qt 的 blockBoundingRect 不含块外边距**（流布局把 margin 直接加在块间定位上），再减一次 bottomMargin 等于把横线上提 .4em，h2 因字号小、descent 余量少，线直接贴住字形（h1 因字号大余量大，视觉上"正常"造成误判）。最终方案改为从 `QTextLayout`+`QTextLine::naturalTextRect()` 取文字本体几何，完全绕开 margin 语义。
     - **踩坑（当日第二版，用户截图：标题/正文全消失只剩底线）**：第一版是在 viewport 的外部事件过滤器里拦 `QEvent::Paint`，手动 `watched->event(event)` 后补画并 return true。**错误点**：直接调 `watched->event()` 绕过了 `QCoreApplication::notify` 的事件过滤器链，而 QAbstractScrollArea 自己装在 viewport 上的事件过滤器负责把 Paint 转成 `paintEvent` 绘制文档内容——链一断，QTextBrowser 根本没绘制，只剩叠加层。教训：事件过滤器里要"基类绘制后叠加"，正确手段只有子类重写 paintEvent（或给过滤器加可重入守卫后用 QApplication::sendEvent 重新派发），不能直接 watched->event()。
  3. **被否方案①：HTML 注入全宽位图**（当日第一版，实测不可见，两个坑）：a) 转换器输出的闭合标签是 `</h1 >`/`</h2 >`（`>` 前带空格，MarkdownConverter.cpp L1646 `close="</h%d >"`），正则 `(<h([12])\b[^>]*>.*?)</h\2>` 零匹配，注入根本没发生；b) Qt 的 QTextImageFormat 只有像素宽度（`setWidth(qreal)`），HTML 导入器不支持 img 的 `width="100%"` 百分比宽度，即使正则修好也只会按位图自然宽度（1px）显示。
  4. 纯绘制方案不进文档模型：lanes↔BlockInfo 1:1 配对、滚动映射、锚点几何完全不受影响；宽度随面板拖拽/字号缩放的每次重绘实时自适应；滚动动画逐帧 repaint，线自然跟随。
- **后果**：预览 h1/h2 呈现整行底部分隔线、间距与参考一致；h3~h6 无竖线无底线；标题不再左缩（旧 padding-left 规则已删）。导出/复制 HTML 在浏览器中为真实 CSS border-bottom。注意：该叠加线只在屏幕预览可见，不进 QTextDocument 打印/导出（PDF 打印路径无此装饰，与 Qt 能力一致）。
- **替代方案**：①只写 CSS（否决：Qt 不渲染）；②HTML 注入位图（否决：闭合标签带空格 + 不支持百分比宽度，见 3）；③标题后插 `<hr>` 块（否决：新增 QTextBlock，破坏块 1:1 配对）；④QTextFrameFormat 包裹标题（否决：破坏块结构且整框四边线）。
