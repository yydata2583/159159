#pragma once
#include <QPlainTextEdit>
#include <QTextBlock>
#include <QVector>
#include "core/FormatDetector.h"

class LineNumberArea;
class QSyntaxHighlighter;
class QTimer;

// Markdown/plain-text editor with line numbers, search/replace and
// a pluggable syntax highlighter.
class EditorWidget : public QPlainTextEdit {
    Q_OBJECT
public:
    explicit EditorWidget(QWidget* parent = nullptr);

    void setFilePath(const QString& path);
    QString filePath() const { return _filePath; }

    bool loadFile(const QString& path);
    bool saveFile(const QString& path = QString());
    bool isDirty() const { return _dirty; }
    void setDirty(bool d);

    // Line number gutter
    void lineNumberAreaPaintEvent(QPaintEvent* event);
    int lineNumberAreaWidth();

    // Highlighting
    void setHighlightEnabled(bool on);
    void applyFormat(TextFormat fmt);
    TextFormat format() const { return _format; }

    // 格式选择："自动"按扩展名识别，或手动指定具体格式
    void setFormatAuto(bool on) { _formatAuto = on; }
    bool isFormatAuto() const { return _formatAuto; }
    void refreshFormat();              // 自动模式下按扩展名重新识别并应用

    // 非模态格式错误提示条（Markdown 格式下由 MarkdownHighlighter 驱动）
    void onLintIssueChanged(int line, const QString& reason, const QString& fix);

    // 快照式撤回/前进历史（QTextDocument 无公开 setUndoLimit，故自管理：
    // 输入停顿约 400ms 存一条文本+光标快照，上限 50 条，按钮走该历史）
    void undoSnapshot();
    void redoSnapshot();
    void resetSnapshotHistory();

    // Line-number gutter visibility
    void setLineNumbersVisible(bool visible);
    bool lineNumbersVisible() const { return _lineNumbersVisible; }

    // 滚动到指定源行（1 起），不移动文本光标；置 _programmaticScroll 标志防回环
    void scrollToSourceLine(int line);
    // 小数源行版：行号 + 行内像素比例（供预览逐行精确跟随）
    void scrollToSourceLineF(qreal lineF);
    // 程序触发的滚动进行中（MainWindow 滚动同步槽据此避免回推预览）
    bool isProgrammaticScroll() const { return _programmaticScroll; }

    // 视口顶部首个可见块对应的源行号（1 起，整数）
    int firstVisibleSourceLine() const;
    // 小数版：整数部分=首可见源行，小数部分=该行被滚出视口顶部的比例
    // （供编辑->预览逐行插值跟随使用）
    qreal firstVisibleSourceLineF() const;
    // 视口内坐标 yInView（视口像素，0=视口顶）对应的源行（小数）：
    // 所在块行号 + 块内像素比例（供 43% 视口参考点跟随）
    qreal sourceLineFAtViewportY(qreal yInView) const;

    // Search / replace (returns true if something was found/changed)
    // wrapped 非空时回传：本次是否循环回卷到了文档另一端才命中
    bool find(const QString& text, bool forward, bool caseSensitive, bool regex,
              bool* wrapped = nullptr);
    bool replace(const QString& find, const QString& with, bool caseSensitive, bool regex);
    int replaceAll(const QString& find, const QString& with, bool caseSensitive, bool regex);

    void setFontPointSize(int pt);

    // 行号字体 = 内容字体 - 2pt，随内容字号变化同步更新（供设置变更时外部调用）
    void updateLineNumberFont();

    // Filter highlighting (todo.txt / text filter): emphasize matching blocks.
    void setFilterBlocks(const QList<int>& blockNumbers, const QColor& color);
    void clearFilter();

    // 光标所在源行（1 起，小数=块内像素比例），供预览跟随编辑位置
    qreal cursorSourceLineF() const;
    // 光标中心在编辑器视口中的垂直比例（0~1），供预览动态决定对齐锚点
    qreal cursorViewportRatio() const;
    // 移动光标到指定源行（1 起）并居中（状态栏错误定位用）
    void gotoLine(int line);
    // 当前第一条格式错误（lint），line<=0 表示无；供状态栏在切换标签时拉取
    int lintLine() const { return _lintLine; }
    QString lintReason() const { return _lintReason; }
    QString lintFix() const { return _lintFix; }

signals:
    void dirtyChanged(bool dirty);
    void statusMessage(const QString& msg);
    // Markdown 第一条格式错误变化（line 1 起；line<=0 表示已无错误）
    void lintIssueChanged(int line, const QString& reason, const QString& fix);

public slots:
    void updateLineNumberAreaWidth(int newBlockCount);
    void highlightCurrentLine();
    void updateLineNumberArea(const QRect& rect, int dy);

protected:
    void resizeEvent(QResizeEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    // Ctrl+滚轮调节字号（8~40，与设置对话框范围一致，实时持久化）
    void wheelEvent(QWheelEvent* event) override;

private:
    struct Snapshot { QString text; int cursor = 0; };
    void commitSnapshot();

    // HTML/Code 编辑增强：括号/引号与 HTML 标签自动闭合、回车自动缩进
    bool handleAutoPairKey(QKeyEvent* event);
    bool handleAutoIndent();
    bool tryAutoCloseHtmlTag();
    bool nextCharIs(QChar ch) const;
    int lineLeadingSpaces(const QTextBlock& block) const;

    // 高亮器诊断到达：存储并转发给状态栏
    void clearLintIssue();

    QString _filePath;
    QString _cleanText;   // 最近一次载入/保存的内容基线：与当前内容一致即视为未编辑
    bool _dirty = false;
    bool _lineNumbersVisible = true;
    bool _formatAuto = true;
    bool _programmaticScroll = false; // 程序触发的滚动（预览反向定位）进行中
    LineNumberArea* _lineNumberArea;
    QSyntaxHighlighter* _highlighter = nullptr;
    TextFormat _format = TextFormat::PlainText;
    QList<int> _filterBlocks;
    QColor _filterColor;
    QTimer* _historyTimer = nullptr;
    QVector<Snapshot> _history;
    int _historyIndex = -1;

    // 当前第一条格式错误（显示在主窗口状态栏，不在编辑器内）
    QString _lintReason;
    QString _lintFix;
    int _lintLine = -1;                // 当前问题行（1 起；<=0 无）
};
