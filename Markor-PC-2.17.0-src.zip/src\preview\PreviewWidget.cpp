#include "PreviewWidget.h"
#include "HtmlPreviewView.h"
#include "core/MarkdownConverter.h"
#include "app/ThemeManager.h"
#include "app/AppSettings.h"
#include "render/MermaidRenderer.h"
#include "render/MathRenderer.h"

#include <QVBoxLayout>
#include <QStackedWidget>
#include <QTextDocument>
#include <QTextFrame>
#include <QTextTable>
#include <QTextCursor>
#include <QTextBlock>
#include <QTextLayout>
#include <QTextLine>
#include <QTextList>
#include <QTextFragment>
#include <QAbstractTextDocumentLayout>
#include <QPair>
#include <QVector>
#include <QSet>
#include <QHash>
#include <QRegularExpression>
#include <QPainter>
#include <QPixmap>
#include <QTimer>
#include <QBuffer>
#include <QDesktopServices>
#include <QScrollBar>
#include <QToolButton>
#include <QApplication>
#include <QClipboard>
#include <QEvent>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QResizeEvent>
#include <QtMath>
#include <QDateTime>
#include <QUrl>
#include <QQueue>
#include <functional>

namespace {

// ADR-028：预览浏览器——先正常绘制文档，再回调叠加 h1/h2 标题底线。
// 注意：不能在外部事件过滤器里直接拦视口的 QEvent::Paint 后手动
// watched->event(event)——那会绕过 QAbstractScrollArea 自身装在 viewport
// 上的事件过滤器，文档内容（标题/正文）将完全不绘制，只剩叠加层。
class PreviewBrowser : public QTextBrowser {
public:
    std::function<void()> afterPaint;
    using QTextBrowser::QTextBrowser;

protected:
    void paintEvent(QPaintEvent* e) override
    {
        QTextBrowser::paintEvent(e);
        if (afterPaint)
            afterPaint();
    }
};

enum SegType { TextSeg, MermaidSeg, MathSeg };
struct Seg {
    SegType type;
    QString content;
    int start = 0;       // 段在整篇 markdown 中的字符偏移
    bool display = false; // 数学块是否为行间公式（$$）
};

// Split markdown into text / mermaid / math segments.
QVector<Seg> splitSegments(const QString& md)
{
    QVector<Seg> segs;
    int i = 0, n = md.size(), textStart = 0;

    auto pushText = [&](int end) {
        if (end > textStart) segs.push_back({ TextSeg, md.mid(textStart, end - textStart), textStart, false });
    };

    while (i < n) {
        if ((i == 0 || md[i - 1] == '\n') && md.mid(i, 10) == QStringLiteral("```mermaid")) {
            pushText(i);
            int contentStart = i + 10;
            int j = md.indexOf(QStringLiteral("```"), contentStart);
            int end = (j < 0 ? n : j);
            segs.push_back({ MermaidSeg, md.mid(contentStart, end - contentStart), i, true });
            i = (j < 0 ? n : j + 3);
            textStart = i;
            continue;
        }
        if (md.mid(i, 2) == QStringLiteral("$$")) {
            int j = md.indexOf(QStringLiteral("$$"), i + 2);
            if (j > i) {
                pushText(i);
                segs.push_back({ MathSeg, md.mid(i + 2, j - (i + 2)), i, true });
                i = j + 2;
                textStart = i;
                continue;
            }
        }
        if (md[i] == '$' && (i + 1 < n) && md[i + 1] != '$') {
            int j = i + 1;
            while (j < n && md[j] != '$' && md[j] != '\n') ++j;
            if (j < n && md[j] == '$' && j > i + 1) {
                pushText(i);
                segs.push_back({ MathSeg, md.mid(i + 1, j - (i + 1)), i, false });
                i = j + 1;
                textStart = i;
                continue;
            }
        }
        ++i;
    }
    pushText(n);
    return segs;
}

QString pixmapToDataUri(const QPixmap& pm)
{
    QByteArray bytes;
    QBuffer buffer(&bytes);
    buffer.open(QIODevice::WriteOnly);
    pm.save(&buffer, "PNG");
    return QStringLiteral("data:image/png;base64,")
        + QString::fromLatin1(bytes.toBase64());
}

// 锚点匹配归一化：小写、全角→半角、中文数字→阿拉伯（含"十"组合），
// 去掉全部非字母/数字。仅用于比较，不改变生成侧 slug 规则。
QString normalizeAnchorText(QString s)
{
    s = s.toLower();
    QString half;
    for (QChar c : s) {
        const ushort u = c.unicode();
        if (u >= 0xFF10 && u <= 0xFF19)          // 全角数字
            half += QChar(u'0' + (u - 0xFF10));
        else
            half += c;
    }
    s = half;
    // 中文数字（十一→11、二十→20、二十三→23）
    auto digitOf = [](const QString& c) {
        static const QString nums = QStringLiteral("一二三四五六七八九");
        return c.isEmpty() ? 0 : nums.indexOf(c[0]) + 1;
    };
    static const QRegularExpression tenRe(
        QStringLiteral("([一二三四五六七八九]?)十([一二三四五六七八九]?)"));
    QString out;
    qsizetype pos = 0;
    QRegularExpressionMatchIterator it = tenRe.globalMatch(s);
    while (it.hasNext()) {
        const QRegularExpressionMatch m = it.next();
        out += s.mid(pos, m.capturedStart() - pos);
        const int a = m.captured(1).isEmpty() ? 1 : digitOf(m.captured(1));
        const int b = digitOf(m.captured(2));
        out += QString::number(a * 10 + b);
        pos = m.capturedEnd();
    }
    out += s.mid(pos);
    s = out;
    static const QString cnNums = QStringLiteral("一二三四五六七八九");
    for (int i = 0; i < int(cnNums.size()); ++i)   // 剩余单字
        s.replace(cnNums[i], QString::number(i + 1));
    static const QRegularExpression nonAlnum(QStringLiteral("[^\\p{L}\\p{N}]"));
    s.remove(nonAlnum);
    return s;
}

// 图表/公式位图缓存：内容、宽度、主题色均相同时直接复用，避免每次输入渲染
// 都把文档里全部 Mermaid 图、数学公式重画一遍（简单 LRU 上限 384 张）
template <class Generator>
QPixmap cachedChartPixmap(const QString& key, Generator gen)
{
    static QHash<QString, QPixmap> s_cache;
    static QQueue<QString> s_order;
    auto it = s_cache.constFind(key);
    if (it != s_cache.constEnd())
        return it.value();
    QPixmap pm = gen();
    if (!pm.isNull()) {
        s_cache.insert(key, pm);
        s_order.enqueue(key);
        if (s_order.size() > 384)
            s_cache.remove(s_order.dequeue());
    }
    return pm;
}

// Build rich body HTML. When embedImages is true chart/math pixmaps are inlined
// as data URIs (standalone export); otherwise they reference named resources
// that the caller registers on the target QTextDocument.
// outBlocks 非空时按全局源行号追加块描述（与输出块级元素顺序一致）。
QString buildRichBody(const QString& md, bool dark, bool embedImages,
                      QVector<QPair<QString, QPixmap>>* res,
                      int* mermaidCount, int* mathCount,
                      bool softBreaks,
                      QVector<MarkdownConverter::BlockInfo>* outBlocks)
{
    const QColor fg = dark ? QColor("#e4e6eb") : QColor("#1c1e21");
    const QColor bg = dark ? QColor("#23272e") : QColor("#ffffff");

    QString body;
    int mCount = 0, xCount = 0, idx = 0;

    auto imageTag = [&](const QPixmap& pm, const QString& extraStyle) {
        QString name = QStringLiteral("img%1").arg(idx++);
        if (embedImages)
            return QStringLiteral("<img src=\"%1\"%2>")
                .arg(pixmapToDataUri(pm),
                     extraStyle.isEmpty() ? QString()
                                          : QStringLiteral(" style=\"%1\"").arg(extraStyle));
        if (res) res->append({ name, pm });
        return QStringLiteral("<img src=\"%1\"%2>")
            .arg(name,
                 extraStyle.isEmpty() ? QString()
                                      : QStringLiteral(" style=\"%1\"").arg(extraStyle));
    };

    const MarkdownConverter::ConvertOptions opts{ softBreaks };

    for (const Seg& s : splitSegments(md)) {
        // 该段首行在整篇文档中的 1 起行号
        const int baseLine = s.start > 0 ? md.left(s.start).count(QLatin1Char('\n')) + 1 : 1;

        if (s.type == TextSeg) {
            QVector<MarkdownConverter::BlockInfo> segBlocks;
            body += MarkdownConverter::toHtmlFragment(s.content, opts,
                                                      outBlocks ? &segBlocks : nullptr);
            if (outBlocks) {
                for (auto b : segBlocks) {
                    b.srcLine += baseLine - 1;
                    b.endLine += baseLine - 1;
                    outBlocks->append(b);
                }
            }
            continue;
        }
        if (s.type == MermaidSeg) {
            ++mCount;
            // 围栏在源码中占：开围栏行 + 内容行 + 闭围栏行
            const int fenceLines = s.content.count(QLatin1Char('\n')) + 1;
            const int endLine = baseLine + fenceLines + 1;
            const QString chartCode = s.content.trimmed();
            const QString cacheKey = QStringLiteral("M|%1|%2|%3|%4|%5")
                .arg(860).arg(dark ? 1 : 0).arg(fg.name(), bg.name(), chartCode);
            QPixmap pm = cachedChartPixmap(cacheKey, [&] {
                return MermaidRenderer::render(chartCode, 860, fg, bg, dark);
            });
            if (pm.isNull()) {
                body += QStringLiteral("<pre data-src-line=\"%1\"><code>%2</code></pre>")
                            .arg(baseLine).arg(s.content.toHtmlEscaped());
                if (outBlocks)
                    outBlocks->append(MarkdownConverter::BlockInfo(
                        baseLine, endLine, MarkdownConverter::BlockInfo::Code));
                continue;
            }
            body += QStringLiteral("<p data-src-line=\"%1\" "
                                   "style=\"text-align:center;margin:12px 0;\">%2</p>")
                        .arg(baseLine).arg(imageTag(pm, QString()));
            if (outBlocks)
                outBlocks->append(MarkdownConverter::BlockInfo(
                    baseLine, endLine, MarkdownConverter::BlockInfo::Media));
            continue;
        }
        // Math
        ++xCount;
        const QString mathCode = s.content.trimmed();
        const QString mathKey = QStringLiteral("X|%1|%2|%3|%4")
            .arg(24).arg(fg.name(), bg.name(), mathCode);
        QPixmap pm = cachedChartPixmap(mathKey, [&] {
            return MathRenderer::render(mathCode, 24, fg, bg);
        });
        if (pm.isNull()) {
            body += QStringLiteral("<code>%1</code>").arg(s.content.toHtmlEscaped());
            // 行内公式不产生新块；行间公式退化为行内 code 时映射可能错位，
            // postProcess 数量校验失败会在该区域回退到比例方式。
            if (s.display && outBlocks)
                outBlocks->append(MarkdownConverter::BlockInfo(
                    baseLine, baseLine, MarkdownConverter::BlockInfo::Media));
            continue;
        }
        // 行间 $$ 公式必须用块级容器包裹：裸 <img> 会被 Qt 当作 inline
        // 内容寄生进前一个段落块，导致与块序列错位
        if (s.display) {
            body += QStringLiteral("<p data-src-line=\"%1\" "
                                   "style=\"text-align:center;margin:6px 0;\">%2</p>")
                        .arg(baseLine)
                        .arg(imageTag(pm, QStringLiteral("vertical-align:middle;")));
        } else {
            body += imageTag(pm, QStringLiteral("vertical-align:middle;"));
        }
        if (s.display && outBlocks) {
            const bool multiLine = s.content.contains(QLatin1Char('\n'));
            outBlocks->append(MarkdownConverter::BlockInfo(
                baseLine,
                multiLine ? baseLine + s.content.count(QLatin1Char('\n')) + 1
                          : baseLine,
                MarkdownConverter::BlockInfo::Media));
        }
    }

    if (mermaidCount) *mermaidCount = mCount;
    if (mathCount) *mathCount = xCount;
    return body;
}

// 从 ThemeManager 构建预览调色板：三套皮肤（浅色/暗色/樱花）全部生效，
// 标题色与编辑区语法高亮同源（headingColor），强调色用 emphasisColor。
static MarkdownConverter::Palette paletteFromTheme()
{
    ThemeManager& t = ThemeManager::instance();
    MarkdownConverter::Palette p;
    p.bg      = t.editorBg().name();
    p.fg      = t.editorFg().name();
    p.codeBg  = t.codeBlockBg().name();
    p.link    = t.linkColor().name();
    p.quote   = t.quoteColor().name();
    p.border  = t.borderColor().name();
    p.strike  = t.strikeColor().name();
    p.accent  = t.emphasisColor().name();
    p.heading = t.headingColor().name();
    return p;
}

void setRichHtml(QTextBrowser* browser, const QString& markdown, bool dark,
                 QVector<MarkdownConverter::BlockInfo>* outBlocks)
{
    QVector<QPair<QString, QPixmap>> res;
    const bool soft = AppSettings::instance().previewSoftBreaks();
    const int fontPx = AppSettings::instance().previewFontSize();
    QString body = buildRichBody(markdown, dark, /*embedImages=*/false, &res,
                                 nullptr, nullptr, soft, outBlocks);

    // h1/h2 标题底部边框不在 HTML 里做：Qt 富文本不渲染块级 border-bottom
    // （ADR-025 实测），内联位图方案又因转换器输出标签为 "</h1 >"（带空格）
    // 匹配失败、且 img 百分比宽度不被支持而不可见（ADR-028 第二版）。
    // 现改为纯绘制叠加：postProcessDocument 完成块配对后，在视口 Paint 事件
    // 末尾按标题块实时布局矩形画 1px 底线（paintHeadingBorders），宽度自适应、
    // 不改文档结构。CSS border-bottom 仍保留，供导出 HTML 在浏览器真实呈现。
    const MarkdownConverter::Palette pal = paletteFromTheme();
    browser->setHtml(MarkdownConverter::wrapHtmlDocument(
        body, dark, fontPx, /*withScripts=*/false, &pal,
        AppSettings::instance().previewFontFamily()));

    // Register images as document resources so they render synchronously.
    QTextDocument* doc = browser->document();
    for (const auto& r : res)
        doc->addResource(QTextDocument::ImageResource, QUrl(r.first), r.second);

    doc->markContentsDirty(0, doc->characterCount());
    browser->viewport()->update();
}

} // namespace

PreviewWidget::PreviewWidget(QWidget* parent)
    : QWidget(parent)
{
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    // 预览容器：普通文档用 QTextBrowser，HTML 文件用 WebView2 浏览器级渲染
    _stack = new QStackedWidget(this);
    auto* pb = new PreviewBrowser(_stack);
    pb->afterPaint = [this] { paintHeadingBorders(); };
    _browser = pb;
    _browser->setObjectName(QStringLiteral("PreviewBrowser"));
    _browser->setOpenExternalLinks(false);
    _browser->setOpenLinks(false);
    // 正文永远不出现整页横向滚动；长代码/长串由断行或容器内滚动处理
    _browser->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 链接：文档内 #锚点 平滑滚动到对应 data-src-line；其余交给系统处理
    connect(_browser, &QTextBrowser::anchorClicked, this, [this](const QUrl& url) {
        if (url.path().isEmpty() && !url.fragment().isEmpty())
            handleAnchorClick(url);
        else
            QDesktopServices::openUrl(url);
    });
    layout->addWidget(_stack);

    _htmlView = new HtmlPreviewView(_stack);
    _stack->addWidget(_browser);
    _stack->addWidget(_htmlView);
    // 初始化结果确定后（成功或失败），若当前是 HTML 文件则重新决定显示页
    connect(_htmlView, &HtmlPreviewView::resolved, this, [this]() {
        if (_format == TextFormat::Html)
            renderNow();
    });

    // 预览滚动（规范 5.3）：大纲高亮 = 最后一个 previewTop <= scrollTop+80
    // 的标题。同步严格单向——预览滚动不回推编辑器（规范 1.1）。
    connect(_browser->verticalScrollBar(), &QScrollBar::valueChanged, this,
            [this](int v) {
        // 用户驱动滚动（滚轮/拖滚动条/键盘；非本类 setValue）：立即停掉
        // 平滑动画并抑制重锚，否则重锚动画会把用户的滚动覆盖回去
        if (!_applyingSmooth) {
            stopSmooth();
            suppressReanchor();
        }
        emit activeHeadingChanged(activeHeadingAt(qreal(v)));
        // resize 锚点记忆（映射无效时按比例折算源行）
        if (_mappingValid) {
            _lastTopLineF = topSourceLineF();
        } else {
            QScrollBar* sb = _browser->verticalScrollBar();
            const qreal maxLine = _blocks.isEmpty() ? 1 : qreal(_blocks.last().end);
            const qreal r = sb->maximum() > 0
                                ? qreal(v) / sb->maximum() : 0.0;
            _lastTopLineF = qMax(1.0, r * maxLine);
        }
    });

    _browser->installEventFilter(this);
    _browser->viewport()->installEventFilter(this);

    _renderTimer = new QTimer(this);
    _renderTimer->setSingleShot(true);
    _renderTimer->setInterval(300);   // 编辑刷新防抖（快速打字时合并渲染）
    connect(_renderTimer, &QTimer::timeout, this, &PreviewWidget::renderNow);

    // 帧驱动平滑滚动：每帧向目标靠近 30%（指数缓出），与参考实现一致
    _smoothTimer = new QTimer(this);
    _smoothTimer->setInterval(16);
    connect(_smoothTimer, &QTimer::timeout, this, &PreviewWidget::smoothTick);
}

void PreviewWidget::setMarkdown(const QString& markdown)
{
    _markdown = markdown;
    // HTML 文件由 WebView2 呈现：逐键重载会反复重启页面脚本，故编辑期间不刷新，
    // 仅在保存 / 手动刷新 / 载入文件时导航（reloadHtmlPreview / setSourcePath）。
    if (_format == TextFormat::Html)
        return;
    scheduleRender();
}

void PreviewWidget::setFormat(TextFormat fmt)
{
    if (_format == fmt)
        return;   // 每次按键都会调用，未变化则跳过（避免 HTML 重复导航）
    _format = fmt;
    scheduleRender();
}

void PreviewWidget::setSourcePath(const QString& path)
{
    if (_sourcePath == path)
        return;
    _sourcePath = path;
    if (_format == TextFormat::Html)
        scheduleRender();
}

void PreviewWidget::refreshTheme()
{
    if (_format == TextFormat::Html)
        return;   // 浏览器页面自带样式，主题变化无需重载
    scheduleRender();
}

void PreviewWidget::refreshSettings()
{
    if (_format == TextFormat::Html)
        return;
    scheduleRender();
}

void PreviewWidget::reloadHtmlPreview()
{
    if (_format == TextFormat::Html)
        _htmlView->reload();
}

void PreviewWidget::scheduleRender()
{
    // setMarkdown() and setFormat() are called back-to-back on every keystroke;
    // coalesce them into a single render.
    _renderTimer->start();
}

// 底部留白（clamp 夹住了.txt + 风险①修正）：每次渲染固定补一个 25vh 高的
// 尾部空白块，让"把光标行对齐到 anchorRatio 处"在文档末尾也不被 clamp
// 贴底。关键点：文档生命周期内始终存在——若只在精确布局路径临时设置，
// 普通渲染时 setHtml 把它冲掉、对齐时又加回，总高反复跳变引起抖动；
// 固定常驻后 clamp 范围恒定，无任何切换抖动。插入在 postProcess 配对完成
// 之后，不影响 lanes↔BlockInfo 严格 1:1；单块尾部插入只脏文末布局。
void PreviewWidget::appendBottomSpacer()
{
    QTextDocument* doc = _browser->document();
    if (!doc)
        return;
    const int want = qRound(qreal(_browser->viewport()->height()) * 0.25);
    if (want <= 0)
        return;
    QSignalBlocker blocker(doc);
    QTextCursor c(doc);
    c.movePosition(QTextCursor::End);
    QTextBlockFormat bf;
    bf.setLineHeight(qreal(want), QTextBlockFormat::FixedHeight);
    c.insertBlock(bf);
}

void PreviewWidget::renderNow()
{
    QScrollBar* sb = _browser->verticalScrollBar();
    // 编辑输入触发的重渲染不得打断"跟随编辑位置"动画：先记住行模式目标，
    // 渲染完成后按新几何继续朝该目标平滑，否则预览会停在渲染前位置
    const bool resumeFollow = _smoothActive && _smoothLineMode;
    const qreal resumeLineF = _smoothLineF;
    const qreal resumeRatio = _smoothRatio;
    const qreal resumeOffset = _smoothOffset;
    stopSmooth();   // 重渲染即时重锚，终止进行中的平滑动画
    const bool first = !_renderedOnce;
    // 一次性"输入到底"对齐目标（消费后清空；HTML 分支不消费）
    const qreal pendingLineF = _pendingLineF;
    const qreal pendingRatio = _pendingRatio;
    _pendingLineF = -1.0;
    // 重渲染前保存像素位置（等价参考实现保存 scrollTop）
    const int savedPx = sb->value();
    _renderedOnce = true;

    if (_format == TextFormat::Html) {
        // HTML 文件：交给 WebView2（Windows 自带 Edge 内核）做浏览器级渲染，
        // 执行页面 JavaScript / 现代 CSS，效果与在浏览器打开一致；
        // 不再经过 Markdown 转换管线（否则会把 HTML 当 Markdown 显示）。
        _stack->setCurrentWidget(_htmlView);
        _htmlView->setHtmlSource(_markdown);   // 运行时不可用时降级展示的文本
        if (!_sourcePath.isEmpty() && _htmlView->currentTarget() != _sourcePath)
            _htmlView->openFile(_sourcePath);
        postProcessDocument({});
        // HTML 预览无块级源行映射，大纲滚动联动对其不适用
        emit activeHeadingChanged(-1);
        hideCopyButton();
        return;
    }

    _stack->setCurrentWidget(_browser);
    // setHtml() 会把滚动条同步复位到 0。重建期间屏蔽 valueChanged：
    //  1) 避免中间态信号触发 activeHeadingChanged 造成大纲高亮闪烁；
    //  2) 避免用户滚动守卫把后续恢复误判为交互。位置在本函数内（重绘前）恢复。
    const bool sbWasBlocked = sb->blockSignals(true);
    {
        // setHtml() 会清空并重建 QTextDocument：旧的 QTextBlock/QTextFrame 随之
        // 失效。重建期间若滚动条 valueChanged 触发，绝不能再用旧几何（悬垂指针
        // 会导致 Qt6Gui 崩溃）。故在替换内容前先作废映射并清空块序列。
        _mappingValid = false;
        _blocks.clear();
        QVector<MarkdownConverter::BlockInfo> blocks;
        setRichHtml(_browser, _markdown, ThemeManager::instance().isDark(), &blocks);
        postProcessDocument(blocks);
        // 底部留白在配对完成后固定补上（详见 appendBottomSpacer）
        appendBottomSpacer();
    }

    // 性能关键：setHtml() 首轮已完成整篇流式布局，滚动条 range 已是有效值；
    // postProcess 的可断行修改只脏了代码块，交给 QTextBrowser 绘制时按视口
    // 惰性重排。这里绝不再无条件调 documentSize() 强制整篇重排（大文档约
    // 150ms，输入卡顿主因）。只有需要精确源行落点的场景才强制整篇布局：
    //   1) 编辑器滚动/大纲跳转的跟随动画恢复（resumeFollow）；
    //   2) 输入跟随判定光标行在预览视口外，需要对齐落点（pending 分支）。

    if (resumeFollow) {
        // setHtml 已把滚动条复位到 0，此时绝不能启动"从 0 出发"的平滑动画，
        // 否则会看到预览先跳到第 1 行再扫回来。这里在重绘前按"新几何"即时
        // 落到目标行，随后再保持行模式，后续输入只在目标变化时平滑移动。
        if (QTextDocument* doc = _browser->document()) {
            if (auto* lay = doc->documentLayout())
                lay->documentSize();
        }
        sb->setValue(qRound(targetYForLineF(resumeLineF, resumeRatio, resumeOffset)));
        startSmoothToLine(resumeLineF, resumeRatio, resumeOffset);
    } else if (pendingLineF >= 0.0) {
        // 输入跟随：光标行已在预览视口内 → 只恢复保存的像素位置，内容纹丝
        // 不动（防跳）；在视口外（尾部新内容 / 预览被滚走）→ 精确布局后把光
        // 标行对到锚点处。锚点比例 _pendingRatio 由编辑器光标在编辑器视口
        // 中的位置动态决定（不再固定 0.5），跳跃更温和。
        const int restPx = qBound(sb->minimum(), savedPx, sb->maximum());
        const int vh = _browser->viewport()->height();

        // 短文档：整篇高度不超过视口时直接贴顶，"中部对齐"无意义
        qreal docHeight = 0;
        if (QTextDocument* doc = _browser->document()) {
            if (auto* lay = doc->documentLayout())
                docHeight = lay->documentSize().height();
        }
        if (docHeight > 0 && docHeight <= qreal(vh)) {
            sb->setValue(0);
            _followEngaged = false;
        } else if (!first && _mappingValid) {
            const qreal lineY = docYForLineF(pendingLineF);
            // 迟滞双阈值，避免光标行恰好在边界时"动/不动"反复横跳：
            //   上次未跟随（_followEngaged=false）：收窄到 15%~85% 才算可见
            //   上次已跟随（_followEngaged=true ）：放宽到  5%~95% 才停止跟随
            const qreal lo = _followEngaged ? 0.05 : 0.15;
            const qreal hi = _followEngaged ? 0.95 : 0.85;
            const bool visible = lineY >= qreal(restPx) + qreal(vh) * lo
                              && lineY <= qreal(restPx) + qreal(vh) * hi;
            if (visible) {
                _followEngaged = false;
                sb->setValue(restPx);
            } else {
                _followEngaged = true;
                if (QTextDocument* doc = _browser->document()) {
                    if (auto* lay = doc->documentLayout())
                        lay->documentSize();
                }
                sb->setValue(qRound(targetYForLineF(pendingLineF, _pendingRatio, 0.0)));
                _lastTopLineF = pendingLineF;
                // 图片/Math/Mermaid 异步加载后布局可能突变，150ms 后重新校准
                // 一次光标行可见性：若被顶出视口则重新对齐（复用已有重校准节奏）
                const qreal lineF = pendingLineF;
                QTimer::singleShot(150, this, [this, lineF]() {
                    if (!_mappingValid || !AppSettings::instance().previewFollowEditor())
                        return;
                    QScrollBar* sb2 = _browser->verticalScrollBar();
                    const int vh2 = _browser->viewport()->height();
                    const qreal y = docYForLineF(lineF);
                    const bool stillVisible =
                        y >= qreal(sb2->value()) + qreal(vh2) * 0.1
                        && y <= qreal(sb2->value()) + qreal(vh2) * 0.9;
                    if (!stillVisible) {
                        if (QTextDocument* doc = _browser->document()) {
                            if (auto* lay = doc->documentLayout())
                                lay->documentSize();
                        }
                        sb2->setValue(qRound(targetYForLineF(lineF, _pendingRatio, 0.0)));
                        _lastTopLineF = lineF;
                    }
                });
            }
        } else {
            // 首次渲染或映射未就绪：直接对齐
            _followEngaged = true;
            if (QTextDocument* doc = _browser->document()) {
                if (auto* lay = doc->documentLayout())
                    lay->documentSize();
            }
            sb->setValue(qRound(targetYForLineF(pendingLineF, _pendingRatio, 0.0)));
            _lastTopLineF = pendingLineF;
        }
    } else if (!first) {
        // 普通输入渲染：等价参考 code.html 的保存/恢复 scrollTop——只保持
        // 像素位置，不同步行位置。视口上方无变更时内容纹丝不动。
        sb->setValue(qBound(sb->minimum(), savedPx, sb->maximum()));
    } else {
        _lastTopLineF = 1.0;
    }
    const int restoredPx = sb->value();
    sb->blockSignals(sbWasBlocked);
    // 大纲高亮/resize 锚点延后到事件循环：先让 QTextBrowser 完成新视口的
    // 绘制与局部布局，此时只查视口附近块即可（blockRect 沿链布局到视口），
    // 避免在这里沿块链强制整篇布局
    QTimer::singleShot(0, this, [this, restoredPx]() {
        if (_mappingValid)
            _lastTopLineF = lineFForDocY(qreal(restoredPx));
        emit activeHeadingChanged(activeHeadingAt(qreal(restoredPx)));
    });
    hideCopyButton();
}

bool PreviewWidget::isHtmlMode() const
{
    return _format == TextFormat::Html;
}

void PreviewWidget::postProcessDocument(const QVector<MarkdownConverter::BlockInfo>& infos)
{
    // 结构槽：QTextDocument 顶层结构的确定性归并（不使用任何文本信息）。
    //   子 frame            → 表格（blockquote 不产 frame，是普通块），1 槽
    //   连续列表区域        → 1 槽（textList 块 + 缩进续行/项内段落/项内代码）
    //   连续 pre 块         → 1 槽（Qt 把多行 <pre> 按行拆成多块）
    //   带 ruler 属性的块   → hr，1 槽
    //   其余非空块          → 1 槽（段落/标题/引用）；纯空块跳过
    struct Slot {
        QTextBlock first;
        QTextBlock last;
        QTextFrame* frame = nullptr;
        bool isList = false;
        bool isHr = false;
        bool isPre = false;
        QVector<QTextList*> seen;   // 列表组内已出现的 QTextList 指针
        bool hasBlocks() const { return first.isValid(); }
    };
    QVector<Slot> lanes;

    QTextDocument* doc = _browser->document();
    QTextFrame* root = doc->rootFrame();
    for (QTextFrame::iterator it = root->begin(); !it.atEnd(); ++it) {
        if (QTextFrame* f = it.currentFrame()) {
            Slot s;
            s.frame = f;
            lanes.append(s);
            continue;
        }
        QTextBlock b = it.currentBlock();
        if (!b.isValid())
            continue;
        const QTextBlockFormat bf = b.blockFormat();
        if (b.textList()) {
            // 列表组延续判定：Qt 把相邻两个独立 <ul>/<ol> 的块物理相连
            // （之间无空块），仅靠 .next() 会把多组误并。同组内 QTextList
            // 指针会复用（嵌套回退时外层列表仍是原指针），已见过的指针
            // 必属同组；新指针只有缩进（QTextListFormat::indent）深于组首
            // 才是嵌套子列表，同级缩进即是新列表（转换器按空行分组）。
            QTextList* cur = b.textList();
            bool cont = false;
            if (!lanes.isEmpty() && lanes.last().isList
                && lanes.last().last.next() == b) {
                Slot& g = lanes.last();
                if (g.seen.contains(cur))
                    cont = true;
                else if (cur->format().indent()
                         > g.first.textList()->format().indent())
                    cont = true;   // 嵌套深入
            }
            if (cont) {
                Slot& g = lanes.last();
                g.last = b;
                if (!g.seen.contains(cur))
                    g.seen.append(cur);
            } else {
                Slot s;
                s.first = b;
                s.last = b;
                s.isList = true;
                s.seen.append(cur);
                lanes.append(s);
            }
            continue;
        }
        // Qt 的 HTML 导入器把 <hr> 表现为带 BlockTrailingHorizontalRulerWidth
        // （qtextformat.h 0x1060）属性的块
        if (bf.hasProperty(QTextFormat::BlockTrailingHorizontalRulerWidth)) {
            Slot s;
            s.first = b;
            s.last = b;
            s.isHr = true;
            lanes.append(s);
            continue;
        }
        const bool isPreFmt = bf.nonBreakableLines();
        // 图片块（Mermaid/数学公式/普通图片）：img 是 fragment，text() 为空，
        // 不能按纯空块跳过
        bool hasImage = false;
        if (b.text().trimmed().isEmpty()) {
            for (QTextBlock::iterator fit = b.begin(); !fit.atEnd(); ++fit) {
                if (fit.fragment().charFormat().isImageFormat()) {
                    hasImage = true;
                    break;
                }
            }
        }
        if (b.text().trimmed().isEmpty() && !hasImage) {
            // 代码块内的空行：Qt 把 <pre> 按行拆块后空行仍带 pre 格式，
            // 必须参与归并，否则含空行的代码块被拆成多个槽
            if (isPreFmt) {
                if (!lanes.isEmpty() && lanes.last().isPre
                    && lanes.last().last.next() == b) {
                    lanes.last().last = b;
                } else if (!lanes.isEmpty() && lanes.last().isList
                           && lanes.last().last.next() == b
                           && bf.indent() > 0) {
                    lanes.last().last = b;   // 列表项内空代码行
                } else {
                    Slot s;
                    s.first = b;
                    s.last = b;
                    s.isPre = true;
                    lanes.append(s);         // 空围栏代码块（极罕见）
                }
            }
            continue;   // 其余纯空块：Qt 填充，无对应输出元素
        }
        // 缩进续块：列表项内段落/代码、嵌套引用等在 Qt 中是无 textList
        // 标记但带块缩进的块，物理上紧邻所属结构，归入上一槽（转换器侧
        // 整个列表/引用只占 1 块）
        if (!lanes.isEmpty() && bf.indent() > 0 && lanes.last().hasBlocks()
            && lanes.last().last.next() == b) {
            lanes.last().last = b;
            continue;
        }
        if (isPreFmt) {
            // <pre> 在 Qt 中按行拆块：连续 pre 块归并为一个代码槽
            if (!lanes.isEmpty() && lanes.last().isPre
                && lanes.last().last.next() == b) {
                lanes.last().last = b;
            } else {
                Slot s;
                s.first = b;
                s.last = b;
                s.isPre = true;
                lanes.append(s);
            }
            continue;
        }
        lanes.append({b, b, nullptr, false, false, false});
    }

    using BI = MarkdownConverter::BlockInfo;
    auto slotKindOk = [](const Slot& s, BI::Kind k) {
        if (s.frame)
            return dynamic_cast<QTextTable*>(s.frame) ? k == BI::Table
                                                      : k == BI::Quote;
        if (s.isList)
            return k == BI::List;
        if (s.isHr)
            return k == BI::Hr;
        if (s.isPre)
            return k == BI::Code;
        // 引用在 Qt 中不是子 frame，是普通块（转换器侧整块 1 条）
        return k == BI::Paragraph || k == BI::Heading
            || k == BI::Quote || k == BI::Media;
    };

    bool ok = (lanes.size() == infos.size());
    const int n = qMin(lanes.size(), infos.size());
    for (int k = 0; k < n; ++k) {
        if (!slotKindOk(lanes[k], infos[k].kind)) {
            ok = false;
            break;
        }
    }

    _blocks.clear();
    if (!ok) {
        // 结构与转换器输出不一致：不猜测，整体退回比例映射，避免错配跳转
        _mappingValid = false;
        emit headingsAvailable({});
        return;
    }

    _blocks.reserve(n);
    for (int k = 0; k < n; ++k) {
        const BI& info = infos[k];
        const Slot& s = lanes[k];
        Block b;
        b.start = info.srcLine;
        b.end = qMax(info.srcLine, info.endLine);
        b.kind = info.kind;
        b.level = info.level;
        b.text = info.text;
        b.slug = info.slug;
        b.frame = s.frame;
        b.block = s.first;
        b.lastBlock = s.last;
        _blocks.append(b);
    }
    _mappingValid = true;

    // 子锚点行区间拆分（markora-block-align-fix.md 第四节）：大块（>3 行）
    // 的表格按行 / 列表按项 / 代码按行 / 引用按空行分段；几何留待首次
    // 使用时直接测量（ensureSubsMeasured），避免每次渲染都触碰布局。
    {
        const QStringList srcLines = _markdown.split(QLatin1Char('\n'));
        for (Block& b : _blocks)
            buildSubAnchors(b, srcLines);
    }

    // 代码块：Qt HTML 导入器对 white-space:pre 逐行拆块并置 nonBreakableLines，
    // 长行不自动断行会被裁。这里把所有代码块的块格式改为可断行——必须合并为
    // 一次 editBlock 且屏蔽文档信号，否则每次 setBlockFormat 都触发重排/信号，
    // 大文档上数千次编辑可达 ~200ms（输入卡顿主因之一）。
    bool needUnbreak = false;
    for (const Block& b : _blocks) {
        if (b.kind != BI::Code || !b.block.isValid())
            continue;
        for (QTextBlock tb = b.block; tb.isValid(); tb = tb.next()) {
            if (tb.blockFormat().nonBreakableLines()) {
                needUnbreak = true;
                break;
            }
            if (tb == b.lastBlock)
                break;
        }
        if (needUnbreak)
            break;
    }
    if (needUnbreak) {
        QSignalBlocker blockSignals(doc);
        QTextCursor bulk(doc);
        bulk.beginEditBlock();
        for (const Block& b : _blocks) {
            if (b.kind != BI::Code || !b.block.isValid())
                continue;
            for (QTextBlock tb = b.block; tb.isValid(); tb = tb.next()) {
                QTextBlockFormat fmt = tb.blockFormat();
                if (fmt.nonBreakableLines()) {
                    fmt.setNonBreakableLines(false);
                    QTextCursor c(tb);
                    c.setBlockFormat(fmt);
                }
                if (tb == b.lastBlock)
                    break;
            }
        }
        bulk.endEditBlock();
    }

    QVector<BI> heads;
    for (const Block& b : _blocks)
        if (b.kind == BI::Heading)
            heads.append(BI::heading(b.start, b.end, b.level, b.text, b.slug));
    emit headingsAvailable(heads);
}

QRectF PreviewWidget::blockRect(const Block& b) const
{
    if (!b.hasGeom())
        return QRectF();
    QAbstractTextDocumentLayout* lay =
        _browser->document()->documentLayout();
    if (!lay)
        return QRectF();
    if (b.frame)
        return lay->frameBoundingRect(b.frame);
    const QRectF first = lay->blockBoundingRect(b.block);
    if (b.lastBlock.isValid() && !(b.lastBlock == b.block)) {
        // 跨块槽（列表组/多行 pre）：首块顶 → 末块底
        return first.united(lay->blockBoundingRect(b.lastBlock));
    }
    return first;
}

// h1/h2 标题底部边框（ADR-028 第二版）：在 QTextBrowser 视口正常绘制完成后
// 叠加 1px 横线。Qt 富文本不渲染块级 border-bottom，位图注入方案又受限于
// 转换器 "</h1 >" 标签格式与 img 百分比宽度不被支持；直接按标题块实时布局
// 矩形绘制，宽度随面板宽度/字号实时自适应，且完全不改动文档结构与块配对。
void PreviewWidget::paintHeadingBorders()
{
    if (!_mappingValid || _blocks.isEmpty())
        return;
    QAbstractTextDocumentLayout* lay = _browser->document()->documentLayout();
    if (!lay)
        return;

    const int scrollY = _browser->verticalScrollBar()->value();
    const int viewH = _browser->viewport()->height();
    const int fontPx = AppSettings::instance().previewFontSize();
    // 标题字号：h1=1.9em、h2=1.5em（与 MarkdownConverter CSS 一致）
    static const qreal kFontEm[3] = {0.0, 1.9, 1.5};
    // 底线相对最后一行 naturalTextRect 底边的间距 = CSS padding-bottom
    // （h1=.12em、h2=.10em，按标题字号计，与 MarkdownConverter CSS 保持一致）。
    // naturalTextRect 底边即字体 content box 底边（baseline+descent），
    // 浏览器里 border 就画在 content 底 + padding-bottom 处，半行距属于
    // line box 不参与，不能额外叠加（否则线落到 margin 区中央，看起来像平均分隔）。
    static const qreal kGapFactor[3] = {0.0, 0.12, 0.10};

    QPainter p(_browser->viewport());
    p.setPen(QPen(ThemeManager::instance().borderColor(), 1));
    p.setRenderHint(QPainter::Antialiasing, false);
    for (const Block& b : _blocks) {
        if (b.kind != MarkdownConverter::BlockInfo::Heading
            || b.level < 1 || b.level > 2 || !b.block.isValid())
            continue;
        QTextLayout* bl = b.block.layout();
        if (!bl || bl->lineCount() == 0)
            continue;
        // 取标题最后一行的字体度量矩形（含 ascent/descent，紧贴真实文字），
        // 配合 QTextLayout 的文档坐标原点定位——不受块外边距语义影响
        const QTextLine lastLine = bl->lineAt(bl->lineCount() - 1);
        const qreal textBottomDoc = bl->position().y()
                                    + lastLine.naturalTextRect().bottom();
        const qreal headingPx = qreal(fontPx) * kFontEm[b.level];
        const qreal gap = qRound(headingPx * kGapFactor[b.level]);
        const qreal y = textBottomDoc + gap - qreal(scrollY);
        if (y < -2 || y > viewH + 2)
            continue;   // 视口外不画
        const QRectF r = lay->blockBoundingRect(b.block);
        p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y));
    }
}

// code.html findBlock：覆盖 lineF 的块；找不到时取已完全滚过的最后一块；
// 文档起点之前取第 0 块。
int PreviewWidget::blockIndexForLineF(qreal lineF) const
{
    for (int i = 0; i < _blocks.size(); ++i) {
        if (lineF >= qreal(_blocks[i].start)
            && lineF < qreal(_blocks[i].end + 1))
            return i;
    }
    for (int i = _blocks.size() - 1; i >= 0; --i) {
        if (qreal(_blocks[i].end) < lineF)
            return i;
    }
    return 0;
}

qreal PreviewWidget::topSourceLineF() const
{
    if (_blocks.isEmpty())
        return 1.0;
    return lineFForDocY(qreal(_browser->verticalScrollBar()->value()));
}

// 用户规则：标题进入预览视口 3/10 高度处即激活（最后一个
// previewTop <= scrollTop + viewportH*0.3 的标题）。
int PreviewWidget::activeHeadingAt(qreal scrollValue) const
{
    if (!_mappingValid)
        return -1;
    const qreal threshold = scrollValue
        + qreal(_browser->viewport()->height()) * 0.3;
    int line = -1;
    for (const Block& b : _blocks) {
        if (!b.hasGeom())
            continue;
        if (blockRect(b).top() > threshold)
            break;
        if (b.kind == MarkdownConverter::BlockInfo::Heading)
            line = b.start;
    }
    return line;
}

// 子锚点拆分（markora-block-align-fix.md 第四节）：只拆 >3 行的大块。
// 此处只记录源码行区间，渲染几何在 ensureSubsMeasured 首次使用时测量。
void PreviewWidget::buildSubAnchors(Block& b, const QStringList& src) const
{
    using BI = MarkdownConverter::BlockInfo;
    b.subs.clear();
    if (b.end - b.start + 1 <= 3)
        return;   // 小块不拆：整块映射误差本来就小（第八节 shouldSplit）
    auto lineAt = [&](int ln) -> QString {
        return (ln >= 1 && ln <= src.size()) ? src[ln - 1] : QString();
    };

    if (b.kind == BI::Code) {
        // 围栏代码：内容行 = 开围栏+1 .. 闭围栏-1；缩进代码：整块即内容。
        // 每 5 行一组（对齐 markora-block-align-fix.md：代码行高固定，
        // 5 行组误差 <2px；风险③——逐行锚点对 500 行块是 500 次测量）。
        int s = b.start, e = b.end;
        static const QRegularExpression fenceRe(
            QStringLiteral("^\\s*(```+|~~~+)"));
        if (fenceRe.match(lineAt(s)).hasMatch()) {
            ++s;
            if (e >= s && fenceRe.match(lineAt(e)).hasMatch())
                --e;
        }
        for (int ln = s; ln <= e; ln += 5)
            b.subs.append({ln, qMin(ln + 4, e), 0, 0, false});
        return;
    }
    if (b.kind == BI::Table) {
        // 行结构：表头行 / 分隔行（渲染高度 0）/ 数据行，逐行一条
        for (int ln = b.start; ln <= b.end; ++ln)
            b.subs.append({ln, ln, 0, 0, false});
        return;
    }
    if (b.kind == BI::List) {
        // 每个列表项起始行一条（续行/项内段落并入上一项）
        static const QRegularExpression itemRe(
            QStringLiteral("^\\s*(?:[-*+]|\\d{1,9}[.)])\\s+"));
        int itemStart = -1;
        for (int ln = b.start; ln <= b.end; ++ln) {
            if (itemRe.match(lineAt(ln)).hasMatch()) {
                if (itemStart > 0)
                    b.subs.append({itemStart, ln - 1, 0, 0, false});
                itemStart = ln;
            }
        }
        if (itemStart > 0)
            b.subs.append({itemStart, b.end, 0, 0, false});
        if (b.subs.size() <= 1)
            b.subs.clear();   // 单项无需子锚点
        return;
    }
    if (b.kind == BI::Quote && !b.frame) {
        // 按空行（含 "> "形式的空引用行）分段
        static const QRegularExpression blankRe(QStringLiteral("^\\s*>?\\s*$"));
        int segStart = -1;
        for (int ln = b.start; ln <= b.end; ++ln) {
            if (blankRe.match(lineAt(ln)).hasMatch()) {
                if (segStart > 0)
                    b.subs.append({segStart, ln - 1, 0, 0, false});
                segStart = -1;
            } else if (segStart < 0) {
                segStart = ln;
            }
        }
        if (segStart > 0)
            b.subs.append({segStart, b.end, 0, 0, false});
        if (b.subs.size() <= 1)
            b.subs.clear();
        return;
    }
}

// 子锚点几何测量（第五节）：不用公式推算，直接量 QTextDocument 中对应
// 子元素的包围盒。数量不一致等任何失配 → 清空回退整块映射，绝不猜测。
void PreviewWidget::ensureSubsMeasured(const Block& cb) const
{
    if (cb.subs.isEmpty() || cb.subs.first().measured)
        return;
    Block& b = *const_cast<Block*>(&cb);   // 惰性写回缓存，对外仍是只读语义
    QAbstractTextDocumentLayout* lay =
        _browser->document()->documentLayout();
    using BI = MarkdownConverter::BlockInfo;
    if (!lay || !b.hasGeom()) {
        b.subs.clear();
        return;
    }
    auto fail = [&b]() { b.subs.clear(); };

    if (b.kind == BI::Table) {
        QTextTable* tbl = dynamic_cast<QTextTable*>(b.frame);
        // subs = [表头, 分隔行, 数据行×N] → QTextTable 行数 = subs-1
        if (!tbl || tbl->rows() != b.subs.size() - 1) {
            fail();
            return;
        }
        // 行顶偏移 = 单元格 padding-top + 边框：优先取表格实际格式的
        // cellPadding（Qt 导入 td/th padding 的结果），取不到才回退 CSS
        // 常量 8px + 1px 边框，避免换主题/字号后测量整体偏移（风险②）。
        qreal pad = 9.0;
        {
            const qreal cp = tbl->format().cellPadding();
            if (cp > 0.0 && cp < 40.0)
                pad = cp + 1.0;
        }
        for (int r = 0; r < tbl->rows(); ++r) {
            const QTextBlock fb = tbl->cellAt(r, 0).begin().currentBlock();
            if (!fb.isValid()) {
                fail();
                return;
            }
            const qreal top = lay->blockBoundingRect(fb).top() - pad;
            qreal bottom;
            if (r + 1 < tbl->rows()) {
                const QTextBlock nb =
                    tbl->cellAt(r + 1, 0).begin().currentBlock();
                if (!nb.isValid()) {
                    fail();
                    return;
                }
                bottom = lay->blockBoundingRect(nb).top() - pad;
            } else {
                bottom = lay->frameBoundingRect(tbl).bottom();
            }
            SubAnchor& sa = b.subs[r == 0 ? 0 : r + 1];   // subs[1]=分隔行，跳过
            sa.top = top;
            sa.height = qMax<qreal>(0, bottom - top);
            sa.measured = true;
        }
        b.subs[1].top = b.subs[0].top + b.subs[0].height;
        b.subs[1].height = 0;
        b.subs[1].measured = true;
        return;
    }
    if (b.kind == BI::Code) {
        // 每 5 行一组：组边界块序号为 0,5,10...（对应 Qt 按行拆的
        // QTextBlock），组高由相邻组顶相减，避免逐行测量上千次的开销
        // （风险③）。长行软换行导致组内行高不均时误差仅限组内，<2px 级。
        int idx = 0;      // 内容块序号
        int subIdx = 0;   // 已确定 top 的组数
        for (QTextBlock tb = b.block; tb.isValid(); tb = tb.next()) {
            if (idx % 5 == 0) {
                if (subIdx >= b.subs.size()) {
                    fail();
                    return;
                }
                b.subs[subIdx].top = lay->blockBoundingRect(tb).top();
                if (subIdx > 0) {
                    b.subs[subIdx - 1].height = qMax<qreal>(
                        1.0, b.subs[subIdx].top - b.subs[subIdx - 1].top);
                    b.subs[subIdx - 1].measured = true;
                }
                ++subIdx;
            }
            ++idx;
            if (tb == b.lastBlock)
                break;
        }
        if (subIdx != b.subs.size()) {
            fail();
            return;
        }
        b.subs.last().height = qMax<qreal>(
            1.0, lay->blockBoundingRect(b.lastBlock).bottom()
                     - b.subs.last().top);
        b.subs.last().measured = true;
        return;
    }
    if (b.kind == BI::List) {
        // 文档序收集列表项头块（含嵌套项），与源码项起始行一一对应
        QVector<QTextBlock> heads;
        for (QTextBlock tb = b.block; tb.isValid(); tb = tb.next()) {
            if (QTextList* l = tb.textList()) {
                const int no = l->itemNumber(tb);
                if (no >= 0 && l->item(no) == tb)
                    heads.append(tb);
            }
            if (tb == b.lastBlock)
                break;
        }
        if (heads.size() != b.subs.size()) {
            fail();
            return;
        }
        for (int i = 0; i < heads.size(); ++i) {
            const qreal top = lay->blockBoundingRect(heads[i]).top();
            const qreal bottom = (i + 1 < heads.size())
                ? lay->blockBoundingRect(heads[i + 1]).top()
                : lay->blockBoundingRect(b.lastBlock).bottom();
            b.subs[i].top = top;
            b.subs[i].height = qMax<qreal>(0, bottom - top);
            b.subs[i].measured = true;
        }
        return;
    }
    // Quote（非 frame）：非空段落序 ↔ 文档块序一一对应
    int idx = 0;
    for (QTextBlock tb = b.block; tb.isValid(); tb = tb.next()) {
        if (idx >= b.subs.size()) {
            fail();
            return;
        }
        const QRectF r = lay->blockBoundingRect(tb);
        b.subs[idx].top = r.top();
        b.subs[idx].height = qMax<qreal>(1.0, r.height());
        b.subs[idx].measured = true;
        ++idx;
        if (tb == b.lastBlock)
            break;
    }
    if (idx != b.subs.size())
        fail();
}

// 子锚点查找（6.3 findSubAnchorContaining）：覆盖 lineF 的项；命中零高度
// 项（表格分隔行）顺延到下一个有高度的；未覆盖取 end < lineF 的最后一条。
const PreviewWidget::SubAnchor*
PreviewWidget::subAnchorFor(const Block& b, qreal lineF) const
{
    for (int i = 0; i < b.subs.size(); ++i) {
        const SubAnchor& sa = b.subs[i];
        if (lineF >= qreal(sa.start) && lineF < qreal(sa.end) + 1.0) {
            if (sa.height > 0)
                return &sa;
            for (int j = i + 1; j < b.subs.size(); ++j)
                if (b.subs[j].height > 0)
                    return &b.subs[j];
            for (int j = i - 1; j >= 0; --j)
                if (b.subs[j].height > 0)
                    return &b.subs[j];
            return nullptr;
        }
    }
    for (int i = b.subs.size() - 1; i >= 0; --i)
        if (b.subs[i].end < lineF && b.subs[i].height > 0)
            return &b.subs[i];
    return b.subs.isEmpty() ? nullptr : &b.subs.first();
}


// 文档 Y -> 源行（小数）：syncPreviewToEditor 的逆映射（resize 锚点用）。
// 归属矩形覆盖 y 的最后一个块，块内按比例；有子锚点时改用子锚点几何。
qreal PreviewWidget::lineFForDocY(qreal y) const
{
    if (_blocks.isEmpty())
        return 1.0;
    int idx = 0;
    for (int i = 0; i < _blocks.size(); ++i) {
        if (blockRect(_blocks[i]).top() <= y + 2.0)
            idx = i;
        else
            break;
    }
    const Block& b = _blocks[idx];
    const QRectF r = blockRect(b);
    // 子锚点优先（6.1 修正）：y 所属子锚点内按比例，直接对应渲染几何
    ensureSubsMeasured(b);
    if (!b.subs.isEmpty()) {
        const SubAnchor* best = nullptr;
        for (const SubAnchor& sa : b.subs) {
            if (sa.height <= 0)
                continue;
            if (sa.top <= y + 1.0)
                best = &sa;
            else
                break;
        }
        if (best) {
            qreal frac = (y - best->top) / best->height;
            frac = qBound(0.0, frac, 1.0);
            return qreal(best->start)
                   + frac * qreal(best->end + 1 - best->start);
        }
    }
    const qreal denom = qMax<qreal>(1.0, qreal(b.end + 1 - b.start));
    qreal frac = r.height() > 0 ? (y - r.top()) / r.height() : 0.0;
    frac = qBound(0.0, frac, 1.0);
    return qreal(b.start) + frac * denom;
}

// 源行（小数）-> 文档 Y：逐字对应 code.html syncPreviewToEditor 的
// 预览侧公式 pRefPos = pBlockTop + ratio * pBlockHeight。
qreal PreviewWidget::docYForLineF(qreal lineF) const
{
    if (_blocks.isEmpty())
        return 0.0;
    const int idx = blockIndexForLineF(lineF);
    const Block& b = _blocks[idx];
    if (!b.hasGeom()) {
        // 该块无可见元素：按整体比例退化（HTML 中 block.el 为 null 同款）
        const int total = qMax(1, totalSourceLines());
        const qreal r = total > 1
            ? (qBound(1.0, lineF, qreal(total)) - 1.0) / qreal(total - 1) : 0.0;
        QScrollBar* sb = _browser->verticalScrollBar();
        return sb->minimum() + r * (sb->maximum() - sb->minimum());
    }
    const qreal denom = qMax<qreal>(1.0, qreal(b.end + 1 - b.start));
    // 子锚点优先（6.1 修正）：refLn 所属子锚点内按比例——子锚点几何是
    // 直接测量的（表格行/列表项/代码行/引用段），不再用整块源码行比例
    // 推算像素位置，大块对齐误差从 30~50px 降到 <2px。
    ensureSubsMeasured(b);
    if (const SubAnchor* sa = subAnchorFor(b, lineF)) {
        const qreal sDenom = qMax<qreal>(1.0, qreal(sa->end + 1 - sa->start));
        const qreal sRatio =
            qBound(0.0, (lineF - qreal(sa->start)) / sDenom, 1.0);
        return sa->top + sRatio * sa->height;
    }
    const qreal ratio = qBound(0.0, (lineF - qreal(b.start)) / denom, 1.0);
    const QRectF r = blockRect(b);
    return r.top() + ratio * r.height();
}

// 旧的源码块解析与文本启发式配对已删除：块序列以 MarkdownConverter 的
// BlockInfo 为唯一真相，postProcessDocument 中与文档结构严格下标配对。

void PreviewWidget::scrollToSourceLine(int line, bool smooth)
{
    if (isHtmlMode())
        return;
    if (!_mappingValid || _blocks.isEmpty()) {
        scrollToSourceLineF(qreal(line), smooth);
        return;
    }
    // 大纲给的是标题行：优先命中该行的标题块，否则取覆盖块
    int idx = -1;
    for (int i = 0; i < _blocks.size(); ++i) {
        if (_blocks[i].kind == MarkdownConverter::BlockInfo::Heading
            && _blocks[i].start == line) {
            idx = i;
            break;
        }
    }
    if (idx < 0)
        idx = blockIndexForLineF(qreal(line));
    if (smooth)
        jumpToBlock(idx);
    else
        scrollToSourceLineF(qreal(line), false);
}

void PreviewWidget::scrollToSourceLineF(qreal lineF, bool smooth)
{
    if (isHtmlMode())
        return;   // HTML 预览由 WebView2 呈现，无块级源行映射
    stopSmooth();
    QScrollBar* sb = _browser->verticalScrollBar();
    int y;
    if (_mappingValid && !_blocks.isEmpty()) {
        // 源行小数 -> 文档 Y（与 code.html 同公式），置于视口顶部
        y = qMax(0, qRound(docYForLineF(lineF)));
    } else {
        // 块映射失效兜底：按源行占全文行数的比例定位
        const int total = qMax(1, totalSourceLines());
        const qreal r = total > 1
            ? (qBound(1.0, lineF, qreal(total)) - 1.0) / qreal(total - 1) : 0.0;
        y = sb->minimum() + qRound(r * (sb->maximum() - sb->minimum()));
    }
    if (smooth) {
        _lastTopLineF = lineF;
        startSmoothToLine(lineF, 0.0, 0.0);
    } else {
        _applyingSmooth = true;
        sb->setValue(qBound(sb->minimum(), y, sb->maximum()));
        _applyingSmooth = false;
        _lastTopLineF = lineF;
    }
    // 目标值与当前相同则不触发 valueChanged，这里补发大纲高亮通知
    emit activeHeadingChanged(activeHeadingAt(qreal(y)));
}

// ── 帧驱动平滑滚动（16ms，每帧逼近目标 30%，与 code.html 一致）──

void PreviewWidget::startSmoothTo(qreal y)
{
    QScrollBar* sb = _browser->verticalScrollBar();
    _smoothTarget = qBound<qreal>(sb->minimum(), y, sb->maximum());
    _smoothLineMode = false;
    suppressReanchor();
    if (_smoothActive)
        return;   // 动画中只更新目标，不重启定时器
    _smoothActive = true;
    _smoothTimer->start();
}

qreal PreviewWidget::targetYForLineF(qreal lineF, qreal anchorRatio,
                                     qreal offsetPx) const
{
    QScrollBar* sb = _browser->verticalScrollBar();
    if (_mappingValid && !_blocks.isEmpty()) {
        const qreal y = docYForLineF(lineF)
            - qreal(_browser->viewport()->height()) * anchorRatio - offsetPx;
        return qBound<qreal>(sb->minimum(), y, sb->maximum());
    }
    // 映射失效：按源行占比
    const int total = qMax(1, totalSourceLines());
    const qreal r = total > 1
        ? (qBound(1.0, lineF, qreal(total)) - 1.0) / qreal(total - 1) : 0.0;
    return sb->minimum() + r * (sb->maximum() - sb->minimum());
}

void PreviewWidget::startSmoothToLine(qreal lineF, qreal anchorRatio,
                                      qreal offsetPx)
{
    _smoothLineMode = true;
    _smoothLineF = lineF;
    _smoothRatio = anchorRatio;
    _smoothOffset = offsetPx;
    _smoothTarget = targetYForLineF(lineF, anchorRatio, offsetPx);
    suppressReanchor();   // 动画期间及其余波不重锚
    if (_smoothActive)
        return;
    _smoothActive = true;
    _smoothTimer->start();
}

void PreviewWidget::smoothTick()
{
    if (!_smoothActive)
        return;
    QScrollBar* sb = _browser->verticalScrollBar();
    // 目标行模式：每帧按当前几何重算，宽度变化/重排后落点依然精确
    if (_smoothLineMode)
        _smoothTarget = targetYForLineF(_smoothLineF, _smoothRatio, _smoothOffset);
    const qreal cur = sb->value();
    const qreal diff = _smoothTarget - cur;
    _applyingSmooth = true;
    if (qAbs(diff) < 0.5) {
        sb->setValue(qRound(_smoothTarget));
        _applyingSmooth = false;
        stopSmooth();
        return;
    }
    sb->setValue(qRound(cur + diff * 0.30));
    _applyingSmooth = false;
}

void PreviewWidget::stopSmooth()
{
    if (_smoothTimer)
        _smoothTimer->stop();
    _smoothActive = false;
    _smoothLineMode = false;
}

void PreviewWidget::suppressReanchor(int ms)
{
    const qint64 until = QDateTime::currentMSecsSinceEpoch() + ms;
    if (until > _suppressReanchorMs)
        _suppressReanchorMs = until;
}

// code.html jumpToOutline：目标元素顶 -12px，帧驱动平滑。
void PreviewWidget::jumpToBlock(int idx)
{
    if (isHtmlMode())
        return;
    if (!_mappingValid || idx < 0 || idx >= _blocks.size()) {
        scrollToSourceLineF(
            idx >= 0 && idx < _blocks.size() ? qreal(_blocks[idx].start) : 1.0,
            /*smooth=*/true);
        return;
    }
    const Block& b = _blocks[idx];
    _lastTopLineF = qreal(b.start);
    // 块顶 -12px，目标行驱动：面板收起等重排不会改变落点
    startSmoothToLine(qreal(b.start), 0.0, 12.0);
    // 目标处即该标题（3/10 阈值内），直接激活大纲高亮
    emit activeHeadingChanged(activeHeadingAt(qMax<qreal>(0.0, blockRect(b).top() - 12.0)));
}

// ── 编辑跟随（43% 视口参考点，与 code.html syncPreviewToEditor 同公式）──

void PreviewWidget::followSourceLineF(qreal lineF, qreal anchorRatio)
{
    if (isHtmlMode())
        return;
    _lastTopLineF = lineF;
    // 目标行驱动：每帧按当前几何重算像素（与 code.html 每帧
    // pBlockTop + ratio*pBlockHeight 等价），中途重排也不跑偏
    startSmoothToLine(lineF, anchorRatio, 0.0);
}

void PreviewWidget::alignNextRender(qreal lineF, qreal anchorRatio)
{
    if (isHtmlMode())
        return;
    _pendingLineF = lineF;
    _pendingRatio = anchorRatio;
}

void PreviewWidget::followEditorEdge(bool toBottom)
{
    if (isHtmlMode())
        return;
    if (toBottom) {
        // 目标必须是含 25vh 底部留白后的最大滚动值（等价 Web 侧
        // scrollHeight - clientHeight）：最后一行落在 75% 处。
        // 绝不能取"内容底对齐视口底"，否则最后一行贴底/露半行。
        // 留白块插入后布局是惰性的，maximum 可能还没算上它，先强制完成布局。
        if (QTextDocument* doc = _browser->document()) {
            if (auto* lay = doc->documentLayout())
                lay->documentSize();
        }
    }
    QScrollBar* sb = _browser->verticalScrollBar();
    startSmoothTo(toBottom ? qreal(sb->maximum()) : qreal(sb->minimum()));
}

bool PreviewWidget::isLineVisible(qreal lineF) const
{
    if (!_mappingValid || _blocks.isEmpty())
        return false;   // 映射未就绪：保守视为不可见，允许跟随
    QScrollBar* sb = _browser->verticalScrollBar();
    const qreal viewTop = sb->value();
    const qreal viewBottom = viewTop + _browser->viewport()->height();
    // 该行块顶 ~ 下一行顶（即该行底）都落在视口内才算"已在窗口内"
    const qreal yTop = docYForLineF(lineF);
    const qreal yBottom = docYForLineF(lineF + 1.0);
    constexpr qreal margin = 4;
    return yTop >= viewTop + margin && yBottom <= viewBottom - margin;
}

// code.html handleAnchorClick：slug 与转换器 BlockInfo.slug 严格同源。
void PreviewWidget::handleAnchorClick(const QUrl& url)
{
    const QString frag = url.fragment();
    if (!_mappingValid) {
        _browser->scrollToAnchor(frag);   // 兜底
        return;
    }
    auto jumpSlug = [&](const QString& want, bool normalized) {
        // 文档顺序正向首匹配：与浏览器锚点（同名 id 跳第一个）行为一致。
        // 飞牛/Windows 两套同名标题时，点目录跳文档中靠前的那一节。
        for (int i = 0; i < _blocks.size(); ++i) {
            const Block& b = _blocks[i];
            if (b.kind != MarkdownConverter::BlockInfo::Heading || b.slug.isEmpty())
                continue;
            const bool hit = normalized
                ? normalizeAnchorText(b.slug) == want
                : b.slug == want;
            if (hit) {
                jumpToBlock(i);   // 规范 5.4：仅滚动预览，编辑器不动
                return true;
            }
        }
        return false;
    };
    if (jumpSlug(frag, false))
        return;
    const QString nf = normalizeAnchorText(frag);
    if (!nf.isEmpty() && jumpSlug(nf, true))
        return;
    // 无效锚点：静默不报错（P11.4）
}

bool PreviewWidget::tryToggleTaskBox(const QPoint& pos)
{
    QTextCursor c = _browser->cursorForPosition(pos);
    QTextBlock block = c.block();
    if (!block.isValid())
        return false;
    const QString t = block.text();
    const int p = c.position() - block.position();   // 块内偏移
    // 找离点击位置最近的任务框字符
    int best = -1, bestDist = 3;
    for (int i = 0; i < t.size(); ++i) {
        const ushort u = t[i].unicode();
        if (u != 0x2610 && u != 0x2611)
            continue;
        int d = qAbs(i + 1 - p);
        if (d < bestDist) { bestDist = d; best = i; }
    }
    if (best < 0)
        return false;
    const bool on = t[best].unicode() == 0x2611;
    QTextCursor ec(block);
    ec.movePosition(QTextCursor::StartOfBlock);
    ec.movePosition(QTextCursor::Right, QTextCursor::MoveAnchor, best);
    ec.movePosition(QTextCursor::Right, QTextCursor::KeepAnchor, 1);
    // QTextBrowser 默认只读；仅此处临时放开做视觉切换（不写回文件）
    const bool wasReadOnly = _browser->isReadOnly();
    _browser->setReadOnly(false);
    ec.insertText(QString(QChar(on ? 0x2610 : 0x2611)));
    _browser->setReadOnly(wasReadOnly);
    return true;
}

void PreviewWidget::hideCopyButton()
{
    if (_copyBtn)
        _copyBtn->hide();
}

void PreviewWidget::updateCopyButton(const QPoint& pos)
{
    if (!_mappingValid)
        return;
    QTextCursor c = _browser->cursorForPosition(pos);
    QTextBlock block = c.block();
    if (!block.isValid()) {
        hideCopyButton();
        return;
    }
    const Block* hit = nullptr;
    for (const Block& b : _blocks) {
        if (b.kind != MarkdownConverter::BlockInfo::Code || !b.block.isValid())
            continue;
        const int first = b.block.position();
        const int last = (b.lastBlock.isValid() ? b.lastBlock : b.block).position();
        if (block.position() >= first && block.position() <= last) {
            hit = &b;
            break;
        }
    }
    if (!hit) {
        hideCopyButton();
        return;
    }
    if (!_copyBtn) {
        _copyBtn = new QToolButton(_browser->viewport());
        _copyBtn->setText(tr("复制"));
        _copyBtn->setAutoRaise(true);
        _copyBtn->setCursor(Qt::ArrowCursor);
        connect(_copyBtn, &QToolButton::clicked, this, [this]() {
            QApplication::clipboard()->setText(_copyBtn->property("code").toString());
            _copyBtn->setText(tr("已复制"));
            QTimer::singleShot(1200, this, [this]() {
                if (_copyBtn) _copyBtn->setText(tr("复制"));
            });
        });
    }
    QString code;
    for (QTextBlock tb = hit->block; tb.isValid(); tb = tb.next()) {
        if (!code.isEmpty())
            code += QLatin1Char('\n');
        code += tb.text();
        if (tb == hit->lastBlock)
            break;
    }
    code.replace(QChar(0x2028), QLatin1Char('\n'));
    code.replace(QChar(0x2029), QLatin1Char('\n'));
    _copyBtn->setProperty("code", code);

    const QRectF r = blockRect(*hit);
    const int sy = _browser->verticalScrollBar()->value();
    _copyBtn->adjustSize();
    int x = _browser->viewport()->width() - _copyBtn->width() - 12;
    int y = qRound(r.top()) - sy + 6;
    _copyBtn->move(x, y);
    _copyBtn->show();
    _copyBtn->raise();
}

bool PreviewWidget::eventFilter(QObject* watched, QEvent* event)
{
    if (watched == _browser && event->type() == QEvent::Resize) {
        // 跳转/跟随动画进行中，或处于用户交互后的抑制窗口内，都不重锚：
        // 否则旧锚点会重启平滑动画，把用户的滚轮/滚动覆盖回去（"锁定"）
        if (_smoothActive
            || QDateTime::currentMSecsSinceEpoch() < _suppressReanchorMs)
            return false;
        // resize/拖分割条后按源行重锚（事件队列排空后文档已完成重排）
        const qreal lineF = _lastTopLineF;
        QTimer::singleShot(0, this, [this, lineF]() {
            if (!_smoothActive && _mappingValid
                && QDateTime::currentMSecsSinceEpoch() >= _suppressReanchorMs)
                scrollToSourceLineF(lineF);
        });
        return false;
    }

    // 规范 4.6：键盘滚动（方向键/PgUp/PgDn/Home/End）立即停止跟随动画
    if (watched == _browser && event->type() == QEvent::KeyPress) {
        stopSmooth();
        suppressReanchor();
    }

    if (watched == _browser->viewport()) {
        switch (event->type()) {
        // h1/h2 底线叠加在 PreviewBrowser::paintEvent 基类绘制完成后进行
        // （不能在这里拦 Paint 手动派发：会绕过 QAbstractScrollArea 自身的
        // 视口事件过滤器，导致文档内容完全不绘制——只剩底线）
        case QEvent::MouseButtonPress: {
            auto* me = static_cast<QMouseEvent*>(event);
            _pressPos = me->pos();
            _pressMoved = false;
            stopSmooth();   // 用户点按预览 = 接管滚动，停掉跟随动画
            suppressReanchor();
            break;
        }
        case QEvent::MouseMove: {
            auto* me = static_cast<QMouseEvent*>(event);
            if ((me->buttons() & Qt::LeftButton)
                && (me->pos() - _pressPos).manhattanLength() > 4)
                _pressMoved = true;
            if (!(me->buttons() & Qt::LeftButton))
                updateCopyButton(me->pos());
            break;
        }
        case QEvent::MouseButtonRelease: {
            auto* me = static_cast<QMouseEvent*>(event);
            if (me->button() != Qt::LeftButton || _pressMoved)
                break;
            const QPoint pos = me->pos();
            // 链接交给 anchorClicked（文档内锚点平滑跳转，外链外部打开）
            if (!_browser->anchorAt(pos).isEmpty())
                break;
            if (tryToggleTaskBox(pos))
                return true;
            // 规范 1.1：预览→编辑器不同步，点击正文不做任何跳转
            break;
        }
        case QEvent::Leave:
            hideCopyButton();
            break;
        case QEvent::Wheel: {
            auto* we = static_cast<QWheelEvent*>(event);
            stopSmooth();   // 用户滚轮 = 接管滚动，停掉跟随动画
            suppressReanchor();
            if (we->modifiers() & Qt::ControlModifier) {
                // Ctrl+滚轮缩放预览字号（±，持久化，仅预览；P12.5）
                const int step = we->angleDelta().y() / 120;
                if (step != 0) {
                    AppSettings& s = AppSettings::instance();
                    const int v = qBound(10, s.previewFontSize() + (step > 0 ? 1 : -1), 28);
                    if (v != s.previewFontSize()) {
                        s.setPreviewFontSize(v);
                        renderNow();
                        const QString suffix =
                            (v == 15) ? QStringLiteral("  （默认值）") : QString();
                        emit statusMessage(tr("预览字号：%1 px%2").arg(v).arg(suffix));
                    }
                }
                return true;
            }
            break;
        }
        default:
            break;
        }
    }
    return QWidget::eventFilter(watched, event);
}

QString PreviewWidget::toHtmlDocument() const
{
    // HTML 文件：导出原始源码本身，与预览（浏览器渲染）保持一致
    if (_format == TextFormat::Html)
        return _markdown;
    const bool dark = ThemeManager::instance().isDark();
    // 导出走同一渲染管线，保持与预览一致；另附浏览器增强脚本
    QString body = buildRichBody(_markdown, dark, /*embedImages=*/true, nullptr,
                                 nullptr, nullptr,
                                 AppSettings::instance().previewSoftBreaks(), nullptr);
    const MarkdownConverter::Palette pal = paletteFromTheme();
    return MarkdownConverter::wrapHtmlDocument(body, dark, /*fontPx=*/15,
                                               /*withScripts=*/true, &pal);
}

QString PreviewWidget::toHtmlWithResources(QVector<QPair<QString, QPixmap>>* resources) const
{
    if (resources) resources->clear();
    // HTML 文件：导出/打印直接用原始源码
    if (_format == TextFormat::Html)
        return _markdown;
    const bool dark = ThemeManager::instance().isDark();
    QString body = buildRichBody(_markdown, dark, /*embedImages=*/false, resources,
                                 nullptr, nullptr,
                                 AppSettings::instance().previewSoftBreaks(), nullptr);
    const MarkdownConverter::Palette pal = paletteFromTheme();
    return MarkdownConverter::wrapHtmlDocument(body, dark, /*fontPx=*/15,
                                               /*withScripts=*/false, &pal);
}
