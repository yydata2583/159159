#pragma once
#include <QWidget>

class EditorWidget;

// Narrow gutter widget drawn on the left of EditorWidget showing line numbers.
class LineNumberArea : public QWidget {
    Q_OBJECT
public:
    explicit LineNumberArea(EditorWidget* editor);

    QSize sizeHint() const override;

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    EditorWidget* _editor;
};
