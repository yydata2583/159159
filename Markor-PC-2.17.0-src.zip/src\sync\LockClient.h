#pragma once
#include <QObject>
#include <QString>

class QNetworkAccessManager;
class QTimer;

// 文件锁客户端：对接服务器端 lockserver API（协议见服务器 README §五）。
//   open      打开文档时登记（POST /api/v1/open）
//   heartbeat 每 30s 刷新（POST /api/v1/heartbeat）
//   close     保存/关闭标签/退出时注销（POST /api/v1/close）
// 返回的 holders 为**其他设备**占用者，经 fileHeldElsewhere 上抛（UI 弹提示）。
//
// 服务器地址(sync/serverApi) 与 API Key(sync/serverApiKey) 默认为空：
// 为空则整体静默禁用（不发任何请求），等用户在设置中填写——
// 服务器信息一律不写死在代码里。
class LockClient : public QObject {
    Q_OBJECT
public:
    static LockClient& instance();

    void setDeviceId(const QString& id);      // 本机 Syncthing 设备 ID
    void open(const QString& absPath);        // 登记打开并启动心跳
    void close();                             // 注销当前文件

signals:
    void statusMessage(const QString& msg);
    void fileHeldElsewhere(const QString& path, const QString& holders);

private:
    explicit LockClient(QObject* parent = nullptr);
    void post(const QString& api, const QString& jsonBody, bool notifyHolders);
    QString relPath(const QString& absPath) const;
    QString currentBody() const;              // open/heartbeat/close 的公共 JSON body

    QNetworkAccessManager* _nam = nullptr;
    QTimer* _heartbeat = nullptr;
    QString _deviceId;
    QString _currentRelPath;
};
