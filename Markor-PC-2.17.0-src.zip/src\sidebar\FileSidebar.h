#pragma once
#include <QWidget>
#include <QString>

class QTabBar;
class QStackedWidget;
class QListWidget;
class QPropertyAnimation;
class FileBrowserWidget;
class SidebarHandle;

// 主窗口级文件侧边栏：固定最左缘，不随文档标签切换。
// 顶部「最近 | 文件」两个 Tab 共用下方列表区域；右缘把手单击收起/展开、拖拽调宽。
// 状态（收起/宽度/Tab）全部走 AppSettings 持久化。
class FileSidebar : public QWidget {
    Q_OBJECT
    // 仅供收起/展开动画驱动：整个面板（内容 + 把手）的固定宽度
    Q_PROPERTY(int panelWidth READ panelWidth WRITE setPanelWidth)
public:
    explicit FileSidebar(QWidget* parent = nullptr);

    void setRootPath(const QString& path);
    // 当前文档高亮（最近列表选中 + 文件树定位）；空路径清除高亮
    void setCurrentPath(const QString& path);

    int panelWidth() const { return width(); }
    void setPanelWidth(int w);

protected:
    // 外部（资源管理器）拖文件到面板：打开并记入最近列表
    void dragEnterEvent(QDragEnterEvent* event) override;
    void dropEvent(QDropEvent* event) override;

signals:
    // 转发内嵌文件树/最近列表的打开请求
    void fileActivated(const QString& path);
    void openInNewTab(const QString& path);
    void toggleFavorite(const QString& path);
    void statusMessage(const QString& msg);

private:
    void setExpanded(bool expanded, bool animated);
    void rebuildRecents();
    void onRecentItemClicked(int row);

    QWidget* _content;
    QTabBar* _tabBar;
    QStackedWidget* _stack;
    QListWidget* _recentList;
    FileBrowserWidget* _browser;
    SidebarHandle* _handle;
    QPropertyAnimation* _anim = nullptr;

    bool _expanded = true;
    int _contentWidth = 240;      // 展开态内容宽度（不含把手）
    QString _currentPath;

    static constexpr int MIN_CONTENT = 180;
    static constexpr int MAX_CONTENT = 420;
    static constexpr int AUTO_COLLAPSE = 110; // 拖拽释放时内容窄于此值自动收起
};
