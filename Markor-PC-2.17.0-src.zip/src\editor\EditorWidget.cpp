#include "EditorWidget.h"
#include "LineNumberArea.h"
#include "MarkdownHighlighter.h"
#include "SourceCodeHighlighter.h"
#include "TodoTxtHighlighter.h"
#include "FormatActions.h"
#include "app/AppSettings.h"
#include "app/ThemeManager.h"

#include <QPainter>
#include <QTextBlock>
#include <QFile>
#include <QTextStream>
#include <QKeyEvent>
#include <QWheelEvent>
#include <QtMath>
#include <QRegularExpression>
#include <QTimer>
#include <QScrollBar>
#include <QFileInfo>
#include <QTextCursor>

EditorWidget::EditorWidget(QWidget* parent)
    : QPlainTextEdit(parent)
{
    _lineNumberArea = new LineNumberArea(this);

    connect(this, &EditorWidget::blockCountChanged, this, &EditorWidget::updateLineNumberAreaWidth);
    connect(this, &EditorWidget::updateRequest, this, &EditorWidget::updateLineNumberArea);

    // 快照历史：输入停顿约 400ms 后存一条文本+光标快照
    _historyTimer = new QTimer(this);
    _historyTimer->setSingleShot(true);
    _historyTimer->setInterval(400);
    connect(_historyTimer, &QTimer::timeout, this, &EditorWidget::commitSnapshot);

    // 内容一致性判脏：textChanged 也会由语法高亮器挂载等非编辑操作触发
    // （空文档会收到一次伪 contentsChange），不能见 textChanged 就标脏，
    // 否则新文档未编辑也会弹"未保存"提示。以"当前内容与最近载入/保存的
    // 基线是否一致"为准；撤销回原文同样自动清除脏标记。
    connect(this, &QPlainTextEdit::textChanged, this, [this]() {
        // 快路径：长度不同必为已编辑；等长时才做整篇比对（高亮器挂载等
        // 伪 textChanged 与基线等长同内容，走慢路径排除）。characterCount
        // 含文档末尾隐式段落符，恒等于 toPlainText().size()+1。
        const bool edited = document()->characterCount() != _cleanText.size() + 1
                            || toPlainText() != _cleanText;
        setDirty(edited);
        if (edited)
            _historyTimer->start();
    });

    AppSettings& s = AppSettings::instance();
    setLineNumbersVisible(s.lineNumbers());
    updateLineNumberAreaWidth(0);
    highlightCurrentLine();

    QFont f = font();
    f.setFamily(s.editorFontFamily());
    f.setPointSize(s.editorFontSize());
    setFont(f);
    updateLineNumberFont();       // 行号字号 = 内容字号 - 2pt
    updateLineNumberAreaWidth(0); // 行号槽宽度按行号字体度量重算
    setLineWrapMode(s.wordWrap() ? QPlainTextEdit::WidgetWidth : QPlainTextEdit::NoWrap);
}

void EditorWidget::clearLintIssue()
{
    _lintLine = -1;
    _lintReason.clear();
    _lintFix.clear();
    emit lintIssueChanged(-1, QString(), QString());
}

void EditorWidget::onLintIssueChanged(int line, const QString& reason,
                                      const QString& fix)
{
    if (line <= 0 || reason.isEmpty()) {
        clearLintIssue();
        return;
    }
    _lintLine = line;
    _lintReason = reason;
    _lintFix = fix;
    emit lintIssueChanged(line, reason, fix);
}

qreal EditorWidget::cursorSourceLineF() const
{
    const QTextCursor c = textCursor();
    const QTextBlock b = c.block();
    const qreal line = b.blockNumber() + 1;
    const QRectF br = blockBoundingRect(b);
    if (br.height() <= 1)
        return line;
    // 块内像素比例：光标矩形顶相对块顶（均换算到视口坐标）
    const qreal blockTop = blockBoundingGeometry(b).translated(contentOffset()).top();
    const qreal frac = (qreal(cursorRect(c).top()) - blockTop) / br.height();
    return line + qBound(0.0, frac, 1.0);
}

qreal EditorWidget::cursorViewportRatio() const
{
    const int vh = viewport()->height();
    if (vh <= 0)
        return 0.5;
    // 光标矩形中心在视口中的垂直比例；光标在视口外时钳制到 0~1
    const qreal center = qreal(cursorRect().center().y());
    return qBound(0.0, center / qreal(vh), 1.0);
}

void EditorWidget::gotoLine(int line)
{
    if (line <= 0)
        return;
    const QTextBlock b = document()->findBlockByNumber(line - 1);
    if (!b.isValid())
        return;
    setTextCursor(QTextCursor(b));
    centerCursor();
    setFocus();
}

void EditorWidget::setFontPointSize(int pt)
{
    QFont f = font();
    f.setPointSize(pt);
    setFont(f);
    updateLineNumberFont();   // 内容字号变化时同步行号字号
}

void EditorWidget::updateLineNumberFont()
{
    // 行号字号始终比内容字号小 2pt，保证视觉协调且随内容字号动态变化
    QFont f = font();
    f.setPointSize(qMax(6, f.pointSize() - 2));
    _lineNumberArea->setFont(f);
}

void EditorWidget::wheelEvent(QWheelEvent* event)
{
    // Ctrl+滚轮调字号（与预览窗口一致）；普通滚动走基类
    if (event->modifiers() & Qt::ControlModifier) {
        const int step = event->angleDelta().y() > 0 ? 1 : -1;
        AppSettings& s = AppSettings::instance();
        const int v = qBound(8, s.editorFontSize() + step, 40);
        if (v != s.editorFontSize()) {
            s.setEditorFontSize(v);   // 持久化：新标签页与重启沿用
            setFontPointSize(v);
            updateLineNumberAreaWidth(0);   // 行号槽宽度随字体度量刷新
            // 状态栏/浮层显示当前字号，避免盲调；命中默认值时标注
            const QString suffix =
                (v == 12) ? QStringLiteral("  （默认值）") : QString();
            emit statusMessage(tr("字号：%1 pt%2").arg(v).arg(suffix));
        }
        event->accept();
        return;
    }
    QPlainTextEdit::wheelEvent(event);
}

void EditorWidget::setLineNumbersVisible(bool visible)
{
    _lineNumbersVisible = visible;
    _lineNumberArea->setVisible(visible);
    updateLineNumberAreaWidth(0);
}

void EditorWidget::scrollToSourceLine(int line)
{
    scrollToSourceLineF(qreal(line));
}

void EditorWidget::scrollToSourceLineF(qreal lineF)
{
    const int line = int(qFloor(lineF));
    const int n = qBound(0, line - 1, qMax(0, document()->blockCount() - 1));
    QTextBlock block = document()->findBlockByNumber(n);
    if (!block.isValid())
        return;
    // 滚动条取值是文档坐标：直接用块顶文档 y。不能平移 contentOffset()
    // （那是视口坐标，滚动越深值越小，会把滚动条顶回顶部）。
    const qreal frac = qBound(0.0, lineF - qreal(line), 1.0);
    const int y = qRound(blockBoundingGeometry(block).top()
                         + frac * blockBoundingRect(block).height());
    // 不能用 QSignalBlocker 阻塞滚动条信号：QAbstractScrollArea 的视口联动
    // (_q_vslide) 同样走 valueChanged，阻塞会导致"滚动条动而内容不动"。
    // 改用具名标志，MainWindow 的滚动同步槽检查该标志防回环。
    _programmaticScroll = true;
    verticalScrollBar()->setValue(y);
    _programmaticScroll = false;
}

int EditorWidget::firstVisibleSourceLine() const
{
    return int(qFloor(firstVisibleSourceLineF()));
}

qreal EditorWidget::firstVisibleSourceLineF() const
{
    QTextBlock b = firstVisibleBlock();
    if (!b.isValid())
        return 1.0;
    // 首可见块顶部已滚出视口的高度占块高的比例 = 行内偏移
    const qreal h = qMax<qreal>(1.0, blockBoundingRect(b).height());
    const qreal topInView = blockBoundingGeometry(b).translated(contentOffset()).top();
    const qreal frac = topInView < 0.0 ? qBound(0.0, -topInView / h, 1.0) : 0.0;
    return qreal(b.blockNumber()) + 1.0 + frac;
}

qreal EditorWidget::sourceLineFAtViewportY(qreal yInView) const
{
    QTextBlock b = firstVisibleBlock();
    if (!b.isValid())
        return 1.0;
    for (; b.isValid(); b = b.next()) {
        const QRectF r = blockBoundingGeometry(b).translated(contentOffset());
        const qreal h = qMax<qreal>(1.0, blockBoundingRect(b).height());
        if (yInView < r.top() + h || !b.next().isValid()) {
            const qreal frac = qBound(0.0, (yInView - r.top()) / h, 1.0);
            return qreal(b.blockNumber()) + 1.0 + frac;
        }
    }
    return 1.0;
}

int EditorWidget::lineNumberAreaWidth()
{
    if (!_lineNumbersVisible)
        return 0;
    int digits = 1;
    int max = qMax(1, blockCount());
    while (max >= 10) { max /= 10; ++digits; }
    // 用行号自身字体（内容字号 - 2pt）的度量计算宽度
    return 12 + _lineNumberArea->fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits;
}

void EditorWidget::updateLineNumberAreaWidth(int)
{
    setViewportMargins(lineNumberAreaWidth(), 0, 0, 0);
}

void EditorWidget::updateLineNumberArea(const QRect& rect, int dy)
{
    if (dy)
        _lineNumberArea->scroll(0, dy);
    else
        _lineNumberArea->update(0, rect.y(), _lineNumberArea->width(), rect.height());

    if (rect.contains(viewport()->rect()))
        updateLineNumberAreaWidth(0);
}

void EditorWidget::resizeEvent(QResizeEvent* event)
{
    QPlainTextEdit::resizeEvent(event);
    const QRect cr = contentsRect();
    _lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
}

void EditorWidget::highlightCurrentLine()
{
    QList<QTextEdit::ExtraSelection> extraSelections;
    // Filter-highlighted blocks (todo.txt filter results)
    for (int blockNo : _filterBlocks) {
        QTextBlock block = document()->findBlockByNumber(blockNo);
        if (!block.isValid())
            continue;
        QTextEdit::ExtraSelection fs;
        fs.format.setBackground(_filterColor);
        fs.format.setProperty(QTextFormat::FullWidthSelection, true);
        fs.cursor = QTextCursor(block);
        fs.cursor.clearSelection();
        extraSelections.append(fs);
    }
    setExtraSelections(extraSelections);
}

void EditorWidget::setFilterBlocks(const QList<int>& blockNumbers, const QColor& color)
{
    _filterBlocks = blockNumbers;
    _filterColor = color;
    highlightCurrentLine();
}

void EditorWidget::clearFilter()
{
    _filterBlocks.clear();
    highlightCurrentLine();
}

void EditorWidget::lineNumberAreaPaintEvent(QPaintEvent* event)
{
    QPainter painter(_lineNumberArea);
    painter.fillRect(event->rect(), ThemeManager::instance().editorBg().darker(106));

    QTextBlock block = firstVisibleBlock();
    int blockNumber = block.blockNumber();
    int top = qRound(blockBoundingGeometry(block).translated(contentOffset()).top());
    int bottom = top + qRound(blockBoundingRect(block).height());

    const QColor fg = ThemeManager::instance().lineNumberFg();
    const QFontMetrics lnm = painter.fontMetrics();   // 行号字体度量
    const int areaW = _lineNumberArea->width();
    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            const QString number = QString::number(blockNumber + 1);
            painter.setPen(fg);
            // 取内容首行的真实基线，行号基线与之重合：无论该行是否因回退字体/
            // 软换行导致块高变大，行号始终与同行文字对齐，不会跑到两行中间。
            int baseline = -1;
            QTextLayout* layout = block.layout();
            if (layout && layout->lineCount() > 0) {
                const QTextLine line = layout->lineAt(0);
                baseline = qRound(blockBoundingGeometry(block).translated(contentOffset()).top()
                                  + line.y() + line.ascent());
            }
            if (baseline >= 0) {
                const int tw = lnm.horizontalAdvance(number);
                painter.drawText(areaW - 4 - tw, baseline, number);
            } else {
                painter.drawText(0, top, areaW - 4, bottom - top,
                                 Qt::AlignRight | Qt::AlignVCenter, number);
            }
        }
        block = block.next();
        top = bottom;
        bottom = top + qRound(blockBoundingRect(block).height());
        ++blockNumber;
    }
}

namespace {

// HTML 空元素（<br>、<img> 等）：无需闭合标签
bool isVoidHtmlTag(const QString& tag)
{
    static const QStringList voids = QStringLiteral(
        "area base br col embed hr img input link meta param source track wbr").split(QLatin1Char(' '));
    return voids.contains(tag.toLower());
}

bool isHtmlCode(TextFormat f)
{
    return f == TextFormat::Html || f == TextFormat::Code;
}

// 形如 <div> / <div class="x"> 的开标签（非闭合、非自闭合、非空元素）
bool opensHtmlTag(const QString& s)
{
    if (!s.endsWith(QLatin1Char('>'))
        || s.endsWith(QStringLiteral("/>"))
        || s.endsWith(QStringLiteral("-->")))
        return false;
    const int lt = s.lastIndexOf(QLatin1Char('<'));
    if (lt < 0)
        return false;
    const QString inside = s.mid(lt + 1, s.size() - lt - 2);
    if (inside.startsWith(QLatin1Char('/')))
        return false;
    static const QRegularExpression re(QStringLiteral("^([A-Za-z][A-Za-z0-9-]*)"));
    const QRegularExpressionMatch m = re.match(inside);
    return m.hasMatch() && !isVoidHtmlTag(m.captured(1));
}

} // namespace

void EditorWidget::keyPressEvent(QKeyEvent* event)
{
    // Tab inserts spaces (4) instead of moving focus.
    if (event->key() == Qt::Key_Tab && !(event->modifiers() & Qt::ControlModifier)) {
        textCursor().insertText(QStringLiteral("    "));
        return;
    }
    // HTML/Code：括号/引号与标签自动闭合、回车自动缩进（VS Code 风格）
    if (isHtmlCode(_format) && event->modifiers() == Qt::NoModifier) {
        if (event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter) {
            if (handleAutoIndent())
                return;
        } else if (handleAutoPairKey(event)) {
            return;
        }
    }
    // 光标在行内格式对（**x**、*x*、~~x~~、`x`）内部按回车：只把光标移到
    // 闭合标记之外，不换行（事件消费掉）——再按一次回车才是真正换行
    if ((event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter)
        && event->modifiers() == Qt::NoModifier) {
        QTextCursor c = textCursor();
        if (!c.hasSelection()) {
            const QString line = c.block().text();
            const int pos = c.positionInBlock();
            if (pos > 0) {
                static const QString markers[] = {
                    QStringLiteral("**"), QStringLiteral("~~"),
                    QStringLiteral("`"),  QStringLiteral("*") };
                for (const QString& m : markers) {   // 长标记优先
                    const int open = line.lastIndexOf(m, pos - 1);
                    const int close = line.indexOf(m, pos);
                    if (open >= 0 && close >= 0) {
                        c.setPosition(c.block().position() + close + m.size());
                        setTextCursor(c);
                        return;   // 只跳出，不换行
                    }
                }
            }
        }
    }
    // Markdown 语法自动补全（回车触发：列表续行、表格分隔行、围栏闭合等）
    if ((event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter)
        && event->modifiers() == Qt::NoModifier
        && FormatActions::handleSmartReturn(this)) {
        return;
    }
    QPlainTextEdit::keyPressEvent(event);
}

bool EditorWidget::nextCharIs(QChar ch) const
{
    QTextCursor c = textCursor();
    const QTextBlock b = c.block();
    const int off = c.position() - b.position();
    const QString t = b.text();
    return off >= 0 && off < t.size() && t.at(off) == ch;
}

int EditorWidget::lineLeadingSpaces(const QTextBlock& block) const
{
    const QString t = block.text();
    int n = 0;
    while (n < t.size() && (t.at(n) == QLatin1Char(' ') || t.at(n) == QLatin1Char('\t')))
        ++n;
    return n;
}

bool EditorWidget::handleAutoPairKey(QKeyEvent* event)
{
    const QString text = event->text();
    if (text.size() != 1)
        return false;
    const QChar ch = text.at(0);

    // 闭合字符：光标后正是同一字符 → 直接越过，不重复插入
    if ((ch == QLatin1Char(')') || ch == QLatin1Char(']') || ch == QLatin1Char('}')
         || ch == QLatin1Char('"') || ch == QLatin1Char('\''))
        && nextCharIs(ch)) {
        QTextCursor c = textCursor();
        c.movePosition(QTextCursor::NextCharacter);
        setTextCursor(c);
        return true;
    }

    // '>' 自动补 HTML 闭合标签
    if (_format == TextFormat::Html && ch == QLatin1Char('>'))
        return tryAutoCloseHtmlTag();

    QChar close;
    switch (ch.unicode()) {
    case '(': close = QLatin1Char(')'); break;
    case '[': close = QLatin1Char(']'); break;
    case '{': close = QLatin1Char('}'); break;
    case '"': close = QLatin1Char('"'); break;
    case '\'': close = QLatin1Char('\''); break;
    default: return false;
    }

    QTextCursor c = textCursor();
    if (c.hasSelection()) {
        // 有选区：用括号包裹，并保持选区仍选中原内容
        const QString sel = c.selectedText();
        const int selStart = c.selectionStart();
        c.removeSelectedText();
        c.insertText(QString(ch) + sel + QString(close));
        c.setPosition(selStart + 1);
        c.setPosition(selStart + 1 + sel.size(), QTextCursor::KeepAnchor);
        setTextCursor(c);
        return true;
    }
    c.insertText(QString(ch) + QString(close));
    c.movePosition(QTextCursor::PreviousCharacter);
    setTextCursor(c);
    return true;
}

bool EditorWidget::tryAutoCloseHtmlTag()
{
    QTextCursor c = textCursor();
    if (c.hasSelection())
        return false;
    const QTextBlock b = c.block();
    const int off = c.position() - b.position();
    const QString before = b.text().left(off);
    const int lt = before.lastIndexOf(QLatin1Char('<'));
    if (lt < 0)
        return false;
    const QString inside = before.mid(lt + 1);   // '<' 之后到光标处的内容
    if (inside.contains(QLatin1Char('>')) || inside.contains(QLatin1Char('<')))
        return false;                            // 已有 '>' 或嵌套 '<'：不干预
    if (inside.startsWith(QLatin1Char('/')) || inside.endsWith(QLatin1Char('/')))
        return false;                            // 闭合标签 / 自闭合标签
    static const QRegularExpression tagRe(QStringLiteral("^([A-Za-z][A-Za-z0-9-]*)"));
    const QRegularExpressionMatch m = tagRe.match(inside);
    if (!m.hasMatch())
        return false;
    const QString tag = m.captured(1);
    if (isVoidHtmlTag(tag))
        return false;                            // <br> <img> 等无需闭合
    c.insertText(QStringLiteral("></%1>").arg(tag));
    c.movePosition(QTextCursor::PreviousCharacter, QTextCursor::MoveAnchor, tag.size() + 3);
    setTextCursor(c);
    return true;
}

bool EditorWidget::handleAutoIndent()
{
    QTextCursor c = textCursor();
    if (c.hasSelection())
        return false;                            // 有选区交给基类处理
    const QTextBlock b = c.block();
    const int off = c.position() - b.position();
    const QString line = b.text();
    const QString indent = line.left(lineLeadingSpaces(b));
    const QString before = line.left(off).trimmed();
    QString extra;
    if (_format == TextFormat::Html) {
        if (opensHtmlTag(before))
            extra = QStringLiteral("    ");
    } else if (_format == TextFormat::Code && before.endsWith(QLatin1Char('{'))) {
        extra = QStringLiteral("    ");
    }

    // 光标恰好夹在 <tag>|</tag> 之间（标签自动闭合后的常见形态）：
    // 回车拆成三行，闭合标签回到基准缩进
    const QString after = line.mid(off);
    static const QRegularExpression closeRe(
        QStringLiteral("^</[A-Za-z][A-Za-z0-9-]*>[ \\t]*$"));
    if (_format == TextFormat::Html && !extra.isEmpty()
        && closeRe.match(after).hasMatch()) {
        c.insertText(QStringLiteral("\n") + indent + extra + QStringLiteral("\n") + indent);
        c.movePosition(QTextCursor::PreviousCharacter, QTextCursor::MoveAnchor,
                       indent.size() + 1);
        setTextCursor(c);
        return true;
    }

    c.insertText(QStringLiteral("\n") + indent + extra);
    setTextCursor(c);
    return true;
}


void EditorWidget::setDirty(bool d)
{
    if (_dirty != d) {
        _dirty = d;
        emit dirtyChanged(d);
    }
}

void EditorWidget::setHighlightEnabled(bool on)
{
    if (!on) {
        if (_highlighter) {
            _highlighter->setDocument(nullptr);
            delete _highlighter;
            _highlighter = nullptr;
        }
        clearLintIssue();
        return;
    }
    applyFormat(_format);
}

void EditorWidget::applyFormat(TextFormat fmt)
{
    _format = fmt;
    if (_highlighter) {
        _highlighter->setDocument(nullptr);
        delete _highlighter;
        _highlighter = nullptr;
    }
    clearLintIssue();   // 旧高亮器已销毁，其 lintIssueChanged 连接随之断开
    if (!AppSettings::instance().syntaxHighlighting())
        return;
    switch (fmt) {
    case TextFormat::Markdown:
    case TextFormat::AsciiDoc:
    case TextFormat::OrgMode:
    case TextFormat::WikiText:
        _highlighter = new MarkdownHighlighter(document());
        break;
    case TextFormat::TodoTxt:
        _highlighter = new TodoTxtHighlighter(document());
        break;
    case TextFormat::Html:
    case TextFormat::Code: {
        // 按扩展名选择语言关键字集/HTML 模式（无路径时用通用集）
        auto* h = new SourceCodeHighlighter(document());
        h->setExtension(QFileInfo(_filePath).suffix());
        _highlighter = h;
        break;
    }
    default:
        break;
    }
    // 仅 Markdown 格式存在格式错误诊断：连接提示条
    if (auto* mh = qobject_cast<MarkdownHighlighter*>(_highlighter)) {
        connect(mh, &MarkdownHighlighter::lintIssueChanged,
                this, &EditorWidget::onLintIssueChanged);
    }
}

void EditorWidget::refreshFormat()
{
    if (_formatAuto)
        _format = FormatDetector::detect(_filePath);
    applyFormat(_format);
}

bool EditorWidget::loadFile(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;
    QTextStream in(&file);
    in.setEncoding(QStringConverter::Utf8);
    const bool wasBlocked = blockSignals(true);
    setPlainText(in.readAll());
    blockSignals(wasBlocked);
    // 基线取编辑器实际内容（CRLF 已被 QTextDocument 归一化），而非原始文件字节
    _cleanText = toPlainText();
    // Signals (blockCountChanged/updateRequest) were suppressed above; refresh
    // the gutter geometry manually.
    updateLineNumberAreaWidth(0);
    _lineNumberArea->update();
    _filePath = path;
    if (_formatAuto)
        _format = FormatDetector::detect(path);
    applyFormat(_format);
    setDirty(false);
    resetSnapshotHistory();
    return true;
}

bool EditorWidget::saveFile(const QString& path)
{
    QString target = path.isEmpty() ? _filePath : path;
    if (target.isEmpty())
        return false;
    QFile file(target);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return false;
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    out << toPlainText();
    out.flush();
    if (out.status() != QTextStream::Ok || file.error() != QFileDevice::NoError)
        return false;
    file.close();
    _filePath = target;
    _cleanText = toPlainText();
    if (_formatAuto) {
        _format = FormatDetector::detect(target);
        applyFormat(_format);
    }
    setDirty(false);
    emit statusMessage(tr("已保存 %1").arg(target));
    return true;
}

bool EditorWidget::find(const QString& text, bool forward, bool caseSensitive, bool regex,
                        bool* wrapped)
{
    if (wrapped) *wrapped = false;
    if (text.isEmpty()) return false;
    auto flags = QTextDocument::FindFlags();
    if (!forward) flags |= QTextDocument::FindBackward;
    if (caseSensitive) flags |= QTextDocument::FindCaseSensitively;

    auto searchFrom = [&](const QTextCursor& from) -> QTextCursor {
        if (regex) {
            QRegularExpression re(text, caseSensitive ? QRegularExpression::NoPatternOption
                                                      : QRegularExpression::CaseInsensitiveOption);
            return document()->find(re, from, flags);
        }
        return document()->find(text, from, flags);
    };

    QTextCursor hit = searchFrom(textCursor());
    if (hit.isNull()) {
        // 循环查找：到达文档末尾（向后）/开头（向前）后，从另一端重新找
        QTextCursor wrapFrom(document());
        wrapFrom.movePosition(forward ? QTextCursor::Start : QTextCursor::End);
        hit = searchFrom(wrapFrom);
        if (!hit.isNull() && wrapped)
            *wrapped = true;
    }
    if (hit.isNull())
        return false;
    setTextCursor(hit);
    return true;
}

bool EditorWidget::replace(const QString& findText, const QString& with, bool caseSensitive, bool regex)
{
    QTextCursor c = textCursor();
    if (c.hasSelection() && c.selectedText() == findText) {
        c.insertText(with);
        return true;
    }
    return find(findText, true, caseSensitive, regex);
}

int EditorWidget::replaceAll(const QString& findText, const QString& with, bool caseSensitive, bool regex)
{
    int count = 0;
    QTextCursor c = textCursor();
    c.beginEditBlock();
    c.movePosition(QTextCursor::Start);

    QRegularExpression re;
    if (regex) {
        re = QRegularExpression(findText, caseSensitive ? QRegularExpression::NoPatternOption
                                                        : QRegularExpression::CaseInsensitiveOption);
    } else {
        re = QRegularExpression(QRegularExpression::escape(findText),
                                caseSensitive ? QRegularExpression::NoPatternOption
                                              : QRegularExpression::CaseInsensitiveOption);
    }

    QTextCursor match = document()->find(re, c);
    while (!match.isNull()) {
        match.insertText(with);
        ++count;
        match = document()->find(re, match);
    }
    c.endEditBlock();
    return count;
}

// ---------------- 快照式撤回/前进历史 ----------------
// 方案：自管理快照历史（文本+光标），输入停顿约 400ms 存一条，上限 50 条；
// 撤回/前进按钮走该历史。QTextDocument 的 Ctrl+Z/Ctrl+Y 撤销栈保持原样可用。

void EditorWidget::resetSnapshotHistory()
{
    _historyTimer->stop();
    _history.clear();
    _history.append({ toPlainText(), textCursor().position() });
    _historyIndex = 0;
}

void EditorWidget::commitSnapshot()
{
    const QString text = toPlainText();
    const int cursor = textCursor().position();
    if (_history.isEmpty()) {
        _history.append({ text, cursor });
        _historyIndex = 0;
        return;
    }
    if (_history[_historyIndex].text == text) {
        _history[_historyIndex].cursor = cursor;
        return;
    }
    // 截断"前进"分支后追加新快照
    while (_history.size() > _historyIndex + 1)
        _history.removeLast();
    _history.append({ text, cursor });
    _historyIndex = _history.size() - 1;
    while (_history.size() > 50) {   // 历史上限 50 条
        _history.removeFirst();
        --_historyIndex;
    }
}

void EditorWidget::undoSnapshot()
{
    _historyTimer->stop();
    if (_history.isEmpty())
        resetSnapshotHistory();
    if (_history[_historyIndex].text != toPlainText())
        commitSnapshot();          // 未入史的改动先落一条，保证步进可预期
    if (_historyIndex > 0) {
        --_historyIndex;
        const Snapshot& s = _history[_historyIndex];
        QTextCursor c = textCursor();
        c.beginEditBlock();
        c.select(QTextCursor::Document);
        c.insertText(s.text);
        c.endEditBlock();
        QTextCursor c2 = textCursor();
        c2.setPosition(qMin(s.cursor, document()->characterCount() - 1));
        setTextCursor(c2);
    }
}

void EditorWidget::redoSnapshot()
{
    _historyTimer->stop();
    if (_history.isEmpty())
        return;
    if (_history[_historyIndex].text != toPlainText())
        commitSnapshot();          // 新改动会截断前进分支
    if (_historyIndex + 1 < _history.size()) {
        ++_historyIndex;
        const Snapshot& s = _history[_historyIndex];
        QTextCursor c = textCursor();
        c.beginEditBlock();
        c.select(QTextCursor::Document);
        c.insertText(s.text);
        c.endEditBlock();
        QTextCursor c2 = textCursor();
        c2.setPosition(qMin(s.cursor, document()->characterCount() - 1));
        setTextCursor(c2);
    }
}
