#include "TodoTxtActions.h"
#include "EditorWidget.h"
#include "core/TodoTxt.h"

#include <QTextCursor>
#include <QDate>
#include <QRegularExpression>
#include <QInputDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QFileInfo>
#include <QVector>
#include <algorithm>

namespace {

struct LineEdit {
    // Fetch the full text of the block at the cursor.
    static QString get(EditorWidget* ed)
    {
        QTextCursor c = ed->textCursor();
        c.movePosition(QTextCursor::StartOfBlock);
        c.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor);
        return c.selectedText();
    }
    // Replace the block at the cursor (keeps cursor in the block).
    static void set(EditorWidget* ed, const QString& text)
    {
        QTextCursor c = ed->textCursor();
        c.movePosition(QTextCursor::StartOfBlock);
        c.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor);
        c.insertText(text);
    }
};

bool isDoneLine(const QString& line)
{
    return line.trimmed().startsWith(QStringLiteral("x "));
}

// Remove an existing leading priority "(A) " (after optional "x [date] ").
QString stripPriority(const QString& line, bool* hadPriority = nullptr)
{
    static const QRegularExpression pri(QStringLiteral("^(x\\s+(?:\\d{4}-\\d{2}-\\d{2}\\s+)?)?\\(([A-Z])\\)\\s+"));
    QRegularExpressionMatch m = pri.match(line);
    if (m.hasMatch()) {
        if (hadPriority) *hadPriority = true;
        return (m.captured(1).isEmpty() ? QString() : m.captured(1)) + line.mid(m.captured(0).size());
    }
    if (hadPriority) *hadPriority = false;
    return line;
}

QString currentPriority(const QString& line)
{
    static const QRegularExpression pri(QStringLiteral("^\\s*(?:x\\s+(?:\\d{4}-\\d{2}-\\d{2}\\s+)?)?\\(([A-Z])\\)\\s+"));
    QRegularExpressionMatch m = pri.match(line);
    return m.hasMatch() ? m.captured(1) : QString();
}

// Insert a priority marker at the correct position (right after the "x [date] " prefix).
QString withPriority(const QString& line, const QString& pri)
{
    QString rest = stripPriority(line);
    if (pri.isEmpty())
        return rest;
    // split off the leading "x [date] " if present so priority goes after it
    static const QRegularExpression lead(QStringLiteral("^(x\\s+(?:\\d{4}-\\d{2}-\\d{2}\\s+)?)"));
    QRegularExpressionMatch m = lead.match(rest);
    if (m.hasMatch())
        return m.captured(1) + "(" + pri + ") " + rest.mid(m.captured(0).size());
    return "(" + pri + ") " + rest;
}

} // namespace

namespace TodoTxtActions {

void toggleDone(EditorWidget* ed)
{
    QString line = LineEdit::get(ed);
    if (line.trimmed().isEmpty())
        return;

    if (isDoneLine(line)) {
        // Reopen: drop "x " and a following completion date.
        static const QRegularExpression done(QStringLiteral("^x\\s+(?:\\d{4}-\\d{2}-\\d{2}\\s+)?"));
        line.replace(done, QString());
    } else {
        const QString today = QDate::currentDate().toString(QStringLiteral("yyyy-MM-dd"));
        line = QStringLiteral("x ") + today + QLatin1Char(' ') + line.trimmed();
    }
    LineEdit::set(ed, line);
}

void cyclePriority(EditorWidget* ed)
{
    QString line = LineEdit::get(ed);
    if (line.trimmed().isEmpty())
        return;
    const QString cur = currentPriority(line);
    QString next;
    if (cur.isEmpty())      next = QStringLiteral("A");
    else if (cur == "A")    next = QStringLiteral("B");
    else if (cur == "B")    next = QStringLiteral("C");
    else                    next = QString();        // clear
    LineEdit::set(ed, withPriority(line, next));
}

void setPriority(EditorWidget* ed, QChar p)
{
    QString line = LineEdit::get(ed);
    if (line.trimmed().isEmpty())
        return;
    QString pri = p.isNull() ? QString() : QString(p.toUpper());
    LineEdit::set(ed, withPriority(line, pri));
}

void insertToday(EditorWidget* ed)
{
    ed->textCursor().insertText(QDate::currentDate().toString(QStringLiteral("yyyy-MM-dd")));
}

void appendToday(EditorWidget* ed)
{
    QString line = LineEdit::get(ed);
    const QString today = QDate::currentDate().toString(QStringLiteral("yyyy-MM-dd"));
    if (line.contains(today))
        return;
    line = line.trimmed() + QLatin1Char(' ') + today;
    LineEdit::set(ed, line);
}

void setDueDate(EditorWidget* ed)
{
    QString line = LineEdit::get(ed);
    if (line.trimmed().isEmpty())
        return;

    // Pre-fill with an existing due date or a sensible default (today + 7).
    static const QRegularExpression dueRe(QStringLiteral("\\bdue:\\d{4}-\\d{2}-\\d{2}\\b"));
    QRegularExpressionMatch m = dueRe.match(line);
    QString initial = m.hasMatch()
        ? line.mid(m.capturedStart(), m.capturedLength()).mid(4)
        : QDate::currentDate().addDays(7).toString(QStringLiteral("yyyy-MM-dd"));

    bool ok = false;
    QString text = QInputDialog::getText(ed, QObject::tr("设置截止日期"),
                                         QObject::tr("截止日期 (yyyy-MM-dd)："),
                                         QLineEdit::Normal, initial, &ok);
    if (!ok)
        return;
    text = text.trimmed();
    QDate d = QDate::fromString(text, QStringLiteral("yyyy-MM-dd"));
    if (!d.isValid()) {
        QMessageBox::warning(ed, QObject::tr("日期无效"),
                             QObject::tr("请按 yyyy-MM-dd 格式输入有效日期。"));
        return;
    }
    const QString tag = QStringLiteral("due:") + d.toString(QStringLiteral("yyyy-MM-dd"));
    if (m.hasMatch())
        line.replace(m.capturedStart(), m.capturedLength(), tag);
    else
        line = line.trimmed() + QLatin1Char(' ') + tag;
    LineEdit::set(ed, line);
}

void archiveDone(EditorWidget* ed)
{
    const QString path = ed->filePath();
    if (path.isEmpty()) {
        QMessageBox::information(ed, QObject::tr("需要先保存"),
                                 QObject::tr("请先保存当前 todo.txt 文件，以便归档到同目录的 done.txt。"));
        return;
    }

    const QString all = ed->toPlainText();
    const QStringList lines = all.split(QLatin1Char('\n'));
    QStringList keep, done;
    for (const QString& l : lines) {
        if (isDoneLine(l))
            done << l;
        else
            keep << l;
    }
    if (done.isEmpty()) {
        QMessageBox::information(ed, QObject::tr("无需归档"),
                                 QObject::tr("当前没有已完成任务。"));
        return;
    }

    const QString donePath = QFileInfo(path).absolutePath() + QStringLiteral("/done.txt");
    QFile f(donePath);
    if (!f.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(ed, QObject::tr("归档失败"),
                             QObject::tr("无法写入 %1").arg(donePath));
        return;
    }
    QTextStream out(&f);
    out.setEncoding(QStringConverter::Utf8);
    for (const QString& l : done)
        out << l << QLatin1Char('\n');
    f.close();

    ed->setPlainText(keep.join(QLatin1Char('\n')));
    ed->setDirty(true);
    QMessageBox::information(ed, QObject::tr("归档完成"),
                             QObject::tr("已将 %1 条已完成任务归档到\n%2").arg(done.size()).arg(donePath));
}

void sortByPriority(EditorWidget* ed)
{
    const QStringList lines = ed->toPlainText().split(QLatin1Char('\n'));
    QVector<QString> active, completed;
    for (const QString& l : lines) {
        if (l.trimmed().isEmpty())
            continue;
        if (isDoneLine(l))
            completed << l;
        else
            active << l;
    }

    auto priKey = [](const QString& l) {
        QString p = currentPriority(l);
        return p.isEmpty() ? 26 : (p.at(0).unicode() - 'A');
    };
    std::stable_sort(active.begin(), active.end(),
                     [&](const QString& a, const QString& b) { return priKey(a) < priKey(b); });

    QVector<QString> out;
    out.reserve(active.size() + completed.size());
    for (const QString& l : active) out << l;
    for (const QString& l : completed) out << l;
    ed->setPlainText(out.join(QLatin1Char('\n')));
    ed->setDirty(true);
}

} // namespace TodoTxtActions
