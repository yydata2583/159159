#include "SearchDialog.h"
#include "editor/EditorWidget.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QLabel>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QTextStream>
#include <QRegularExpression>
#include <QTimer>
#include <QtConcurrent>
#include <QFutureWatcher>
#include <QVector>

namespace {

struct VaultHit {
    QString path;
    QString rel;
    int line = 0;
    QString text;
};

bool isSearchableFile(const QString& lower)
{
    return lower.endsWith(".md") || lower.endsWith(".markdown") || lower.endsWith(".txt")
           || lower.endsWith(".todo") || lower.endsWith(".adoc") || lower.endsWith(".org")
           || lower.endsWith(".csv") || lower.endsWith(".json") || lower.endsWith(".yaml");
}

} // namespace

SearchDialog::SearchDialog(EditorWidget* editor, const QString& vaultDir, QWidget* parent)
    : QDialog(parent)
    , _editor(editor)
    , _vaultDir(vaultDir)
{
    setWindowTitle(tr("搜索 / 替换"));
    resize(560, 480);

    auto* root = new QVBoxLayout(this);

    auto* form = new QFormLayout();
    _findEdit = new QLineEdit(this);
    _replaceEdit = new QLineEdit(this);
    form->addRow(tr("查找："), _findEdit);
    form->addRow(tr("替换为："), _replaceEdit);
    root->addLayout(form);

    auto* opts = new QHBoxLayout();
    _caseSensitive = new QCheckBox(tr("区分大小写"), this);
    _regex = new QCheckBox(tr("正则表达式"), this);
    opts->addWidget(_caseSensitive);
    opts->addWidget(_regex);
    opts->addStretch();
    root->addLayout(opts);

    auto* btns = new QHBoxLayout();
    _findNextBtn = new QPushButton(tr("查找下一个"), this);
    auto* findPrev = new QPushButton(tr("查找上一个"), this);
    findPrev->setProperty("secondary", true);
    auto* replace = new QPushButton(tr("替换"), this);
    replace->setProperty("secondary", true);
    auto* replaceAll = new QPushButton(tr("全部替换"), this);
    replaceAll->setProperty("secondary", true);
    auto* vaultSearch = new QPushButton(tr("全库搜索"), this);
    _vaultSearchBtn = vaultSearch;
    btns->addWidget(_findNextBtn);
    btns->addWidget(findPrev);
    btns->addWidget(replace);
    btns->addWidget(replaceAll);
    btns->addStretch();
    btns->addWidget(vaultSearch);
    root->addLayout(btns);

    root->addWidget(new QLabel(tr("全库搜索结果（双击打开）："), this));
    _results = new QListWidget(this);
    root->addWidget(_results);

    auto* close = new QPushButton(tr("关闭"), this);
    close->setProperty("secondary", true);
    connect(close, &QPushButton::clicked, this, &QDialog::accept);
    root->addWidget(close, 0, Qt::AlignRight);

    connect(_findNextBtn, &QPushButton::clicked, this, &SearchDialog::findNext);
    connect(findPrev, &QPushButton::clicked, this, &SearchDialog::findPrev);
    connect(replace, &QPushButton::clicked, this, &SearchDialog::doReplace);
    connect(replaceAll, &QPushButton::clicked, this, &SearchDialog::doReplaceAll);
    connect(vaultSearch, &QPushButton::clicked, this, &SearchDialog::searchVault);
    connect(_results, &QListWidget::itemDoubleClicked, this, [this](QListWidgetItem* item) {
        const QString path = item->data(Qt::UserRole).toString();
        const int line = item->data(Qt::UserRole + 1).toInt();
        emit openFileAt(path, line);
    });
    connect(_findEdit, &QLineEdit::returnPressed, this, &SearchDialog::findNext);
}

// 查找结果提示浮条：显示在对话框顶部，不抢焦点、不响应鼠标（透过点击），
// 1.5 秒后自动消失——查找流程不被打断，无需点"确定"。
void SearchDialog::showFindToast(const QString& msg)
{
    if (!_toast) {
        _toast = new QLabel(this);
        _toast->setAlignment(Qt::AlignCenter);
        _toast->setAttribute(Qt::WA_TransparentForMouseEvents);
        _toast->setStyleSheet(QStringLiteral(
            "QLabel{background:rgba(45,45,45,225);color:#fff;"
            "padding:6px 16px;border-radius:7px;}"));
        _toast->hide();
    }
    _toast->setText(msg);
    _toast->adjustSize();
    _toast->move((width() - _toast->width()) / 2, 10);
    _toast->show();
    _toast->raise();
    QTimer::singleShot(1500, _toast, &QLabel::hide);
}

void SearchDialog::findNext()
{
    if (!_editor) return;
    bool wrapped = false;
    const bool found = _editor->find(_findEdit->text(), true,
                                     _caseSensitive->isChecked(), _regex->isChecked(),
                                     &wrapped);
    if (wrapped)
        showFindToast(tr("已到达文档末尾，回到第一个匹配"));
    else if (!found)
        showFindToast(tr("未找到：%1").arg(_findEdit->text()));
}

void SearchDialog::findPrev()
{
    if (!_editor) return;
    bool wrapped = false;
    const bool found = _editor->find(_findEdit->text(), false,
                                     _caseSensitive->isChecked(), _regex->isChecked(),
                                     &wrapped);
    if (wrapped)
        showFindToast(tr("已到达文档开头，回到最后一个匹配"));
    else if (!found)
        showFindToast(tr("未找到：%1").arg(_findEdit->text()));
}

void SearchDialog::doReplace()
{
    if (_editor)
        _editor->replace(_findEdit->text(), _replaceEdit->text(),
                         _caseSensitive->isChecked(), _regex->isChecked());
}

void SearchDialog::doReplaceAll()
{
    if (_editor) {
        int n = _editor->replaceAll(_findEdit->text(), _replaceEdit->text(),
                                    _caseSensitive->isChecked(), _regex->isChecked());
        _results->addItem(tr("已替换 %1 处").arg(n));
    }
}

void SearchDialog::searchVault()
{
    _results->clear();
    const QString needle = _findEdit->text();
    if (needle.isEmpty()) return;

    const QString vaultDir = _vaultDir;
    if (!QDir(vaultDir).exists()) {
        _results->addItem(tr("文档库目录不存在：%1").arg(vaultDir));
        return;
    }

    const bool useRegex = _regex->isChecked();
    const bool caseSensitive = _caseSensitive->isChecked();
    QRegularExpression re;
    if (useRegex) {
        re = QRegularExpression(needle,
            caseSensitive ? QRegularExpression::NoPatternOption
                          : QRegularExpression::CaseInsensitiveOption);
        if (!re.isValid()) {
            _results->addItem(tr("正则表达式无效：%1").arg(re.errorString()));
            return;
        }
    }

    if (_vaultSearchBtn) {
        _vaultSearchBtn->setEnabled(false);
        _vaultSearchBtn->setText(tr("搜索中…"));
    }
    _results->addItem(tr("正在搜索，请稍候…"));

    auto* watcher = new QFutureWatcher<QVector<VaultHit>>(this);
    connect(watcher, &QFutureWatcher<QVector<VaultHit>>::finished, this, [this, watcher]() {
        const QVector<VaultHit> hits = watcher->result();
        _results->clear();
        if (hits.isEmpty()) {
            _results->addItem(tr("无匹配结果"));
        } else {
            for (const VaultHit& h : hits) {
                auto* item = new QListWidgetItem(QStringLiteral("%1:%2  %3")
                    .arg(h.rel).arg(h.line).arg(h.text));
                item->setData(Qt::UserRole, h.path);
                item->setData(Qt::UserRole + 1, h.line);
                _results->addItem(item);
            }
        }
        if (_vaultSearchBtn) {
            _vaultSearchBtn->setEnabled(true);
            _vaultSearchBtn->setText(tr("全库搜索"));
        }
        watcher->deleteLater();
    });

    watcher->setFuture(QtConcurrent::run([vaultDir, needle, useRegex, caseSensitive, re]() {
        QVector<VaultHit> hits;
        QDirIterator it(vaultDir, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            const QString path = it.next();
            if (!isSearchableFile(path.toLower()))
                continue;

            QFile f(path);
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) continue;
            QTextStream in(&f);
            int lineNo = 0;
            while (!in.atEnd()) {
                const QString line = in.readLine();
                ++lineNo;
                bool hit = useRegex
                    ? re.match(line).hasMatch()
                    : line.contains(needle,
                          caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
                if (hit) {
                    hits.push_back({ path,
                                     QDir(vaultDir).relativeFilePath(path),
                                     lineNo,
                                     line.trimmed().left(80) });
                }
            }
        }
        return hits;
    }));
}
