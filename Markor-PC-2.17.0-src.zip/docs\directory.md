# 目录与文件职责（directory.md）

> 用途：**找"改哪里"**。每个文件一句话职责 + 修改时的注意点。
> 总计 55 个 C++ 文件（27 对 .h/.cpp + main.cpp）。

## 顶层

```
Markor V2.17.0/
├─ AGENTS.md            AI 入口（知识库总纲）★
├─ docs/                分层知识库 ★
├─ BUILD.md             开发/编译环境说明（原始文档）
├─ FEATURE_MAP.md       功能移植对照表（Android Markor → 本项目）
├─ THEMES.md            三主题配色说明
├─ CMakeLists.txt       构建脚本（主）：APP_SOURCES 全量清单 + WebView2 链接
├─ markor-win.pro       构建脚本（备，qmake）：与 CMakeLists 双轨并存
├─ build-env.ps1        作者本机 MSVC/Qt 环境变量脚本（路径需本地化！）
├─ build-buildlog.txt   最近一次构建日志（3 行，证明可构建）
├─ build/               构建辅助
│   └─ installer.iss    Inno Setup 安装包脚本
├─ resources/           资源（见下）
├─ third_party/         第三方（见下）
├─ samples/             示例文档（demo.md / diagram.md / notes.org / todo.txt）
├─ screenshots/         功能截图（FEATURE_MAP 配图）
└─ extracted/…          （仓库分发包结构，非源码内容）
```

## resources/ — 资源

| 文件 | 职责 | 注意 |
|---|---|---|
| `resources.qrc` | Qt 资源清单（qss/图标/i18n） | **加主题/图标必须在此登记** |
| `app.rc` | Windows 版本信息 + 应用图标（v2.17.0） | 发版改版本号 |
| `theme/light.qss` | 浅色主题样式表 | 主题三件套：qss + qrc + ThemeManager |
| `theme/dark.qss` | 深色主题样式表 | 同上 |
| `theme/sakura.qss` | 樱花主题样式表 | 同上 |
| `i18n/qtbase_zh_CN.qm` | Qt 内置对话框汉化（Save/Cancel 等） | 编译产物 |
| `icon/markor_512.png` 等 | 应用/功能图标（取自 Android 源码） | |

## third_party/ — 第三方

| 文件 | 职责 |
|---|---|
| `webview2/include/WebView2.h`、`WebView2EnvironmentOptions.h` | Microsoft WebView2 SDK 头文件（约 2.9MB，勿手改） |
| `webview2/lib/x64/WebView2Loader.dll.lib` | 导入库 |
| `webview2/bin/x64/WebView2Loader.dll` | 运行期加载器（构建后自动复制到 exe 旁） |

## src/ — 源码

### src/main.cpp  — 入口
QApplication 初始化、应用名/版本、Qt 汉化、**建窗前应用主题**、CLI 解析（`[file]`、`--screenshot`、`--export-html`、`--export-pdf`）、导出模式延时退出。改 CLI 行为只动这里。

### src/app/ — 应用组装
| 文件 | 职责 | 注意 |
|---|---|---|
| `MainWindow.{h,cpp}`（39KB） | 主窗口：菜单/工具栏/状态栏/标签页/全部信号接线、导出 HTML/PDF/剪贴板、未保存提示、状态持久化 | **接线中枢**；`createPage()` 是页面工厂；菜单/快捷键表见 conventions.md |
| `AppSettings.{h,cpp}` | 全部持久化设置的单例门面（QSettings INI） | 新设置项必须加在此 + SettingsDialog + data-model §5 |
| `ThemeManager.{h,cpp}` | 主题应用（qss+调色板+Win 标题栏）与全部主题色出口 | 语法高亮/渲染器取色唯一来源 |

### src/core/ — 领域模型（无 UI 依赖）
| 文件 | 职责 | 注意 |
|---|---|---|
| `Document.{h,cpp}` | 单文件文档薄封装：路径、格式、load/save（UTF-8） | 目前轻量；预览/编辑器尚未完全经由它 |
| `FormatDetector.{h,cpp}` | 扩展名 → `TextFormat`；格式显示名；文件对话框过滤器 | 加格式/扩展名改这里 |
| `MarkdownConverter.{h,cpp}`（72KB） | **自研 Markdown→HTML**（CommonMark 0.31.2 + GFM）；块级 `data-src-line`；`BlockInfo` 输出 | 体量最大；头部注释 = 合规范围 + COMMONMARK-TODO；改渲染行为只动这里 |
| `TodoTxt.{h,cpp}` | todo.txt 任务模型（`TodoTxtTask` 解析/序列化）+ 过滤表达式（`TodoTxtFilter::matches`） | 语法细节见 data-model §2/§3 |

### src/editor/ — 编辑器
| 文件 | 职责 | 注意 |
|---|---|---|
| `EditorWidget.{h,cpp}`（21KB） | 编辑器主体：载入/保存、脏标记、行号、高亮器切换、查找/替换、快照历史、自动配对/HTML 标签闭合/自动缩进、过滤高亮块、滚动定位 | `QPlainTextEdit` 子类；`_programmaticScroll` 防回环 |
| `LineNumberArea.{h,cpp}` | 行号槽（绘制在编辑器左侧） | 纯绘制 |
| `MarkdownHighlighter.{h,cpp}` | Markdown 语法高亮 + **6 类 lint 波浪线** | 块状态机；`refreshFormats()` 主题联动 |
| `TodoTxtHighlighter.{h,cpp}` | todo.txt 高亮（优先级/项目/上下文/标签/日期/完成） | |
| `SourceCodeHighlighter.{h,cpp}` | 通用源码高亮（关键字/字符串/数字/注释 + HTML 模式标签/属性/实体） | `setExtension()` 选注释风格族 |
| `FormatActions.{h,cpp}`（19KB） | 14 个格式动作 + 智能回车 `handleSmartReturn` + 全文整理 `tidyMarkdown` | `markupFor()` 各格式记号表；仅 Markdown 系做补全/整理 |
| `TodoTxtActions.{h,cpp}` | 任务操作：完成切换/优先级/日期/due:/归档 done.txt/排序 | 行级操作基于光标所在块；归档追加到同目录 `done.txt` |

### src/preview/ — 预览
| 文件 | 职责 | 注意 |
|---|---|---|
| `PreviewWidget.{h,cpp}`（30KB） | 预览主控：`buildRichBody` 渲染管线、防抖重渲染、源行映射与双向滚动、锚点点击、任务框视觉勾选、代码块悬停复制按钮、HTML/PDF 导出体生成 | 与 MarkdownConverter 并列的两大件之一 |
| `HtmlPreviewView.{h,cpp}` | WebView2 宿主（HTML 文件浏览器级预览）；缺运行时降级源码展示 | pImpl（`Impl* d`）；Win32 消息钩子/窗口嵌入 |

### src/sidebar/ — 双侧边栏（批次2）
| 文件 | 职责 | 注意 |
|---|---|---|
| `FileSidebar.{h,cpp}` | 主窗口级文件侧边栏：「最近\|文件」双 Tab + 把手收展/调宽；状态持久化 | 宽度 180–420，<110 自动收起 |
| `OutlinePanel.{h,cpp}` | 每页大纲：解析 H1–H4（跳围栏）、点击跳源行、ScrollSpy 高亮、400ms 防抖刷新 | 宽度 180–220 |
| `SidebarHandle.{h,cpp}` | 通用把手：单击收展、拖拽调宽（8px） | 两面板共用 |

### src/browser/
| 文件 | 职责 |
|---|---|
| `FileBrowserWidget.{h,cpp}` | 文档库目录树（QFileSystemModel 懒加载）：打开/新标签/右键新建·重命名·删除·收藏；`selectPath` 定位当前文档 |

### src/search/
| 文件 | 职责 |
|---|---|
| `SearchDialog.{h,cpp}` | 非模态查找/替换（正则/大小写/全部替换）+ **全库文本搜索**（结果双击 → `openFileAt(path,line)`） |

### src/sync/
| 文件 | 职责 |
|---|---|
| `SyncManager.{h,cpp}` | 内嵌 Syncthing：拉起子进程、REST 配置（星型：只连服务器）、连接探测 | 细节见 architecture §7 |
| `LockClient.{h,cpp}` | 文件锁客户端（open/heartbeat/close + 占用提示），对接服务器 lockserver | 服务器信息默认空→静默禁用 |

### src/render/ — 原生渲染
| 文件 | 职责 |
|---|---|
| `MathRenderer.{h,cpp}` | KaTeX 子集公式 → QPixmap（QPainter） |
| `MermaidRenderer.{h,cpp}`（20KB） | Mermaid 流程图/时序图 → QPixmap；`canRender()` 不支持图种返回 false |

### src/ui/ — 对话框
| 文件 | 职责 |
|---|---|
| `SettingsDialog.{h,cpp}` | 设置：主题/字体/字号/换行/行号/高亮/跟随系统/预览跟随/软换行/大纲默认/vault 路径/同步四项 |
| `MoreDialog.{h,cpp}` | "更多"：设置、更新日志（**开源协议/社交/团队/帮助/评价按需求排除**） |
| `TodoTxtFilterDialog.{h,cpp}` | 任务过滤器：表达式 + 快捷过滤（@context/+project）+ 匹配高亮 + 统计 |

## 改动定位速查

| 想改什么 | 动哪里 |
|---|---|
| Markdown 渲染效果 | `core/MarkdownConverter.cpp`（正文）+ `preview/PreviewWidget.cpp::buildRichBody`（分段/图表公式嵌入） |
| 语法高亮颜色/规则 | `editor/*Highlighter.cpp`（规则）+ `app/ThemeManager.cpp`（颜色） |
| 主题 | `resources/theme/*.qss` + `resources.qrc` + `ThemeManager.cpp`（THEMES.md 有流程） |
| 新设置项 | `AppSettings.{h,cpp}` + `SettingsDialog.{h,cpp}` + `docs/data-model.md` |
| 快捷键/菜单 | `MainWindow::buildMenus()/buildToolBar()` + `docs/conventions.md` |
| todo.txt 行为 | `core/TodoTxt.cpp`（解析/过滤）+ `editor/TodoTxtActions.cpp`（操作） |
| 预览↔编辑同步 | `MainWindow::createPage` 接线 + `EditorWidget`/`PreviewWidget` 滚动函数 |
| 公式/图表支持范围 | `render/MathRenderer.cpp` / `render/MermaidRenderer.cpp` |
| HTML 预览行为 | `preview/HtmlPreviewView.cpp` |
| 同步行为 | `sync/SyncManager.cpp` + `AppSettings::sync*` |
| 构建/安装包 | `CMakeLists.txt`、`markor-win.pro`（**两处**）、`build/installer.iss` |
