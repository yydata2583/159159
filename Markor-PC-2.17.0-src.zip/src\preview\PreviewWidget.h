#pragma once
#include <QWidget>
#include <QTextBrowser>
#include <QTextBlock>
#include <QPair>
#include <QVector>
#include <QPixmap>
#include <QtMath>
#include "core/FormatDetector.h"
#include "core/MarkdownConverter.h"

class QTimer;
class QToolButton;
class QTextFrame;
class QStackedWidget;
class HtmlPreviewView;

// Renders the edited document as formatted HTML (live preview) using the
// bundled MarkdownConverter and the current theme palette.
class PreviewWidget : public QWidget {
    Q_OBJECT
public:
    explicit PreviewWidget(QWidget* parent = nullptr);

    void setMarkdown(const QString& markdown);
    void setFormat(TextFormat fmt);
    void setSourcePath(const QString& path);   // HTML 文件路径（浏览器级预览用）
    void refreshTheme();
    void refreshSettings();          // 软换行/字号等设置变更后立即重渲染
    void reloadHtmlPreview();        // 保存/刷新后重载 HTML 预览

    // Standalone HTML document with rendered charts/math inlined as data URIs.
    QString toHtmlDocument() const;
    // HTML document whose charts/math reference named image resources; the
    // caller must register the returned QPixmaps via QTextDocument::addResource.
    QString toHtmlWithResources(QVector<QPair<QString, QPixmap>>* resources) const;
    QTextBrowser* browser() const { return _browser; }

    // 按源行（1 起）滚动：smooth=true 走大纲/锚点跳转语义（该行最后一个
    // 元素顶 -12px 边距，帧驱动平滑）；smooth=false 即时定位。
    void scrollToSourceLine(int line, bool smooth = false);
    // 小数源行版：行号 + 行内比例，块内插值到像素 Y（smooth 时帧驱动平滑）
    void scrollToSourceLineF(qreal lineF, bool smooth = false);
    // 编辑跟随：把源行 lineF 对应内容点锚定在预览视口 anchorRatio（0=顶对齐，
    // 0.431≈参考实现的 43% 参考点）处，帧驱动平滑追随
    void followSourceLineF(qreal lineF, qreal anchorRatio = 0.0);
    // 编辑跟随边界：编辑器到顶/到底时预览同步到顶/到底
    void followEditorEdge(bool toBottom);
    // 输入跟随（仅边界用）：编辑器光标进入文档最后 3 行时，下一次渲染把
    // 该源行对到预览视口 anchorRatio 处（0.5=中部）；渲染一次后自动失效。
    // 普通输入不调用——渲染只保持像素位置，不同步行位置。
    void alignNextRender(qreal lineF, qreal anchorRatio = 0.5);
    // 指定源行（小数）当前是否完整落在预览视口内（编辑跟随"在内不动"判定）
    bool isLineVisible(qreal lineF) const;

signals:
    // 大纲自动高亮：预览滚动时发出"当前激活标题"的源行（规范 5.3：
    // 最后一个 previewTop <= scrollTop + 80px 的标题；-1 表示无）。
    // 同步是严格单向的——预览没有任何回推编辑器的通道。
    void activeHeadingChanged(int sourceLine);
    // 每次渲染后发出转换器权威标题序列（大纲唯一数据源，与 code.html 的
    // headings = blocks.filter(heading) 同源）
    void headingsAvailable(const QVector<MarkdownConverter::BlockInfo>& headings);
    // 预览内 Ctrl+滚轮调字号时通知状态栏显示当前值
    void statusMessage(const QString& msg);

protected:
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    // 与 code.html blocks 同构：一条 = 一个源码块 + 对应预览元素的几何。
    // 块序列直接取自 MarkdownConverter 的 BlockInfo（渲染器权威输出，等价
    // 浏览器里 preview.children），与 QTextDocument 顶层结构按下标严格 1:1，
    // 配对只使用确定的结构规则（frame=表格/引用、连续列表块归并、ruler 属
    // 性=hr、其余 1 块对 1 元素），不做任何文本猜测。
    // 子锚点（markora-block-align-fix.md 第三节）：大块（表格/列表/代码/
    // 引用）内部按 行/项/段 再细分，源码行区间与渲染几何一一对应，
    // 块内定位不再用"源码行比例×像素高"推算（大块误差 30~50px），
    // 改为直接测量的子元素几何（误差 <2px）。
    struct SubAnchor {
        int   start = 0;      // 源码起始行（1 起，闭区间）
        int   end = 0;        // 源码结束行
        qreal top = 0;        // 渲染后文档 Y（直接测量）
        qreal height = 0;     // 渲染后高度（0=表格分隔行等无视觉元素）
        bool  measured = false;
    };
    struct Block {
        int start = 0;        // 起始源码行（1 起，闭区间）
        int end = 0;          // 结束源码行（1 起，闭区间）
        MarkdownConverter::BlockInfo::Kind kind =
            MarkdownConverter::BlockInfo::Paragraph;
        int level = 0;        // 标题层级
        QString text;
        QString slug;
        QTextBlock block;       // 普通块 / hr 块 / 列表组首块
        QTextBlock lastBlock;   // 列表组末块（其余类型 == block）
        QTextFrame* frame = nullptr; // 表格 / 引用子 frame
        QVector<SubAnchor> subs;   // 子锚点（小块为空，走整块映射）
        bool hasGeom() const { return frame || block.isValid(); }
    };

    void scheduleRender();
    void renderNow();
    void postProcessDocument(const QVector<MarkdownConverter::BlockInfo>& infos);
    void paintHeadingBorders();   // 视口绘制后叠加 h1/h2 底部边框（Qt 不渲染 CSS border-bottom，ADR-028）
    bool isHtmlMode() const;                  // 当前为 HTML 文件且由 WebView2 呈现
    qreal topSourceLineF() const;             // 视口顶部对应源行（小数，resize 锚点用）
    QRectF blockRect(const Block& b) const;   // 块在文档坐标中的矩形
    // code.html findBlock：覆盖 lineF 的块下标；越界时取更早的最后一块
    int blockIndexForLineF(qreal lineF) const;
    qreal docYForLineF(qreal lineF) const;    // 源行(小数) -> 文档 Y（块内比例）
    qreal lineFForDocY(qreal y) const;        // 文档 Y -> 源行(小数)（逆映射）
    // 子锚点：拆分行区间（postProcess 配对后）、首次使用时直接测量几何
    void buildSubAnchors(Block& b, const QStringList& srcLines) const;
    void ensureSubsMeasured(const Block& b) const;
    const SubAnchor* subAnchorFor(const Block& b, qreal lineF) const;
    // 底部留白：每次渲染固定补 60vh 尾部空白块（clamp 修复，始终存在）
    void appendBottomSpacer();
    // 规范 5.3：scrollTop + 80px 阈值内的最后一个标题源行（-1 表示无）
    int activeHeadingAt(qreal scrollValue) const;
    void handleAnchorClick(const QUrl& url);
    bool tryToggleTaskBox(const QPoint& pos); // 任务框视觉勾选（不写回文件）
    void updateCopyButton(const QPoint& pos); // 代码块悬停显示"复制"
    void hideCopyButton();

    // 帧驱动平滑滚动（16ms 定时器，每帧向目标靠近 30%，与参考实现一致）
    void startSmoothTo(qreal y);
    // 目标行驱动：每帧按"当前"几何重算目标像素，重排（如侧栏收起导致
    // 预览宽度变化）也不会把落点带偏，杜绝多滚动机制互相打架
    void startSmoothToLine(qreal lineF, qreal anchorRatio, qreal offsetPx);
    qreal targetYForLineF(qreal lineF, qreal anchorRatio, qreal offsetPx) const;
    void smoothTick();
    void stopSmooth();
    // 用户交互/跳转动画后短暂抑制 resize 重锚，避免重锚动画与用户滚动
    // 互相覆盖（表现为滚轮被"锁定"）
    void suppressReanchor(int ms = 500);
    // 跳转语义（code.html jumpToOutline）：块顶 -12px，帧驱动平滑
    void jumpToBlock(int idx);

    int totalSourceLines() const { return _markdown.count(QLatin1Char('\n')) + 1; }

    QTextBrowser* _browser;
    QStackedWidget* _stack;
    HtmlPreviewView* _htmlView;
    QTimer* _renderTimer;
    QTimer* _smoothTimer = nullptr;   // 帧驱动平滑滚动（~16ms）
    qreal  _smoothTarget = 0;
    bool   _smoothActive = false;
    bool   _smoothLineMode = false;   // 目标行驱动（vs 纯像素）
    qreal  _smoothLineF = 0;          // 目标源行（小数）
    qreal  _smoothRatio = 0;          // 视口锚点比例（跳转 0，跟随 0.43）
    qreal  _smoothOffset = 0;         // 额外像素偏移（跳转 -12）
    qint64 _suppressReanchorMs = 0;   // 抑制 resize 重锚的截止时刻（epoch ms）
    // 下一次渲染的一次性"输入到底"对齐目标（-1=无），由 alignNextRender 设置
    qreal  _pendingLineF = -1.0;
    qreal  _pendingRatio = 0.5;
    bool   _applyingSmooth = false;   // 正在由本类写 scrollbar（区分用户滚动）
    bool   _followEngaged = false;    // 输入跟随迟滞：上次是否处于"跟随对齐"状态
    QToolButton* _copyBtn = nullptr;
    QString _markdown;
    QString _sourcePath;          // 当前文档磁盘路径（HTML 预览导航用）
    TextFormat _format = TextFormat::Markdown;
    bool _renderedOnce = false;   // 首次渲染后才恢复滚动位置
    bool _mappingValid = false;   // _blocks 与文档结构严格 1:1 配对完成
    qreal _lastTopLineF = 1.0;    // 最近一次视口顶部源行（resize 前锚点）
    QPoint _pressPos;
    bool _pressMoved = false;
    QVector<Block> _blocks;       // 与转换器 BlockInfo 同序的配对块序列
};
