#include <QtGlobal>
#ifdef Q_OS_WIN
// 先于 Qt 头文件包含 Windows/WebView2 头，避免宏冲突
#  define WIN32_LEAN_AND_MEAN
#  define NOMINMAX
#  include <windows.h>
#  include <wrl.h>
#  include <WebView2.h>
#endif

#include "HtmlPreviewView.h"

#include <QVBoxLayout>
#include <QTextBrowser>
#include <QPointer>
#include <QUrl>
#include <QDir>
#include <QStandardPaths>
#include <QResizeEvent>
#include <QShowEvent>
#include <QHideEvent>
#include <string>

#ifdef Q_OS_WIN
using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;
#endif

struct HtmlPreviewView::Impl {
    QTextBrowser* fb = nullptr;          // 降级/初始化提示用的只读展示
    QString pendingFile;                 // 待导航的本地文件
    QString htmlSource;                  // 内存中的 HTML 文本
    bool initStarted = false;
    bool resolved = false;
    bool available = false;
    bool ready = false;
#ifdef Q_OS_WIN
    ComPtr<ICoreWebView2Environment> env;
    ComPtr<ICoreWebView2Controller> controller;
    ComPtr<ICoreWebView2> webview;
#endif
};

HtmlPreviewView::HtmlPreviewView(QWidget* parent)
    : QWidget(parent), d(new Impl)
{
    auto* lay = new QVBoxLayout(this);
    lay->setContentsMargins(0, 0, 0, 0);

    d->fb = new QTextBrowser(this);
    d->fb->setObjectName(QStringLiteral("HtmlPreviewFallback"));
    d->fb->setOpenExternalLinks(true);
    d->fb->setPlainText(QStringLiteral("正在初始化浏览器预览…"));
    lay->addWidget(d->fb);

    // WebView2 需要真实 HWND 作为父窗口
    setAttribute(Qt::WA_NativeWindow);
}

HtmlPreviewView::~HtmlPreviewView()
{
#ifdef Q_OS_WIN
    // 释放 WebView2：先隐藏并关闭控制器，再释放 Impl 中的引用
    if (d->controller) {
        d->controller->put_IsVisible(FALSE);
        d->controller->Close();
    }
#endif
    delete d;
}

bool HtmlPreviewView::isAvailable() const { return d->available && d->ready; }
bool HtmlPreviewView::isResolved() const { return d->resolved; }
QString HtmlPreviewView::currentTarget() const { return d->pendingFile; }

void HtmlPreviewView::showEvent(QShowEvent* event)
{
    QWidget::showEvent(event);
    if (!d->initStarted)
        ensureEnvironment();
    else
        updateBounds();
}

void HtmlPreviewView::hideEvent(QHideEvent* event)
{
    QWidget::hideEvent(event);
#ifdef Q_OS_WIN
    // WebView2 是原生子窗口，不受 Qt 堆叠顺序约束：切换到其他标签页 / 隐藏本页时
    // 必须显式隐藏，否则会盖在其他标签页内容之上。
    if (d->ready && d->controller)
        d->controller->put_IsVisible(FALSE);
#endif
}

void HtmlPreviewView::resizeEvent(QResizeEvent* event)
{
    QWidget::resizeEvent(event);
    updateBounds();
}

void HtmlPreviewView::updateBounds()
{
#ifdef Q_OS_WIN
    if (!d->ready || !d->controller)
        return;
    RECT r{};
    if (!GetClientRect(reinterpret_cast<HWND>(winId()), &r))
        return;
    d->controller->put_Bounds(r);
    d->controller->put_IsVisible(isVisible() ? TRUE : FALSE);
#endif
}

void HtmlPreviewView::ensureEnvironment()
{
#ifdef Q_OS_WIN
    if (d->initStarted)
        return;
    d->initStarted = true;

    // Qt 已在 GUI 线程初始化 COM（STA）；此处重复调用会返回 S_FALSE，属正常
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (dataDir.isEmpty())
        dataDir = QDir::homePath() + QStringLiteral("/.markor-webview2");
    dataDir += QStringLiteral("/WebView2");
    QDir().mkpath(dataDir);
    const std::wstring udf = dataDir.toStdWString();

    QPointer<HtmlPreviewView> self(this);
    HRESULT hr = CreateCoreWebView2EnvironmentWithOptions(
        nullptr, udf.c_str(), nullptr,
        Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>(
            [self](HRESULT result, ICoreWebView2Environment* env) -> HRESULT {
                if (!self)
                    return S_OK;
                if (FAILED(result) || !env) {
                    self->d->available = false;
                    self->d->resolved = true;
                    self->showFallbackNotice();
                    emit self->resolved();
                    return S_OK;
                }
                self->d->env = env;
                HWND hwnd = reinterpret_cast<HWND>(self->winId());
                env->CreateCoreWebView2Controller(
                    hwnd,
                    Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
                        [self](HRESULT r2, ICoreWebView2Controller* ctrl) -> HRESULT {
                            if (!self)
                                return S_OK;
                            if (FAILED(r2) || !ctrl) {
                                self->d->available = false;
                                self->d->resolved = true;
                                self->showFallbackNotice();
                                emit self->resolved();
                                return S_OK;
                            }
                            self->d->controller = ctrl;
                            ctrl->get_CoreWebView2(&self->d->webview);
                            ctrl->put_IsVisible(TRUE);
                            self->d->ready = true;
                            self->d->available = true;
                            self->d->resolved = true;
                            self->d->fb->hide();   // 真实页面接管显示
                            self->updateBounds();
                            self->applyPendingNavigation();
                            emit self->resolved();
                            return S_OK;
                        })
                        .Get());
                return S_OK;
            })
        .Get());

    if (FAILED(hr)) {
        d->available = false;
        d->resolved = true;
        showFallbackNotice();
        emit resolved();
    }
#else
    d->resolved = true;
    d->available = false;
    showFallbackNotice();
    emit resolved();
#endif
}

void HtmlPreviewView::applyPendingNavigation()
{
#ifdef Q_OS_WIN
    if (!d->ready || !d->webview)
        return;
    if (!d->pendingFile.isEmpty()) {
        const QUrl url = QUrl::fromLocalFile(d->pendingFile);
        const std::wstring u = url.toString(QUrl::FullyEncoded).toStdWString();
        d->webview->Navigate(u.c_str());
    } else if (!d->htmlSource.isEmpty()) {
        const std::wstring s = d->htmlSource.toStdWString();
        d->webview->NavigateToString(s.c_str());
    }
#endif
}

void HtmlPreviewView::openFile(const QString& filePath)
{
    d->pendingFile = filePath;
    if (!d->initStarted)
        ensureEnvironment();
    if (d->ready)
        applyPendingNavigation();
}

void HtmlPreviewView::setHtmlSource(const QString& html)
{
    d->htmlSource = html;
    if (!d->initStarted)
        ensureEnvironment();
    // 已有本地文件时以文件为准；否则渲染内存文本
    if (d->ready && d->pendingFile.isEmpty())
        applyPendingNavigation();
}

void HtmlPreviewView::reload()
{
    if (!d->initStarted) {
        ensureEnvironment();
        return;
    }
    if (d->ready)
        applyPendingNavigation();
}

void HtmlPreviewView::showFallbackNotice()
{
    QString extra;
    if (!d->htmlSource.isEmpty() && d->pendingFile.isEmpty()) {
        extra = QStringLiteral("<hr><pre style=\"white-space:pre-wrap;\">")
                + d->htmlSource.toHtmlEscaped() + QStringLiteral("</pre>");
    }
    d->fb->setHtml(
        QStringLiteral("<p style=\"color:#c0392b;font-weight:600;\">")
        + QStringLiteral("浏览器预览不可用：未检测到 WebView2 运行时，已降级为源码展示。")
        + QStringLiteral("请安装 Microsoft Edge WebView2 Runtime 后重新打开此文件。</p>")
        + extra);
    d->fb->show();
}
