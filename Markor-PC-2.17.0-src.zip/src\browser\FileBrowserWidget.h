#pragma once
#include <QWidget>
#include <QTreeView>
#include <QFileSystemModel>

// 文档库目录树（QFileSystemModel，懒加载）：嵌入文件侧边栏「文件」Tab，
// 单击打开文件，右键菜单提供新建/重命名/删除/收藏。
class FileBrowserWidget : public QWidget {
    Q_OBJECT
public:
    explicit FileBrowserWidget(QWidget* parent = nullptr);

    void setRootPath(const QString& path);
    QString rootPath() const;

    void refresh();
    // 选中并滚动到指定文件（当前文档高亮）；自动展开父目录链
    void selectPath(const QString& path);

public slots:
    void newDocument();
    void newFolder();

signals:
    void fileActivated(const QString& path);
    void openInNewTab(const QString& path);
    void toggleFavorite(const QString& path);
    void statusMessage(const QString& msg);

protected:
    void contextMenuEvent(QContextMenuEvent* event) override;

private:
    void onClicked(const QModelIndex& index);
    void renameSelected();
    void deleteSelected();
    void favoriteSelected();

    QTreeView* _tree;
    QFileSystemModel* _model;
    QString _rootPath;
};
