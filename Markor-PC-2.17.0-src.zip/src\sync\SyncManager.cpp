#include "SyncManager.h"
#include "app/AppSettings.h"

#include <QProcess>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QTimer>
#include <QCoreApplication>
#include <QStandardPaths>
#include <QDir>
#include <QFileInfo>
#include <QUuid>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>

namespace {
// 本机 Syncthing 管理界面（仅回环）。注意 --gui-address 只接受 host:port，
// 带 scheme/尾斜杠会导致监听配置解析失败——18384 打不开的根因之一；
// 根因之二是 GUI 默认 HTTPS 自签证书，浏览器 http:// 访问必失败，
// 因此 applyConfig 里显式把 gui.tls 置 false。
constexpr const char* kGuiUrl = "http://127.0.0.1:8385/";
constexpr const char* kGuiAddress = "127.0.0.1:8385";
constexpr const char* kFolderId = "markor-vault";   // 三端约定的共享文件夹 ID
constexpr const char* kServerDeviceName = "markor-server";
} // namespace

SyncManager& SyncManager::instance()
{
    static SyncManager s;
    return s;
}

SyncManager::SyncManager(QObject* parent)
    : QObject(parent)
{
    _nam = new QNetworkAccessManager(this);
    connect(_nam, &QNetworkAccessManager::sslErrors, this,
            [](QNetworkReply* reply, const QList<QSslError>&) { reply->ignoreSslErrors(); });
    _pollTimer = new QTimer(this);
    _pollTimer->setInterval(1500);
    connect(_pollTimer, &QTimer::timeout, this, &SyncManager::pollStatus);
    _connTimer = new QTimer(this);
    _connTimer->setInterval(3000);
    connect(_connTimer, &QTimer::timeout, this, &SyncManager::pollServerConnection);
}

SyncManager::~SyncManager()
{
    stop();
}

QNetworkRequest SyncManager::makeRequest(const QString& path) const
{
    QNetworkRequest req(QString::fromLatin1(kGuiUrl) + path);
    req.setRawHeader("X-API-Key", _apiKey.toUtf8());
    req.setTransferTimeout(5000);
    return req;
}

void SyncManager::startIfEnabled()
{
    AppSettings& s = AppSettings::instance();
    if (!s.syncEnabled()) {
        if (_proc)
            stop();
        return;
    }

    // 服务器信息一律默认为空、由用户填写；缺项要明确提示（成功与否都要弹窗）。
    const QString serverId = s.syncServerDeviceId().trimmed();
    const QString serverAddr = s.syncServerSyncAddress().trimmed();
    if (serverId.isEmpty() || serverAddr.isEmpty()) {
        emit statusMessage(tr("同步服务器信息未填写完整（服务器设备 ID / 服务器同步地址）"));
        emit serverConnectionResult(false,
            tr("同步服务器信息未填写完整，请先在 设置→同步 中填写\n"
               "“服务器设备 ID”与“服务器同步地址”（形如 tcp://服务器IP:22000）。"));
        return;
    }

    if (!_proc) {
        launch();
        return;
    }
    // 已在运行：设置可能变化，重新应用配置并重探测连接
    _configApplied = false;
    if (_ready) {
        applyConfig();
        checkServerConnection();
    }
}

void SyncManager::launch()
{
    // 引擎查找：程序根目录 与 bin\ 子目录（开发构建/安装包布局不同，
    // installer.iss 装到 {app}\bin——“路径错位”即代码只找根目录导致引擎永远找不到）。
    // 两处都找，取第一个命中；都缺则明确报出查找位置。
    const QString dir = QCoreApplication::applicationDirPath();
    const QStringList candidates = {
        dir + QStringLiteral("/syncthing.exe"),
        dir + QStringLiteral("/bin/syncthing.exe"),
    };
    QString exe;
    for (const QString& cand : candidates) {
        if (QFileInfo::exists(cand)) {
            exe = cand;
            break;
        }
    }
    if (exe.isEmpty()) {
        emit statusMessage(tr("未找到同步引擎 syncthing.exe（已查找：程序根目录、bin\\ 子目录）"));
        emit serverConnectionResult(false,
            tr("未找到同步引擎 syncthing.exe（已查找程序根目录与 bin\\ 子目录），同步无法启动。\n"
               "请将 syncthing.exe 放到程序目录或其 bin\\ 下。"));
        return;
    }

    _home = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation)
            + QStringLiteral("/syncthing");
    QDir().mkpath(_home);

    _apiKey = QUuid::createUuid().toString(QUuid::WithoutBraces).remove('-');
    _tries = 0;
    _ready = false;
    _configApplied = false;

    QStringList args;
    args << QStringLiteral("serve")
         << QStringLiteral("--home=%1").arg(_home)
         // host:port 形式，禁止带 http:// 与尾斜杠（见文件头注释）
         << QStringLiteral("--gui-address=%1").arg(QLatin1String(kGuiAddress))
         << QStringLiteral("--gui-apikey=%1").arg(_apiKey)
         << QStringLiteral("--no-browser")
         << QStringLiteral("--no-console")
         << QStringLiteral("--log-file=%1/syncthing.log").arg(_home);

    _proc = new QProcess(this);
    _proc->setProgram(exe);
    _proc->setArguments(args);
    connect(_proc, &QProcess::errorOccurred, this, [this](QProcess::ProcessError) {
        emit statusMessage(tr("同步引擎进程异常退出"));
        emit serverConnectionResult(false, tr("同步引擎进程异常退出，同步未生效。"));
    });
    _proc->start();
    _pollTimer->start();
    emit statusMessage(tr("同步引擎启动中…"));
}

void SyncManager::pollStatus()
{
    if (_ready || !_proc)
        return;
    if (++_tries > 40) {
        _pollTimer->stop();
        emit statusMessage(tr("同步引擎启动超时（详见 syncthing.log）"));
        emit serverConnectionResult(false,
            tr("同步引擎启动超时，无法连接同步服务器（详见 syncthing.log）。"));
        return;
    }
    QNetworkReply* r = _nam->get(makeRequest(QStringLiteral("rest/system/status")));
    connect(r, &QNetworkReply::finished, this, [this, r]() {
        r->deleteLater();
        if (_ready || r->error() != QNetworkReply::NoError)
            return;
        const QString id = QJsonDocument::fromJson(r->readAll())
                               .object().value(QStringLiteral("myID")).toString();
        if (id.isEmpty())
            return;
        _myId = id;
        _ready = true;
        _pollTimer->stop();
        emit deviceIdReady(id);
        emit statusMessage(tr("同步引擎已启动，本机设备ID：%1").arg(id.left(7)));
        applyConfig();
        checkServerConnection();
    });
}

void SyncManager::applyConfig()
{
    if (!_ready || _myId.isEmpty())
        return;

    QNetworkReply* r = _nam->get(makeRequest(QStringLiteral("rest/config")));
    connect(r, &QNetworkReply::finished, this, [this, r]() {
        r->deleteLater();
        if (r->error() != QNetworkReply::NoError) {
            emit statusMessage(tr("读取同步配置失败：%1").arg(r->errorString()));
            return;
        }
        QJsonObject cfg = QJsonDocument::fromJson(r->readAll()).object();
        if (cfg.isEmpty())
            return;

        AppSettings& s = AppSettings::instance();
        const QString serverId = s.syncServerDeviceId().trimmed();
        const QString serverAddr = s.syncServerSyncAddress().trimmed();

        // ---- devices：只登记服务器设备（星型：不引入其他设备，introducer 不开）----
        if (!serverId.isEmpty()) {
            QJsonArray devs = cfg.value(QLatin1String("devices")).toArray();
            int idx = -1;
            for (int i = 0; i < devs.size(); ++i) {
                if (devs.at(i).toObject().value(QLatin1String("deviceID")).toString() == serverId) {
                    idx = i;
                    break;
                }
            }
            QJsonObject d = idx >= 0 ? devs.at(idx).toObject() : QJsonObject();
            d.insert(QStringLiteral("deviceID"), serverId);
            d.insert(QStringLiteral("name"), QString::fromLatin1(kServerDeviceName));
            d.insert(QStringLiteral("compression"), QStringLiteral("metadata"));
            d.remove(QStringLiteral("introducer"));   // 关闭设备互引，保证星型
            // 显式服务器地址（监听/同步地址）；为空才退回 dynamic（局域网兜底）
            d.insert(QStringLiteral("addresses"),
                     QJsonArray{serverAddr.isEmpty() ? QStringLiteral("dynamic")
                                                     : serverAddr});
            if (idx >= 0)
                devs.replace(idx, d);
            else
                devs.append(d);
            cfg.insert(QStringLiteral("devices"), devs);
        }

        // ---- folders：markor-vault = 当前文档库（每次应用都取当前设置，修“路径错位”）----
        // 旧实现在启动时一次性落配置，之后修改文档库路径不同步 → 同步的不是所见目录。
        QString vaultPath = s.vaultDir().trimmed();
        if (vaultPath.isEmpty()) {
            vaultPath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)
                        + QStringLiteral("/Markor");
        }
        QDir vault(vaultPath);
        if (!vault.exists())
            QDir().mkpath(vault.absolutePath());
        const QString vaultAbs = QDir::fromNativeSeparators(vault.absolutePath());

        QJsonArray folders = cfg.value(QLatin1String("folders")).toArray();
        int idx = -1;
        for (int i = 0; i < folders.size(); ++i) {
            if (folders.at(i).toObject().value(QLatin1String("id")).toString()
                    == QLatin1String(kFolderId)) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            QJsonObject f;
            f.insert(QStringLiteral("id"), QString::fromLatin1(kFolderId));
            f.insert(QStringLiteral("label"), QStringLiteral("Markor"));
            f.insert(QStringLiteral("type"), QStringLiteral("sendreceive"));
            folders.append(f);
            idx = folders.size() - 1;
        }
        QJsonObject folder = folders.at(idx).toObject();
        folder.insert(QStringLiteral("path"), vaultAbs);
        QJsonArray fdevs = folder.value(QLatin1String("devices")).toArray();
        auto ensureDev = [&fdevs](const QString& id) {
            for (const QJsonValue& v : fdevs) {
                if (v.toObject().value(QLatin1String("deviceID")).toString() == id)
                    return;
            }
            QJsonObject d;
            d.insert(QStringLiteral("deviceID"), id);
            fdevs.append(d);
        };
        ensureDev(_myId);
        if (!serverId.isEmpty())
            ensureDev(serverId);
        folder.insert(QStringLiteral("devices"), fdevs);
        folders.replace(idx, folder);
        cfg.insert(QStringLiteral("folders"), folders);

        // ---- options：关中继/自动发现（星型只走显式服务器地址）、关引擎自升级 ----
        QJsonObject opts = cfg.value(QLatin1String("options")).toObject();
        opts.insert(QStringLiteral("relaysEnabled"), false);
        opts.insert(QStringLiteral("globalAnnounceEnabled"), false);
        opts.insert(QStringLiteral("localAnnounceEnabled"), false);
        opts.insert(QStringLiteral("autoUpgradeIntervalH"), 0);   // 不需要“更新同步版本”
        // 清掉旧版本可能写入的 relay:// 监听地址
        QJsonArray la = opts.value(QLatin1String("listenAddress")).toArray();
        QJsonArray cleaned;
        for (const QJsonValue& v : la) {
            if (!v.toString().startsWith(QLatin1String("relay://")))
                cleaned.append(v);
        }
        if (!cleaned.isEmpty())
            opts.insert(QStringLiteral("listenAddress"), cleaned);
        cfg.insert(QStringLiteral("options"), opts);

        // ---- gui：127.0.0.1:8385 明文 HTTP（浏览器可直接打开管理界面）----
        QJsonObject gui = cfg.value(QLatin1String("gui")).toObject();
        gui.insert(QStringLiteral("address"), QString::fromLatin1(kGuiAddress));
        gui.insert(QStringLiteral("tls"), false);
        gui.insert(QStringLiteral("apiKey"), _apiKey);
        cfg.insert(QStringLiteral("gui"), gui);

        QNetworkReply* put = _nam->put(makeRequest(QStringLiteral("rest/config")),
                                       QJsonDocument(cfg).toJson());
        connect(put, &QNetworkReply::finished, this, [this, put, vaultAbs]() {
            put->deleteLater();
            if (put->error() == QNetworkReply::NoError) {
                _configApplied = true;
                emit statusMessage(tr("同步配置已应用（同步目录：%1）").arg(vaultAbs));
            } else {
                emit statusMessage(tr("同步配置应用失败：%1").arg(put->errorString()));
            }
        });
    });
}

void SyncManager::checkServerConnection()
{
    _connTries = 0;
    if (!_connTimer->isActive())
        _connTimer->start();
}

void SyncManager::pollServerConnection()
{
    if (!_ready) {
        if (++_connTries > 10) {
            _connTimer->stop();
            emit serverConnectionResult(false,
                tr("无法连接同步服务器：同步引擎未就绪。"));
        }
        return;
    }
    const QString serverId = AppSettings::instance().syncServerDeviceId().trimmed();
    if (serverId.isEmpty()) {
        _connTimer->stop();
        emit serverConnectionResult(false, tr("未配置服务器设备 ID，无法连接同步服务器。"));
        return;
    }

    QNetworkReply* r = _nam->get(makeRequest(QStringLiteral("rest/system/connections")));
    connect(r, &QNetworkReply::finished, this, [this, r, serverId]() {
        r->deleteLater();
        if (r->error() != QNetworkReply::NoError)
            return;   // 本轮失败，等下一轮 / 超时
        const QJsonObject root = QJsonDocument::fromJson(r->readAll()).object();
        const QJsonObject conns = root.value(QLatin1String("connections")).toObject();
        const QJsonObject peer = conns.value(serverId).toObject();
        if (peer.value(QLatin1String("connected")).toBool()) {
            _connTimer->stop();
            emit serverConnectionResult(true,
                tr("已连接到同步服务器（设备 %1）").arg(serverId.left(7)));
        } else if (++_connTries > 10) {
            _connTimer->stop();
            emit serverConnectionResult(false,
                tr("无法连接同步服务器。\n请检查：服务器同步地址、服务器设备 ID、"
                   "网络可达性（防火墙/VPN），并确认服务器端 Syncthing 已启动。"));
        }
    });
}

void SyncManager::stop()
{
    _pollTimer->stop();
    _connTimer->stop();
    if (_proc) {
        _proc->terminate();
        if (!_proc->waitForFinished(3000)) {
            _proc->kill();
            _proc->waitForFinished(2000);
        }
        _proc->deleteLater();
        _proc = nullptr;
    }
    _ready = false;
    _configApplied = false;
    _myId.clear();
}
