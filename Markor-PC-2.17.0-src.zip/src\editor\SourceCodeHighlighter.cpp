#include "SourceCodeHighlighter.h"
#include "app/ThemeManager.h"

#include <QColor>
#include <QFont>
#include <QSet>
#include <QTextDocument>

SourceCodeHighlighter::SourceCodeHighlighter(QTextDocument* parent)
    : QSyntaxHighlighter(parent)
{
    // 先取主题色，规则库待 setExtension() 后按语言构建
    refreshFormats();
}

void SourceCodeHighlighter::refreshFormats()
{
    ThemeManager& t = ThemeManager::instance();

    _keyword = QTextCharFormat();
    _keyword.setForeground(t.listColor());
    _keyword.setFontWeight(QFont::Bold);

    _number = QTextCharFormat();
    _number.setForeground(t.linkColor());

    _string = QTextCharFormat();
    _string.setForeground(t.strongColor());

    _comment = QTextCharFormat();
    _comment.setForeground(t.quoteColor());
    _comment.setFontItalic(true);

    _tag = QTextCharFormat();
    _tag.setForeground(t.headingColor());
    _tag.setFontWeight(QFont::Bold);

    _attr = QTextCharFormat();
    _attr.setForeground(t.emphasisColor());

    _entity = QTextCharFormat();
    _entity.setForeground(t.codeColor());

    rehighlight();
}

void SourceCodeHighlighter::setExtension(const QString& ext)
{
    _ext = ext.toLower();
    _htmlMode = (_ext == "html" || _ext == "htm" || _ext == "xhtml" || _ext == "xml"
                 || _ext == "svg" || _ext == "xsl" || _ext == "xslt" || _ext == "vue"
                 || _ext == "svelte");
    _hashComment = _dashComment = _semiComment = _pctComment = _cppBlockComment = false;

    static const QSet<QString> hashExt = {
        "py", "pyw", "rb", "sh", "bash", "zsh", "pl", "pm", "r", "ps1", "psm1",
        "make", "mk", "cmake", "tcl", "yaml", "yml", "toml", "ini", "conf",
        "properties"
    };
    static const QSet<QString> dashExt = { "sql", "lua", "hs", "ada" };
    static const QSet<QString> semiExt = { "asm", "s", "lisp", "clj" };
    static const QSet<QString> pctExt  = { "tex", "erl" };
    static const QSet<QString> blockExt = {
        "c", "h", "cpp", "cc", "cxx", "hpp", "hxx", "cs", "java", "js", "mjs",
        "cjs", "jsx", "ts", "tsx", "go", "rs", "kt", "kts", "swift", "scala",
        "dart", "groovy", "gradle", "php", "css", "scss", "less", "sass", "sql",
        "proto", "m", "mm"
    };
    if (!_htmlMode) {
        _hashComment = hashExt.contains(_ext);
        _dashComment = dashExt.contains(_ext);
        _semiComment = semiExt.contains(_ext);
        _pctComment  = pctExt.contains(_ext);
        _cppBlockComment = blockExt.contains(_ext);
    }

    _blockCommentStart = QRegularExpression(QStringLiteral("/\\*"));
    _blockCommentEnd   = QRegularExpression(QStringLiteral("\\*/"));
    _htmlCommentStart  = QRegularExpression(QStringLiteral("<!--"));
    _htmlCommentEnd    = QRegularExpression(QStringLiteral("-->"));

    if (_htmlMode)
        buildHtmlRules();
    else
        buildCodeRules();
    rehighlight();
}

void SourceCodeHighlighter::buildCodeRules()
{
    _rules.clear();
    auto add = [this](const QString& pat, const QTextCharFormat& fmt) {
        _rules.append({ QRegularExpression(pat), fmt });
    };

    // 关键字 / 类型 / 字面量（跨语言合并的超集）
    add(QStringLiteral(
            "\\b(?:if|else|elif|for|while|do|switch|case|default|break|continue|"
            "return|goto|class|struct|enum|union|interface|extends|implements|"
            "import|export|package|namespace|using|public|private|protected|"
            "internal|static|final|const|constexpr|readonly|void|new|delete|"
            "sizeof|typedef|template|typename|virtual|override|abstract|try|"
            "catch|finally|throw|throws|raise|except|assert|yield|await|async|"
            "lambda|def|function|fn|func|var|let|val|with|as|in|is|of|from|and|"
            "or|not|xor|print|echo|require|module|this|super|self|true|false|"
            "null|nullptr|nil|None|True|False|Undefined|undefined|go|defer|"
            "select|range|chan|match|impl|trait|use|mod|pub|mut|fun|when|where|"
            "object|companion|global|nonlocal|pass|del|int|float|double|long|"
            "short|byte|bool|boolean|char|wchar_t|size_t|ssize_t|string|wstring|"
            "varchar|text|number|decimal|auto|extern|inline|register|volatile|"
            "signed|unsigned)\\b"),
        _keyword);

    // 数字（十六进制 / 浮点 / 科学计数）
    add(QStringLiteral("\\b0[xX][0-9a-fA-F]+\\b"), _number);
    add(QStringLiteral("\\b\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b"), _number);

    // 字符串：双引号 / 单引号；js/ts 额外支持反引号模板串
    add(QStringLiteral("\"(?:\\\\.|[^\"\\\\])*\""), _string);
    add(QStringLiteral("'(?:\\\\.|[^'\\\\])*'"), _string);
    if (_ext == "js" || _ext == "mjs" || _ext == "cjs" || _ext == "jsx"
        || _ext == "ts" || _ext == "tsx")
        add(QStringLiteral("`(?:\\\\.|[^`\\\\])*`"), _string);

    // 行注释（按语言族选择；未命中任何族时为 C 风格的 //）
    if (_hashComment)
        add(QStringLiteral("#.*$"), _comment);
    else if (_dashComment)
        add(QStringLiteral("--.*$"), _comment);
    else if (_semiComment)
        add(QStringLiteral(";.*$"), _comment);
    else if (_pctComment)
        add(QStringLiteral("%.*$"), _comment);
    else
        add(QStringLiteral("//.*$"), _comment);
}

void SourceCodeHighlighter::buildHtmlRules()
{
    _rules.clear();
    auto add = [this](const QString& pat, const QTextCharFormat& fmt) {
        _rules.append({ QRegularExpression(pat), fmt });
    };

    // 标签名 <div / </div
    add(QStringLiteral("</?\\s*([A-Za-z_][\\w:.\\-]*)"), _tag);
    // 属性名 attr=
    add(QStringLiteral("([A-Za-z_][\\w:.\\-]*)\\s*="), _attr);
    // 实体引用 &amp; &#123;
    add(QStringLiteral("&[A-Za-z#][A-Za-z0-9]*;"), _entity);
    // 属性值字符串
    add(QStringLiteral("\"(?:\\\\.|[^\"\\\\])*\""), _string);
    add(QStringLiteral("'(?:\\\\.|[^'\\\\])*'"), _string);
}

void SourceCodeHighlighter::highlightBlock(const QString& text)
{
    for (const Rule& r : _rules) {
        auto it = r.pattern.globalMatch(text);
        while (it.hasNext()) {
            const QRegularExpressionMatch m = it.next();
            setFormat(m.capturedStart(), m.capturedLength(), r.format);
        }
    }

    // 跨块的块注释（HTML 注释 / C 风格 /* */），最后应用以覆盖行内规则
    if (_htmlMode) {
        setCurrentBlockState(StateNormal);
        int start = previousBlockState() == StateHtmlComment
                        ? 0 : text.indexOf(_htmlCommentStart);
        while (start >= 0) {
            const QRegularExpressionMatch end = _htmlCommentEnd.match(text, start);
            int stop;
            if (!end.hasMatch()) {
                setCurrentBlockState(StateHtmlComment);
                stop = text.length();
            } else {
                stop = end.capturedEnd();
            }
            setFormat(start, stop - start, _comment);
            start = text.indexOf(_htmlCommentStart, stop);
        }
        return;
    }

    if (_cppBlockComment) {
        setCurrentBlockState(StateNormal);
        int start = previousBlockState() == StateBlockComment
                        ? 0 : text.indexOf(_blockCommentStart);
        while (start >= 0) {
            const QRegularExpressionMatch end = _blockCommentEnd.match(text, start + 2);
            int stop;
            if (!end.hasMatch()) {
                setCurrentBlockState(StateBlockComment);
                stop = text.length();
            } else {
                stop = end.capturedEnd();
            }
            setFormat(start, stop - start, _comment);
            start = text.indexOf(_blockCommentStart, stop);
        }
    }
}
