# 开发规范与操作手册（conventions.md）

> 动手改代码前读完本文件：规范、菜单全结构、"新增 X" checklist、构建打包、测试回归、文档维护。

---

## 1. 代码规范（从现有代码归纳，新增代码请保持一致）

### 命名与结构
| 项 | 约定 | 示例 |
|---|---|---|
| 类 | PascalCase，头文件同名（`类名.h/.cpp`） | `EditorWidget.h` |
| 成员变量 | `_camelCase` 前缀下划线 | `_filePath`、`_historyIndex` |
| 局部/参数 | `camelCase` | `sourceLine` |
| 命名空间 | 无状态函数集合（不写类） | `FormatActions`、`MathRenderer` |
| 单例 | `static X& instance()` 函数内静态对象 | `AppSettings::instance()` |
| 常量 | `static constexpr` 或匿名空间 `constexpr` | `MIN_CONTENT = 180` |
| UI 对象名 | `setObjectName("XxxYyy")`，供 QSS 选择器 | `#SidebarHandle`、`#FormatCombo` |
| 信号 | 动词过去式/名词变化 | `themeChanged`、`recentsChanged` |

### Qt 惯例
- 所有可翻译文本 `tr()`；**UI 文案中文**。
- 跨线程/生命周期风险的连接用 `QPointer` 保护 lambda 捕获（见 `createPage` 的主题连接）。
- 文件读写 UTF-8：`QTextStream::setEncoding(QStringConverter::Utf8)`。
- 定时器防抖：单次 `QTimer`（预览渲染、大纲刷新 400ms、分割条落盘 300ms），**不要轮询**。
- 内存：Qt 父子树管理为主；WebView2 用 pImpl（`Impl* d`）隔离 Win32 头文件。
- 提交的代码自带说明性中文注释（"为什么"而非"是什么"），关键机制留长注释（滚动同步、快照历史、块映射都有）。

### 布尔语义（易错点）
- `_programmaticScroll`：**成对设置/清除**，两侧（editor/preview）各一份，见 ADR-004。
- `_formatAuto`：true = 按扩展名识别；false = 用 `_format` 手动值。
- `isDirty()`：基于 `_cleanText` 基线比较，非 `QTextDocument::isModified()`。

---

## 2. 菜单全结构（改动后更新本表）

```
文件(&F)                      编辑(&E)                格式(&M)              任务(&K)
├ 新建文档 Ctrl+N             ├ 撤销 Ctrl+Z           ├ 加粗                ├ 切换完成 Ctrl+D
├ 打开… Ctrl+O                ├ 重做 Ctrl+Y           ├ 斜体                ├ 优先级循环 Ctrl+P
├─ ─ ─                       ├─ ─ ─                  ├ 删除线              ├ 设置优先级 (A)(B)(C)/清除
├ 保存 Ctrl+S                 └ 查找/替换 Ctrl+F      ├ 行内代码            ├─ ─ ─
├ 另存为… Ctrl+Shift+S                                ├ 标题                ├ 插入今日日期 Ctrl+Shift+D
├ 刷新 Ctrl+R                                         ├ 引用                ├ 追加今日日期
├─ ─ ─                                                ├ 项目符号列表         ├ 设置截止日期 due:…
├ 导出/分享(&E)                                        ├ 有序列表            ├─ ─ ─
│   ├ 导出 HTML…                                       ├ 任务清单            ├ 归档已完成到 done.txt
│   ├ 导出 PDF…                                        ├ 水平分割线          ├ 按优先级排序
│   ├─ ─ ─                                             ├ 插入链接            ├─ ─ ─
│   ├ 复制 HTML 源码                                   ├ 插入图片            └ 过滤器… Ctrl+Shift+F
│   ├ 复制富文本预览                                   ├ 增加缩进
│   └ 复制纯文本                                       ├ 减少缩进
└ 退出 Ctrl+Q                                          └─ ─ ─
                                                       └ 整理 Markdown Ctrl+Alt+T

视图(&V)                     工具(&T)                帮助(&H)          [菜单栏右上角]
├ 预览面板 (开关)             ├ 设置…                 └ 关于…            └ 撤回 | 前进 (快照历史)
└ 主题(&T)                    └ 更多…
    ├ 浅色/深色/樱花 (单选)
    └ 循环切换主题 Ctrl+Shift+T
```

**"更多"对话框仅含**：设置、更新日志。⚠️ 禁止添加：开源协议/社交/团队/帮助/评价（ADR-012）。

### 格式工具栏（`#FormatToolBar`）
`B 加粗 · I 斜体 · S 删除线 · <> 代码 | H 标题 · ❯ 引用 · • 列表 · 1. 有序 · ☑ 任务 | 🔗 链接 · 🖼 图片 · ⇥ 缩进 · ⇤ 反缩进 | 格式: [自动▾] · 🧹 整理`

---

## 3. "新增 X" Checklist

### 3.1 新增源文件（类）
- [ ] 放入正确模块目录（见 directory.md）
- [ ] **`CMakeLists.txt` 的 `APP_SOURCES` 登记**（.cpp 和 .h 都要）
- [ ] **`markor-win.pro` 的 `SOURCES` / `HEADERS` 登记**
- [ ] 需要 MOC 的类带 `Q_OBJECT`
- [ ] 更新 `docs/directory.md`（+ 如有新接口 → `docs/api-index.md`）

### 3.2 新增设置项
- [ ] `AppSettings.h/.cpp`：getter/setter + 默认值
- [ ] `SettingsDialog`：控件 + `applyAndClose()` 落盘 + 信号
- [ ] `MainWindow::showSettings()` 里接信号 → 即时应用
- [ ] `docs/data-model.md` §5 键表补行
- [ ] 默认值选择遵守"不破坏既有用户配置"（QSettings 缺省即默认）

### 3.3 新增主题
- [ ] `resources/theme/<id>.qss`
- [ ] `resources/resources.qrc` 登记
- [ ] `ThemeManager::availableThemes()` 注册 (id, 显示名)
- [ ] `ThemeManager` 全部色值函数加分支（editorBg…strikeColor，共 13 个）
- [ ] `qssFor()` 加映射
- [ ] 更新 `THEMES.md` + `docs/decisions.md`（如是新配色逻辑）

### 3.4 新增文本格式
- [ ] `TextFormat` 枚举 + `FormatDetector::detect/name/fileFilter/highlightable`
- [ ] 决定高亮器（复用 `SourceCodeHighlighter` 或新建）
- [ ] `FormatActions::markupFor/linkFor/imageFor/hrFor` 加分支（若要格式动作）
- [ ] 工具栏 `FormatCombo` 加项（`MainWindow::buildToolBar`）
- [ ] `docs/data-model.md` §1 表格 + `FEATURE_MAP.md` 状态

### 3.5 新增 Markdown 渲染特性
- [ ] `MarkdownConverter`：块级/行内语法 + `data-src-line` 保持 + `BlockInfo` 顺序不破坏
- [ ] 兼顾 lint（`MarkdownHighlighter`）与整理器（`FormatActions::tidyMarkdown`）是否需要跟进
- [ ] 考虑软换行选项 `softBreaks` 的表现
- [ ] `docs/architecture.md` §3/§11 更新

---

## 4. 构建 / 打包 / 版本号

### 构建
```bat
cmake -S . -B build -DCMAKE_PREFIX_PATH=<Qt6 路径>
cmake --build build --config Release     :: 产物 build\Release\MarkorWin.exe
:: 或 qmake: qmake markor-win.pro && mingw32-make release
```
- 依赖：Qt6 Widgets/PrintSupport/Concurrent/Network；Windows + WebView2Loader（内置）。
- `build-env.ps1` 是作者机器的环境脚本（MSVC 14.44.35207 / Win SDK 10.0.26100 / Qt 6.8.3 msvc2022_64），**换机器必须改路径**。

### 打包
- `windeployqt MarkorWin.exe` → 拷贝 Qt 依赖 → 连同 `WebView2Loader.dll`（构建已自动复制）分发。
- 安装包：`build/installer.iss`（Inno Setup）。
- 可选：`syncthing.exe` 放 exe 同目录启用同步功能。
- 目标机需 WebView2 运行时（缺失时 HTML 预览降级为源码展示）。

### 版本号（⚠️ 四处同步改）
`main.cpp::setApplicationVersion` · `resources/app.rc` · `CMakeLists.txt project(VERSION)` · `markor-win.pro VERSION`
（另有 `MainWindow::showChangelog/about` 文案中的版本号。）

---

## 5. 测试与回归

无自动化测试框架；可用 CLI 做冒烟回归：
```bat
MarkorWin.exe samples\demo.md --screenshot out.png       :: UI 截图
MarkorWin.exe samples\demo.md --export-html out.html     :: 渲染管线（含 Mermaid/公式内嵌）
MarkorWin.exe samples\demo.md --export-pdf  out.pdf      :: 打印管线（含具名资源）
```
检查点：导出 HTML 中块级元素含 `data-src-line`；Mermaid/公式变 `<img>`；主题切换后高亮/预览变色；todo.txt 用 `samples/todo.txt` 试任务操作。

**Markdown 合规场景**（lint 规则出处，改语义前先看）：
- `10-errorhint`：未闭合强调/围栏、列表缩进、结尾围栏带语言
- `02-table`：缺 `|---|` 分隔行、表格贴正文
- `03-heading`：`#` 后缺空格
- 验收标准 4.1.2：结尾围栏带语言标注仍正确闭合（只警告）

---

## 6. 已知约束速查（避免误判为 bug）

1. Markdown 三条 COMMONMARK-TODO（architecture §11）。
2. AsciiDoc/Org/Wiki/CSV/KV 只有识别+格式动作，无专用渲染（FEATURE_MAP 🟡）。
3. 预览勾选任务框不写文件（ADR-013）。
4. 保存不做文件占用检查（Syncthing `.sync-conflict` 兜底）。
5. 分割条状态所有页共用一份 `window/splitterState`。
6. `MarkdownConverter::toHtmlFragment` 的 `blocks` 与块序一一对应，任何插块都要同步追加 BlockInfo。
7. `EditorWidget::saveFile(path)`：`_formatAuto` 为真时按目标路径扩展名**重新识别并应用格式**；手动模式则保持当前格式不变。

---

## 7. 文档维护（每次改动必做）

见 [docs/README.md](README.md) 协议；速记：

| 改动 | 更新 |
|---|---|
| 文件增删/职责变化 | directory.md + 两处构建脚本 |
| 接口变化 | api-index.md |
| 设置/格式/数据结构 | data-model.md |
| 架构/数据流/渲染/同步 | architecture.md |
| 技术决策/推翻旧做法 | decisions.md 新 ADR |
| 菜单/快捷键/构建/版本 | 本文件 + AGENTS.md §6 |
| 功能完成度 | FEATURE_MAP.md |
