#include "MathRenderer.h"
#include <QPainter>
#include <QFontMetricsF>
#include <QHash>
#include <QStringList>
#include <vector>
#include <memory>

namespace {

// ---- Symbol tables -------------------------------------------------------
QHash<QString, QString> symbolMap()
{
    static QHash<QString, QString> m = {
        // Greek (lower)
        { "\\alpha","α" }, { "\\beta","β" }, { "\\gamma","γ" }, { "\\delta","δ" },
        { "\\epsilon","ε" }, { "\\zeta","ζ" }, { "\\eta","η" }, { "\\theta","θ" },
        { "\\iota","ι" }, { "\\kappa","κ" }, { "\\lambda","λ" }, { "\\mu","μ" },
        { "\\nu","ν" }, { "\\xi","ξ" }, { "\\pi","π" }, { "\\rho","ρ" },
        { "\\sigma","σ" }, { "\\tau","τ" }, { "\\upsilon","υ" }, { "\\phi","φ" },
        { "\\chi","χ" }, { "\\psi","ψ" }, { "\\omega","ω" },
        // Greek (upper)
        { "\\Gamma","Γ" }, { "\\Delta","Δ" }, { "\\Theta","Θ" }, { "\\Lambda","Λ" },
        { "\\Xi","Ξ" }, { "\\Pi","Π" }, { "\\Sigma","Σ" }, { "\\Phi","Φ" },
        { "\\Psi","Ψ" }, { "\\Omega","Ω" },
        // Operators / relations
        { "\\sum","∑" }, { "\\prod","∏" }, { "\\int","∫" }, { "\\infty","∞" },
        { "\\pm","±" }, { "\\mp","∓" }, { "\\times","×" }, { "\\div","÷" },
        { "\\cdot","·" }, { "\\le","≤" }, { "\\ge","≥" }, { "\\ne","≠" },
        { "\\approx","≈" }, { "\\equiv","≡" }, { "\\to","→" }, { "\\rightarrow","→" },
        { "\\leftarrow","←" }, { "\\Rightarrow","⇒" }, { "\\Leftrightarrow","⇔" },
        { "\\in","∈" }, { "\\notin","∉" }, { "\\subset","⊂" }, { "\\subseteq","⊆" },
        { "\\cup","∪" }, { "\\cap","∩" }, { "\\forall","∀" }, { "\\exists","∃" },
        { "\\partial","∂" }, { "\\nabla","∇" }, { "\\ldots","…" }, { "\\cdots","⋯" },
        { "\\degree","°" },
        // Fences
        { "\\{","{" }, { "\\}","}" }, { "\\%","%" }, { "\\&","&" }, { "\\#","#" },
        { "\\$","$" }, { "\\_","_" }, { "\\|","‖" },
    };
    return m;
}

QFont makeFont(int size, bool italic)
{
    QFont f;
    f.setFamily(QStringLiteral("DejaVu Serif"));
    f.setPixelSize(size);
    f.setItalic(italic);
    return f;
}

// ---- Node model ---------------------------------------------------------
enum Kind { Text, Frac, Sqrt, Row };

struct Node {
    Kind kind = Text;
    QString text;
    std::vector<Node> ch;   // frac: [num,den]; sqrt: [radicand]; row: items
    bool hasSup = false, hasSub = false;
    std::shared_ptr<Node> sup, sub;
};

struct M { qreal w = 0, asc = 0, desc = 0; };

// ---- Parser -------------------------------------------------------------
struct Parser {
    QString s;
    int i = 0;

    explicit Parser(const QString& src) : s(src) {}

    void skipSpaces() { while (i < s.size() && s[i].isSpace()) ++i; }

    // read a braced group { ... } -> inner text
    QString readGroup() {
        skipSpaces();
        if (i < s.size() && s[i] == '{') {
            int depth = 0, start = ++i;
            while (i < s.size()) {
                if (s[i] == '{') ++depth;
                else if (s[i] == '}') {
                    if (depth == 0) { QString r = s.mid(start, i - start); ++i; return r; }
                    --depth;
                }
                ++i;
            }
            return s.mid(start);
        }
        if (i < s.size()) { QString r(s[i]); ++i; return r; }
        return QString();
    }

    // parse a single atom (with optional ^ _)
    Node atom() {
        Node n;
        skipSpaces();
        if (i >= s.size()) { n.kind = Text; return n; }

        if (s[i] == '\\') {
            int start = i;
            ++i;
            if (i < s.size() && s[i].isLetter()) {
                while (i < s.size() && s[i].isLetter()) ++i;
            } else if (i < s.size()) {
                ++i;
            }
            QString cmd = s.mid(start, i - start);
            if (cmd == QStringLiteral("\\frac")) {
                n.kind = Frac;
                Node a = parseInner(); Node b = parseInner();
                n.ch.push_back(a); n.ch.push_back(b);
                return decorate(n);
            }
            if (cmd == QStringLiteral("\\sqrt")) {
                n.kind = Sqrt;
                n.ch.push_back(parseInner());
                return decorate(n);
            }
            if (cmd == QStringLiteral("\\left") || cmd == QStringLiteral("\\right")) {
                // consume the fence char and render as plain text
                skipSpaces();
                QString fence;
                if (i < s.size()) { fence = s[i]; ++i; }
                n.kind = Text;
                n.text = fence;
                return decorate(n);
            }
            QString sym = symbolMap().value(cmd, cmd.mid(1));
            n.kind = Text; n.text = sym;
            return decorate(n);
        }

        // plain character
        n.kind = Text;
        n.text = s[i];
        ++i;
        return decorate(n);
    }

    Node decorate(Node n) {
        while (true) {
            skipSpaces();
            if (i < s.size() && s[i] == '^') {
                ++i;
                n.sup = std::make_shared<Node>(parseInner());
                n.hasSup = true;
            } else if (i < s.size() && s[i] == '_') {
                ++i;
                n.sub = std::make_shared<Node>(parseInner());
                n.hasSub = true;
            } else break;
        }
        return n;
    }

    Node parseInner() {
        skipSpaces();
        if (i < s.size() && s[i] == '{') {
            int save = i;
            QString grp = readGroup();
            Q_UNUSED(save);
            Parser sub(grp);
            return sub.parseRow();
        }
        return atom();
    }

    Node parseRow() {
        Node row; row.kind = Row;
        while (i < s.size()) {
            skipSpaces();
            if (i >= s.size()) break;
            if (s[i] == '}') break;
            row.ch.push_back(atom());
        }
        return row;
    }

    Node parse() { return parseRow(); }
};

// ---- Layout -------------------------------------------------------------
M layout(QPainter& p, const Node& n, int size);

M layoutText(QPainter& p, const QString& t, int size, bool italic) {
    QFontMetricsF fm(makeFont(size, italic));
    M m;
    m.w = fm.horizontalAdvance(t);
    m.asc = fm.ascent();
    m.desc = fm.descent();
    return m;
}

M layout(QPainter& p, const Node& n, int size) {
    switch (n.kind) {
    case Text: {
        bool italic = n.text.size() == 1 && n.text[0].isLetter();
        M m = layoutText(p, n.text, size, italic);
        if (n.hasSup) {
            M s = layout(p, *n.sup, int(size * 0.7));
            m.w += s.w;
            m.asc = qMax(m.asc, size * 0.9 + s.asc * 0.4);
        }
        if (n.hasSub) {
            M s = layout(p, *n.sub, int(size * 0.7));
            m.w += s.w;
            m.desc = qMax(m.desc, size * 0.5 + s.desc);
        }
        return m;
    }
    case Row: {
        M m;
        for (const auto& c : n.ch) {
            M cm = layout(p, c, size);
            m.w += cm.w;
            m.asc = qMax(m.asc, cm.asc);
            m.desc = qMax(m.desc, cm.desc);
        }
        return m;
    }
    case Frac: {
        M a = layout(p, n.ch[0], int(size * 0.9));
        M b = layout(p, n.ch[1], int(size * 0.9));
        M m;
        m.w = qMax(a.w, b.w) + size * 0.7;
        m.asc = a.asc + a.desc + size * 0.35;   // numerator above bar
        m.desc = b.asc + b.desc + size * 0.35;
        return m;
    }
    case Sqrt: {
        M a = layout(p, n.ch[0], size);
        QFontMetricsF fm(makeFont(size, true));
        qreal rw = fm.horizontalAdvance(QChar(0x221A));
        M m;
        m.w = rw + a.w + size * 0.15;
        m.asc = a.asc + size * 0.25;
        m.desc = a.desc + size * 0.15;
        return m;
    }
    }
    return M();
}

// ---- Paint --------------------------------------------------------------
void paint(QPainter& p, const Node& n, int size, qreal x, qreal baseline, const QColor& fg) {
    p.setPen(fg);
    switch (n.kind) {
    case Text: {
        bool italic = n.text.size() == 1 && n.text[0].isLetter();
        p.setFont(makeFont(size, italic));
        QFontMetricsF fm(makeFont(size, italic));
        p.drawText(QPointF(x, baseline), n.text);
        qreal adv = fm.horizontalAdvance(n.text);
        if (n.hasSup) {
            paint(p, *n.sup, int(size * 0.7), x + adv, baseline - size * 0.55, fg);
        }
        if (n.hasSub) {
            paint(p, *n.sub, int(size * 0.7), x + adv, baseline + size * 0.35, fg);
        }
        break;
    }
    case Row: {
        qreal cx = x;
        for (const auto& c : n.ch) {
            M cm = layout(p, c, size);
            paint(p, c, size, cx, baseline, fg);
            cx += cm.w;
        }
        break;
    }
    case Frac: {
        M a = layout(p, n.ch[0], int(size * 0.9));
        M b = layout(p, n.ch[1], int(size * 0.9));
        qreal totalW = qMax(a.w, b.w) + size * 0.7;
        qreal barY = baseline - size * 0.12;
        // numerator
        paint(p, n.ch[0], int(size * 0.9), x + (totalW - a.w) / 2, barY - size * 0.18, fg);
        // bar
        p.setPen(QPen(fg, qMax<qreal>(1.0, size * 0.055)));
        p.drawLine(QPointF(x + size * 0.1, barY), QPointF(x + totalW - size * 0.1, barY));
        // denominator
        paint(p, n.ch[1], int(size * 0.9), x + (totalW - b.w) / 2, barY + size * 0.55 + b.asc, fg);
        break;
    }
    case Sqrt: {
        QFontMetricsF fm(makeFont(size, true));
        qreal rw = fm.horizontalAdvance(QChar(0x221A));
        p.setFont(makeFont(size, true));
        M a = layout(p, n.ch[0], size);
        p.drawText(QPointF(x, baseline + size * 0.15), QChar(0x221A));
        // overline
        qreal topY = baseline - a.asc - size * 0.22;
        p.setPen(QPen(fg, qMax<qreal>(1.0, size * 0.05)));
        p.drawLine(QPointF(x + rw - size * 0.06, topY), QPointF(x + rw + a.w + size * 0.1, topY));
        paint(p, n.ch[0], size, x + rw + size * 0.1, baseline, fg);
        break;
    }
    }
}

} // namespace

namespace MathRenderer {

QPixmap render(const QString& latex, int pointSize, const QColor& fg, const QColor& bg)
{
    Parser parser(latex.trimmed());
    Node root = parser.parse();

    const int size = qMax(12, pointSize);
    QImage img(1, 1, QImage::Format_ARGB32_Premultiplied);
    QPainter measure(&img);
    M m = layout(measure, root, size);
    measure.end();

    const int pad = qMax(6, size / 3);
    int w = int(m.w) + pad * 2 + 2;
    int h = int(m.asc + m.desc) + pad * 2 + 2;

    QPixmap pm(w, h);
    pm.fill(bg);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);
    const qreal baseline = pad + m.asc;
    paint(p, root, size, pad, baseline, fg);
    p.end();
    return pm;
}

} // namespace MathRenderer
