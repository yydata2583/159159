#include "ThemeManager.h"
#include <QApplication>
#include <QEvent>
#include <QFile>
#include <QPalette>
#include <QWidget>

#ifdef Q_OS_WIN
#include <dwmapi.h>
#pragma comment(lib, "dwmapi.lib")
#endif

ThemeManager& ThemeManager::instance()
{
    static ThemeManager t;
    return t;
}

ThemeManager::ThemeManager(QObject* parent)
    : QObject(parent)
{
}

QList<QPair<QString, QString>> ThemeManager::availableThemes()
{
    return {
        { QStringLiteral("light"),  QStringLiteral("浅色 (Light)") },
        { QStringLiteral("dark"),   QStringLiteral("深色 (Dark)") },
        { QStringLiteral("sakura"), QStringLiteral("樱花 (Sakura)") },
    };
}

QString ThemeManager::displayName(const QString& id)
{
    for (const auto& p : availableThemes())
        if (p.first == id)
            return p.second;
    return QStringLiteral("浅色 (Light)");
}

QString ThemeManager::systemThemeId()
{
    const QColor win = QGuiApplication::palette().color(QPalette::Window);
    return (win.lightness() < 128) ? QStringLiteral("dark") : QStringLiteral("light");
}

static QString qssFor(const QString& theme)
{
    QString res;
    if (theme == QStringLiteral("dark"))
        res = QStringLiteral(":/theme/dark.qss");
    else if (theme == QStringLiteral("sakura"))
        res = QStringLiteral(":/theme/sakura.qss");
    else
        res = QStringLiteral(":/theme/light.qss");

    QFile f(res);
    if (f.open(QIODevice::ReadOnly | QIODevice::Text))
        return QString::fromUtf8(f.readAll());
    return QString();
}

void ThemeManager::apply(const QString& theme)
{
    if (theme == QStringLiteral("dark"))
        _theme = QStringLiteral("dark");
    else if (theme == QStringLiteral("sakura"))
        _theme = QStringLiteral("sakura");
    else
        _theme = QStringLiteral("light");

    qApp->setStyleSheet(qssFor(_theme));

    // Also tune the system palette so native dialogs match.
    QPalette pal = qApp->palette();
    if (isDark()) {
        pal.setColor(QPalette::Window, QColor("#1e2127"));
        pal.setColor(QPalette::WindowText, QColor("#e4e6eb"));
        pal.setColor(QPalette::Base, QColor("#23272e"));
        pal.setColor(QPalette::Text, QColor("#e4e6eb"));
    } else if (_theme == QStringLiteral("sakura")) {
        pal.setColor(QPalette::Window, QColor("#fff5f7"));
        pal.setColor(QPalette::WindowText, QColor("#b2607e"));
        pal.setColor(QPalette::Base, QColor("#fffbfc"));
        pal.setColor(QPalette::Text, QColor("#b2607e"));
        pal.setColor(QPalette::ButtonText, QColor("#b2607e"));
    } else {
        pal.setColor(QPalette::Window, QColor("#f5f6f8"));
        pal.setColor(QPalette::WindowText, QColor("#1c1e21"));
        pal.setColor(QPalette::Base, QColor("#ffffff"));
        pal.setColor(QPalette::Text, QColor("#1c1e21"));
    }
    pal.setColor(QPalette::Highlight, QColor("#3574f0"));
    pal.setColor(QPalette::HighlightedText, QColor("#ffffff"));
    qApp->setPalette(pal);

    // Colour the native title bars of every window (incl. child dialogs).
    qApp->installEventFilter(this);
    for (QWidget* w : qApp->topLevelWidgets()) {
        if (w->isWindow())
            applyTitleBarColor(w);
    }

    emit themeChanged(_theme);
}

bool ThemeManager::eventFilter(QObject* watched, QEvent* event)
{
    if (event->type() == QEvent::Show) {
        QWidget* w = qobject_cast<QWidget*>(watched);
        if (w && w->isWindow())
            applyTitleBarColor(w);
    }
    return QObject::eventFilter(watched, event);
}

void ThemeManager::applyTitleBarColor(QWidget* w) const
{
#ifdef Q_OS_WIN
    if (!w)
        return;
    QColor bg, fg;
    if (isDark()) {
        bg = QColor("#1e2127");
        fg = QColor("#e4e6eb");
    } else if (_theme == QStringLiteral("sakura")) {
        bg = QColor("#fff5f7");
        fg = QColor("#c93a66");
    } else {
        bg = QColor("#f5f6f8");
        fg = QColor("#1c1e21");
    }
    const HWND hwnd = reinterpret_cast<HWND>(w->winId());
    const COLORREF bgRef = RGB(bg.red(), bg.green(), bg.blue());
    const COLORREF fgRef = RGB(fg.red(), fg.green(), fg.blue());
    // DWMWA_CAPTION_COLOR / TEXT_COLOR / BORDER_COLOR (Windows 11).
    DwmSetWindowAttribute(hwnd, 35, &bgRef, sizeof(bgRef));
    DwmSetWindowAttribute(hwnd, 36, &fgRef, sizeof(fgRef));
    DwmSetWindowAttribute(hwnd, 34, &bgRef, sizeof(bgRef));
#else
    Q_UNUSED(w);
#endif
}

// --- Palette ---
// Each accessor switches over the theme id. Sakura is a light variant.

QColor ThemeManager::editorBg() const
{
    if (isDark()) return QColor("#23272e");
    if (_theme == QStringLiteral("sakura")) return QColor("#fffbfc");
    return QColor("#ffffff");
}
QColor ThemeManager::editorFg() const
{
    if (isDark()) return QColor("#e4e6eb");
    if (_theme == QStringLiteral("sakura")) return QColor("#4a4a5a");
    return QColor("#1c1e21");
}
QColor ThemeManager::lineNumberFg() const
{
    if (isDark()) return QColor("#6b7280");
    if (_theme == QStringLiteral("sakura")) return QColor("#c99bad");
    return QColor("#a0a6b0");
}
QColor ThemeManager::highlightBg() const
{
    if (isDark()) return QColor("#2c4a7c");
    if (_theme == QStringLiteral("sakura")) return QColor("#ffc2d1");
    return QColor("#b6d0fb");
}
QColor ThemeManager::codeBlockBg() const
{
    if (isDark()) return QColor("#2a2f36");
    if (_theme == QStringLiteral("sakura")) return QColor("#fdeef2");
    return QColor("#f2f3f5");
}
QColor ThemeManager::borderColor() const
{
    if (isDark()) return QColor("#3a4048");
    if (_theme == QStringLiteral("sakura")) return QColor("#f2b8c6");
    return QColor("#d8dce1");
}

// --- Markdown syntax colors ---
QColor ThemeManager::headingColor() const
{
    if (isDark()) return QColor("#7aa2f7");
    if (_theme == QStringLiteral("sakura")) return QColor("#d64c7a");
    return QColor("#1a56c4");
}
QColor ThemeManager::emphasisColor() const
{
    if (isDark()) return QColor("#c3a6ff");
    if (_theme == QStringLiteral("sakura")) return QColor("#c85c8e");
    return QColor("#8a3ffc");
}
QColor ThemeManager::strongColor() const
{
    if (isDark()) return QColor("#ffb86c");
    if (_theme == QStringLiteral("sakura")) return QColor("#e0683a");
    return QColor("#c76a00");
}
QColor ThemeManager::codeColor() const
{
    if (isDark()) return QColor("#9ece6a");
    if (_theme == QStringLiteral("sakura")) return QColor("#5c9d6e");
    return QColor("#1a7f37");
}
QColor ThemeManager::linkColor() const
{
    if (isDark()) return QColor("#73daca");
    if (_theme == QStringLiteral("sakura")) return QColor("#e75480");
    return QColor("#0a7d8c");
}
QColor ThemeManager::quoteColor() const
{
    if (isDark()) return QColor("#8ba3c7");
    if (_theme == QStringLiteral("sakura")) return QColor("#b5657e");
    return QColor("#6a737d");
}
QColor ThemeManager::listColor() const
{
    if (isDark()) return QColor("#e0af68");
    if (_theme == QStringLiteral("sakura")) return QColor("#d67a4a");
    return QColor("#b58900");
}
QColor ThemeManager::hrColor() const
{
    if (isDark()) return QColor("#565f89");
    if (_theme == QStringLiteral("sakura")) return QColor("#e2a3b4");
    return QColor("#9aa0a6");
}
QColor ThemeManager::strikeColor() const
{
    if (isDark()) return QColor("#f7768e");
    if (_theme == QStringLiteral("sakura")) return QColor("#c0392b");
    return QColor("#c0392b");
}
