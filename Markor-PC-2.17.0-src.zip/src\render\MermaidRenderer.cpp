#include "MermaidRenderer.h"
#include <QPainter>
#include <QPainterPath>
#include <QFontMetricsF>
#include <QRegularExpression>
#include <QHash>
#include <QSet>
#include <QVector>
#include <QStringList>
#include <algorithm>

namespace {

enum Shape { Rect, Round, Diamond, Circle, Stadium };

struct MNode {
    QString id;
    QString label;
    Shape shape = Rect;
    int layer = 0;
    int order = 0;
    qreal x = 0, y = 0, w = 0, h = 0;
};

struct MEdge {
    QString from, to, label;
    bool dashed = false;
    bool thick = false;
    bool arrow = true;
};

struct SeqMsg {
    QString from, to, text;
    bool dashed = false;
    bool arrowHead = true;
};

QFont dfont(int px, bool bold = false)
{
    QFont f;
    f.setFamily(QStringLiteral("DejaVu Sans"));
    f.setPixelSize(px);
    f.setBold(bold);
    return f;
}

QString cleanLabel(const QString& raw)
{
    QString s = raw.trimmed();
    s.remove(QRegularExpression(QStringLiteral("^\"|\"$")));
    return s;
}

// Parse node shape + label from a bracket group body.
Shape shapeFromDelims(const QString& open, const QString& close)
{
    if (open == "[" && close == "]") return Rect;
    if (open == "(" && close == ")") return Round;
    if (open == "{" && close == "}") return Diamond;
    if (open == "((" && close == "))") return Circle;
    if (open == "([" && close == "])") return Stadium;
    return Rect;
}

// ---- Flowchart parsing --------------------------------------------------
struct Flow {
    bool lr = false;
    QVector<MNode> nodes;
    QVector<MEdge> edges;
    QHash<QString, int> index;
};

int ensureNode(Flow& f, const QString& id, const QString& label, Shape shape)
{
    if (!f.index.contains(id)) {
        MNode n;
        n.id = id;
        n.label = label.isEmpty() ? id : label;
        n.shape = shape;
        f.index[id] = f.nodes.size();
        f.nodes.push_back(n);
    } else {
        MNode& n = f.nodes[f.index[id]];
        if (!label.isEmpty()) n.label = label;
    }
    return f.index[id];
}

// Scan one flowchart line into nodes + edges.
void scanFlowLine(const QString& line, Flow& f)
{
    int i = 0;
    const int N = line.size();

    auto readNodeId = [&]() -> QString {
        QString id;
        while (i < N && (line[i].isLetterOrNumber() || line[i] == '_')) { id += line[i]; ++i; }
        return id;
    };
    auto readBracket = [&](QString& open, QString& close, QString& body) {
        // at '(' '[' '{' possibly doubled
        QString o;
        if (line[i] == '(' && i + 1 < N && line[i + 1] == '(') { o = "(("; i += 2; }
        else if (line[i] == '(' && i + 1 < N && line[i + 1] == '[') { o = "(["; i += 2; }
        else { o = line[i]; ++i; }
        open = o;
        int depth = 1;
        body.clear();
        while (i < N) {
            QChar c = line[i];
            bool closing = false;
            if (o == "((" && c == ')' && i + 1 < N && line[i + 1] == ')') closing = true;
            else if (o == "([" && c == ']' && i + 1 < N && line[i + 1] == ')') closing = true;
            else if (o == "[" && c == ']') closing = true;
            else if (o == "(" && c == ')') closing = true;
            else if (o == "{" && c == '}') closing = true;
            if (closing) {
                if (o == "((") { close = "))"; i += 2; }
                else if (o == "([") { close = "])"; i += 2; }
                else { close = QString(c); ++i; }
                return;
            }
            body += c;
            ++i;
        }
        close = o == "((" ? "))" : (o == "([") ? "])" : QString();
    };

    QString pendingFrom;
    while (i < N) {
        QChar c = line[i];
        if (c.isSpace()) { ++i; continue; }
        if (c == '|') { // edge label
            int j = line.indexOf('|', i + 1);
            QString lbl = line.mid(i + 1, (j < 0 ? N : j) - (i + 1));
            i = (j < 0 ? N : j + 1);
            if (!f.edges.isEmpty()) f.edges.last().label = cleanLabel(lbl);
            continue;
        }
        // edge operators
        static const QStringList ops = { QStringLiteral("-.->"), QStringLiteral("==>"),
                                          QStringLiteral("-->"), QStringLiteral("---"),
                                          QStringLiteral("--x"), QStringLiteral("--o"),
                                          QStringLiteral("-.-"), QStringLiteral("===") };
        bool matchedOp = false;
        for (const QString& op : ops) {
            if (line.mid(i, op.size()) == op) {
                MEdge e;
                e.from = pendingFrom;
                e.dashed = op.startsWith(QStringLiteral("-.")) || op == QStringLiteral("-.-");
                e.thick = op.startsWith(QStringLiteral("=="));
                e.arrow = !(op == QStringLiteral("---") || op == QStringLiteral("-.-"));
                // "--x"/"--o" arrow styles: keep arrow
                f.edges.push_back(e);
                i += op.size();
                matchedOp = true;
                break;
            }
        }
        if (matchedOp) continue;

        // node reference
        if (c.isLetter() || c == '_') {
            QString id = readNodeId();
            QString label, open, close, body;
            if (i < N && (line[i] == '[' || line[i] == '(' || line[i] == '{')) {
                readBracket(open, close, body);
                label = cleanLabel(body);
            }
            Shape shp = open.isEmpty() ? Rect : shapeFromDelims(open, close);
            ensureNode(f, id, label, shp);
            if (!f.edges.isEmpty() && f.edges.last().to.isEmpty())
                f.edges.last().to = id;
            else if (!pendingFrom.isEmpty() && !f.edges.isEmpty() && !f.edges.last().to.isEmpty()) {
                // chain already handled
            }
            pendingFrom = id;
            continue;
        }
        ++i;
    }
}

void layoutFlow(Flow& f)
{
    // BFS layering from root nodes (cycle-safe)
    QHash<QString, int> indeg;
    QHash<QString, QVector<QString>> adj;
    for (const MNode& n : f.nodes) indeg[n.id] = 0;
    for (const MEdge& e : f.edges) {
        if (e.from.isEmpty() || e.to.isEmpty()) continue;
        adj[e.from].push_back(e.to);
        indeg[e.to] += 1;
    }
    QHash<QString, int> layer;
    QVector<QString> queue;
    QSet<QString> seen;
    for (const MNode& n : f.nodes) {
        if (indeg[n.id] == 0) { layer[n.id] = 0; queue.push_back(n.id); seen.insert(n.id); }
    }
    if (queue.isEmpty() && !f.nodes.isEmpty()) {
        layer[f.nodes[0].id] = 0; queue.push_back(f.nodes[0].id); seen.insert(f.nodes[0].id);
    }
    for (int qi = 0; qi < queue.size(); ++qi) {
        QString u = queue[qi];
        for (const QString& v : adj[u]) {
            if (!seen.contains(v)) {
                layer[v] = layer[u] + 1;
                seen.insert(v);
                queue.push_back(v);
            }
        }
    }
    for (MNode& n : f.nodes) n.layer = layer.value(n.id, 0);

    // order within layer by declaration
    QHash<int, int> counter;
    QVector<MNode*> byLayer;
    for (MNode& n : f.nodes) { n.order = counter[n.layer]++; }
    int maxOrder = 0;
    for (const MNode& n : f.nodes) maxOrder = qMax(maxOrder, n.order + 1);

    // measure + position
    QFontMetricsF fm(dfont(15));
    for (MNode& n : f.nodes) {
        qreal tw = fm.horizontalAdvance(n.label) + 34;
        qreal th = fm.height() + 22;
        if (n.shape == Diamond) { tw += 24; th += 16; }
        if (n.shape == Circle) { tw = qMax(tw, th + 20); th = tw; }
        n.w = qMax<qreal>(72, tw);
        n.h = qMax<qreal>(48, th);
    }

    const qreal hgap = 70, vgap = 80;
    if (f.lr) {
        for (MNode& n : f.nodes) {
            n.x = n.layer * 220 + 40;
            n.y = n.order * 120 + 40;
        }
    } else {
        for (MNode& n : f.nodes) {
            n.x = n.order * 200 + 60;
            n.y = n.layer * 140 + 50;
        }
    }
    Q_UNUSED(hgap); Q_UNUSED(vgap); Q_UNUSED(maxOrder); Q_UNUSED(byLayer);
}

QPixmap drawFlow(Flow& f, int maxWidth, const QColor& fg, const QColor& bg)
{
    if (f.nodes.isEmpty()) return QPixmap();
    qreal maxW = 0, maxH = 0;
    for (const MNode& n : f.nodes) {
        maxW = qMax(maxW, n.x + n.w);
        maxH = qMax(maxH, n.y + n.h);
    }
    const int pad = 40;
    int W = int(maxW) + pad * 2;
    int H = int(maxH) + pad * 2;
    qreal scale = 1.0;
    if (maxWidth > 0 && W > maxWidth) {
        scale = qreal(maxWidth) / W;
    }

    QPixmap pm(W, H);
    pm.fill(bg);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.translate(pad, pad);
    p.scale(scale, scale);

    // edges first
    for (const MEdge& e : f.edges) {
        if (!f.index.contains(e.from) || !f.index.contains(e.to)) continue;
        MNode& a = f.nodes[f.index[e.from]];
        MNode& b = f.nodes[f.index[e.to]];
        QPointF pa(a.x + a.w / 2, a.y + a.h / 2);
        QPointF pb(b.x + b.w / 2, b.y + b.h / 2);
        // clip to box borders
        QPointF src = pa + (pb - pa) * 0.5 * 0.62;
        QPointF dst = pb + (pa - pb) * 0.5 * 0.62;

        QPen pen(fg, e.thick ? 3.2 : 1.9);
        if (e.dashed) pen.setStyle(Qt::DashLine);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawLine(src, dst);
        if (e.arrow) {
            QPolygonF head;
            QPointF dir = dst - src;
            qreal len = qMax<qreal>(1, qSqrt(dir.x() * dir.x() + dir.y() * dir.y()));
            QPointF u = dir / len;
            QPointF perp(-u.y(), u.x());
            head << dst
                 << dst - u * 12 + perp * 6
                 << dst - u * 12 - perp * 6;
            p.setBrush(fg);
            p.drawPolygon(head);
        }
        if (!e.label.isEmpty()) {
            QPointF mid = (src + dst) / 2;
            p.setFont(dfont(13));
            QFontMetricsF fm(dfont(13));
            qreal lw = fm.horizontalAdvance(e.label) + 10;
            QRectF lr(mid.x() - lw / 2, mid.y() - fm.height() / 2 - 2, lw, fm.height() + 4);
            p.fillRect(lr, bg);
            p.setPen(fg);
            p.drawText(lr, Qt::AlignCenter, e.label);
        }
    }

    // nodes
    for (const MNode& n : f.nodes) {
        QRectF r(n.x, n.y, n.w, n.h);
        p.setBrush(bg.lightness() < 128 ? QColor("#31363d") : QColor("#ffffff"));
        QPen pen(fg, 2.0);
        p.setPen(pen);
        p.setFont(dfont(15, true));
        switch (n.shape) {
        case Diamond: {
            QPolygonF poly;
            poly << QPointF(r.center().x(), r.top())
                 << QPointF(r.right(), r.center().y())
                 << QPointF(r.center().x(), r.bottom())
                 << QPointF(r.left(), r.center().y());
            p.drawPolygon(poly);
            break;
        }
        case Circle:
            p.drawEllipse(r);
            break;
        case Round:
        case Stadium:
            p.drawRoundedRect(r, r.height() / 2, r.height() / 2);
            break;
        case Rect:
        default:
            p.drawRoundedRect(r, 10, 10);
            break;
        }
        p.setPen(fg);
        p.drawText(r, Qt::AlignCenter | Qt::TextWordWrap, n.label);
    }
    p.end();
    return pm;
}

// ---- Sequence diagram ---------------------------------------------------
QPixmap drawSequence(const QStringList& lines, int maxWidth,
                     const QColor& fg, const QColor& bg, bool dark)
{
    QStringList actors;
    QHash<QString, QString> actorLabel;
    QVector<SeqMsg> msgs;
    QVector<QStringList> notes; // {scope, text}

    for (QString raw : lines) {
        QString line = raw.trimmed();
        if (line.isEmpty() || line.startsWith(QStringLiteral("%%"))) continue;
        if (line.startsWith(QStringLiteral("participant")) ||
            line.startsWith(QStringLiteral("actor"))) {
            static const QRegularExpression pa(
                QStringLiteral("^(?:participant|actor)\\s+([^\\s]+)(?:\\s+as\\s+(.+))?$"));
            QRegularExpressionMatch m = pa.match(line);
            if (m.hasMatch()) {
                QString id = m.captured(1);
                actors << id;
                actorLabel[id] = m.hasMatch() && !m.captured(2).isEmpty()
                                     ? m.captured(2).trimmed() : id;
            }
            continue;
        }
        if (line.startsWith(QStringLiteral("note"))) {
            static const QRegularExpression nr(
                QStringLiteral("^note\\s+(?:over|left of|right of)\\s+([^:]+):\\s*(.*)$"));
            QRegularExpressionMatch m = nr.match(line);
            if (m.hasMatch()) notes.push_back({ m.captured(1).trimmed(), m.captured(2).trimmed() });
            continue;
        }
        if (line.startsWith(QStringLiteral("loop")) || line.startsWith(QStringLiteral("alt")) ||
            line.startsWith(QStringLiteral("else")) || line.startsWith(QStringLiteral("opt")) ||
            line.startsWith(QStringLiteral("par")) || line.startsWith(QStringLiteral("end")) ||
            line.startsWith(QStringLiteral("activate")) || line.startsWith(QStringLiteral("deactivate")))
            continue;

        static const QRegularExpression mr(
            QStringLiteral("^([^\\s-]+)\\s*(-->>|-x|->>|->|-->)\\s*([^:]+):\\s*(.*)$"));
        QRegularExpressionMatch m = mr.match(line);
        if (m.hasMatch()) {
            SeqMsg msg;
            msg.from = m.captured(1).trimmed();
            QString arrow = m.captured(2);
            msg.to = m.captured(3).trimmed();
            msg.text = m.captured(4).trimmed();
            msg.dashed = arrow.startsWith(QStringLiteral("--"));
            msg.arrowHead = !arrow.endsWith(QLatin1Char('x'));
            msgs.push_back(msg);
            if (!actors.contains(msg.from)) actors << msg.from;
            if (!actors.contains(msg.to)) actors << msg.to;
            if (!actorLabel.contains(msg.from)) actorLabel[msg.from] = msg.from;
            if (!actorLabel.contains(msg.to)) actorLabel[msg.to] = msg.to;
        }
    }
    if (actors.isEmpty()) return QPixmap();

    const int pad = 44;
    const int boxW = 150, boxH = 52;
    const int colGap = 200;
    const int rowH = 70;
    int W = pad * 2 + colGap * (actors.size() - 1) + boxW;
    int H = pad * 2 + boxH + 70 + rowH * (msgs.size() + notes.size()) + 40;

    qreal scale = 1.0;
    if (maxWidth > 0 && W > maxWidth) scale = qreal(maxWidth) / W;

    QPixmap pm(W, H);
    pm.fill(bg);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.translate(pad, pad);
    p.scale(scale, scale);

    QHash<QString, qreal> colX;
    for (int i = 0; i < actors.size(); ++i) {
        colX[actors[i]] = i * colGap + boxW / 2;
    }

    // actor boxes + lifelines
    QColor boxFill = dark ? QColor("#31363d") : QColor("#ffffff");
    QColor altFill = dark ? QColor("#2c3d5e") : QColor("#eaf0fb");
    QColor noteFill = dark ? QColor("#4a4126") : QColor("#fff4c2");
    QColor noteBorder = dark ? QColor("#d8b84a") : QColor("#c9a227");
    for (int i = 0; i < actors.size(); ++i) {
        QRectF r(colX[actors[i]] - boxW / 2, 20, boxW, boxH);
        p.setPen(QPen(fg, 2));
        p.setBrush(i % 2 ? altFill : boxFill);
        p.drawRoundedRect(r, 8, 8);
        p.setPen(fg);
        p.setFont(dfont(15, true));
        p.drawText(r, Qt::AlignCenter | Qt::TextWordWrap, actorLabel[actors[i]]);
        // lifeline
        QPen lp(fg, 1.2, Qt::DashLine);
        p.setPen(lp);
        p.drawLine(QPointF(colX[actors[i]], 20 + boxH),
                   QPointF(colX[actors[i]], H - 60));
    }

    int y = 20 + boxH + 60;
    for (const SeqMsg& m : msgs) {
        if (!colX.contains(m.from) || !colX.contains(m.to)) {
            // Unknown actor: still advance the row so later lines don't overlap.
            y += rowH;
            continue;
        }
        qreal x1 = colX[m.from], x2 = colX[m.to];
        QPen pen(fg, 2.0);
        if (m.dashed) pen.setStyle(Qt::DashLine);
        p.setPen(pen);
        p.setBrush(fg);
        if (qAbs(x2 - x1) < 1) {
            // self message
            p.drawLine(QPointF(x1, y), QPointF(x1 + 46, y));
            p.drawLine(QPointF(x1 + 46, y), QPointF(x1 + 46, y + 26));
            p.drawLine(QPointF(x1 + 46, y + 26), QPointF(x1, y + 26));
            if (m.arrowHead) {
                QPolygonF head; head << QPointF(x1, y + 26) << QPointF(x1 + 12, y + 26 - 5)
                                      << QPointF(x1 + 12, y + 26 + 5);
                p.drawPolygon(head);
            }
        } else {
            p.drawLine(QPointF(x1, y), QPointF(x2, y));
            if (m.arrowHead) {
                qreal dir = x2 > x1 ? 1 : -1;
                QPolygonF head;
                head << QPointF(x2, y) << QPointF(x2 - dir * 13, y - 6) << QPointF(x2 - dir * 13, y + 6);
                p.drawPolygon(head);
            }
        }
        // text label
        if (!m.text.isEmpty()) {
            p.setFont(dfont(13));
            p.setPen(fg);
            QFontMetricsF fm(dfont(13));
            qreal cx = (x1 + x2) / 2;
            QRectF tr(cx - fm.horizontalAdvance(m.text) / 2 - 6, y - fm.height() - 4,
                      fm.horizontalAdvance(m.text) + 12, fm.height() + 2);
            p.fillRect(tr, bg);
            p.drawText(tr, Qt::AlignCenter, m.text);
        }
        y += rowH;
    }

    // Notes (parsed earlier; drawn in their own section below the messages).
    for (const QStringList& note : notes) {
        if (note.size() < 2) { y += rowH; continue; }
        const QString scope = note[0];
        const QString text = note[1];

        // Resolve actor span: "note over A,B" / "note left of A".
        QStringList ids = scope.split(QLatin1Char(','));
        qreal xMin = 0, xMax = 0;
        bool found = false;
        for (QString id : ids) {
            id = id.trimmed();
            if (!colX.contains(id)) continue;
            qreal cx = colX[id];
            if (!found) { xMin = xMax = cx; found = true; }
            else { xMin = qMin(xMin, cx); xMax = qMax(xMax, cx); }
        }
        if (!found && !actors.isEmpty()) {
            xMin = colX[actors.first()];
            xMax = colX[actors.last()];
        }
        QRectF nr(xMin - boxW / 2.0, y - 2, qMax<qreal>(boxW, xMax - xMin + boxW), 44);
        p.setPen(QPen(noteBorder, 1.6));
        p.setBrush(noteFill);
        p.drawRoundedRect(nr, 6, 6);
        p.setPen(fg);
        p.setFont(dfont(13));
        p.drawText(nr.adjusted(8, 0, -8, 0), Qt::AlignCenter | Qt::TextWordWrap, text);
        y += rowH;
    }

    p.end();
    return pm;
}

} // namespace

namespace MermaidRenderer {

bool canRender(const QString& code)
{
    for (QString l : code.split(QLatin1Char('\n'))) {
        l = l.trimmed();
        if (l.isEmpty() || l.startsWith(QStringLiteral("%%"))) continue;
        return l.startsWith(QStringLiteral("graph")) ||
               l.startsWith(QStringLiteral("flowchart")) ||
               l.startsWith(QStringLiteral("sequenceDiagram"));
    }
    return false;
}

QPixmap render(const QString& code, int maxWidth,
               const QColor& fg, const QColor& bg, bool dark)
{
    QStringList lines = code.split(QLatin1Char('\n'));
    QString kind;
    for (QString l : lines) {
        l = l.trimmed();
        if (l.isEmpty() || l.startsWith(QStringLiteral("%%"))) continue;
        kind = l;
        break;
    }

    if (kind.startsWith(QStringLiteral("sequenceDiagram")))
        return drawSequence(lines.mid(1), maxWidth, fg, bg, dark);

    if (kind.startsWith(QStringLiteral("graph")) ||
        kind.startsWith(QStringLiteral("flowchart"))) {
        Flow f;
        f.lr = kind.contains(QStringLiteral("LR")) || kind.contains(QStringLiteral("RL"));
        for (int li = 1; li < lines.size(); ++li) {
            QString l = lines[li].trimmed();
            if (l.isEmpty() || l.startsWith(QStringLiteral("%%"))) continue;
            scanFlowLine(l, f);
        }
        layoutFlow(f);
        return drawFlow(f, maxWidth, fg, bg);
    }
    return QPixmap();
}

} // namespace MermaidRenderer
