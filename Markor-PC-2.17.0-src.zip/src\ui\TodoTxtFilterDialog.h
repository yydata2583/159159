#pragma once
#include <QDialog>

class EditorWidget;
class QLineEdit;
class QCheckBox;
class QLabel;
class QComboBox;

// Todo.txt filter: filter tasks by text / +project / @context / pri: / done,
// highlight matching lines in the editor and report counts.
class TodoTxtFilterDialog : public QDialog {
    Q_OBJECT
public:
    explicit TodoTxtFilterDialog(EditorWidget* editor, QWidget* parent = nullptr);

private slots:
    void applyFilter();
    void clearFilter();
    void refreshQuickFilters();

private:
    int matchCount(const QString& expr, bool* ok);

    EditorWidget* _editor;
    QLineEdit* _expr;
    QComboBox* _quickFilters;
    QCheckBox* _caseSensitive;
    QLabel* _stats;
};
