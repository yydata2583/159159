# docs/ — 项目知识库（分层文档）

> 本目录 + 上级 `AGENTS.md` 构成项目的**完整知识库**。**全部文档由 AI 维护**（工作方式：用户提需求 → AI 写代码 → AI 更新文档）：让 AI 不必重读源码即可理解、修改、维护本项目。
> 所有内容以**当前代码**为准；发现不一致 → 修文档，并可在此追加"教训"。

## 文档地图

| 文档 | 内容 | 什么时候读 |
|---|---|---|
| [../AGENTS.md](../AGENTS.md) | AI 入口：速览、红线、架构一图、构建速查 | **每次开工先读** |
| [architecture.md](architecture.md) | 分层架构、对象图、数据流、渲染管线、滚动同步、同步子系统 | 改任何涉及数据流/渲染/同步的代码前 |
| [directory.md](directory.md) | 完整目录树 + 每个文件的职责一句话 | 找"改哪里"时 |
| [data-model.md](data-model.md) | 数据模型：TextFormat、Todo.txt 语法、QSettings 键表、内部结构体 | 改设置/格式/持久化/解析时 |
| [api-index.md](api-index.md) | 全部类/命名空间的公开 API 速查 + 典型调用路径 | 写代码需要调用现有接口时 |
| [decisions.md](decisions.md) | ADR 决策记录（为什么这样做） | 做技术选型、想推翻旧设计前 |
| [conventions.md](conventions.md) | 代码规范、菜单/快捷键全表、新增功能 checklist、构建打包 | **动手改代码前** |
| [CHANGELOG.md](CHANGELOG.md) | **需求与变更记录**（用户需求→实现追溯、答疑记录） | 每次接手先看 |
| ../BUILD.md | 开发/编译环境原始说明 | 搭环境 |
| ../FEATURE_MAP.md | 功能移植对照表（✅/🟡/🔁/➖/❌） | 判断某功能是否已实现/要不要补 |
| ../THEMES.md | 三主题配色与新增主题流程 | 改主题时 |

## 维护协议（AI 必须遵守）

**核心原则：文档是代码的影子。代码动了，影子必须跟上。**

1. **改动即更新**：一次提交里如果改了行为/接口/结构，同一个回合内更新对应文档（对照 `AGENTS.md` §7 的映射表）。
2. **决策必留痕**：任何"为什么这么改/为什么不那么改"的结论，写进 `decisions.md`，格式：
   ```
   ### ADR-0NN：标题（状态：Accepted / Superseded by ADR-0MM）
   - 背景：
   - 决策：
   - 后果：
   - 替代方案（被否决的）：
   ```
   旧 ADR 不删除；被推翻时改状态并链接新 ADR。
3. **不确定就标注**：文档里写不准的细节标 `⚠️ 待核对`，不要编造。宁可少写，不可写错。
4. **不要复制大段源码**进文档；贴签名、贴关键常量/正则/默认值，源码引用写 `文件:行号` 或 `文件 + 函数名`。
5. **教训入册**：踩过的坑写进本文档"教训/勘误"一节或 `AGENTS.md` 红线，避免下一个 AI 重蹈覆辙。
6. **范围**：知识库只描述本仓库（`Markor V2.17.0/`）；上游 Android Markor 的行为差异记在 `FEATURE_MAP.md`。

## 教训 / 勘误（历次维护追加）

- 2026-10：知识库初建（基于全量源码通读）。`third_party/webview2/` 目录在 zip 中权限位为 000，Linux 下解压后需 `chmod -R u+rwX` 才能访问。
- `build-env.ps1` 含作者本机绝对路径（用户 `Administrator`、Qt 6.8.3、MSVC 14.44.35207），**换机构建前必须改**，不是可移植脚本。
- **本容器可做编译校验**（无 Windows/显示环境）：`pip3 install --user aqtinstall` → `python3 -m aqt install-qt linux desktop 6.8.3 linux_gcc_64 --archives qtbase -O ~/qt`，再对每个 .cpp 跑 `g++ -std=c++17 -fPIC -fsyntax-only -I~/qt/6.8.3/gcc_64/include -I<各模块include> -Isrc`。不能链接/运行（缺 libGL 与显示），行为级验证需在 Windows 实机进行。
- **"路径错位"实锤**：`installer.iss` 装 `syncthing.exe` 到 `{app}\bin`，代码却只找程序根目录 → 同步引擎从未启动（18384"打不开"的主因）。已改两级查找；**改安装布局/引擎路径时两头都要看**（SyncManager::launch 的查找列表 vs installer.iss 的 [Files]）。
- `MarkdownConverter.cpp` 体量约 72KB（占源码 1/3），是自研 Markdown 解析器本体；改 Markdown 渲染行为只需动它 + `PreviewWidget::buildRichBody`，不必碰高亮器。
