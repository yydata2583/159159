#include "MarkdownConverter.h"
#include "CodeLexer.h"
#include <QHash>
#include <QRegularExpression>
#include <QSet>
#include <QStringList>
#include <QVector>

// ============================================================================
// 自研 Markdown -> HTML 转换器（CommonMark 0.31.2 + GFM 扩展合规整改）
//
// 架构（批次1确立，本轮保持不变）：
//   - 按行扫描、成块输出；每个块级标签携带 data-src-line；
//   - 同步产出 QVector<BlockInfo>，与输出块级元素顺序一一对应
//     （预览滚动映射依赖，QTextBrowser 块计数规则见各处注释）；
//   - 预览 / HTML 导出 / PDF 导出共用 PreviewWidget::buildRichBody。
//
// 合规范围：ATX/Setext 标题、围栏/缩进代码块、GFM 表格、有序/无序/嵌套/
//   松散/任务列表、行内强调（侧翼规则、intra-word _ 限制）、代码跨度、
//   反斜杠转义、自动链接、引用式链接、图片、分隔线、HTML 块透传、
//   引用定义。引用块沿用批次1的简化合并实现（不在本轮 65 场景内）。
//
// COMMONMARK-TODO（自研架构下的已知低优先级差异，详见交付报告）：
//   1. [id]: 引用定义在 Mermaid/公式分段两侧不可见（buildRichBody 分段转换）。
//   2. 引用块内部不做二次块解析（列表/代码/多段落在 > 内不递归）。
//   3. 多块级子标签的原生 HTML 块在 QTextBrowser 中块计数不可预测，
//      此时源行映射自动降级为像素/比例方式（postProcess 既有兜底）。
// ============================================================================

namespace {

// ---------------- 基础工具 ----------------

QString escapeHtml(const QString& s)
{
    QString out;
    out.reserve(s.size());
    for (const QChar& c : s) {
        switch (c.unicode()) {
        case '&': out += QStringLiteral("&amp;"); break;
        case '<': out += QStringLiteral("&lt;"); break;
        case '>': out += QStringLiteral("&gt;"); break;
        case '"': out += QStringLiteral("&quot;"); break;
        default: out += c; break;
        }
    }
    return out;
}

// 按语言给代码着色（转义 + span 包裹）；未知语言时 langKey 传空串 -> 原样转义（不分色）。
// span 仅用 CSS class 承载语义，颜色由文档级 hl-* 主题 CSS 决定。
QString highlightCodeHtml(const QString& code, const QString& langKey)
{
    const QVector<CodeLexer::Token> toks = CodeLexer::tokenize(code, langKey);
    if (toks.isEmpty())
        return escapeHtml(code);

    const auto spanClass = [](CodeLexer::TokenType t) -> const char* {
        switch (t) {
        case CodeLexer::TokenType::Keyword:      return "hl-kw";
        case CodeLexer::TokenType::Type:         return "hl-ty";
        case CodeLexer::TokenType::Function:     return "hl-fn";
        case CodeLexer::TokenType::String:       return "hl-st";
        case CodeLexer::TokenType::Comment:      return "hl-cm";
        case CodeLexer::TokenType::Number:       return "hl-nu";
        case CodeLexer::TokenType::Operator:     return "hl-op";
        case CodeLexer::TokenType::Preprocessor: return "hl-pp";
        case CodeLexer::TokenType::Tag:          return "hl-tag";
        case CodeLexer::TokenType::Attribute:    return "hl-at";
        case CodeLexer::TokenType::Value:        return "hl-val";
        case CodeLexer::TokenType::Punctuation:  return "hl-pn";
        case CodeLexer::TokenType::Plain:        return nullptr;
        }
        return nullptr;
    };

    QString out;
    out.reserve(code.size() + code.size() / 4);
    int pos = 0;
    for (const CodeLexer::Token& t : toks) {
        // 补齐 token 之间的空隙（HTML 语言中 '<' 等未被切分的字符）并转义
        if (t.start > pos)
            out += escapeHtml(code.mid(pos, t.start - pos));
        const QString piece = escapeHtml(code.mid(t.start, t.length));
        const char* cls = spanClass(t.type);
        if (!cls)
            out += piece;                                   // Plain 直接输出
        else
            out += QStringLiteral("<span class=\"%1\">%2</span>")
                       .arg(QString::fromLatin1(cls), piece);
        pos = t.start + t.length;
    }
    if (pos < code.size())
        out += escapeHtml(code.mid(pos));
    return out;
}

// 前导空白列数：空格计 1 列，Tab 按 4 列制表位补齐
int indentColumns(const QString& s)
{
    int col = 0;
    for (const QChar& c : s) {
        if (c == QLatin1Char(' ')) ++col;
        else if (c == QLatin1Char('\t')) col += 4 - (col % 4);
        else break;
    }
    return col;
}

// 删除前导至多 cols 列空白（用于列表项内容列切片），返回剩余正文
QString removeIndentColumns(const QString& s, int cols)
{
    int col = 0, i = 0;
    for (; i < s.size(); ++i) {
        if (col >= cols) break;
        if (s[i] == QLatin1Char(' ')) ++col;
        else if (s[i] == QLatin1Char('\t')) col += 4 - (col % 4);
        else break;
    }
    return s.mid(i);
}

// 从第 cols 列起截取剩余正文（列按 Tab=4 制表位展开）。
// 与 removeIndentColumns 的区别：本函数按列号硬切，用于"前 cols 列是
// 列表标记+空白"的首行内容切片（如 "1. a" 的 contentCol=3 → "a"）。
// removeIndentColumns 只切空白，遇到标记字符会原地返回，首行场景
// 会把整行标记原样留在 body 里，递归解析时造成无限递归（栈溢出）。
QString sliceFromColumn(const QString& s, int cols)
{
    int col = 0, i = 0;
    for (; i < s.size(); ++i) {
        if (col >= cols) break;
        if (s[i] == QLatin1Char('\t')) col += 4 - (col % 4);
        else ++col;
    }
    return s.mid(i);
}

bool isBlank(const QString& s) { return s.trimmed().isEmpty(); }

// ---------------- 引用定义 ----------------

struct RefDef { QString url; QString title; };

// 引用定义语法：[id]: 目标 ["标题"]（目标可由 <> 包裹）
bool parseRefDef(const QString& line, QString& id, RefDef& def)
{
    static const QRegularExpression re(QStringLiteral(
        "^ {0,3}\\[([^\\[\\]]{1,999})\\]:[ \\t]*"
        "(?:<([^\\s>]+)>|(\\S+))"
        "(?:[ \\t]+[\"'(]([^\"')]+)[\"')])?[ \\t]*$"));
    const QRegularExpressionMatch m = re.match(line);
    if (!m.hasMatch()) return false;
    id = m.captured(1).toLower();
    def.url = m.captured(2).isEmpty() ? m.captured(3) : m.captured(2);
    def.title = m.captured(4);
    return true;
}

// ---------------- 行内解析 ----------------
//
// 占位符约定（控制字符不会出现在正文中）：
//   \x01 n \x02  惰性片段（代码跨度、转义字符、图片、裸标签、普通URL…）
//   \x03 n \x04  链接开标签 <a ...>   \x05 n \x06  链接闭标签 </a>
//   \x0B 软换行点  \x0C 硬换行点
// 后续强调扫描无法进入占位符，故不会污染 href/代码内容。

QChar STX = QLatin1Char('\x01'), ETX = QLatin1Char('\x02');
QChar SOX = QLatin1Char('\x03'), EOX = QLatin1Char('\x04');
QChar SCX = QLatin1Char('\x05'), ECX = QLatin1Char('\x06');

struct InlineParser {
    QString s;                       // 工作串
    QStringList holds;               // 惰性片段
    QStringList anchorOpen;          // <a ...>
    QStringList anchorClose;         // </a>
    const QHash<QString, RefDef>* refs = nullptr;
    bool softBreaks = true;

    QString hold(const QString& html)
    {
        const QString ph = QStringLiteral("\x01%1\x02").arg(holds.size());
        holds << html;
        return ph;
    }

    // 跳过占位符，返回占位符之后的位置（pos 位于控制字符上时）
    int skipPlaceholder(int pos) const
    {
        if (pos >= s.size()) return pos;
        const QChar c = s[pos];
        if (c == STX || c == SOX || c == SCX) {
            const QChar end = (c == STX) ? ETX : (c == SOX ? EOX : ECX);
            int k = pos + 1;
            while (k < s.size() && s[k] != end) ++k;
            return qMin(k + 1, s.size());
        }
        return pos;
    }
    int prevCharPos(int pos) const   // pos 之前首个有效字符
    {
        int p = pos - 1;
        while (p >= 0) {
            const QChar c = s[p];
            if (c == ETX || c == EOX || c == ECX) {
                while (p >= 0 && s[p] != STX && s[p] != SOX && s[p] != SCX) --p;
                --p;
                continue;
            }
            if (c == STX || c == SOX || c == SCX) { --p; continue; }
            return p;
        }
        return -1;
    }
    int nextCharPos(int pos) const
    {
        int p = pos;
        while (p < s.size()) {
            const QChar c = s[p];
            if (c == STX || c == SOX || c == SCX) { p = skipPlaceholder(p); continue; }
            if (c == ETX || c == EOX || c == ECX) { ++p; continue; }
            return p;
        }
        return -1;
    }

    // 代码跨度：反引号串等长定界；内容换行→空格；首尾各一个空格的剥离规则
    void extractCodeSpans()
    {
        QString out;
        int i = 0;
        while (i < s.size()) {
            if (s[i] != QLatin1Char('`')) { out += s[i++]; continue; }
            int n = 0;
            while (i + n < s.size() && s[i + n] == QLatin1Char('`')) ++n;
            int j = i + n, close = -1;
            while (j < s.size()) {
                if (s[j] == QLatin1Char('`')) {
                    int m = 0;
                    while (j + m < s.size() && s[j + m] == QLatin1Char('`')) ++m;
                    if (m == n) { close = j; break; }
                    j += m;
                } else ++j;
            }
            if (close < 0) { out += s.mid(i, n); i += n; continue; }
            QString code = s.mid(i + n, close - i - n);
            code.replace(QLatin1Char('\x0B'), QStringLiteral(" "));
            code.replace(QLatin1Char('\x0C'), QStringLiteral(" "));
            if (code.size() >= 2 && code.startsWith(QLatin1Char(' '))
                && code.endsWith(QLatin1Char(' '))
                && code.trimmed().size() > 0)
                code = code.mid(1, code.size() - 2);
            out += hold(QStringLiteral("<code>%1</code>").arg(code));
            i = close + n;
        }
        s = out;
    }

    // 反斜杠转义：CommonMark 可转义 ASCII 标点集合
    void extractEscapes()
    {
        static const QString punct = QStringLiteral(
            "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~");
        QString out;
        int i = 0;
        while (i < s.size()) {
            if (s[i] == QLatin1Char('\\') && i + 1 < s.size()
                && punct.contains(s[i + 1])) {
                out += hold(QString(s[i + 1]));
                i += 2;
            } else {
                out += s[i++];
            }
        }
        s = out;
    }

    // 自动链接 <http://...> / <mail@x>，以及其余裸 HTML 标签/注释
    void extractAutoLinksAndTags()
    {
        QString out;
        int i = 0;
        static const QRegularExpression uriRe(QStringLiteral(
            "^[A-Za-z][A-Za-z0-9+.-]{1,31}://[^<>\\s]+>"));
        static const QRegularExpression mailRe(QStringLiteral(
            "^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)+>"));
        static const QRegularExpression tagRe(QStringLiteral(
            "^/?[A-Za-z][A-Za-z0-9-]*(?:\\s+[^<>]*)?\\s*/?>"));
        while (i < s.size()) {
            if (s[i] != QLatin1Char('<')) { out += s[i++]; continue; }
            const QString tail = s.mid(i + 1);
            QRegularExpressionMatch m;
            if ((m = uriRe.match(tail)).hasMatch()) {
                QString url = m.captured(0); url.chop(1);
                out += hold(QStringLiteral("<a href=\"%1\">%1</a>").arg(url));
                i += m.capturedLength() + 1;
            } else if ((m = mailRe.match(tail)).hasMatch()) {
                QString addr = m.captured(0); addr.chop(1);
                out += hold(QStringLiteral("<a href=\"mailto:%1\">%1</a>").arg(addr));
                i += m.capturedLength() + 1;
            } else if (tail.startsWith(QStringLiteral("<!--"))) {
                int k = tail.indexOf(QStringLiteral("-->"), 4);
                if (k >= 0) { out += hold(QString()); i += k + 7; }
                else { out += s[i++]; }
            } else if ((m = tagRe.match(tail)).hasMatch()) {
                out += hold(QLatin1Char('<') + m.captured(0));
                i += m.capturedLength() + 1;
            } else {
                out += s[i++];
            }
        }
        s = out;
    }

    // 解析起点 ( 处的链接目标：返回 ) 后位置，失败返回 -1
    int parseLinkDestParen(int openParen, QString& dest, QString& title)
    {
        int depth = 1, j = openParen + 1;
        while (j < s.size() && depth > 0) {
            const QChar c = s[j];
            if (c == QLatin1Char('\\') && j + 1 < s.size()) { j += 2; continue; }
            if (c == STX) { j = skipPlaceholder(j); continue; }
            if (c == QLatin1Char('(')) ++depth;
            else if (c == QLatin1Char(')')) { --depth; if (depth == 0) break; }
            ++j;
        }
        if (depth != 0 || j >= s.size()) return -1;
        QString inner = s.mid(openParen + 1, j - openParen - 1).trimmed();
        // title：首个空白之后的引号片段
        int ws = -1;
        for (int k = 0; k < inner.size(); ++k) {
            if (inner[k].isSpace()) { ws = k; break; }
        }
        if (ws > 0) {
            dest = inner.left(ws);
            QString t = inner.mid(ws + 1).trimmed();
            if (t.size() >= 2 &&
                ((t.front() == QLatin1Char('"') && t.back() == QLatin1Char('"'))
                 || (t.front() == QLatin1Char('\'') && t.back() == QLatin1Char('\''))
                 || (t.front() == QLatin1Char('(') && t.back() == QLatin1Char(')'))))
                title = t.mid(1, t.size() - 2);
        } else {
            dest = inner;
        }
        if (dest.size() >= 2 && dest.startsWith(QLatin1Char('<'))
            && dest.endsWith(QLatin1Char('>')))
            dest = dest.mid(1, dest.size() - 2);
        return j + 1;
    }

    // 图片 ![alt](dest "title")（先于文字链接处理）
    void extractImages()
    {
        static const QRegularExpression imgRe(QStringLiteral(
            "^\\[([^\\[\\]]*)\\]\\(\\s*"
            "(?:<([^>\\s]+)>|([^\\s()]+(?:\\([^()\\s]*\\)[^\\s()]*)*))"
            "(?:\\s+[\"']([^\"']*)[\"'])?\\s*\\)"));
        QString out;
        int i = 0;
        while (i < s.size()) {
            if (s[i] != QLatin1Char('!')) { out += s[i++]; continue; }
            const QRegularExpressionMatch m = imgRe.match(s.mid(i + 1));
            if (m.hasMatch()) {
                const QString alt = m.captured(1);
                const QString src = m.captured(2).isEmpty() ? m.captured(3) : m.captured(2);
                const QString title = m.captured(4);
                // 加载失败时以 alt 文本替换（浏览器导出）；QTextBrowser 忽略该属性
                out += hold(QStringLiteral(
                    "<img src=\"%1\" alt=\"%2\"%3 "
                    "onerror=\"this.replaceWith(document.createTextNode(this.alt||''));\">")
                    .arg(src, alt,
                         title.isEmpty() ? QString()
                                         : QStringLiteral(" title=\"%1\"").arg(title)));
                i += 1 + m.capturedLength();
            } else {
                out += s[i++];
            }
        }
        s = out;
    }

    // 行内链接 [t](u "t") / [t][id] / [t][] / [id]，未定义引用保持原文
    void extractLinks()
    {
        int i = 0;
        while (i < s.size()) {
            if (s[i] != QLatin1Char('[')) { ++i; continue; }
            // 方括号配对（允许一层嵌套），记录文字结束 ]
            int depth = 1, rb = -1, j = i + 1;
            while (j < s.size()) {
                const QChar c = s[j];
                if (c == STX) { j = skipPlaceholder(j); continue; }
                if (c == QLatin1Char('[')) ++depth;
                else if (c == QLatin1Char(']')) { --depth; if (depth == 0) { rb = j; break; } }
                ++j;
            }
            if (rb < 0) { ++i; continue; }
            const int after = rb + 1;

            // [text](inline)
            if (after < s.size() && s[after] == QLatin1Char('(')) {
                QString dest, title;
                int end = parseLinkDestParen(after, dest, title);
                if (end >= 0 && !dest.isEmpty()) {
                    const int oi = anchorOpen.size();
                    anchorOpen << QStringLiteral("<a href=\"%1\"%2>")
                        .arg(dest,
                             title.isEmpty() ? QString()
                                             : QStringLiteral(" title=\"%1\"").arg(title));
                    anchorClose << QStringLiteral("</a>");
                    s = s.left(i) + QStringLiteral("\x03%1\x04").arg(oi)
                        + s.mid(i + 1, rb - i - 1)
                        + QStringLiteral("\x05%1\x06").arg(oi) + s.mid(end);
                    i += 3 + QString::number(oi).size() * 2;
                    continue;
                }
            }

            // [text][id] / [text][] / [id]
            QString refId;
            int consumed = 0;
            if (after < s.size() && s[after] == QLatin1Char('[')) {
                int k = after + 1;
                while (k < s.size() && s[k] != QLatin1Char(']')) ++k;
                if (k < s.size()) {
                    refId = s.mid(after + 1, k - after - 1).trimmed();
                    consumed = k - i + 1;
                }
            }
            if (!consumed) {
                // 仅当 [id] 整体可作为已定义的简短引用时才成立
                refId = s.mid(i + 1, rb - i - 1).trimmed();
                consumed = after - i;
            }
            if (consumed && refs) {
                const QString key = (refId.isEmpty()
                    ? s.mid(i + 1, rb - i - 1).trimmed() : refId).toLower();
                auto it = refs->constFind(key);
                if (it != refs->constEnd() && !it->url.isEmpty()) {
                    const int oi = anchorOpen.size();
                    anchorOpen << QStringLiteral("<a href=\"%1\"%2>")
                        .arg(it->url,
                             it->title.isEmpty()
                                 ? QString()
                                 : QStringLiteral(" title=\"%1\"").arg(it->title));
                    anchorClose << QStringLiteral("</a>");
                    s = s.left(i) + QStringLiteral("\x03%1\x04").arg(oi)
                        + s.mid(i + 1, rb - i - 1)
                        + QStringLiteral("\x05%1\x06").arg(oi) + s.mid(i + consumed);
                    i += 3 + QString::number(oi).size() * 2;
                    continue;
                }
            }
            ++i;
        }
    }

    // GFM 之外的宽松扩展：裸 URL 自动成链（占位符之外，href 不会被波及）
    void linkifyPlainUrls()
    {
        static const QRegularExpression urlRe(QStringLiteral(
            "(?<![A-Za-z0-9@.])(?:https?|ftp)://[^\\s<]+"));
        QRegularExpressionMatchIterator it = urlRe.globalMatch(s);
        QString out;
        int last = 0;
        while (it.hasNext()) {
            const QRegularExpressionMatch m = it.next();
            int end = m.capturedEnd();
            while (end > m.capturedStart()
                   && QStringLiteral(".,!?;:").contains(s[end - 1]))
                --end;
            if (end == m.capturedStart()) { continue; }
            out += s.mid(last, m.capturedStart() - last);
            const QString url = s.mid(m.capturedStart(), end - m.capturedStart());
            out += hold(QStringLiteral("<a href=\"%1\">%1</a>").arg(url));
            if (end < m.capturedEnd()) out += s.mid(end, m.capturedEnd() - end);
            last = m.capturedEnd();
        }
        out += s.mid(last);
        s = out;
    }

    // ---------------- 强调 / 加粗 / 删除线（CommonMark 侧翼规则） ----------------

    struct DNode {
        bool delim = false;
        QString text;             // 普通文本
        QChar ch;                 // 定界符字符
        int len = 0;              // 定界符长度
        bool canOpen = false, canClose = false;
        int used = 0;
        QStringList openTags;     // 命中后在定界符处输出的开标签
        QStringList closeTags;    // 闭标签（输出时逆序）
    };

    static bool wsP(QChar c) { return c.isSpace() || c == QLatin1Char('\x0B')
                                    || c == QLatin1Char('\x0C'); }

    void applyEmphasis()
    {
        // 切分普通文本 / 定界符游程（跳过占位符）
        QVector<DNode> nodes;
        int i = 0;
        QString text;
        auto flushText = [&]() {
            if (!text.isEmpty()) { nodes << DNode{}; nodes.last().text = text; text.clear(); }
        };
        while (i < s.size()) {
            const QChar c = s[i];
            if (c == STX || c == SOX || c == SCX) {
                text += s.mid(i, skipPlaceholder(i) - i);
                i = skipPlaceholder(i);
                continue;
            }
            if (c == QLatin1Char('*') || c == QLatin1Char('_')
                || c == QLatin1Char('~')) {
                int n = 0;
                while (i + n < s.size() && s[i + n] == c) ++n;
                if (c == QLatin1Char('~') && n < 2) { text += QString(n, c); i += n; continue; }
                const int p = prevCharPos(i), q = nextCharPos(i + n);
                const QChar pc = p >= 0 ? s[p] : QChar();
                const QChar qc = q >= 0 ? s[q] : QChar();
                const bool prevWs = p < 0 || wsP(pc);
                const bool nextWs = q < 0 || wsP(qc);
                const bool prevPunct = p >= 0 && pc.isPunct();
                const bool nextPunct = q >= 0 && qc.isPunct();
                const bool leftFlank = !nextWs && (!nextPunct || prevWs || prevPunct);
                const bool rightFlank = !prevWs && (!prevPunct || nextWs || nextPunct);
                flushText();
                DNode d; d.delim = true; d.ch = c; d.len = n;
                if (c == QLatin1Char('_')) {
                    d.canOpen = leftFlank && !rightFlank;
                    d.canClose = rightFlank && !leftFlank;
                } else if (c == QLatin1Char('~')) {
                    d.canOpen = leftFlank; d.canClose = rightFlank;
                } else {
                    d.canOpen = leftFlank; d.canClose = rightFlank;
                }
                nodes << d;
                i += n;
            } else {
                text += c;
                ++i;
            }
        }
        flushText();

        // 就近向后配对（保证嵌套正确）；~~ 固定消耗 2，** 优先 2，其余 1
        bool changed = true;
        while (changed) {
            changed = false;
            for (int ci = 0; ci < nodes.size(); ++ci) {
                DNode& cn = nodes[ci];
                if (!cn.delim || !cn.canClose || cn.used >= cn.len) continue;
                for (int oi = ci - 1; oi >= 0; --oi) {
                    DNode& on = nodes[oi];
                    if (!on.delim || !on.canOpen || on.used >= on.len
                        || on.ch != cn.ch) continue;
                    const bool strong = (cn.ch == QLatin1Char('~'))
                        || (cn.len - cn.used >= 2 && on.len - on.used >= 2);
                    const int need = strong ? 2 : 1;
                    if (on.len - on.used < need || cn.len - cn.used < need) continue;
                    QString open, close;
                    if (cn.ch == QLatin1Char('~')) { open = "<del>"; close = "</del>"; }
                    else if (strong) { open = "<strong>"; close = "</strong>"; }
                    else { open = "<em>"; close = "</em>"; }
                    on.used += need; cn.used += need;
                    on.openTags << open;
                    cn.closeTags << close;
                    changed = true;
                    break;
                }
            }
        }

        QString out;
        for (const DNode& d : nodes) {
            if (!d.delim) { out += d.text; continue; }
            // 未消耗的定界符原样输出；部分消耗（*** 等）剩余星号留在标签外侧
            const int remain = d.len - d.used;
            if (remain > 0) out += QString(remain, d.ch);
            for (const QString& t : d.openTags) out += t;
            for (int k = d.closeTags.size() - 1; k >= 0; --k) out += d.closeTags[k];
        }
        s = out;
    }

    QString finish()
    {
        // 链接开/闭占位符
        for (int i = anchorOpen.size() - 1; i >= 0; --i) {
            s.replace(QStringLiteral("\x05%1\x06").arg(i), anchorClose[i]);
            s.replace(QStringLiteral("\x03%1\x04").arg(i), anchorOpen[i]);
        }
        // 惰性片段
        for (int i = holds.size() - 1; i >= 0; --i)
            s.replace(QStringLiteral("\x01%1\x02").arg(i), holds[i]);
        // 换行点：硬换行恒为 <br>；软换行视开关
        s.replace(QLatin1Char('\x0C'), QStringLiteral("<br>"));
        s.replace(QLatin1Char('\x0B'),
                  softBreaks ? QStringLiteral("<br>") : QStringLiteral(" "));
        return s;
    }

    QString run()
    {
        extractCodeSpans();
        extractEscapes();
        extractAutoLinksAndTags();
        extractImages();
        extractLinks();
        linkifyPlainUrls();
        applyEmphasis();
        return finish();
    }
};

QString convertInline(const QString& in, bool softBreaks,
                      const QHash<QString, RefDef>& refs)
{
    InlineParser p;
    p.s = escapeHtml(in);
    p.softBreaks = softBreaks;
    p.refs = &refs;
    return p.run();
}

// ---------------- 块级解析 ----------------

struct Ln {
    QString text;   // 原文（仅去除行尾 \r）
    int no = 0;     // 在本次转换输入中的 1 起行号
};

struct ListItem {
    int startLine = 0;
    int contentCol = 0;
    QChar delim;            // '-' '*' '+' '.' ')'
    bool ordered = false;
    int orderStart = 1;
    bool task = false;
    bool taskChecked = false;
    QVector<Ln> body;
};

using MarkdownConverter::BlockInfo;

class Parser {
public:
    Parser(const MarkdownConverter::ConvertOptions& options,
           QVector<MarkdownConverter::BlockInfo>* blocks)
        : _options(options), _blocks(blocks) {}

    // 预扫描：收集行外的 [id]: 定义（忽略围栏代码块内文本）
    void collectRefs(const QVector<Ln>& lines)
    {
        QChar fenceChar;
        int fenceLen = 0;
        for (const Ln& ln : lines) {
            int fc = 0;
            while (fc < ln.text.size() && ln.text[fc] == QLatin1Char(' ')) ++fc;
            if (fc <= 3 && fc < ln.text.size()
                && (ln.text[fc] == QLatin1Char('`') || ln.text[fc] == QLatin1Char('~'))) {
                int n = 0;
                while (fc + n < ln.text.size() && ln.text[fc + n] == ln.text[fc]) ++n;
                const QString rest = ln.text.mid(fc + n).trimmed();
                if (n >= 3 && (ln.text[fc] == QLatin1Char('~')
                               || !rest.contains(QLatin1Char('`')))) {
                    if (fenceLen > 0 && ln.text[fc] == fenceChar
                        && n >= fenceLen) {
                        // 闭合位同字符且不短于开围栏即闭合（允许尾随空格；
                        // 带语言标注的非标准写法也算闭合，由编辑器 lint 另行警告；
                        // 闭合位之后再含反引号的行已被上方外层条件排除，不会到此）
                        fenceLen = 0;
                    } else if (fenceLen == 0) {
                        fenceChar = ln.text[fc];
                        fenceLen = n;
                    }
                    continue;
                }
            }
            if (fenceLen > 0) continue;
            QString id; RefDef def;
            if (parseRefDef(ln.text, id, def)) _refs.insert(id, def);
        }
    }

    // 渲染若干行；tight=true 时直接段落不输出 <p>（紧凑列表项内容）
    QString render(const QVector<Ln>& lines, bool tight)
    {
        // 递归深度防御：render ↔ renderList（列表项 body）互调递归，
        // 深度=列表/引用嵌套深度，正常输入远低于此；超限兜底返回空，
        // 防止畸形输入造成栈溢出闪退
        static int s_depth = 0;
        struct DepthGuard {
            bool ok;
            DepthGuard() : ok(++s_depth <= 100) {}
            ~DepthGuard() { --s_depth; }
        } guard;
        if (!guard.ok)
            return QString();

        QString html;
        QStringList para;          // 段落缓冲（行原文 trim 后）
        QStringList paraRaw;       // 段落缓冲（行原文，用于判断硬换行）
        QList<int> paraNos;        // 段落各行在本次转换输入中的 1 起行号
        int paraStart = 0;

        // 行末硬换行（反斜杠）判定：仅奇数个反斜杠收尾时最后一个为硬换行
        // 转义；偶数个（如 \\）是转义出来的字面反斜杠，不构成硬换行。
        auto endsHardBackslash = [](const QString& raw) {
            const QString t = raw.trimmed();
            int n = 0;
            while (n < t.size()
                   && t[t.size() - 1 - n] == QLatin1Char('\\')) ++n;
            return n > 0 && (n % 2) == 1;
        };

        auto flushPara = [&]() {
            if (para.isEmpty()) return;
            // 用 \x0B/\x0C 连接后一次性行内解析（强调可跨软换行、不跨段落）
            QString joined;
            for (int k = 0; k < para.size(); ++k) {
                if (k > 0) {
                    const QString& prev = paraRaw[k - 1];
                    const bool hardTwoSpaces =
                        prev.size() >= 2
                        && prev[prev.size() - 1] == QLatin1Char(' ')
                        && prev[prev.size() - 2] == QLatin1Char(' ');
                    joined += (hardTwoSpaces || endsHardBackslash(prev))
                                  ? QLatin1Char('\x0C') : QLatin1Char('\x0B');
                }
                QString cur = para[k];
                // 行末反斜杠为硬换行标记：该反斜杠本身不输出
                if (k + 1 < para.size() && endsHardBackslash(paraRaw[k]))
                    cur.chop(1);
                joined += cur;
            }
            if (tight) {
                html += convertInline(joined, _options.softBreaks, _refs);
                // 紧凑段落与 <li> 共用同一个 QTextBlock，不追加 BlockInfo
            } else {
                html += QStringLiteral("<p data-src-line=\"%1\">%2</p>\n")
                            .arg(paraStart)
                            .arg(convertInline(joined, _options.softBreaks, _refs));
                addBlock(BlockInfo(paraStart, paraNos.last(), BlockInfo::Paragraph));
            }
            para.clear();
            paraRaw.clear();
            paraNos.clear();
        };

        int i = 0;
        while (i < lines.size()) {
            const Ln cur = lines[i];
            const QString& line = cur.text;
            const int ind = indentColumns(line);
            const QString trimmed = line.trimmed();

            // ---- 围栏代码块（``` 与 ~~~，允许 ≤3 空格缩进）----
            int fc = 0;
            while (fc < line.size() && line[fc] == QLatin1Char(' ')) ++fc;
            if (fc <= 3 && fc < line.size()
                && (line[fc] == QLatin1Char('`') || line[fc] == QLatin1Char('~'))) {
                int n = 0;
                while (fc + n < line.size() && line[fc + n] == line[fc]) ++n;
                const QString rest = line.mid(fc + n).trimmed();
                if (n >= 3 && (line[fc] == QLatin1Char('~')
                               || !rest.contains(QLatin1Char('`')))) {
                    flushPara();
                    const QChar ch = line[fc];
                    const int fenceLen = n;
                    const int openInd = fc;
                    int j = i + 1, close = -1;
                    while (j < lines.size()) {
                        const QString& l2 = lines[j].text;
                        int c2 = 0;
                        while (c2 < l2.size() && l2[c2] == QLatin1Char(' ')) ++c2;
                        if (c2 <= 3 && c2 < l2.size() && l2[c2] == ch) {
                            int m2 = 0;
                            while (c2 + m2 < l2.size() && l2[c2 + m2] == ch) ++m2;
                            // 闭合位同字符且不短于开围栏即闭合（允许尾随空格；
                            // 带语言标注的非标准写法也算闭合，由编辑器 lint 警告；
                            // 闭合位之后再含反引号则不是闭合，与编辑器 lint 判定一致）
                            if (m2 >= fenceLen
                                && (ch != QLatin1Char('`')
                                    || !l2.mid(c2 + m2).contains(QLatin1Char('`')))) {
                                close = j; break;
                            }
                        }
                        ++j;
                    }
                    const int end = close >= 0 ? close : lines.size();
                    QStringList code;
                    code.reserve(end - i - 1);
                    for (int k = i + 1; k < end; ++k) {
                        QString c = lines[k].text;
                        // 开围栏有缩进时，整块内容统一去除该缩进
                        if (openInd > 0 && !isBlank(c) && indentColumns(c) >= openInd)
                            c = removeIndentColumns(c, openInd);
                        code << c;
                    }
                    while (!code.isEmpty() && isBlank(code.last())) code.removeLast();
                    while (!code.isEmpty() && isBlank(code.first())) code.removeFirst();
                    const QString lang = rest.section(QLatin1Char(' '), 0, 0);
                    const QString classAttr =
                        (lang.isEmpty()
                         ? QString()
                         : QStringLiteral(" class=\"language-%1\"").arg(escapeHtml(lang)));
                    // 围栏代码块：按语言词法着色（未知语言 -> 仅转义）
                    const QString codeHtml =
                        highlightCodeHtml(code.join(QLatin1Char('\n')),
                                          CodeLexer::detectLanguage(lang));
                    html += QStringLiteral("<pre data-src-line=\"%1\">"
                                           "<code%2>%3</code></pre>\n")
                                .arg(cur.no)
                                .arg(classAttr, codeHtml);
                    addBlock(BlockInfo(cur.no,
                                       close >= 0 ? close + 1 : lines.size(),
                                       BlockInfo::Code));
                    i = close >= 0 ? close + 1 : lines.size();
                    continue;
                }
            }

            // ---- 空行 ----
            if (trimmed.isEmpty()) {
                flushPara();
                ++i;
                continue;
            }

            // ---- ATX 标题（# 后须为空白或行尾；空标题合法）----
            if (ind <= 3) {
                int hp = ind, level = 0;
                while (hp < line.size() && line[hp] == QLatin1Char('#')) { ++level; ++hp; }
                if (level >= 1 && level <= 6
                    && (hp >= line.size() || line[hp].isSpace())) {
                    flushPara();
                    QString head = line.mid(hp);
                    // 开头序列之后至多 3 个空白是分隔，不计入标题文本
                    int ls = 0;
                    while (ls < head.size() && ls < 3
                           && head[ls].isSpace()) ++ls;
                    head = head.mid(ls).trimmed();
                    // 行末闭合 # 序列：前面必须有空白；若内容本身为空，
                    // 整串 #（如 "# ###"）也作为闭合序列，标题为空
                    static const QRegularExpression onlyHashRe(
                        QStringLiteral("^#+[ \\t]*$"));
                    static const QRegularExpression closeRe(QStringLiteral(
                        "[ \\t]+#+[ \\t]*$"));
                    if (onlyHashRe.match(head).hasMatch())
                        head.clear();
                    else
                        head.remove(closeRe);
                    const QString slug = slugFor(head);
                    html += QStringLiteral("<h%1 id=\"%2\" data-src-line=\"%3\">"
                                           "<a name=\"%2\"></a>%4</h%1>\n")
                                .arg(level).arg(slug).arg(cur.no)
                                .arg(convertInline(head, _options.softBreaks, _refs));
                    addBlock(BlockInfo::heading(cur.no, cur.no, level, head, slug));
                    ++i;
                    continue;
                }
            }

            // ---- Setext 下划线（紧邻段落、无空行；优先级高于 hr）----
            // 下划线行为 ≤3 空格缩进 + 一个或多个相同的 = 或 -（允许尾随空白）
            if (!para.isEmpty() && ind <= 3) {
                const QString underline = line.mid(ind).trimmed();
                bool validUnderline = !underline.isEmpty();
                for (QChar uc : underline)
                    if (uc != underline[0]) { validUnderline = false; break; }
                if (validUnderline
                    && (underline[0] == QLatin1Char('=')
                        || underline[0] == QLatin1Char('-'))) {
                    const int level = (underline[0] == QLatin1Char('=')) ? 1 : 2;
                    QString joined;
                    for (int k = 0; k < para.size(); ++k) {
                        if (k > 0) joined += QLatin1Char('\x0B');
                        joined += para[k];
                    }
                    const QString slug = slugFor(joined);
                    html += QStringLiteral("<h%1 id=\"%2\" data-src-line=\"%3\">"
                                           "<a name=\"%2\"></a>%4</h%1>\n")
                                .arg(level).arg(slug).arg(paraStart)
                                .arg(convertInline(joined, _options.softBreaks, _refs));
                    addBlock(BlockInfo::heading(
                        paraStart, cur.no, level,
                        QString(joined).replace(QLatin1Char('\x0B'), QChar::Space),
                        slug));
                    para.clear();
                    paraRaw.clear();
                    paraNos.clear();
                    ++i;
                    continue;
                }
            }

            // ---- 分隔线：同字符 ≥3，仅夹空白；≤3 空格缩进 ----
            if (ind <= 3 && isHrLine(line)) {
                flushPara();
                html += QStringLiteral("<hr data-src-line=\"%1\">\n").arg(cur.no);
                addBlock(BlockInfo(cur.no, cur.no, BlockInfo::Hr));
                ++i;
                continue;
            }

            // ---- HTML 块 / HTML 注释（透传，块内 Markdown 不解析）----
            if (ind <= 3) {
                int htmlEnd = -1;
                bool isComment = false;
                if (line.mid(ind).startsWith(QStringLiteral("<!--"))) {
                    isComment = true;
                    int j = i;
                    while (j < lines.size() && !lines[j].text.contains(QStringLiteral("-->")))
                        ++j;
                    htmlEnd = qMin(j + 1, lines.size());
                    // 注释结束后若紧跟非空行，CM 仍按空行结束；此处至少消费注释行
                } else if (startsBlockHtmlTag(line.mid(ind))) {
                    int j = i + 1;
                    while (j < lines.size() && !isBlank(lines[j].text)) ++j;
                    htmlEnd = j;
                }
                if (htmlEnd >= 0) {
                    flushPara();
                    QString raw;
                    for (int k = i; k < htmlEnd; ++k) {
                        if (k > i) raw += isComment ? QLatin1Char(' ') : QLatin1Char('\n');
                        raw += lines[k].text.trimmed();
                    }
                    if (isComment) {
                        // 注释在输出源码中保留、画面不可见；不产生块/BlockInfo
                        html += raw + QLatin1Char('\n');
                    } else {
                        // data-src-line 注入首标签；<table> 映射为 QTextTable
                        const bool tableTag = line.mid(ind)
                            .contains(QRegularExpression(QStringLiteral("^<table(?=[\\s>/])"),
                                                        QRegularExpression::CaseInsensitiveOption));
                        const int gt = raw.indexOf(QLatin1Char('>'));
                        if (gt >= 0)
                            raw.insert(gt, QStringLiteral(" data-src-line=\"%1\"").arg(cur.no));
                        html += raw + QLatin1Char('\n');
                        addBlock(BlockInfo(cur.no, lines[htmlEnd - 1].no,
                                           tableTag ? BlockInfo::Table
                                                    : BlockInfo::Paragraph));
                    }
                    i = htmlEnd;
                    continue;
                }
            }

            // ---- 引用块（简化：连续 > 行合并为单块，软换行连接）----
            if (ind <= 3 && trimmed.startsWith(QLatin1Char('>'))) {
                flushPara();
                struct Q { int depth; QString text; };
                QVector<Q> qs;
                int j = i;
                for (; j < lines.size(); ++j) {
                    const QString t = lines[j].text.trimmed();
                    if (!t.startsWith(QLatin1Char('>'))) break;
                    int depth = 0, k = 0;
                    while (k < t.size() && t[k] == QLatin1Char('>')) { ++depth; ++k; }
                    if (k < t.size() && t[k] == QLatin1Char(' ')) ++k;
                    qs.append({ depth, t.mid(k) });
                }
                html += QStringLiteral("<blockquote data-src-line=\"%1\">").arg(cur.no);
                int curDepth = 1;
                for (int qi = 0; qi < qs.size(); ++qi) {
                    const int d = qMax(1, qs[qi].depth);
                    if (qi > 0) {
                        while (curDepth > d) { html += QStringLiteral("</blockquote>"); --curDepth; }
                        while (curDepth < d) { html += QStringLiteral("<blockquote>"); ++curDepth; }
                        html += _options.softBreaks ? QStringLiteral("<br>\n")
                                                    : QStringLiteral(" ");
                    }
                    html += convertInline(qs[qi].text, _options.softBreaks, _refs);
                }
                while (curDepth-- > 0) html += QStringLiteral("</blockquote>");
                html += QLatin1Char('\n');
                // BlockInfo 与 Qt 块结构对齐：Qt 对 blockquote 无任何格式
                // 特征，仅在遇到内层 <blockquote> 标签时分块，因此按深度
                // 连续段拆分（深度变化的行段各一条 Quote）
                int segStart = cur.no;
                int segDepth = qMax(1, qs[0].depth);
                for (int qi = 1; qi < qs.size(); ++qi) {
                    const int d = qMax(1, qs[qi].depth);
                    if (d != segDepth) {
                        addBlock(BlockInfo(segStart, lines[i + qi - 1].no,
                                           BlockInfo::Quote));
                        segStart = lines[i + qi].no;
                        segDepth = d;
                    }
                }
                addBlock(BlockInfo(segStart, lines[j - 1].no, BlockInfo::Quote));
                i = j;
                continue;
            }

            // ---- 引用定义（段落外独立出现；不产生可见输出）----
            if (para.isEmpty() && ind <= 3) {
                QString id; RefDef def;
                if (parseRefDef(line, id, def)) { ++i; continue; }
            }

            // ---- 4 空格缩进代码块（不能打断段落）----
            if (ind >= 4 && para.isEmpty()) {
                int j = i;
                int lastCode = i - 1;
                while (j < lines.size()) {
                    if (isBlank(lines[j].text)) { ++j; continue; }
                    if (indentColumns(lines[j].text) >= 4) { lastCode = j; ++j; }
                    else break;
                }
                QStringList code;
                for (int k = i; k <= lastCode; ++k)
                    code << (isBlank(lines[k].text)
                                 ? QString()
                                 : removeIndentColumns(lines[k].text, 4));
                while (!code.isEmpty() && code.first().isEmpty()) code.removeFirst();
                while (!code.isEmpty() && code.last().isEmpty()) code.removeLast();
                // 列表内容列切片后可能整体多出公共缩进：所有非空行共享时统一去除
                int common = INT_MAX;
                for (const QString& c : code) {
                    if (c.trimmed().isEmpty()) continue;
                    int n2 = 0;
                    while (n2 < c.size() && c[n2] == QLatin1Char(' ')) ++n2;
                    common = qMin(common, n2);
                }
                if (common > 0 && common != INT_MAX) {
                    for (QString& c : code)
                        if (c.size() >= common) c = c.mid(common);
                }
                // 缩进代码块无语言标注：仅转义、不分色（与旧行为等价）
                html += QStringLiteral("<pre data-src-line=\"%1\"><code>%2</code></pre>\n")
                            .arg(cur.no)
                            .arg(highlightCodeHtml(code.join(QLatin1Char('\n')),
                                                   QString()));
                addBlock(BlockInfo(cur.no, lastCode + 1, BlockInfo::Code));
                i = lastCode + 1;
                continue;
            }

            // ---- GFM 表格（表头 + 等列数分隔行；不可打断段落）----
            if (para.isEmpty() && ind <= 3 && hasUnescapedPipe(line) && i + 1 < lines.size()) {
                const QString& next = lines[i + 1].text;
                if (indentColumns(next) <= 3 && isDelimiterRow(next)) {
                    QStringList headCells, aligns;
                    splitTableRow(line, headCells);
                    QStringList sepCells;
                    splitTableRow(next, sepCells);
                    if (headCells.size() == sepCells.size()) {
                        for (const QString& c : sepCells)
                            aligns << alignOfCell(c);
                        int j = i + 2;
                        QVector<QStringList> rows;
                        while (j < lines.size() && !isBlank(lines[j].text)
                               && hasUnescapedPipe(lines[j].text)
                               && indentColumns(lines[j].text) <= 3) {
                            QStringList cells;
                            splitTableRow(lines[j].text, cells);
                            rows << cells;
                            ++j;
                        }
                        auto cellTag = [&](const QString& tag, int c, const QString& content) {
                            const QString align = c < aligns.size() ? aligns[c] : QString();
                            const QString body = convertInline(content.trimmed(),
                                                               _options.softBreaks, _refs);
                            if (align.isEmpty())
                                return QStringLiteral("<%1>%2</%1>").arg(tag, body);
                            // 同时给 align 属性（QTextBrowser 支持）与 text-align（浏览器）
                            return QStringLiteral("<%1 align=\"%2\" "
                                                  "style=\"text-align:%2\">%3</%1>")
                                .arg(tag, align, body);
                        };
                        html += QStringLiteral("<table data-src-line=\"%1\">\n<thead><tr>")
                                    .arg(cur.no);
                        for (int c = 0; c < headCells.size(); ++c)
                            html += cellTag(QStringLiteral("th"), c, headCells[c]);
                        html += QStringLiteral("</tr></thead>\n");
                        if (!rows.isEmpty()) {
                            html += QStringLiteral("<tbody>\n");
                            for (const QStringList& cells : rows) {
                                html += QStringLiteral("<tr>");
                                for (int c = 0; c < headCells.size(); ++c)
                                    html += cellTag(QStringLiteral("td"), c,
                                                    c < cells.size() ? cells[c] : QString());
                                html += QStringLiteral("</tr>\n");
                            }
                            html += QStringLiteral("</tbody>\n");
                        }
                        html += QStringLiteral("</table>\n");
                        addBlock(BlockInfo(cur.no, lines[j - 1].no,
                                           BlockInfo::Table));
                        i = j;
                        continue;
                    }
                    // 表头/分隔行列数不一致：整体不是表格，落入段落
                }
            }

            // ---- 列表（有序 ./) 与无序 -/*/+；含嵌套/续行/任务项）----
            if (ind <= 3) {
                QChar mdelim; bool mordered = false; int mstart = 1, mcol = 0;
                if (matchListMarker(line, mdelim, mordered, mstart, mcol)) {
                    flushPara();
                    int end = i;
                    // renderList 递归渲染列表项时会为 <li>/项内段落追加
                    // BlockInfo；整个 ul/ol 在块序列中只占一条（与参考实现
                    // list 块 = 一个元素一致），渲染后丢弃递归产出补一条。
                    const int savedSize = _blocks ? _blocks->size() : 0;
                    QString listHtml = renderList(lines, i, end);
                    if (_blocks) {
                        _blocks->resize(savedSize);
                        addBlock(BlockInfo(cur.no, lines[end - 1].no,
                                          BlockInfo::List));
                    }
                    html += listHtml;
                    i = end;
                    continue;
                }
            }

            // ---- 普通段落行 ----
            if (para.isEmpty()) paraStart = cur.no;
            para << trimmed;
            paraRaw << line;
            paraNos << cur.no;
            ++i;
        }
        flushPara();
        return html;
    }

private:
    MarkdownConverter::ConvertOptions _options;
    QVector<MarkdownConverter::BlockInfo>* _blocks;
    QHash<QString, RefDef> _refs;
    QHash<QString, int> _slugCount;

    void addBlock(const MarkdownConverter::BlockInfo& b)
    {
        if (_blocks) _blocks->append(b);
    }

    QString slugFor(const QString& raw)
    {
        QString s = raw.toLower();
        s.remove(QRegularExpression(QStringLiteral("[`*_~\\[\\]()#]")));
        s.replace(QRegularExpression(QStringLiteral("[^\\p{L}\\p{N}\\s-]")), QString());
        s = s.trimmed();
        s.replace(QRegularExpression(QStringLiteral("\\s+")), QStringLiteral("-"));
        if (s.isEmpty()) s = QStringLiteral("sec");
        const int n = ++_slugCount[s];
        return (n > 1) ? QStringLiteral("%1-%2").arg(s).arg(n) : s;
    }

    static bool isHrLine(const QString& line)
    {
        int k = 0;
        while (k < line.size() && line[k] == QLatin1Char(' ') && k < 3) ++k;
        if (k >= line.size()) return false;
        const QChar c = line[k];
        if (c != QLatin1Char('-') && c != QLatin1Char('*') && c != QLatin1Char('_'))
            return false;
        int count = 0;
        for (; k < line.size(); ++k) {
            if (line[k] == c) ++count;
            else if (line[k] == QLatin1Char(' ') || line[k] == QLatin1Char('\t')) continue;
            else return false;
        }
        return count >= 3;
    }

    // CommonMark HTML 块 type6 起始标签集合（大小写不敏感）
    static bool startsBlockHtmlTag(const QString& t)
    {
        static const QSet<QString> tags = {
            QStringLiteral("address"), QStringLiteral("article"), QStringLiteral("aside"),
            QStringLiteral("base"), QStringLiteral("basefont"), QStringLiteral("blockquote"),
            QStringLiteral("body"), QStringLiteral("button"), QStringLiteral("caption"),
            QStringLiteral("center"), QStringLiteral("col"), QStringLiteral("colgroup"),
            QStringLiteral("dd"), QStringLiteral("details"), QStringLiteral("dialog"),
            QStringLiteral("dir"), QStringLiteral("div"), QStringLiteral("dl"),
            QStringLiteral("dt"), QStringLiteral("fieldset"), QStringLiteral("figcaption"),
            QStringLiteral("figure"), QStringLiteral("footer"), QStringLiteral("form"),
            QStringLiteral("frame"), QStringLiteral("frameset"),
            QStringLiteral("h1"), QStringLiteral("h2"), QStringLiteral("h3"),
            QStringLiteral("h4"), QStringLiteral("h5"), QStringLiteral("h6"),
            QStringLiteral("head"), QStringLiteral("header"), QStringLiteral("hr"),
            QStringLiteral("html"), QStringLiteral("iframe"), QStringLiteral("legend"),
            QStringLiteral("li"), QStringLiteral("link"), QStringLiteral("main"),
            QStringLiteral("menu"), QStringLiteral("menuitem"), QStringLiteral("nav"),
            QStringLiteral("noframes"), QStringLiteral("ol"), QStringLiteral("optgroup"),
            QStringLiteral("option"), QStringLiteral("p"), QStringLiteral("param"),
            QStringLiteral("search"), QStringLiteral("section"), QStringLiteral("summary"),
            QStringLiteral("table"), QStringLiteral("tbody"), QStringLiteral("td"),
            QStringLiteral("tfoot"), QStringLiteral("th"), QStringLiteral("thead"),
            QStringLiteral("title"), QStringLiteral("tr"), QStringLiteral("track"),
            QStringLiteral("ul")
        };
        if (!t.startsWith(QLatin1Char('<'))) return false;
        int p = 1;
        if (p < t.size() && t[p] == QLatin1Char('/')) ++p;
        int b = p;
        while (p < t.size() && (t[p].isLetterOrNumber() || t[p] == QLatin1Char('-'))) ++p;
        if (p == b) return false;
        const QString name = t.mid(b, p - b).toLower();
        if (!tags.contains(name)) return false;
        if (p >= t.size()) return true;
        const QChar nx = t[p];
        return nx == QLatin1Char(' ') || nx == QLatin1Char('\t')
               || nx == QLatin1Char('>') || nx == QLatin1Char('/');
    }

    static bool hasUnescapedPipe(const QString& s)
    {
        for (int k = 0; k < s.size(); ++k) {
            if (s[k] == QLatin1Char('|')
                && (k == 0 || s[k - 1] != QLatin1Char('\\')))
                return true;
        }
        return false;
    }

    // 分隔行：单元格仅由 : 与 ≥1 个 - 构成，允许首尾省略管道
    static bool isDelimiterRow(const QString& s)
    {
        QStringList cells;
        splitTableRow(s, cells);
        if (cells.isEmpty()) return false;
        static const QRegularExpression cellRe(QStringLiteral("^:?-+:?$"));
        for (const QString& c : cells)
            if (!cellRe.match(c.trimmed()).hasMatch()) return false;
        return hasUnescapedPipe(s) || cells.size() == 1;
    }

    // 按未转义 | 切分单元格并去除单个首尾管道
    static void splitTableRow(const QString& s, QStringList& out)
    {
        QString t = s.trimmed();
        if (t.startsWith(QLatin1Char('|'))) t = t.mid(1);
        if (t.endsWith(QLatin1Char('|'))
            && t.size() >= 2 && t[t.size() - 2] != QLatin1Char('\\'))
            t.chop(1);
        QString cell;
        for (int k = 0; k < t.size(); ++k) {
            if (t[k] == QLatin1Char('|')
                && (k == 0 || t[k - 1] != QLatin1Char('\\'))) {
                out << cell;
                cell.clear();
            } else {
                cell += t[k];
            }
        }
        out << cell;
    }

    static QString alignOfCell(const QString& cell)
    {
        const QString t = cell.trimmed();
        const bool left = t.startsWith(QLatin1Char(':'));
        const bool right = t.endsWith(QLatin1Char(':'));
        if (left && right) return QStringLiteral("center");
        if (right) return QStringLiteral("right");
        if (left) return QStringLiteral("left");
        return QString();
    }

    // 列表标记识别；contentCol 为续行内容列（制表按 4 列）
    static bool matchListMarker(const QString& line, QChar& delim, bool& ordered,
                                int& orderStart, int& contentCol)
    {
        int p = 0;
        const int ind = indentColumns(line);
        if (ind > 3) return false;
        p = ind;
        int num = 0, digits = 0;
        while (p < line.size() && line[p].isDigit() && digits < 9) {
            num = num * 10 + line[p].digitValue();
            ++digits; ++p;
        }
        if (digits > 0 && p < line.size()
            && (line[p] == QLatin1Char('.') || line[p] == QLatin1Char(')'))) {
            delim = line[p];
            ordered = true;
            orderStart = num;
            ++p;
        } else if (digits == 0 && p < line.size()
                   && (line[p] == QLatin1Char('-') || line[p] == QLatin1Char('*')
                       || line[p] == QLatin1Char('+'))) {
            delim = line[p];
            ordered = false;
            ++p;
        } else return false;

        // CommonMark：标记后必须紧跟空白或行尾（"-foo"、"**"、"1.foo"
        // 均不是列表项；这也避免 "***" 等被吞进列表）
        if (p < line.size() && !line[p].isSpace())
            return false;

        const int markerEnd = p;
        int w = 0;
        while (p < line.size() && (line[p] == QLatin1Char(' ')
                                   || line[p] == QLatin1Char('\t'))) {
            if (line[p] == QLatin1Char(' ')) ++w;
            else w += 4 - (w % 4);
            ++p;
        }
        // 标记后空白 1..4 列按实际对齐；≥5 列或无内容时内容列 = 标记末列 +1
        contentCol = (w >= 5 || w == 0) ? markerEnd + 1 : markerEnd + w;
        return true;
    }

    // 下一非空行（从 k 起）
    int nextNonBlank(const QVector<Ln>& lines, int k) const
    {
        while (k < lines.size() && isBlank(lines[k].text)) ++k;
        return k;
    }

    // 判断行是否可能“懒续行”：不能是可打断段落的块结构起始
    bool canLazyContinue(const QString& line) const
    {
        if (line.trimmed().isEmpty()) return false;
        const int ind = indentColumns(line);
        if (ind > 3) return true;
        const QString t = line.mid(ind);
        if (t.startsWith(QLatin1Char('#'))) return false;
        if (t.startsWith(QLatin1Char('>'))) return false;
        if (t.startsWith(QStringLiteral("<!--"))) return false;
        if (startsBlockHtmlTag(t)) return false;
        if (isHrLine(line)) return false;
        // 围栏
        if (t.startsWith(QStringLiteral("```")) || t.startsWith(QStringLiteral("~~~")))
            return false;
        QChar d; bool o; int ns, cc;
        if (matchListMarker(line, d, o, ns, cc)) return false;
        if (t.contains(QRegularExpression(QStringLiteral(
                "^\\|?\\s*:?-+:?\\s*(\\|\\s*:?-+:?\\s*)*\\|?$"))))
            return false;
        return true;
    }

    // 任务复选框（QTextBrowser 不支持 <input>，用 Unicode 方框；
    // 浏览器导出脚本接管点击，仅视觉切换、不写回文件）
    static QString taskBoxHtml(bool checked)
    {
        return checked
            ? QStringLiteral("<span class=\"task-box\" data-checked=\"true\">&#9745;</span> ")
            : QStringLiteral("<span class=\"task-box\" data-checked=\"false\">&#9744;</span> ");
    }

    // 从 start 行起解析整个列表，HTML 写入返回值，*end 为结束行（不含）
    QString renderList(const QVector<Ln>& lines, int start, int& end)
    {
        QVector<ListItem> items;

        const int markerIndent = indentColumns(lines[start].text);
        QChar firstDelim;
        bool firstOrdered = false;
        int firstStartTmp = 1, firstColTmp = 0;
        matchListMarker(lines[start].text, firstDelim, firstOrdered,
                        firstStartTmp, firstColTmp);
        int i = start;
        bool loose = false;

        // "紧凑组 + 空行 + 松散组"（- 紧凑…\n\n- 松散…）形态：
        // 紧凑组在首个空行处切分为独立列表，新列表按松散诞生并继续吸收
        // 后续空行分隔项；若空行另一侧标记类型不同（- → *、. → )）或
        // 前方是普通段落，则仍是独立的紧凑列表。
        if (start >= 2 && isBlank(lines[start - 1].text)) {
            const QString& before = lines[start - 2].text;
            QChar bd; bool bo; int bs = 1, bc = 0;
            if (indentColumns(before) == markerIndent
                && matchListMarker(before, bd, bo, bs, bc)
                && bo == firstOrdered && bd == firstDelim)
                loose = true;
        }

        while (i < lines.size()) {
            const QString& line = lines[i].text;
            const int ind = indentColumns(line);
            QChar delim; bool ordered = false; int orderStart = 1, contentCol = 0;
            const bool isMarkerHere =
                ind == markerIndent
                && matchListMarker(line, delim, ordered, orderStart, contentCol);

            if (items.isEmpty()) {
                if (!isMarkerHere) break;
                firstDelim = delim;
                firstOrdered = ordered;
            } else if (!isMarkerHere || ordered != firstOrdered || delim != firstDelim) {
                break;
            }

            ListItem item;
            item.startLine = lines[i].no;
            item.contentCol = contentCol;
            item.delim = delim;
            item.ordered = ordered;
            item.orderStart = orderStart;
            // 首行内容按列硬切：前 contentCol 列是"标记+空白"（可能含
            // 数字/横线等非空白字符），removeIndentColumns 只切空白会
            // 把标记原样留下，导致 body 再次解析为同一列表 → 无限递归
            QString firstText = sliceFromColumn(line, contentCol);
            // 任务标记 [ ] / [x]（后跟空白或行尾）
            if (firstText.startsWith(QStringLiteral("[ ]"))
                && (firstText.size() == 3 || firstText[3].isSpace())) {
                item.task = true; item.taskChecked = false;
                firstText = firstText.mid(qMin(4, firstText.size()));
            } else if ((firstText.startsWith(QStringLiteral("[x]"))
                        || firstText.startsWith(QStringLiteral("[X]")))
                       && (firstText.size() == 3 || firstText[3].isSpace())) {
                item.task = true; item.taskChecked = true;
                firstText = firstText.mid(qMin(4, firstText.size()));
            }
            if (!firstText.isEmpty())
                item.body << Ln{ firstText, lines[i].no };
            ++i;

            bool pendingBlank = false;
            while (i < lines.size()) {
                const Ln& nxt = lines[i];
                if (isBlank(nxt.text)) {
                    const int k = nextNonBlank(lines, i + 1);
                    if (k >= lines.size()) { i = k; goto itemDone; }
                    const int nind = indentColumns(lines[k].text);
                    QChar nd; bool no2; int nstart, ncol;
                    const bool nextIsMarker =
                        nind == markerIndent
                        && !isHrLine(lines[k].text)
                        && matchListMarker(lines[k].text, nd, no2, nstart, ncol)
                        && no2 == firstOrdered && nd == firstDelim;
                    if (nextIsMarker) {
                        if (loose) {
                            // 已松散的列表继续吸收空行分隔的同标记项
                            i = k;
                            goto itemDone;
                        }
                        // 紧凑列表在"空行 + 同级标记"处切分为两个列表：
                        // 当前项收尾，end 停在空行；主循环会以松散形态
                        // 从下一标记重新开启列表
                        end = i;
                        goto itemDone;
                    }
                    if (nind >= contentCol) {
                        loose = true;           // 空行后仍有续行内容 → 松散
                        // 保留首个空行到 item body（多段落需要）
                        item.body << Ln{ QString(), nxt.no };
                        ++i;
                        pendingBlank = true;    // 空行之后不允许懒续行
                        continue;
                    }
                    // 空行后脱缩进 → 列表结束；当前项必须先经 itemDone 收尾
                    // 入列（直接 goto listDone 会丢项：单项有序列表将因
                    // items 为空而在 items.first() 处崩溃，多项列表丢末项）
                    i = k;
                    goto itemDone;
                }
                const int nind = indentColumns(nxt.text);
                QChar nd; bool no2; int nstart, ncol;
                const bool sameMarker =
                    nind == markerIndent
                    && !isHrLine(nxt.text)
                    && matchListMarker(nxt.text, nd, no2, nstart, ncol)
                    && no2 == firstOrdered && nd == firstDelim;
                if (sameMarker) break;          // 下一项
                if (nind >= contentCol) {
                    item.body << Ln{ removeIndentColumns(nxt.text, contentCol), nxt.no };
                    pendingBlank = false;
                    ++i;
                    continue;
                }
                // 以下 listDone 同样一律经 itemDone 收尾，原因同上
                if (nind < markerIndent) goto itemDone;
                if (nind > markerIndent && nind < contentCol)
                    goto itemDone;              // 续行缩进不足 → 列表终止
                // nind == markerIndent 但非标记：懒续行（空行之后不允许）
                if (pendingBlank) goto itemDone;
                if (item.body.isEmpty() || !canLazyContinue(nxt.text))
                    goto itemDone;
                item.body << Ln{ nxt.text.trimmed(), nxt.no };
                ++i;
            }
        itemDone:
            // 去除 body 首尾空行
            while (!item.body.isEmpty() && isBlank(item.body.first().text))
                item.body.removeFirst();
            while (!item.body.isEmpty() && isBlank(item.body.last().text))
                item.body.removeLast();
            items << item;
        }
        // 所有内层出口统一经 itemDone 收尾，此处 items 必然非空
        end = i;

        bool anyTask = false;
        for (const auto& it : items) anyTask = anyTask || it.task;

        QString html;
        if (firstOrdered) {
            const int first = items.first().orderStart;
            html += (first != 1)
                ? QStringLiteral("<ol start=\"%1\">\n").arg(first)
                : QStringLiteral("<ol>\n");
        } else {
            html += anyTask ? QStringLiteral("<ul class=\"task-list\">\n")
                            : QStringLiteral("<ul>\n");
        }

        for (const auto& it : items) {
            // <li> 自身在 QTextBrowser 中产生一个块（先于内部块）。
            // 该产出会被主列表分支整体丢弃（整个 ul/ol 只占一条 List 块），
            // 这里仅为递归渲染期间的占位。
            addBlock(MarkdownConverter::BlockInfo(
                it.startLine, it.startLine, MarkdownConverter::BlockInfo::Paragraph));
            const QString cls = it.task ? QStringLiteral(" class=\"task-list-item\"")
                                        : QString();
            html += QStringLiteral("<li%1 data-src-line=\"%2\">").arg(cls).arg(it.startLine);
            if (it.task) html += taskBoxHtml(it.taskChecked);
            // 紧凑列表：直接段落不产生 <p>/BlockInfo（与 li 块合并）
            html += render(it.body, /*tight=*/!loose);
            html += QStringLiteral("</li>\n");
        }
        html += firstOrdered ? QStringLiteral("</ol>\n") : QStringLiteral("</ul>\n");
        return html;
    }
};

} // namespace

QString MarkdownConverter::toHtmlFragment(const QString& markdown,
                                          const ConvertOptions& options,
                                          QVector<BlockInfo>* blocks)
{
    QString norm = markdown;
    norm.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    norm.replace(QLatin1Char('\r'), QLatin1Char('\n'));
    const QStringList rawLines = norm.split(QLatin1Char('\n'));
    QVector<Ln> lines;
    lines.reserve(rawLines.size());
    for (int i = 0; i < rawLines.size(); ++i)
        lines << Ln{ rawLines[i], i + 1 };

    Parser parser(options, blocks);
    parser.collectRefs(lines);
    return parser.render(lines, /*tight=*/false);
}

QString MarkdownConverter::toHtmlDocument(const QString& markdown, bool darkTheme,
                                          const ConvertOptions& options)
{
    return wrapHtmlDocument(toHtmlFragment(markdown, options), darkTheme);
}

QString MarkdownConverter::wrapHtmlDocument(const QString& bodyHtml, bool darkTheme,
                                            int fontPx, bool withScripts,
                                            const Palette* palette,
                                            const QString& fontFamily)
{
    QString body = bodyHtml;

    // 默认调色板（导出路径/未传 palette 时）：与 ThemeManager 的 light/dark
    // 配色保持一致，标题色与编辑区语法高亮同色。
    Palette pal{
        darkTheme ? QStringLiteral("#23272e") : QStringLiteral("#ffffff"),  // bg
        darkTheme ? QStringLiteral("#e4e6eb") : QStringLiteral("#1c1e21"),  // fg
        darkTheme ? QStringLiteral("#2a2f36") : QStringLiteral("#f2f3f5"),  // codeBg
        darkTheme ? QStringLiteral("#73daca") : QStringLiteral("#0a7d8c"),  // link
        darkTheme ? QStringLiteral("#8ba3c7") : QStringLiteral("#6a737d"),  // quote
        darkTheme ? QStringLiteral("#3a4048") : QStringLiteral("#d8dce1"),  // border
        darkTheme ? QStringLiteral("#f7768e") : QStringLiteral("#c0392b"),  // strike
        darkTheme ? QStringLiteral("#c3a6ff") : QStringLiteral("#8a3ffc"),  // accent
        darkTheme ? QStringLiteral("#7aa2f7") : QStringLiteral("#1a56c4"),  // heading
    };
    if (palette)
        pal = *palette;

    const QString& bg     = pal.bg;
    const QString& fg     = pal.fg;
    const QString& codeBg = pal.codeBg;
    const QString& link   = pal.link;
    const QString& quote  = pal.quote;
    const QString& border = pal.border;
    const QString& strike = pal.strike;

    // 代码语法高亮配色（暗色取 atom-one-dark，浅色取语义对应的浅色主题）。
    // span 只带 class，颜色在此按主题写死两套。
    const QString hlCss = darkTheme
        ? QStringLiteral(
            ".hl-kw{color:#c678dd;}.hl-ty{color:#56b6c2;}.hl-fn{color:#61afef;}"
            ".hl-st{color:#98c379;}.hl-cm{color:#5c6370;font-style:italic;}"
            ".hl-nu{color:#d19a66;}.hl-op{color:#abb2bf;}.hl-pp{color:#e06c75;}"
            ".hl-tag{color:#e06c75;}.hl-at{color:#d19a66;}.hl-val{color:#98c379;}"
            ".hl-pn{color:#abb2bf;}")
        : QStringLiteral(
            ".hl-kw{color:#a626a4;}.hl-ty{color:#c18401;}.hl-fn{color:#4078f2;}"
            ".hl-st{color:#50a14f;}.hl-cm{color:#a0a1a7;font-style:italic;}"
            ".hl-nu{color:#986801;}.hl-op{color:#383a42;}.hl-pp{color:#e45649;}"
            ".hl-tag{color:#e45649;}.hl-at{color:#986801;}.hl-val{color:#50a14f;}"
            ".hl-pn{color:#383a42;}");

    QString html = QStringLiteral(
        "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "<style>"
        // 整页永不出现横向滚动条；长串/长 URL 在词内可断（英文整词优先）
        "html,body{overflow-x:hidden;}"
        "body{background:%1;color:%2;font-family:'%F','Microsoft YaHei UI',sans-serif;"
        "line-height:1.6;padding:18px 24px;font-size:%4px;"
        "overflow-wrap:anywhere;word-break:break-word;}"
        "p,li,td,th,blockquote,h1,h2,h3,h4,h5,h6{overflow-wrap:anywhere;word-break:break-word;}"
        "h1,h2,h3,h4,h5,h6{line-height:1.3;margin:1.1em 0 0.5em;color:%H;}"
        // 标题样式（与参考 .preview-content 一致）：h1/h2 底部 1px 边框，无左侧竖条。
        // 注意：Qt 富文本不渲染块级 border-bottom（ADR-025），预览端由
        // PreviewWidget 注入全宽位图底线（ADR-028）；本 CSS 对导出 HTML 的浏览器生效。
        "h1{font-size:1.9em;margin:.67em 0 .75em;padding-bottom:.12em;"
        "border-bottom:1px solid %8;scroll-margin-top:20px;}"
        "h2{font-size:1.5em;margin:.75em 0 .7em;padding-bottom:.10em;"
        "border-bottom:1px solid %8;scroll-margin-top:20px;}"
        "html{scroll-behavior:smooth;}"
        "a{color:%5;text-decoration:none;} a:hover{text-decoration:underline;}"
        "code{background:%3;padding:2px 6px;border-radius:4px;"
        "font-family:Consolas,'Cascadia Mono',monospace;font-size:0.92em;}"
        // 代码块：圆角/内边距/容器内横向滚动，绝不让整页横滚
        ".codeblock{position:relative;}"
        "pre{background:%3;padding:14px 16px;border-radius:8px;overflow-x:auto;"
        "border:1px solid %8;font-family:Consolas,'Cascadia Mono',monospace;}"
        "pre code{background:none;padding:0;font-size:1em;white-space:pre;}"
        ".copy-btn{position:absolute;top:6px;right:8px;font-size:12px;line-height:1;"
        "padding:4px 10px;border:1px solid %8;border-radius:4px;background:%1;color:%2;"
        "cursor:pointer;opacity:.75;}"
        ".copy-btn:hover{opacity:1;}"
        // 引用块：左竖线 + 浅底，嵌套引用缩进
        "blockquote{border-left:4px solid %6;margin:0.8em 0;padding:4px 16px;"
        "color:%6;background:rgba(127,127,127,0.06);border-radius:0 6px 6px 0;}"
        "blockquote blockquote{margin:0.4em 0;background:rgba(127,127,127,0.06);}"
        // 表格：表头背景/边框/内边距/列宽自适应，超出宽度时仅容器内横滚
        "table{border-collapse:collapse;margin:1em 0;display:block;overflow-x:auto;"
        "max-width:100%;}"
        "th,td{border:1px solid %8;padding:8px 12px;text-align:left;}"
        "th{background:rgba(127,127,127,0.10);}"
        "tr:nth-child(even){background:rgba(127,127,127,0.04);}"
        "hr{border:none;border-top:2px solid %8;margin:1.5em 0;}"
        // 图片等比缩放，不超出正文宽度
        "img{max-width:100%;height:auto;border-radius:8px;}"
        "ul,ol{padding-left:1.6em;} li{margin:0.25em 0;}"
        // 松散列表项间距（GFM：松散列表 li 内含 <p>）
        "li p{margin:0.35em 0;}"
        "del{color:%7;}"
        // 任务复选框视觉切换（结构对齐 GFM task-list-item，控件用 span 兼容 Qt）
        ".task-list{list-style:none;padding-left:1.2em;}"
        ".task-box{display:inline-block;margin-right:6px;cursor:pointer;"
        "user-select:none;font-family:'Segoe UI Symbol','Segoe UI',sans-serif;}"
        ) + hlCss + QStringLiteral("</style></head><body>%9");

    if (withScripts) {
        // 浏览器查看导出 HTML 时：代码块复制按钮（prompt 降级）、
        // 任务框仅视觉勾选、#锚点平滑滚动（无效锚点不报错）。
        // QTextBrowser 不执行脚本，预览路径(withScripts=false)不含此段。
        html += QStringLiteral(
            "<script>(function(){"
            "document.querySelectorAll('pre').forEach(function(pre){"
              "var box=document.createElement('div');box.className='codeblock';"
              "pre.parentNode.insertBefore(box,pre);box.appendChild(pre);"
              "var btn=document.createElement('button');btn.type='button';"
              "btn.className='copy-btn';btn.textContent='\\u590d\\u5236';"
              "btn.onclick=function(){"
                "var txt=pre.innerText;"
                "if(navigator.clipboard&&navigator.clipboard.writeText){"
                  "navigator.clipboard.writeText(txt).then(function(){"
                    "btn.textContent='\\u5df2\\u590d\\u5236';"
                    "setTimeout(function(){btn.textContent='\\u590d\\u5236';},1200);});"
                "}else{window.prompt('\\u590d\\u5236\\uff1a',txt);}"
              "};"
              "box.appendChild(btn);"
            "});"
            "document.querySelectorAll('.task-box').forEach(function(box){"
              "box.addEventListener('click',function(){"
                "var on=box.getAttribute('data-checked')==='true';"
                "on=!on;box.setAttribute('data-checked',on?'true':'false');"
                "box.textContent=on?'\\u2611':'\\u2610';"
              "});"
            "});"
            "document.addEventListener('click',function(e){"
              "var a=e.target.closest?e.target.closest('a[href^=\"#\"]'):null;"
              "if(!a)return;"
              "var id=decodeURIComponent(a.getAttribute('href').slice(1));"
              "var el=document.getElementById(id);"
              "if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth',block:'start'});}"
              "else{e.preventDefault();}"
            "});"
            "})();</script>");
    }
    html += QStringLiteral("</body></html>");

    html.replace(QStringLiteral("%1"), bg);
    html.replace(QStringLiteral("%2"), fg);
    html.replace(QStringLiteral("%3"), codeBg);
    html.replace(QStringLiteral("%4"), QString::number(qBound(10, fontPx, 28)));
    html.replace(QStringLiteral("%5"), link);
    html.replace(QStringLiteral("%6"), quote);
    html.replace(QStringLiteral("%7"), strike);
    html.replace(QStringLiteral("%8"), border);
    html.replace(QStringLiteral("%9"), body);
    html.replace(QStringLiteral("%A"), pal.accent);
    html.replace(QStringLiteral("%H"), pal.heading);
    // 字体族来自 QFontComboBox 的系统字体名，不含引号，直接内联进 CSS 字符串安全
    html.replace(QStringLiteral("%F"), fontFamily);
    return html;
}
