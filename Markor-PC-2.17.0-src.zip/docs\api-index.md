# API 索引（api-index.md）

> 全部公开类/命名空间的**签名级速查** + 典型调用路径。参数/返回细节以头文件为准；此处是"不用开文件就能想起接口"的地图。
> 约定：`/斜体/` 为说明；单例 = `X::instance()`。

---

## 1. app/ — 单例与主窗口

### `AppSettings`（QObject 单例）
持久化门面。getter/setter 成对，此处只列"读"：
```
外观: theme() · followSystemTheme() · editorFontFamily() · editorFontSize()
编辑: wordWrap() · lineNumbers() · syntaxHighlighting()
预览: previewFollowEditor() · previewSoftBreaks() · previewFontSize()
文件: vaultDir() · favorites() · isFavorite(p) · toggleFavorite(p)
      recents() · addRecent(p) · removeRecent(p) · clearRecents()
同步: syncEnabled() · syncDeviceName() · syncNasDeviceId() · syncRelayUrl()
窗口: windowGeometry() · windowState() · splitterState()
侧栏: fileSidebarVisible() · fileSidebarWidth() · fileSidebarTab()
      outlineDefaultExpanded() · outlineExpanded() · setOutlineExpanded() · outlineWidth()
其他: sync()  // 落盘
信号: recentsChanged()
```

### `ThemeManager`（QObject 单例）
```
static availableThemes() -> QList<QPair<id, 显示名>>   // light/dark/sakura
static displayName(id) · static systemThemeId()        // 按系统调色板判 light/dark
apply(theme) · current() · isDark()
色值: editorBg() editorFg() lineNumberFg() highlightBg()
      headingColor() emphasisColor() strongColor() codeColor() linkColor()
      quoteColor() listColor() hrColor() strikeColor()
信号: themeChanged(QString)
```

### `MainWindow`（QMainWindow）
```
公开槽: openFilePath(path) · exportScreenshot(png) · exportHtmlTo(html)->bool · exportPdfTo(pdf)->bool
私有槽（即 UI 动作全集）: openFile/newDocument/saveCurrent/saveCurrentAs/refreshCurrent/closeTab
        applyFormatAction/onFormatComboChanged/tidyCurrentMarkdown/historyBack/historyForward
        findInFile/openFileAtLine · exportHtml/exportPdf/copyHtmlSource/copyRichText/copyPlainText
        togglePreview/cycleTheme/setThemeFromSettings/showSettings/showMore/showChangelog/about
私有工具: createPage(path)->EditorWidget* · currentEditor() · currentPreview() · indexOfPath()
        syncPreview() · promptSaveEditor(e)->bool · applyTheme/applyEditorSettings/applySyncSettings
        updateFormatCombo() · currentHtmlDocument() · currentHtmlWithResources(&res)
```
⚠️ `createPage` 内含**全部滚动同步/主题/防回环接线**，改接线先读该函数长注释。

---

## 2. core/ — 领域（无 UI 依赖）

### `Document`
```
Document(path) · load()->bool · save()->bool · exists() · isWritable()
path() · fileName() · dirPath() · format() · setPath(path)
```

### `namespace FormatDetector`
```
detect(path)->TextFormat · name(fmt)->QString · fileFilter()->QString
highlightable(fmt)->bool · isMarkdownFamily(fmt)->bool
```

### `namespace MarkdownConverter`
```
struct ConvertOptions { bool softBreaks = true; };
struct BlockInfo { int srcLine; bool isTable; bool isPre; QString slug; };
toHtmlFragment(markdown, opts={}, blocks=nullptr)->QString
toHtmlDocument(markdown, darkTheme, opts={})->QString
wrapHtmlDocument(bodyHtml, darkTheme, fontPx=15, withScripts=false)->QString
```

### `class TodoTxtTask` + `namespace TodoTxtFilter`
```
TodoTxtTask() / TodoTxtTask(line) · setLine(line) · line()->QString   // line() 返回原始行！
isDone()/setDone(bool) · priority()/setPriority(QChar)
completionDate() · creationDate() · description()/setDescription(d)
projects() · contexts() · tags() · value(key)->QString
static fromParts(done, priority, description)->TodoTxtTask

TodoTxtFilter::matches(task, filter, caseSensitive=false)->bool
```

---

## 3. editor/ — 编辑器

### `EditorWidget`（QPlainTextEdit）
```
文件: setFilePath(p) · filePath() · loadFile(p)->bool · saveFile(p=空)->bool · isDirty() · setDirty(b)
格式: applyFormat(fmt) · format() · setFormatAuto(b) · isFormatAuto() · refreshFormat()
      setHighlightEnabled(b)
显示: setLineNumbersVisible(b) · lineNumbersVisible() · setFontPointSize(pt)
      lineNumberAreaWidth() · lineNumberAreaPaintEvent(e)   // 供 LineNumberArea
搜索: find(text, forward, caseSensitive, regex)->bool
      replace(find, with, cs, regex)->bool · replaceAll(...)->int
滚动: scrollToSourceLine(line)  // 1 起，不移动文本光标
      scrollToSourceLineF(lineF)  // 小数源行：行号+行内像素比例
      isProgrammaticScroll()->bool · firstVisibleSourceLine()->int
      firstVisibleSourceLineF()->qreal   // 小数版，供逐行插值跟随
      sourceLineFAtViewportY(y)->qreal   // 视口内像素 y 对应源行（43% 参考点跟随）
历史: undoSnapshot() · redoSnapshot() · resetSnapshotHistory()   // 快照轨
过滤: setFilterBlocks(QList<int>, color) · clearFilter()
信号: dirtyChanged(bool) · statusMessage(QString)
槽:   updateLineNumberAreaWidth/updateLineNumberArea/highlightCurrentLine
```

### `namespace FormatActions`（14 个动作 + 2 个 Markdown 专属）
```
bold italic strikeout inlineCode heading blockquote bulletList orderedList
checkboxList horizontalRule insertLink insertImage indent deindent
toggleSurround(ed, marker)                 // 通用包裹
handleSmartReturn(ed)->bool               // 仅 Markdown：表格分隔行/围栏闭合/列表续行
tidyMarkdown(ed)->bool                    // 仅 Markdown：全文整理，宁少勿错
```

### `namespace TodoTxtActions`
```
toggleDone(ed) · cyclePriority(ed) · setPriority(ed, QChar)
insertToday(ed) · appendToday(ed) · setDueDate(ed)
archiveDone(ed)   // → 同目录 done.txt（需已保存）
sortByPriority(ed)
```

### 高亮器（都继承 `QSyntaxHighlighter`，均含 `refreshFormats()`）
- `MarkdownHighlighter`：语法 + 6 类 lint（详见 header 注释）
- `TodoTxtHighlighter`
- `SourceCodeHighlighter`：`setExtension(ext)` 选注释族/HTML 模式

---

## 4. preview/ — 预览

### `PreviewWidget`（QWidget）
```
输入: setMarkdown(md) · setFormat(fmt) · setSourcePath(path)  // HTML 文件浏览器预览
刷新: refreshTheme() · refreshSettings() · reloadHtmlPreview()
导出: toHtmlDocument()->QString                       // 图表/公式 data URI 内嵌
      toHtmlWithResources(QVector<QPair<QString,QPixmap>>* res)->QString  // 具名资源（PDF 用）
访问: browser()->QTextBrowser*
滚动: scrollToSourceLine(line, smooth=false)      // smooth=true：跳转语义（该行最后元素顶-12px）
      scrollToSourceLineF(lineF, smooth=false)   // 小数行：逐行像素映射（块内插值）
      followSourceLineF(lineF, anchorRatio=0)    // 编辑跟随：43% 参考点锚定（帧驱动平滑）
      followEditorEdge(toBottom)                 // 编辑器到顶/到底 → 预览到顶/到底
信号: sourceLineRequested(int line)          // 预览→编辑器
      currentTopSourceLineChanged(int line)  // → OutlinePanel ScrollSpy
```

### `HtmlPreviewView`（QWidget，WebView2 宿主）
```
isAvailable() · isResolved() · currentTarget()
openFile(filePath) · setHtmlSource(html) · reload()
信号: resolved()
```

---

## 5. sidebar/ · browser/ · search/ · sync/ · render/ · ui/

### `FileSidebar`
```
setRootPath(path) · setCurrentPath(path)   // 空 = 清除高亮
panelWidth()/setPanelWidth(w)              // 动画属性
信号: fileActivated(p) · openInNewTab(p) · toggleFavorite(p) · statusMessage(msg)
```

### `OutlinePanel`
```
bind(editor, preview)   // 每页仅一次；内接防抖刷新 + ScrollSpy
refreshNow()            // 载入后立即解析（编辑防抖 400ms）
setActiveSourceLine(line)  // 槽：ScrollSpy
信号: headingActivated(int sourceLine)
```

### `SidebarHandle`（两面板共用）
```
HANDLE_WIDTH = 8 · setCollapsed(bool)
信号: toggled() · dragged(int deltaX) · dragFinished()
```

### `FileBrowserWidget`
```
setRootPath(p) · rootPath() · refresh() · selectPath(p)   // 自动展开父链
槽: newDocument() · newFolder()
信号: fileActivated(p) · openInNewTab(p) · toggleFavorite(p) · statusMessage(msg)
```

### `SearchDialog`（非模态）
```
SearchDialog(editor, vaultDir, parent)
setEditor(editor)      // 标签切换/关闭后重绑（QPointer，允许空）
setVaultDir(dir)
信号: openFileAt(path, line)
```

### `SyncManager`（QObject 单例）
```
startIfEnabled()  // 幂等；设置变化→重应用配置+重探测 · stop() · running() · deviceId()
checkServerConnection()   // 轮询 rest/system/connections，结果上抛（弹窗用）
信号: deviceIdReady(id) · statusMessage(msg) · serverConnectionResult(ok, message)
```

### `LockClient`（QObject 单例，文件锁客户端）
```
setDeviceId(id)      // 由 SyncManager::deviceIdReady 接入
open(absPath)        // 登记打开 + 30s 心跳；未配置服务器则静默
close()              // 保存/关标签/退出时注销
信号: statusMessage(msg) · fileHeldElsewhere(relPath, holders)
```

### `namespace MathRenderer`
```
render(latex, pointSize, fg, bg=transparent)->QPixmap
```

### `namespace MermaidRenderer`
```
canRender(code)->bool · render(code, maxWidth, fg, bg, dark)->QPixmap
```

### 对话框
- `SettingsDialog`：信号 `themeChanged(themeId)` `editorSettingsChanged()` `previewSettingsChanged()` `vaultChanged(dir)` `syncSettingsChanged()`
- `MoreDialog`：信号 `openSettingsRequested()` `openChangelogRequested()`
- `TodoTxtFilterDialog(editor)`：内部完成过滤（`EditorWidget::setFilterBlocks`）

---

## 6. 典型调用路径（"我要做 X → 调 Y"）

| 我要做 | 路径 |
|---|---|
| 打开文件到标签 | `MainWindow::openFilePath(p)` → `indexOfPath` 去重 → `createPage(p)` → `EditorWidget::loadFile` |
| 改主题 | `AppSettings::setTheme` (+`setFollowSystemTheme(false)`) → `MainWindow::applyTheme` → `ThemeManager::apply` → `themeChanged` 信号链 |
| 让预览重渲染 | `MainWindow::syncPreview()` → `PreviewWidget::setMarkdown` → `scheduleRender`(防抖) → `renderNow` |
| Markdown 转 HTML（导出用） | `MarkdownConverter::toHtmlFragment/toHtmlDocument`；含图表公式 → `PreviewWidget::toHtmlDocument()` |
| 定位预览到某行 | `PreviewWidget::jumpToSourceLine(line)`（该行最后元素顶-12px，帧驱动平滑）或 `scrollToSourceLineF(lineF)`（逐行像素映射：`docYForSourceLine` 块内插值） |
| 定位编辑器到某行 | `EditorWidget::scrollToSourceLine(line)` 或 `MainWindow::openFileAtLine(p,line)`（搜索结果跳转） |
| 改 todo.txt 当前行 | `TodoTxtActions::*(currentEditor())`（行级文本正则改写） |
| 全库搜索 | `SearchDialog::searchVault()` → `openFileAt` 信号 → `MainWindow::openFileAtLine` |
| 导出 PDF | `MainWindow::exportPdfTo` → `currentHtmlWithResources` → `QTextDocument::addResource` → `QPrinter` |
| 应用新设置 | `SettingsDialog` 信号 → `applyEditorSettings()`（遍历所有页）/ `PreviewWidget::refreshSettings()` |
| 收藏/最近 | `AppSettings::toggleFavorite/addRecent` → `recentsChanged` → `FileSidebar::rebuildRecents` |
| 启停同步 | `AppSettings::setSyncEnabled` → `SyncManager::startIfEnabled/stop`（仅运行期） |
| 连接服务器弹窗 | `SyncManager::checkServerConnection` → `serverConnectionResult` → `QMessageBox` |
| 文件占用提示 | `LockClient::open/close` → `fileHeldElsewhere` → `QMessageBox` |
