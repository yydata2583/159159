#pragma once
#include <QString>
#include <QChar>
#include "core/FormatDetector.h"

class EditorWidget;

// Text formatting operations applied to the current selection of an editor.
// Markup is chosen per-document format (Markdown / AsciiDoc / OrgMode /
// WikiText / plain). Signatures are format-agnostic; the correct syntax is
// selected from EditorWidget::format().
namespace FormatActions {
    void bold(EditorWidget* ed);
    void italic(EditorWidget* ed);
    void strikeout(EditorWidget* ed);
    void inlineCode(EditorWidget* ed);
    void heading(EditorWidget* ed);          // cycle heading levels
    void blockquote(EditorWidget* ed);
    void bulletList(EditorWidget* ed);
    void orderedList(EditorWidget* ed);
    void checkboxList(EditorWidget* ed);
    void horizontalRule(EditorWidget* ed);
    void insertLink(EditorWidget* ed);
    void insertImage(EditorWidget* ed);
    void indent(EditorWidget* ed);
    void deindent(EditorWidget* ed);

    // Generic toggle using an explicit marker (format-agnostic).
    void toggleSurround(EditorWidget* ed, const QString& marker);

    // Markdown 语法自动补全（回车触发）：表格头行插 |---| 分隔行、``` 围栏闭合、
    // 列表续行/空项清除、标题行不延续 #。仅 Markdown 系生效。
    // 返回 true 表示已处理，调用方应跳过默认换行。
    bool handleSmartReturn(EditorWidget* ed);

    // 一次性全文自动整理：补表格分隔行、闭合未闭合的 ``` 围栏、裸标题补 #、
    // 连续 --- 规范成分隔线、待办行规范为 - [ ] / - [x]。宁少勿错，返回是否有改动。
    bool tidyMarkdown(EditorWidget* ed);
}
