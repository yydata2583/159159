#include "CodeLexer.h"

#include <QChar>
#include <QSet>

namespace CodeLexer {

// ---------------- 语言规则表 ----------------

namespace {

struct LangRule {
    QSet<QString> keywords;
    QSet<QString> types;
    QString lineComment;
    QString blockCommentStart;
    QString blockCommentEnd;
    bool backtickStrings = false;   // JS/TS 模板串
    bool hashPreprocessor = false;  // C 风格 # 预处理指令
};

QSet<QString> words(const QString& s)
{
    QSet<QString> out;
    const QStringList parts = s.split(QLatin1Char(' '), Qt::SkipEmptyParts);
    for (const QString& w : parts)
        out.insert(w);
    return out;
}

const LangRule& cppRule()
{
    static const LangRule r = [] {
        LangRule x;
        x.keywords = words(QStringLiteral(
            "alignas alignof auto break case catch class const constexpr "
            "continue default delete do else enum explicit extern for friend "
            "goto if inline namespace new noexcept operator private protected "
            "public register return sizeof static static_assert struct switch "
            "template this thread_local throw try typedef typeid typename "
            "union using virtual volatile while true false nullptr"));
        x.types = words(QStringLiteral(
            "int float double char bool void long short unsigned signed "
            "size_t wchar_t string wstring vector map set pair "
            "std::string std::vector std::map std::set std::pair"));
        x.lineComment = QStringLiteral("//");
        x.blockCommentStart = QStringLiteral("/*");
        x.blockCommentEnd = QStringLiteral("*/");
        x.hashPreprocessor = true;
        return x;
    }();
    return r;
}

const LangRule& pythonRule()
{
    static const LangRule r = [] {
        LangRule x;
        x.keywords = words(QStringLiteral(
            "and as assert async await break class continue def del elif else "
            "except finally for from global if import in is lambda nonlocal "
            "not or pass raise return try while with yield True False None"));
        x.types = words(QStringLiteral(
            "int float str list dict tuple set bool bytes self complex frozenset"));
        x.lineComment = QStringLiteral("#");
        return x;
    }();
    return r;
}

const LangRule& javascriptRule()
{
    static const LangRule r = [] {
        LangRule x;
        x.keywords = words(QStringLiteral(
            "async await break case catch class const continue default delete "
            "do else export extends finally for from function if import in "
            "instanceof let new of return static super switch this throw try "
            "typeof var void while yield true false null undefined "
            // TypeScript 关键字（js/ts/tsx 复用同一套）
            "interface type enum declare readonly abstract implements namespace "
            "any unknown never keyof as satisfies infer is public private "
            "protected"));
        x.types = words(QStringLiteral(
            "Array Boolean Date Error Function JSON Math Number Object Promise "
            "RegExp String Symbol Map Set WeakMap WeakSet"));
        x.lineComment = QStringLiteral("//");
        x.blockCommentStart = QStringLiteral("/*");
        x.blockCommentEnd = QStringLiteral("*/");
        x.backtickStrings = true;
        return x;
    }();
    return r;
}

const LangRule& rustRule()
{
    static const LangRule r = [] {
        LangRule x;
        x.keywords = words(QStringLiteral(
            "as async await break const continue crate dyn else enum extern fn "
            "for if impl in let loop match mod move mut pub ref return self Self "
            "static struct super trait type unsafe use where while true false"));
        x.types = words(QStringLiteral(
            "i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool "
            "char str String Vec Option Result Box HashMap"));
        x.lineComment = QStringLiteral("//");
        x.blockCommentStart = QStringLiteral("/*");
        x.blockCommentEnd = QStringLiteral("*/");
        return x;
    }();
    return r;
}

const LangRule& javaRule()
{
    static const LangRule r = [] {
        LangRule x;
        x.keywords = words(QStringLiteral(
            "abstract assert break case catch class const continue default do "
            "else enum extends final finally for goto if implements import "
            "instanceof interface native new package private protected public "
            "return static strictfp super switch synchronized this throw throws "
            "transient try volatile while true false null var record sealed"));
        x.types = words(QStringLiteral(
            "int float double char boolean byte short long void String Integer "
            "Double Boolean Long Short Byte Character List Map ArrayList HashMap "
            "Set Object"));
        x.lineComment = QStringLiteral("//");
        x.blockCommentStart = QStringLiteral("/*");
        x.blockCommentEnd = QStringLiteral("*/");
        return x;
    }();
    return r;
}

// 通用兜底：仅 C 风格注释/字符串/数字/运算符，无关键字与类型表
const LangRule& genericRule()
{
    static const LangRule r = [] {
        LangRule x;
        x.lineComment = QStringLiteral("//");
        x.blockCommentStart = QStringLiteral("/*");
        x.blockCommentEnd = QStringLiteral("*/");
        x.hashPreprocessor = true;
        return x;
    }();
    return r;
}

const LangRule& ruleFor(const QString& langKey)
{
    if (langKey == QLatin1String("cpp")) return cppRule();
    if (langKey == QLatin1String("python")) return pythonRule();
    if (langKey == QLatin1String("javascript")) return javascriptRule();
    if (langKey == QLatin1String("rust")) return rustRule();
    if (langKey == QLatin1String("java")) return javaRule();
    return genericRule();
}

bool isOperatorChar(QChar c)
{
    switch (c.unicode()) {
    case '+': case '-': case '*': case '/': case '%': case '=':
    case '<': case '>': case '!': case '&': case '|': case '^':
    case '~': case '?': case ':':
        return true;
    default:
        return false;
    }
}

bool isHexDigit(QChar c)
{
    const ushort u = c.unicode();
    return (u >= '0' && u <= '9') || (u >= 'a' && u <= 'f') || (u >= 'A' && u <= 'F');
}

// 编程语言通用 tokenizer（文档 §3.4）：空白/注释/字符串/数字/标识符/运算符/标点
QVector<Token> tokenizeCode(const QString& code, const LangRule& rule)
{
    QVector<Token> toks;
    const int n = code.size();
    int i = 0;
    while (i < n) {
        const QChar c = code[i];

        // 1) 空白 -> Plain
        if (c.isSpace()) {
            const int s = i;
            while (i < n && code[i].isSpace()) ++i;
            toks.append({s, i - s, TokenType::Plain});
            continue;
        }

        // 2) C 风格预处理指令：# 位于行首
        if (rule.hashPreprocessor && c == QLatin1Char('#')
            && (i == 0 || code[i - 1] == QLatin1Char('\n'))
            && i + 1 < n && code[i + 1].isLetter()) {
            const int s = i;
            while (i < n && code[i] != QLatin1Char('\n')) ++i;
            toks.append({s, i - s, TokenType::Preprocessor});
            continue;
        }

        // 3) 单行注释
        if (!rule.lineComment.isEmpty()
            && code.mid(i, rule.lineComment.size()) == rule.lineComment) {
            const int s = i;
            while (i < n && code[i] != QLatin1Char('\n')) ++i;
            toks.append({s, i - s, TokenType::Comment});
            continue;
        }

        // 4) 多行注释
        if (!rule.blockCommentStart.isEmpty()
            && code.mid(i, rule.blockCommentStart.size()) == rule.blockCommentStart) {
            const int s = i;
            i += rule.blockCommentStart.size();
            while (i < n
                   && code.mid(i, rule.blockCommentEnd.size()) != rule.blockCommentEnd)
                ++i;
            i = qMin(n, i + rule.blockCommentEnd.size());
            toks.append({s, i - s, TokenType::Comment});
            continue;
        }

        // 5) 字符串（双/单引号，JS 额外支持反引号模板串）
        if (c == QLatin1Char('"') || c == QLatin1Char('\'')
            || (rule.backtickStrings && c == QLatin1Char('`'))) {
            const int s = i;
            const QChar q = c;
            ++i;
            while (i < n && code[i] != q) {
                if (code[i] == QLatin1Char('\\') && i + 1 < n) ++i;
                ++i;
            }
            if (i < n) ++i;   // 跳过闭引号（未闭合时停在行尾）
            toks.append({s, i - s, TokenType::String});
            continue;
        }

        // 6) 数字（十进制/小数/科学计数/0x 十六进制）
        if (c.isDigit() || (c == QLatin1Char('.') && i + 1 < n && code[i + 1].isDigit())) {
            const int s = i;
            if (c == QLatin1Char('0') && i + 1 < n
                && (code[i + 1] == QLatin1Char('x') || code[i + 1] == QLatin1Char('X'))) {
                i += 2;
                while (i < n && (isHexDigit(code[i]) || code[i] == QLatin1Char('_'))) ++i;
            } else {
                while (i < n && (code[i].isDigit() || code[i] == QLatin1Char('_'))) ++i;
                if (i < n && code[i] == QLatin1Char('.')) {
                    ++i;
                    while (i < n && (code[i].isDigit() || code[i] == QLatin1Char('_'))) ++i;
                }
                if (i < n && (code[i] == QLatin1Char('e') || code[i] == QLatin1Char('E'))) {
                    const int save = i;
                    ++i;
                    if (i < n && (code[i] == QLatin1Char('+') || code[i] == QLatin1Char('-'))) ++i;
                    if (i < n && code[i].isDigit()) {
                        while (i < n && (code[i].isDigit() || code[i] == QLatin1Char('_'))) ++i;
                    } else {
                        i = save;
                    }
                }
            }
            toks.append({s, i - s, TokenType::Number});
            continue;
        }

        // 7) 标识符 / 关键字 / 类型 / 函数名（含 a::b 作用域名）
        if (c.isLetter() || c == QLatin1Char('_')) {
            const int s = i;
            while (i < n && (code[i].isLetterOrNumber() || code[i] == QLatin1Char('_'))) ++i;
            while (i + 1 < n && code[i] == QLatin1Char(':') && code[i + 1] == QLatin1Char(':')) {
                i += 2;
                while (i < n && (code[i].isLetterOrNumber() || code[i] == QLatin1Char('_'))) ++i;
            }
            const QString word = code.mid(s, i - s);
            if (rule.keywords.contains(word))
                toks.append({s, i - s, TokenType::Keyword});
            else if (rule.types.contains(word))
                toks.append({s, i - s, TokenType::Type});
            else if (i < n && code[i] == QLatin1Char('('))
                toks.append({s, i - s, TokenType::Function});
            else
                toks.append({s, i - s, TokenType::Plain});
            continue;
        }

        // 8) 运算符
        if (isOperatorChar(c)) {
            const int s = i;
            while (i < n && isOperatorChar(code[i])) ++i;
            toks.append({s, i - s, TokenType::Operator});
            continue;
        }

        // 9) 标点（其余单字符）
        toks.append({i, 1, TokenType::Punctuation});
        ++i;
    }
    return toks;
}

bool isAttrNameChar(QChar c)
{
    return c.isLetterOrNumber() || c == QLatin1Char('-') || c == QLatin1Char('_')
           || c == QLatin1Char(':') || c == QLatin1Char('.');
}

// HTML/XML 专用 tokenizer（文档 §3.3）。<style>/<script> 内嵌 CSS/JS 为控制实现
// 成本，此处统一按 HTML 规则处理（文本段按 Plain 输出）。
QVector<Token> tokenizeHtml(const QString& code)
{
    QVector<Token> toks;
    const int n = code.size();
    int i = 0;
    while (i < n) {
        // 注释 <!-- -->
        if (code.mid(i, 4) == QLatin1String("<!--")) {
            const int s = i;
            i += 4;
            while (i < n && code.mid(i, 3) != QLatin1String("-->")) ++i;
            i = qMin(n, i + 3);
            toks.append({s, i - s, TokenType::Comment});
            continue;
        }

        // 标签
        if (code[i] == QLatin1Char('<')) {
            ++i;   // 跳过 '<'（与文档一致，不单独着色）
            // 标签名
            const int ns = i;
            while (i < n && isAttrNameChar(code[i])) ++i;
            if (i > ns)
                toks.append({ns, i - ns, TokenType::Tag});
            // 属性循环
            while (i < n && code[i] != QLatin1Char('>') && code[i] != QLatin1Char('/')) {
                if (code[i].isSpace()) { ++i; continue; }
                const int as = i;
                while (i < n && isAttrNameChar(code[i])) ++i;
                if (i == as) { ++i; continue; }   // 跳过无法归类的杂散字符
                toks.append({as, i - as, TokenType::Attribute});
                const int save = i;
                while (i < n && code[i].isSpace()) ++i;
                if (i < n && code[i] == QLatin1Char('=')) {
                    toks.append({i, 1, TokenType::Operator});
                    ++i;
                    while (i < n && code[i].isSpace()) ++i;
                    if (i < n && (code[i] == QLatin1Char('"') || code[i] == QLatin1Char('\''))) {
                        const int vs = i;
                        const QChar q = code[i];
                        ++i;
                        while (i < n && code[i] != q) ++i;
                        if (i < n) ++i;
                        toks.append({vs, i - vs, TokenType::Value});
                    }
                } else {
                    i = save;
                }
            }
            // > 或 />
            if (i < n && code[i] == QLatin1Char('/')) {
                toks.append({i, 1, TokenType::Punctuation});
                ++i;
            }
            if (i < n && code[i] == QLatin1Char('>')) {
                toks.append({i, 1, TokenType::Punctuation});
                ++i;
            }
            continue;
        }

        // 标签间文本
        const int s = i;
        while (i < n && code[i] != QLatin1Char('<')) ++i;
        if (i > s)
            toks.append({s, i - s, TokenType::Plain});
    }
    return toks;
}

} // namespace

// ---------------- 公开接口 ----------------

QStringList languageKeys()
{
    // 索引 0 = 未知/纯文本；其余顺序固定稳定
    static const QStringList keys = {
        QString(),
        QStringLiteral("cpp"),
        QStringLiteral("python"),
        QStringLiteral("javascript"),
        QStringLiteral("rust"),
        QStringLiteral("java"),
        QStringLiteral("html"),
        QStringLiteral("generic")
    };
    return keys;
}

int languageIndex(const QString& langKey)
{
    const int idx = languageKeys().indexOf(langKey);
    return idx < 0 ? 0 : idx;
}

QString languageAt(int index)
{
    const QStringList keys = languageKeys();
    if (index < 0 || index >= keys.size())
        return QString();
    return keys.at(index);
}

QString detectLanguage(const QString& fenceInfo)
{
    // 去掉前导反引号/波浪号与首尾空白，取首个空白分隔的词并小写
    QString s = fenceInfo;
    int k = 0;
    while (k < s.size() && (s[k] == QLatin1Char('`') || s[k] == QLatin1Char('~'))) ++k;
    s = s.mid(k).trimmed();
    int sp = 0;
    while (sp < s.size() && !s[sp].isSpace()) ++sp;
    s = s.left(sp).toLower();
    if (s.isEmpty())
        return QString();

    if (s == QLatin1String("cpp") || s == QLatin1String("c++")
        || s == QLatin1String("cxx") || s == QLatin1String("cc")
        || s == QLatin1String("c") || s == QLatin1String("h")
        || s == QLatin1String("hpp") || s == QLatin1String("hxx")
        || s == QLatin1String("hh"))
        return QStringLiteral("cpp");
    if (s == QLatin1String("python") || s == QLatin1String("py")
        || s == QLatin1String("python3"))
        return QStringLiteral("python");
    if (s == QLatin1String("javascript") || s == QLatin1String("js")
        || s == QLatin1String("mjs") || s == QLatin1String("cjs")
        || s == QLatin1String("jsx") || s == QLatin1String("typescript")
        || s == QLatin1String("ts") || s == QLatin1String("tsx"))
        return QStringLiteral("javascript");
    if (s == QLatin1String("rust") || s == QLatin1String("rs"))
        return QStringLiteral("rust");
    if (s == QLatin1String("java"))
        return QStringLiteral("java");
    if (s == QLatin1String("html") || s == QLatin1String("htm")
        || s == QLatin1String("xhtml") || s == QLatin1String("xml")
        || s == QLatin1String("svg"))
        return QStringLiteral("html");

    // 未识别 -> 空串（调用方按纯文本处理，不分色）
    return QString();
}

QVector<Token> tokenize(const QString& code, const QString& langKey)
{
    if (code.isEmpty() || langKey.isEmpty())
        return {};
    if (languageIndex(langKey) <= 0)
        return {};   // 未知语言键
    if (langKey == QLatin1String("html"))
        return tokenizeHtml(code);
    return tokenizeCode(code, ruleFor(langKey));
}

} // namespace CodeLexer
