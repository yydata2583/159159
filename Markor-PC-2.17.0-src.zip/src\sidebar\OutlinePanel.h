#pragma once
#include <QWidget>
#include <QVector>
#include <QString>
#include "core/MarkdownConverter.h"

class QTreeWidget;
class QTreeWidgetItem;
class QStackedWidget;
class QLabel;
class QPropertyAnimation;
class SidebarHandle;
class EditorWidget;
class PreviewWidget;

// 大纲面板（预览区左侧）：每个文档标签各一套。
// 标题序列唯一来自 MarkdownConverter 的 BlockInfo（PreviewWidget 每次渲染后
// 发出 headingsAvailable），与预览元素、编辑器源行严格同源——不再自写正则
// 解析。点击平滑滚动预览并同步定位编辑器；ScrollSpy 随预览视口高亮章节。
class OutlinePanel : public QWidget {
    Q_OBJECT
    // 供收起/展开动画驱动：面板（树 + 把手）固定宽度
    Q_PROPERTY(int panelWidth READ panelWidth WRITE setPanelWidth)
public:
    explicit OutlinePanel(QWidget* parent = nullptr);

    // 绑定该页的编辑器/预览：heading 序列、ScrollSpy（每页仅绑定一次）
    void bind(EditorWidget* editor, PreviewWidget* preview);
    void refreshNow();        // 兼容保留：标题由预览渲染信号推送，无需手动解析

    int panelWidth() const { return width(); }
    void setPanelWidth(int w);

public slots:
    // 自动高亮：预览侧按规范 5.3（80px 阈值）给出激活标题的精确源行
    void setActiveHeadingLine(int line);

private slots:
    // 消费转换器权威标题序列（仅 H1–H4，与历史大纲层级一致）
    void setHeadings(const QVector<MarkdownConverter::BlockInfo>& headings);

private:
    struct Heading {
        QString text;
        int level = 1;
        int line = 1;         // 源行号（1 起，即 BlockInfo.srcLine）
    };

    void rebuild();
    void setExpanded(bool expanded, bool animated);

    QWidget* _content;
    QStackedWidget* _stack;
    QTreeWidget* _tree;
    QLabel* _placeholder;
    SidebarHandle* _handle;
    QPropertyAnimation* _anim = nullptr;

    EditorWidget* _editor = nullptr;
    PreviewWidget* _preview = nullptr;

    QVector<Heading> _headings;
    QVector<QTreeWidgetItem*> _items;
    bool _expanded = true;
    int _contentWidth = 200;      // 展开态内容宽度（不含把手）

    static constexpr int MIN_CONTENT = 180;
    static constexpr int MAX_CONTENT = 220;
};
