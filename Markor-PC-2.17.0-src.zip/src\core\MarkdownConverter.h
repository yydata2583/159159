#pragma once
#include <QString>
#include <QVector>

// Self-contained Markdown -> HTML converter used for the live preview and for
// HTML export. Supports the common Markor/markdown feature set:
// headings, emphasis, strong, strikeout, inline code, fenced code blocks,
// links, images, blockquotes, ordered/unordered/checkbox lists, tables,
// horizontal rules, hard/soft line breaks and YAML front-matter passthrough.
namespace MarkdownConverter {

    // 转换选项
    struct ConvertOptions {
        // true：段落内单换行渲染为 <br>（Markor 风格）；
        // false：严格 CommonMark，软换行渲染为空格。
        bool softBreaks = true;
    };

    // 块级元素描述：转换输出的每个顶层块一条，与输出 HTML 的顶层元素
    // （p/h/pre/table/blockquote/hr/ul/ol/div）顺序一一对应。
    // 这是滚动映射的唯一块序列真相（等价 code.html 中 preview.children
    // 与源码块配对后的 blocks），预览侧据此与 QTextDocument 结构按下标
    // 严格配对，不做任何文本猜测。
    struct BlockInfo {
        enum Kind {
            Paragraph,  // 普通段落 / HTML 文本块
            Heading,    // 标题（level 1-6，text 纯文本，slug 锚点 id）
            Code,       // 围栏或缩进代码块
            Quote,      // 引用块（整块一条）
            List,       // 列表（整个 ul/ol 一条，含嵌套列表与列表项内段落）
            Table,      // 表格（文档树中对应 QTextTable）
            Hr,         // 水平分隔线
            Media       // 图表 / 行间公式等单块媒体
        };
        int srcLine = 0;   // 起始源码行（1 起）
        int endLine = 0;   // 结束源码行（1 起，闭区间）
        Kind kind = Paragraph;
        int level = 0;     // 标题层级 1-6
        QString text;      // 标题纯文本（其余块为空）
        QString slug;      // 标题锚点 id

        BlockInfo() = default;
        BlockInfo(int start, int end, Kind k)
            : srcLine(start), endLine(end), kind(k) {}
        static BlockInfo heading(int start, int end, int lvl,
                                 const QString& txt, const QString& anchor) {
            BlockInfo b(start, end, Heading);
            b.level = lvl;
            b.text = txt;
            b.slug = anchor;
            return b;
        }
        bool isTable() const { return kind == Table; }
        bool isPre() const { return kind == Code; }
    };

    // Convert markdown body to an HTML fragment.
    // 每个块级 HTML 元素均注入 data-src-line="源文件起始行号(1 起)"；
    // blocks 非空时按输出顺序追加块描述（行号相对于传入的 markdown）。
    QString toHtmlFragment(const QString& markdown,
                           const ConvertOptions& options = {},
                           QVector<BlockInfo>* blocks = nullptr);

    // Convert markdown to a complete standalone HTML document with themed CSS.
    QString toHtmlDocument(const QString& markdown, bool darkTheme,
                           const ConvertOptions& options = {});

    // 预览调色板：为空时使用内置 dark/light 两套（历史行为）；非空时逐项
    // 采用调用方给定的主题色（ThemeManager），让预览跟随三套皮肤而不仅是
    // 亮/暗二态，且标题色与编辑区语法高亮一致。
    struct Palette {
        QString bg, fg, codeBg, link, quote, border, strike, accent, heading;
    };

    // Wrap an already-built HTML body into a themed standalone document.
    // fontPx：正文字号（预览缩放用，导出固定 15px）；
    // withScripts：附加复制按钮/任务勾选/平滑锚点脚本（仅供浏览器导出）。
    // fontFamily：正文字体族（预览读设置，导出默认 Segoe UI）。
    QString wrapHtmlDocument(const QString& bodyHtml, bool darkTheme,
                             int fontPx = 15, bool withScripts = false,
                             const Palette* palette = nullptr,
                             const QString& fontFamily = QStringLiteral("Segoe UI"));
}
