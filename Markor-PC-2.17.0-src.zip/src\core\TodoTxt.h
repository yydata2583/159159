#pragma once
#include <QString>
#include <QStringList>
#include <QDate>

// A single todo.txt task, with parse/serialize and structured accessors
// mirroring Markor's TodoTxtTask.
class TodoTxtTask {
public:
    TodoTxtTask() = default;
    explicit TodoTxtTask(const QString& line);

    QString line() const;            // re-serialize to a todo.txt line
    void setLine(const QString& line);

    bool isDone() const;
    void setDone(bool done);

    QChar priority() const;          // 'A'..'Z' or null
    void setPriority(QChar p);

    QDate completionDate() const;
    QDate creationDate() const;

    QString description() const;
    void setDescription(const QString& d);

    QStringList projects() const;    // +project
    QStringList contexts() const;    // @context
    QStringList tags() const;        // key:value

    QString value(const QString& key) const;   // tag value by key (e.g. "due")

    static TodoTxtTask fromParts(bool done, QChar priority, const QString& description);

private:
    void parse(const QString& line);
    QString _raw;
    bool _done = false;
    QChar _priority;
    QDate _completionDate;
    QDate _creationDate;
    QString _description;
    QStringList _projects;
    QStringList _contexts;
    QStringList _tags;
};

// Filter expression for todo.txt lists (mirrors Markor TodoTxtFilter basics).
namespace TodoTxtFilter {
    // tokens: text, +project, @context, pri:A, done, undone, key:value
    // A leading '-' negates a token.
    bool matches(const TodoTxtTask& task, const QString& filter, bool caseSensitive = false);
}
