#include "MarkdownHighlighter.h"
#include "app/ThemeManager.h"
#include <QColor>
#include <QTextBlock>
#include <QTextDocument>
#include <climits>

// 围栏状态解码助手（定义见文件后部「lint 规则」区）
static bool isFenceState(int s);
static int fenceLangIndex(int s);

MarkdownHighlighter::MarkdownHighlighter(QTextDocument* parent)
    : QSyntaxHighlighter(parent)
{
    refreshFormats();
}

void MarkdownHighlighter::refreshFormats()
{
    ThemeManager& t = ThemeManager::instance();

    _heading = QTextCharFormat();
    _heading.setForeground(t.headingColor());
    _heading.setFontWeight(QFont::Bold);

    _emphasis = QTextCharFormat();
    _emphasis.setForeground(t.emphasisColor());
    _emphasis.setFontItalic(true);

    _strong = QTextCharFormat();
    _strong.setForeground(t.strongColor());
    _strong.setFontWeight(QFont::Bold);

    _strike = QTextCharFormat();
    _strike.setForeground(t.strikeColor());
    _strike.setFontStrikeOut(true);

    _code = QTextCharFormat();
    _code.setForeground(t.codeColor());
    _code.setFontFamilies({QStringLiteral("Consolas"), QStringLiteral("monospace")});

    _link = QTextCharFormat();
    _link.setForeground(t.linkColor());
    _link.setFontUnderline(true);

    _quote = QTextCharFormat();
    _quote.setForeground(t.quoteColor());
    _quote.setFontItalic(true);

    _list = QTextCharFormat();
    _list.setForeground(t.listColor());
    _list.setFontWeight(QFont::Bold);

    _hr = QTextCharFormat();
    _hr.setForeground(t.hrColor());

    // lint 诊断：红色波浪下划线（叠加在常规高亮之上）
    _lintWarn = QTextCharFormat();
    _lintWarn.setUnderlineStyle(QTextCharFormat::WaveUnderline);
    _lintWarn.setUnderlineColor(QColor(Qt::red));

    // 围栏代码块内容着色：等宽字体 + 主题色映射（沿用 SourceCodeHighlighter 风格）
    _codePlain = QTextCharFormat();
    _codePlain.setForeground(t.editorFg());
    _codePlain.setFontFamilies({QStringLiteral("Consolas"), QStringLiteral("monospace")});

    _tokKeyword = QTextCharFormat();
    _tokKeyword.setForeground(t.listColor());
    _tokKeyword.setFontWeight(QFont::Bold);

    _tokType = QTextCharFormat();
    _tokType.setForeground(t.linkColor());

    _tokFunction = QTextCharFormat();
    _tokFunction.setForeground(t.headingColor());

    _tokString = QTextCharFormat();
    _tokString.setForeground(t.strongColor());

    _tokComment = QTextCharFormat();
    _tokComment.setForeground(t.quoteColor());
    _tokComment.setFontItalic(true);

    _tokNumber = QTextCharFormat();
    _tokNumber.setForeground(t.emphasisColor());

    _tokOperator = QTextCharFormat();
    _tokOperator.setForeground(t.codeColor());

    _tokPunctuation = QTextCharFormat();
    _tokPunctuation.setForeground(t.codeColor());

    _tokPreprocessor = QTextCharFormat();
    _tokPreprocessor.setForeground(t.strikeColor());

    _tokTag = QTextCharFormat();
    _tokTag.setForeground(t.headingColor());
    _tokTag.setFontWeight(QFont::Bold);

    _tokAttribute = QTextCharFormat();
    _tokAttribute.setForeground(t.emphasisColor());

    _tokValue = QTextCharFormat();
    _tokValue.setForeground(t.strongColor());

    buildRules();
    _memo.clear();
    ++_memoEpoch;   // 主题色全变：旧备忘录格式整体作废
    rehighlight();
}

void MarkdownHighlighter::record(int start, int len, const QTextCharFormat& fmt)
{
    setFormat(start, len, fmt);
    _recording.append({ start, len, fmt });
}

QTextCharFormat MarkdownHighlighter::tokenFormat(CodeLexer::TokenType t) const
{
    switch (t) {
    case CodeLexer::TokenType::Keyword:      return _tokKeyword;
    case CodeLexer::TokenType::Type:         return _tokType;
    case CodeLexer::TokenType::Function:     return _tokFunction;
    case CodeLexer::TokenType::String:       return _tokString;
    case CodeLexer::TokenType::Comment:      return _tokComment;
    case CodeLexer::TokenType::Number:       return _tokNumber;
    case CodeLexer::TokenType::Operator:     return _tokOperator;
    case CodeLexer::TokenType::Preprocessor: return _tokPreprocessor;
    case CodeLexer::TokenType::Tag:          return _tokTag;
    case CodeLexer::TokenType::Attribute:    return _tokAttribute;
    case CodeLexer::TokenType::Value:        return _tokValue;
    case CodeLexer::TokenType::Punctuation:  return _tokPunctuation;
    case CodeLexer::TokenType::Plain:        return _codePlain;
    }
    return _codePlain;
}

void MarkdownHighlighter::buildRules()
{
    _rules.clear();

    auto add = [this](const QString& pat, const QTextCharFormat& fmt) {
        Rule r;
        r.pattern = QRegularExpression(pat);
        r.format = fmt;
        _rules.append(r);
    };

    // Headings
    add(QStringLiteral("^#{1,6}\\s.*$"), _heading);
    // Horizontal rule
    add(QStringLiteral("^\\s*([-*_])(\\s*\\1){2,}\\s*$"), _hr);
    // Blockquote
    add(QStringLiteral("^\\s*>.*$"), _quote);
    // List bullets / numbers
    add(QStringLiteral("^\\s*[-*+]\\s"), _list);
    add(QStringLiteral("^\\s*\\d+[.)]\\s"), _list);
    // Checkbox
    add(QStringLiteral("\\[[ xX]\\]"), _list);
    // Inline code
    add(QStringLiteral("`[^`]+`"), _code);
    // Fenced code fence markers
    add(QStringLiteral("^```.*$"), _code);
    // Strong
    add(QStringLiteral("\\*\\*[^*]+\\*\\*"), _strong);
    add(QStringLiteral("__(.+?)__"), _strong);
    // Emphasis
    add(QStringLiteral("\\*[^*]+\\*"), _emphasis);
    add(QStringLiteral("_(.+?)_"), _emphasis);
    // Strikeout
    add(QStringLiteral("~~(.+?)~~"), _strike);
    // Links / images
    add(QStringLiteral("!?\\[[^\\]]*\\]\\([^)]*\\)"), _link);
}

void MarkdownHighlighter::scheduleRefresh()
{
    if (_rehighlightGuard || _refreshPending)
        return;
    _refreshPending = true;
    // 一次编辑会连续重算多个块：合并到事件循环空闲时仅全量重刷一遍，
    // 保证依赖相邻块的 lint（围栏闭合、表头分隔行）结果及时刷新
    QMetaObject::invokeMethod(this, [this]() {
        _refreshPending = false;
        _rehighlightGuard = true;
        rehighlight();
        _rehighlightGuard = false;
    }, Qt::QueuedConnection);
}

void MarkdownHighlighter::highlightBlock(const QString& text)
{
    const int bn = currentBlock().blockNumber();
    const int rawPrev = previousBlockState();

    // 备忘录快速路径：文本与前块状态均未变 → 高亮输出必然相同，
    // 直接恢复缓存格式，跳过全部正则与代码词法分析（整篇重刷时
    // 未受影响的块从这里通过，重刷开销从 O(全文×规则) 降为 O(全文)）
    if (auto it = _memo.constFind(bn); it != _memo.constEnd()
        && it->epoch == _memoEpoch && it->prevState == rawPrev
        && it->text == text) {
        for (const FormatRange& r : it->ranges)
            setFormat(r.start, r.len, r.fmt);
        setCurrentBlockState(it->newState);
        return;   // 诊断未变：_diags 保留原条目，无需重发 lint
    }

    // 本块诊断重建：先移除旧条目，lint 命中时由 warnRange 重新写入
    _diags.remove(bn);
    _recording.clear();

    for (const Rule& r : _rules) {
        QRegularExpressionMatchIterator it = r.pattern.globalMatch(text);
        while (it.hasNext()) {
            QRegularExpressionMatch m = it.next();
            record(m.capturedStart(), m.capturedLength(), r.format);
        }
    }

    const int oldState = currentBlockState();

    int prev = previousBlockState();
    if (prev < 0) prev = StateNormal;

    // 围栏块优先：处于围栏内（含开/闭合行）时不再做其它 lint
    if (!lintFence(text, prev)) {
        lintTableAndList(text, prev);
        if (currentBlockState() == StateNormal)
            lintInlineAndHeading(text);
    }

    // 围栏代码内容：本行不是围栏行时按语言词法着色（覆盖行内 lint 标记）
    if (isFenceState(currentBlockState())) {
        QChar fch; int flen = 0; QString frest;
        if (!isFenceLine(text, fch, flen, frest)) {
            const QString key =
                CodeLexer::languageAt(fenceLangIndex(currentBlockState()));
            if (!key.isEmpty()) {
                const QVector<CodeLexer::Token> toks = CodeLexer::tokenize(text, key);
                if (!toks.isEmpty()) {
                    record(0, text.size(), _codePlain);   // 先清底色再逐 token 着色
                    for (const CodeLexer::Token& t : toks) {
                        if (t.type == CodeLexer::TokenType::Plain) continue;
                        record(t.start, t.length, tokenFormat(t.type));
                    }
                }
            }
        }
    }

    // 块结构状态变化（围栏进出、表格成/坏）会影响相邻块诊断，
    // 排队一次全量重刷以消除跨块波浪线的陈旧状态；
    // oldState<0 表示首次高亮（前向扫描已得到正确结果），无需重刷
    if (oldState >= 0 && currentBlockState() != oldState)
        scheduleRefresh();

    // 存入备忘录：同一 (文本, 前块状态) 的重刷直接复用本次全部格式
    if (_memo.size() > document()->blockCount() * 2 + 64)
        _memo.clear();   // 块数收缩后的陈旧条目一次性回收
    _memo[bn] = { text, rawPrev, currentBlockState(), _memoEpoch, _recording };

    scheduleLintEmit();
}

void MarkdownHighlighter::scheduleLintEmit()
{
    if (_lintEmitPending)
        return;
    _lintEmitPending = true;
    QMetaObject::invokeMethod(this, [this]() {
        _lintEmitPending = false;
        if (!document())
            return;
        const int blockCount = document()->blockCount();
        int best = INT_MAX;
        LintDiag bestDiag;
        for (auto it = _diags.constBegin(); it != _diags.constEnd(); ++it) {
            if (it.key() < 0 || it.key() >= blockCount)
                continue;   // 忽略陈旧项
            if (it.key() < best) {
                best = it.key();
                bestDiag = it.value();
            }
        }
        if (best == INT_MAX)
            emit lintIssueChanged(-1, QString(), QString());
        else
            emit lintIssueChanged(best + 1, bestDiag.reason, bestDiag.fix);
    }, Qt::QueuedConnection);
}

void MarkdownHighlighter::warnRange(int start, int len, const QString& reason,
                                    const QString& fix)
{
    if (len <= 0 || start < 0 || start >= currentBlock().text().size())
        return;
    record(start, qBound(1, len, currentBlock().text().size() - start),
           _lintWarn);
    const int bn = currentBlock().blockNumber();
    auto it = _diags.find(bn);
    if (it == _diags.end() || start < it->start) {
        LintDiag d;
        d.reason = reason;
        d.fix = fix;
        d.start = start;
        _diags.insert(bn, d);
    }
}

// ---------------- 静态行判定工具（与 MarkdownConverter 规则保持一致） ----------------

int MarkdownHighlighter::leadColumns(const QString& s)
{
    int col = 0;
    for (QChar c : s) {
        if (c == QLatin1Char(' ')) ++col;
        else if (c == QLatin1Char('\t')) col += 4 - (col % 4);
        else break;
    }
    return col;
}

bool MarkdownHighlighter::isHrLike(const QString& s)
{
    int k = 0;
    while (k < s.size() && s[k] == QLatin1Char(' ') && k < 3) ++k;
    if (k >= s.size()) return false;
    const QChar c = s[k];
    if (c != QLatin1Char('-') && c != QLatin1Char('*') && c != QLatin1Char('_'))
        return false;
    int count = 0;
    for (; k < s.size(); ++k) {
        if (s[k] == c) ++count;
        else if (s[k] == QLatin1Char(' ') || s[k] == QLatin1Char('\t')) continue;
        else return false;
    }
    return count >= 3;
}

// 按未转义 | 切分单元格并去除单个首尾管道
static QStringList splitCells(const QString& s)
{
    QStringList out;
    QString t = s.trimmed();
    if (t.startsWith(QLatin1Char('|'))) t = t.mid(1);
    if (t.endsWith(QLatin1Char('|'))
        && t.size() >= 2 && t[t.size() - 2] != QLatin1Char('\\'))
        t.chop(1);
    QString cell;
    for (int k = 0; k < t.size(); ++k) {
        if (t[k] == QLatin1Char('|')
            && (k == 0 || t[k - 1] != QLatin1Char('\\'))) {
            out << cell;
            cell.clear();
        } else {
            cell += t[k];
        }
    }
    out << cell;
    return out;
}

bool MarkdownHighlighter::isDelimiterRow(const QString& s)
{
    const QStringList cells = splitCells(s);
    if (cells.isEmpty()) return false;
    static const QRegularExpression cellRe(QStringLiteral("^:?-+:?$"));
    for (const QString& c : cells)
        if (!cellRe.match(c.trimmed()).hasMatch()) return false;
    return unescapedPipeCount(s) > 0 || cells.size() == 1;
}

int MarkdownHighlighter::unescapedPipeCount(const QString& s)
{
    int n = 0;
    for (int k = 0; k < s.size(); ++k)
        if (s[k] == QLatin1Char('|')
            && (k == 0 || s[k - 1] != QLatin1Char('\\')))
            ++n;
    return n;
}

bool MarkdownHighlighter::matchListMarker(const QString& s, int& contentCol)
{
    const int ind = leadColumns(s);
    if (ind > 3) return false;
    int p = ind;
    int num = 0, digits = 0;
    while (p < s.size() && s[p].isDigit() && digits < 9) {
        num = num * 10 + s[p].digitValue();
        ++digits; ++p;
    }
    if (digits > 0 && p < s.size()
        && (s[p] == QLatin1Char('.') || s[p] == QLatin1Char(')'))) {
        ++p;
    } else if (digits == 0 && p < s.size()
               && (s[p] == QLatin1Char('-') || s[p] == QLatin1Char('*')
                   || s[p] == QLatin1Char('+'))) {
        ++p;
    } else return false;

    // 标记后必须为空白或行尾
    if (p < s.size() && !s[p].isSpace())
        return false;

    const int markerEnd = p;
    int w = 0;
    while (p < s.size() && (s[p] == QLatin1Char(' ')
                            || s[p] == QLatin1Char('\t'))) {
        if (s[p] == QLatin1Char(' ')) ++w;
        else w += 4 - (w % 4);
        ++p;
    }
    contentCol = (w >= 5 || w == 0) ? markerEnd + 1 : markerEnd + w;
    Q_UNUSED(num);
    return true;
}

bool MarkdownHighlighter::looksLikeBlockStart(const QString& s)
{
    if (isHrLike(s)) return true;
    const QString t = s.trimmed();
    if (t.isEmpty()) return false;
    if (t.startsWith(QLatin1Char('>'))) return true;
    if (t.startsWith(QStringLiteral("<!--"))) return true;
    if (t.startsWith(QLatin1Char('<'))) return true;
    static const QRegularExpression atxRe(QStringLiteral("#{1,6}(?:\\s|$)"));
    if (atxRe.match(t).hasMatch()) return true;
    QChar ch; int len; QString rest;
    if (isFenceLine(s, ch, len, rest)) return true;
    int contentCol = 0;
    if (matchListMarker(s, contentCol)) return true;
    return false;
}

bool MarkdownHighlighter::isFenceLine(const QString& s, QChar& ch, int& len,
                                      QString& rest)
{
    static const QRegularExpression re(QStringLiteral(
        "^ {0,3}(`{3,}|~{3,})(.*)$"));
    const QRegularExpressionMatch m = re.match(s);
    if (!m.hasMatch()) return false;
    const QString mark = m.captured(1);
    ch = mark[0];
    len = mark.size();
    rest = m.captured(2).trimmed();
    // 反引号围栏的 info string 内不得再出现反引号
    if (ch == QLatin1Char('`') && rest.contains(QLatin1Char('`')))
        return false;
    return true;
}

// ---------------- lint 规则 ----------------
// 围栏块状态编码：base(反引号 1000000 / 波浪线 2000000) + langIndex * 10000
// + openLen，以便闭合判定比较长度（嵌套围栏 1.10：``` 不能闭合 ````），
// 同时携带语言索引供块内容词法着色。langIndex < 100、openLen < 10000。
static int fenceStateFor(QChar ch, int openLen, int langIndex)
{
    const int base = (ch == QLatin1Char('`')) ? 1000000 : 2000000;
    return base + qBound(0, langIndex, 99) * 10000 + qBound(0, openLen, 9999);
}

// 围栏状态解码助手
static bool isFenceState(int s) { return s >= 1000000; }
static bool fenceIsTilde(int s) { return s >= 2000000; }
static int fenceLangIndex(int s) { return (s % 1000000) / 10000; }
static int fenceOpenLen(int s) { return s % 10000; }

// 返回 true 表示本行属于围栏（开/闭/内容），跳过其余 lint
bool MarkdownHighlighter::lintFence(const QString& text, int prevState)
{
    QChar ch; int len = 0; QString rest;
    const bool fenceHere = isFenceLine(text, ch, len, rest);

    if (isFenceState(prevState)) {
        const QChar expect = fenceIsTilde(prevState) ? QLatin1Char('~')
                                                     : QLatin1Char('`');
        const int openLen = fenceOpenLen(prevState);
        if (fenceHere && ch == expect && len >= openLen) {
            setCurrentBlockState(StateNormal);   // 闭合行（1.3：尾随空格由 trimmed rest 兼容）
            if (!rest.isEmpty()) {
                // 验收 1.2：结尾围栏不应带语言标注 → 警告标注部分，但仍正确闭合
                int q = 0;
                while (q < text.size() && text[q] == QLatin1Char(' ')) ++q;
                q += len;
                while (q < text.size()
                       && (text[q] == QLatin1Char(' ') || text[q] == QLatin1Char('\t'))) ++q;
                warnRange(q, text.size() - q,
                          QStringLiteral("结尾围栏后不应带语言标注"),
                          QStringLiteral("结尾围栏只写围栏符号，去掉后面的语言名"));
            }
        } else {
            setCurrentBlockState(prevState);     // 围栏内容（保持编码状态）
        }
        return true;
    }

    if (!fenceHere) return false;

    // 开围栏：前扫至文档结束，寻找同字符且不短于开围栏的闭合行；
    // 带语言标注的闭合行也算闭合（该行自身会被 1.2 规则警告）
    bool closed = false;
    QTextBlock b = currentBlock().next();
    while (b.isValid()) {
        QChar c2; int l2 = 0; QString r2;
        if (isFenceLine(b.text(), c2, l2, r2) && c2 == ch && l2 >= len) {
            closed = true;
            break;
        }
        b = b.next();
    }
    if (!closed) {
        int p = 0;
        while (p < text.size() && p < 3 && text[p] == QLatin1Char(' ')) ++p;
        warnRange(p, len,
                  QStringLiteral("未闭合的代码围栏"),
                  QStringLiteral("在代码块末尾补一行 ``` 或 ~~~ 闭合围栏"));
    }
    const QString key = CodeLexer::detectLanguage(rest);
    setCurrentBlockState(fenceStateFor(ch, len, CodeLexer::languageIndex(key)));
    return true;
}

void MarkdownHighlighter::lintTableAndList(const QString& text, int prevState)
{
    if (text.trimmed().isEmpty()) {
        setCurrentBlockState(StateNormal);
        return;
    }

    // 验收 2.2/2.3：全角竖线 ｜ 不作列分隔 → 警告（逐字标出）
    for (int k = text.indexOf(u'｜'); k >= 0; k = text.indexOf(u'｜', k + 1))
        warnRange(k, 1,
                  QStringLiteral("全角竖线 ｜ 不能作为表格列分隔"),
                  QStringLiteral("改用半角竖线 |"));

    // 验收 7.2/7.3：--- 紧跟段落（Setext 歧义）或 ***/___ 前无空行 → 警告；
    // 上一行是块起始（标题/列表/围栏/引用等）或缩进代码块时不警告
    if (isHrLike(text)) {
        const QTextBlock pb = currentBlock().previous();
        if (pb.isValid() && !pb.text().trimmed().isEmpty()
            && prevState == StateNormal
            && !isHrLike(pb.text())
            && !looksLikeBlockStart(pb.text())
            && leadColumns(pb.text()) < 4)
            warnRange(0, text.size(),
                      QStringLiteral("分隔线 --- 前缺少空行，存在 Setext 标题歧义"),
                      QStringLiteral("在分隔线前插入一个空行"));
    }

    const int pipes = unescapedPipeCount(text);
    const bool delim = isDelimiterRow(text);
    const QTextBlock nextBlock = currentBlock().next();
    const bool nextIsDelim =
        nextBlock.isValid() && !nextBlock.text().trimmed().isEmpty()
        && isDelimiterRow(nextBlock.text());

    int state = StateNormal;
    if (delim) {
        state = StateTableRow;
    } else if (pipes >= 2) {
        if (prevState == StateTableRow) {
            state = StateTableRow;              // 合法数据行
        } else if (nextIsDelim
                   && splitCells(text).size()
                          == splitCells(nextBlock.text()).size()) {
            state = StateTableHead;
            // 02-9：表头紧贴普通文本（无空行）→ 跨平台渲染不一致
            const QTextBlock pb = currentBlock().previous();
            if (pb.isValid() && !pb.text().trimmed().isEmpty()
                && previousBlockState() != StateTableRow
                && previousBlockState() != StateTableHead
                && !looksLikeBlockStart(pb.text())) {
                warnRange(0, text.size(),
                          QStringLiteral("表头紧贴上一段文本（缺少空行）"),
                          QStringLiteral("在表头前插入一个空行"));
            }
        } else {
            // 缺分隔行 / 表头与分隔行列数不一致：仅告警该连续管道段的首行
            if (prevState != StateOrphanPipe)
                warnRange(0, text.size(),
                          QStringLiteral("疑似表格缺少 |---| 分隔行"),
                          QStringLiteral("在表头下一行添加 |---|---| 分隔行"));
            state = StateOrphanPipe;
        }
    }
    setCurrentBlockState(state);

    // 列表续行缩进不足：上一非空行（紧邻块）是列表标记，本行有缩进
    // 但小于该标记的内容列，且本行自身不是新列表标记
    if (state == StateNormal) {
        const int ind = leadColumns(text);
        int selfCol = 0;
        if (ind > 0 && !matchListMarker(text, selfCol)) {
            const QTextBlock pb = currentBlock().previous();
            if (pb.isValid() && !pb.text().trimmed().isEmpty()
                && previousBlockState() == StateNormal) {
                int contentCol = 0;
                if (matchListMarker(pb.text(), contentCol) && ind < contentCol)
                    warnRange(0, text.size(),
                              QStringLiteral("列表续行缩进不足"),
                              QStringLiteral("本节续行缩进到与列表内容对齐"));
            }
        }
    }
}

void MarkdownHighlighter::lintInlineAndHeading(const QString& text)
{
    // ---- ATX 标题 # 后缺少空格（#标签 形态）----
    static const QRegularExpression noSpaceRe(QStringLiteral(
        "^ {0,3}(#{1,6})(?=[^#\\s])"));
    const QRegularExpressionMatch hm = noSpaceRe.match(text);
    if (hm.hasMatch())
        warnRange(hm.capturedStart(1), hm.capturedLength(1),
                  QStringLiteral("标题 # 与文字之间缺少空格"),
                  QStringLiteral("写成 \"# 标题\"（# 后加一个空格）"));

    // 列表/引用/分隔线/围栏行不做强调配对检查，避免把标记当未闭合定界符
    int markerCol = 0;
    if (matchListMarker(text, markerCol) || isHrLike(text)
        || text.trimmed().startsWith(QLatin1Char('>')))
        return;
    QChar fch; int flen = 0; QString frest;
    if (isFenceLine(text, fch, flen, frest))
        return;

    // ---- 未闭合的 ** / * ----
    // 扫描时屏蔽代码跨度与反斜杠转义；定界符按简化侧翼规则就近配对，
    // 最终仍未消耗的开定界符标红波浪。
    struct Tok { int pos; int weight; bool canOpen; bool canClose; bool used; };
    QVector<Tok> toks;
    const int n = text.size();
    int i = 0;
    while (i < n) {
        const QChar c = text[i];
        if (c == QLatin1Char('\\') && i + 1 < n) { i += 2; continue; }
        if (c == QLatin1Char('`')) {
            int l = 0;
            while (i + l < n && text[i + l] == QLatin1Char('`')) ++l;
            int j = i + l, closePos = -1;
            while (j < n) {
                if (text[j] == QLatin1Char('`')) {
                    int m = 0;
                    while (j + m < n && text[j + m] == QLatin1Char('`')) ++m;
                    if (m == l) { closePos = j; break; }
                    j += m;
                } else ++j;
            }
            i = closePos >= 0 ? closePos + l : i + l;
            continue;
        }
        if (c == QLatin1Char('*')) {
            int l = 0;
            while (i + l < n && text[i + l] == QLatin1Char('*')) ++l;
            const bool left = i + l < n && !text[i + l].isSpace();
            const bool right = i > 0 && !text[i - 1].isSpace();
            const int doubles = l / 2;
            for (int k = 0; k < doubles; ++k) {
                Tok t{ i + 2 * k, 2,
                       k == 0 && left,
                       (l % 2 == 0) && k == doubles - 1 && right, false };
                toks << t;
            }
            if (l % 2 == 1)
                toks << Tok{ i + 2 * doubles, 1, left, right, false };
            i += l;
        } else {
            ++i;
        }
    }

    for (int ci = 0; ci < toks.size(); ++ci) {
        if (!toks[ci].canClose) continue;
        for (int oi = ci - 1; oi >= 0; --oi) {
            if (!toks[oi].used && toks[oi].canOpen
                && toks[oi].weight == toks[ci].weight) {
                toks[oi].used = true;
                toks[ci].used = true;
                break;
            }
        }
    }
    for (const Tok& t : toks)
        if (t.canOpen && !t.used)
            warnRange(t.pos, t.weight,
                      QStringLiteral("未闭合的加粗/斜体定界符 ** 或 *"),
                      QStringLiteral("行内成对使用 **加粗** 或 *斜体*"));
}
