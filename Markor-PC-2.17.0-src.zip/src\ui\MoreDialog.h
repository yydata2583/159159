#pragma once
#include <QDialog>

// "More" screen. Per project requirements the following entries are
// intentionally NOT included: open-source license, social/community,
// project team, help, and rate-this-app.
class MoreDialog : public QDialog {
    Q_OBJECT
public:
    explicit MoreDialog(QWidget* parent = nullptr);

signals:
    void openSettingsRequested();
    void openChangelogRequested();
};
