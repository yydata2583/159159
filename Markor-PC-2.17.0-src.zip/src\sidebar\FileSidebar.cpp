#include "FileSidebar.h"
#include "SidebarHandle.h"
#include "browser/FileBrowserWidget.h"
#include "app/AppSettings.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QTabBar>
#include <QStackedWidget>
#include <QListWidget>
#include <QListWidgetItem>
#include <QItemSelectionModel>
#include <QMenu>
#include <QMessageBox>
#include <QFile>
#include <QFileInfo>
#include <QFileIconProvider>
#include <QPropertyAnimation>
#include <QTimer>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QUrl>
#include <QAbstractItemView>

FileSidebar::FileSidebar(QWidget* parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("FileSidebar"));

    AppSettings& s = AppSettings::instance();
    _expanded = s.fileSidebarVisible();
    _contentWidth = qBound(MIN_CONTENT, s.fileSidebarWidth(), MAX_CONTENT);

    auto* root = new QHBoxLayout(this);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);

    // --- 内容区：顶部两个 Tab + 共用的列表堆栈（无额外标题） ---
    _content = new QWidget(this);
    auto* contentLay = new QVBoxLayout(_content);
    contentLay->setContentsMargins(2, 2, 2, 2);
    contentLay->setSpacing(2);

    _tabBar = new QTabBar(_content);
    _tabBar->setObjectName(QStringLiteral("SidebarTabBar"));
    _tabBar->setDrawBase(false);
    _tabBar->setUsesScrollButtons(false);
    _tabBar->addTab(tr("最近"));
    _tabBar->addTab(tr("文件"));
    _tabBar->setCurrentIndex(qBound(0, s.fileSidebarTab(), 1));
    contentLay->addWidget(_tabBar);

    _stack = new QStackedWidget(_content);
    contentLay->addWidget(_stack, 1);

    // 最近：打开时间倒序（AppSettings 中 addRecent 始终前插）
    _recentList = new QListWidget(_stack);
    _recentList->setObjectName(QStringLiteral("RecentListView"));
    _recentList->setContextMenuPolicy(Qt::CustomContextMenu);
    _recentList->setMinimumWidth(0);   // 拖窄/收起过程中允许压缩，不溢出
    _stack->addWidget(_recentList);

    // 文件：复用 FileBrowserWidget 的 QFileSystemModel 目录树
    _browser = new FileBrowserWidget(_stack);
    _browser->setMinimumWidth(0);
    _stack->addWidget(_browser);
    _stack->setCurrentIndex(_tabBar->currentIndex());

    _content->setMinimumWidth(0);
    _stack->setMinimumWidth(0);
    root->addWidget(_content, 1);

    // --- 右缘 Toggle 把手 ---
    _handle = new SidebarHandle(this);
    _handle->setCollapsed(!_expanded);
    root->addWidget(_handle);

    // 初始尺寸（无动画直接落位）
    setFixedWidth(_expanded ? _contentWidth + SidebarHandle::HANDLE_WIDTH
                            : SidebarHandle::HANDLE_WIDTH);
    _content->setVisible(_expanded);

    // Tab 切换
    connect(_tabBar, &QTabBar::currentChanged, this, [this](int idx) {
        _stack->setCurrentIndex(idx);
        AppSettings::instance().setFileSidebarTab(idx);
    });

    // 最近列表：单击打开/切换文档
    connect(_recentList, &QListWidget::itemClicked, this, [this](QListWidgetItem* it) {
        onRecentItemClicked(_recentList->row(it));
    });
    connect(_recentList, &QListWidget::customContextMenuRequested, this, [this](const QPoint& pos) {
        QListWidgetItem* it = _recentList->itemAt(pos);
        QMenu menu(this);
        QAction* ren = it ? menu.addAction(tr("重命名")) : nullptr;
        QAction* rm = menu.addAction(tr("从最近列表移除"));
        QAction* clearAll = menu.addAction(tr("清空最近列表"));
        QAction* chosen = menu.exec(_recentList->mapToGlobal(pos));
        if (chosen == ren && it) {
            // 行内编辑：临时允许编辑，提交后改回只读（避免双击误触发）
            it->setFlags(it->flags() | Qt::ItemIsEditable);
            _recentList->editItem(it);
            it->setFlags(it->flags() & ~Qt::ItemIsEditable);
        }
        else if (chosen == rm && it)
            AppSettings::instance().removeRecent(it->data(Qt::UserRole).toString());
        else if (chosen == clearAll)
            AppSettings::instance().clearRecents();
    });
    // 行内重命名提交：改文件名、更新路径记录
    connect(_recentList, &QListWidget::itemChanged, this, [this](QListWidgetItem* it) {
        const QString oldPath = it->data(Qt::UserRole).toString();
        const QString newName = it->text().trimmed();
        if (oldPath.isEmpty() || newName.isEmpty())
            return;
        const QFileInfo fi(oldPath);
        if (newName == fi.fileName())
            return;
        const QString newPath = fi.absolutePath() + QLatin1Char('/') + newName;
        if (QFile::exists(newPath)) {
            QMessageBox::warning(this, tr("重命名失败"), tr("已存在同名文件：%1").arg(newName));
            it->setText(fi.fileName());
            return;
        }
        if (QFile::rename(oldPath, newPath)) {
            it->setData(Qt::UserRole, newPath);
            it->setToolTip(newPath);
            AppSettings::instance().renameRecent(oldPath, newPath);
            emit statusMessage(tr("已重命名为 %1").arg(newName));
        } else {
            QMessageBox::warning(this, tr("重命名失败"), tr("无法重命名为 %1").arg(newName));
            it->setText(fi.fileName());
        }
    });
    connect(&AppSettings::instance(), &AppSettings::recentsChanged,
            this, &FileSidebar::rebuildRecents);
    rebuildRecents();

    // 外部拖文件到面板（最近/文件任意位置）：打开并记入最近列表。
    // 子视图默认各自接收拖放事件且不冒泡，需先关掉让事件落到本面板
    setAcceptDrops(true);
    _recentList->setAcceptDrops(false);
    for (auto* v : _browser->findChildren<QAbstractItemView*>())
        v->setAcceptDrops(false);

    // 文件树信号直接外抛给主窗口
    connect(_browser, &FileBrowserWidget::fileActivated,
            this, &FileSidebar::fileActivated);
    connect(_browser, &FileBrowserWidget::openInNewTab,
            this, &FileSidebar::openInNewTab);
    connect(_browser, &FileBrowserWidget::toggleFavorite,
            this, &FileSidebar::toggleFavorite);
    connect(_browser, &FileBrowserWidget::statusMessage,
            this, &FileSidebar::statusMessage);

    // 把手：单击收起/展开
    connect(_handle, &SidebarHandle::toggled, this, [this]() {
        setExpanded(!_expanded, /*animated=*/true);
        AppSettings::instance().setFileSidebarVisible(_expanded);
    });
    // 把手：按住拖拽实时改宽（收起态向右拖即拉出）
    connect(_handle, &SidebarHandle::dragged, this, [this](int dx) {
        if (_anim) {
            _anim->stop();
            _anim->deleteLater();
            _anim = nullptr;
        }
        int content = qBound(0, width() - SidebarHandle::HANDLE_WIDTH + dx, MAX_CONTENT);
        _content->setVisible(content > 0);
        setFixedWidth(SidebarHandle::HANDLE_WIDTH + content);
    });
    // 拖拽释放：窄于阈值自动收起；否则吸附最小宽度并记忆
    connect(_handle, &SidebarHandle::dragFinished, this, [this]() {
        int content = width() - SidebarHandle::HANDLE_WIDTH;
        AppSettings& st = AppSettings::instance();
        if (content <= AUTO_COLLAPSE) {
            setExpanded(false, /*animated=*/true);
            st.setFileSidebarVisible(false);
            return;
        }
        if (content < MIN_CONTENT)
            content = MIN_CONTENT;
        setFixedWidth(SidebarHandle::HANDLE_WIDTH + content);
        _content->setVisible(true);
        _expanded = true;
        _handle->setCollapsed(false);
        _contentWidth = content;
        st.setFileSidebarWidth(_contentWidth);
        st.setFileSidebarVisible(true);
    });
}

void FileSidebar::setPanelWidth(int w)
{
    setFixedWidth(w);
}

void FileSidebar::dragEnterEvent(QDragEnterEvent* event)
{
    // 至少一个本地文件即接受（文件夹/远程地址忽略）
    if (!event->mimeData()->hasUrls())
        return;
    for (const QUrl& u : event->mimeData()->urls()) {
        if (u.isLocalFile() && QFileInfo(u.toLocalFile()).isFile()) {
            event->acceptProposedAction();
            return;
        }
    }
}

void FileSidebar::dropEvent(QDropEvent* event)
{
    for (const QUrl& u : event->mimeData()->urls()) {
        if (!u.isLocalFile())
            continue;
        const QString p = u.toLocalFile();
        if (QFileInfo(p).isFile())
            emit fileActivated(p);   // 主窗口打开；createPage 内会记入最近列表
    }
    event->acceptProposedAction();
}

void FileSidebar::setExpanded(bool expanded, bool animated)
{
    // 状态相同且可见性已一致才跳过（拖拽后状态未变但内容可能仍显示）
    if (_expanded == expanded && _anim == nullptr
        && _content->isVisible() == expanded)
        return;
    _expanded = expanded;
    _handle->setCollapsed(!expanded);

    const int target = expanded ? _contentWidth + SidebarHandle::HANDLE_WIDTH
                                : SidebarHandle::HANDLE_WIDTH;
    if (!animated) {
        setFixedWidth(target);
        _content->setVisible(expanded);
        return;
    }

    if (expanded)
        _content->setVisible(true);   // 动画开始前先显示内容
    if (_anim) {
        _anim->stop();
        _anim->deleteLater();
    }
    _anim = new QPropertyAnimation(this, "panelWidth", this);
    _anim->setDuration(200);
    _anim->setStartValue(width());
    _anim->setEndValue(target);
    _anim->setEasingCurve(QEasingCurve::OutCubic);
    connect(_anim, &QPropertyAnimation::finished, this, [this, expanded]() {
        if (!expanded)
            _content->setVisible(false);
        if (expanded)
            AppSettings::instance().setFileSidebarWidth(_contentWidth);
        _anim->deleteLater();
        _anim = nullptr;
    });
    _anim->start();
}

void FileSidebar::setRootPath(const QString& path)
{
    _browser->setRootPath(path);
}

void FileSidebar::setCurrentPath(const QString& path)
{
    _currentPath = path;

    // 最近列表：选中匹配条目（不触发 itemClicked）
    bool found = false;
    for (int i = 0; i < _recentList->count(); ++i) {
        QListWidgetItem* it = _recentList->item(i);
        if (it->data(Qt::UserRole).toString() == path) {
            _recentList->setCurrentItem(it, QItemSelectionModel::ClearAndSelect);
            found = true;
            break;
        }
    }
    if (!found)
        _recentList->clearSelection();

    // 文件树：定位并高亮（QFileSystemModel 懒加载，目录索引可能尚未就绪，
    // 未就绪时延迟一拍重试一次）
    _browser->selectPath(path);
    if (!path.isEmpty()) {
        QTimer::singleShot(300, this, [this, path]() {
            if (_currentPath == path)
                _browser->selectPath(path);
        });
    }
}

void FileSidebar::rebuildRecents()
{
    const QString current = _currentPath;
    _recentList->clear();
    const QStringList recents = AppSettings::instance().recents();
    QFileIconProvider icons;
    for (const QString& p : recents) {
        if (!QFile::exists(p))
            continue;
        const QFileInfo fi(p);
        auto* it = new QListWidgetItem(icons.icon(fi), fi.fileName(), _recentList);
        it->setToolTip(p);
        it->setData(Qt::UserRole, p);
    }
    // 重建后恢复当前文档高亮
    if (!current.isEmpty())
        setCurrentPath(current);
}

void FileSidebar::onRecentItemClicked(int row)
{
    QListWidgetItem* it = _recentList->item(row);
    if (it)
        emit fileActivated(it->data(Qt::UserRole).toString());
}
