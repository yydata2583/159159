#include "SidebarHandle.h"

#include <QPainter>
#include <QPainterPath>
#include <QMouseEvent>
#include <QPaintEvent>

SidebarHandle::SidebarHandle(QWidget* parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("SidebarHandle"));
    setFixedWidth(HANDLE_WIDTH);
    setCursor(Qt::SplitHCursor);
    setToolTip(tr("单击收起/展开，拖动调整宽度"));
    setAttribute(Qt::WA_Hover, true);
}

void SidebarHandle::setCollapsed(bool collapsed)
{
    _collapsed = collapsed;
    update();
}

void SidebarHandle::paintEvent(QPaintEvent* /*event*/)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);

    // 小箭头：展开态 «（点一下收起），收起态 »（点一下展开）
    const QColor c = palette().windowText().color();
    p.setPen(QPen(QColor(c.red(), c.green(), c.blue(), 150), 1.4));
    const QPointF mid(width() / 2.0, height() / 2.0);
    const qreal dx = 2.2, dy = 3.2;
    QPainterPath path;
    if (_collapsed) {
        // »
        path.moveTo(mid.x() - dx, mid.y() - dy);
        path.lineTo(mid.x() + dx * 0.4, mid.y());
        path.lineTo(mid.x() - dx, mid.y() + dy);
        path.moveTo(mid.x() - dx - 2.6, mid.y() - dy);
        path.lineTo(mid.x() + dx * 0.4 - 2.6, mid.y());
        path.lineTo(mid.x() - dx - 2.6, mid.y() + dy);
    } else {
        // «
        path.moveTo(mid.x() + dx, mid.y() - dy);
        path.lineTo(mid.x() - dx * 0.4, mid.y());
        path.lineTo(mid.x() + dx, mid.y() + dy);
        path.moveTo(mid.x() + dx + 2.6, mid.y() - dy);
        path.lineTo(mid.x() - dx * 0.4 + 2.6, mid.y());
        path.lineTo(mid.x() + dx + 2.6, mid.y() + dy);
    }
    p.drawPath(path);
}

void SidebarHandle::mousePressEvent(QMouseEvent* event)
{
    if (event->button() != Qt::LeftButton)
        return;
    _pressed = true;
    _dragging = false;
    _pressX = _lastX = event->globalPosition().toPoint().x();
}

void SidebarHandle::mouseMoveEvent(QMouseEvent* event)
{
    if (!_pressed)
        return;
    const int x = event->globalPosition().toPoint().x();
    if (!_dragging && qAbs(x - _pressX) >= 4)
        _dragging = true;
    if (_dragging) {
        emit dragged(x - _lastX);
        _lastX = x;
    }
}

void SidebarHandle::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() != Qt::LeftButton || !_pressed)
        return;
    _pressed = false;
    if (_dragging) {
        _dragging = false;
        emit dragFinished();
    } else {
        emit toggled();
    }
}
