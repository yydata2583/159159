#pragma once
#include <QObject>
#include <QColor>
#include <QString>
#include <QList>
#include <QPair>

class QEvent;
class QWidget;

// Applies Qt Style Sheets for the available themes and exposes theme colors
// used by syntax highlighters and the HTML preview.
//
// Themes: "light", "dark", "sakura" (cherry-blossom light variant).
class ThemeManager : public QObject {
    Q_OBJECT
public:
    static ThemeManager& instance();

    // Available themes as (id, display name) pairs, for settings/combo UI.
    static QList<QPair<QString, QString>> availableThemes();
    static QString displayName(const QString& id);

    // "dark" | "light" derived from the system palette (for follow-system).
    static QString systemThemeId();

    void apply(const QString& theme);   // "light" | "dark" | "sakura"
    QString current() const { return _theme; }
    bool isDark() const { return _theme == QStringLiteral("dark"); }

    // Palette for editors / preview.
    QColor editorBg() const;
    QColor editorFg() const;
    QColor lineNumberFg() const;
    QColor highlightBg() const;
    QColor codeBlockBg() const;   // 预览代码块/行内代码底色
    QColor borderColor() const;   // 预览表格/代码块/hr 边框色

    // Markdown syntax colors.
    QColor headingColor() const;
    QColor emphasisColor() const;
    QColor strongColor() const;
    QColor codeColor() const;
    QColor linkColor() const;
    QColor quoteColor() const;
    QColor listColor() const;
    QColor hrColor() const;
    QColor strikeColor() const;

signals:
    void themeChanged(const QString& theme);

protected:
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    explicit ThemeManager(QObject* parent = nullptr);
    void applyTitleBarColor(QWidget* w) const;
    QString _theme = QStringLiteral("light");
};
