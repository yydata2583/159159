#include "OutlinePanel.h"
#include "SidebarHandle.h"
#include "editor/EditorWidget.h"
#include "preview/PreviewWidget.h"
#include "app/AppSettings.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QStackedWidget>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QItemSelectionModel>
#include <QLabel>
#include <QPropertyAnimation>

OutlinePanel::OutlinePanel(QWidget* parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("OutlinePanel"));

    AppSettings& s = AppSettings::instance();
    _expanded = s.outlineExpanded();
    _contentWidth = qBound(MIN_CONTENT, s.outlineWidth(), MAX_CONTENT);

    auto* root = new QHBoxLayout(this);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);

    _content = new QWidget(this);
    auto* contentLay = new QVBoxLayout(_content);
    contentLay->setContentsMargins(2, 2, 2, 2);
    contentLay->setSpacing(0);

    _stack = new QStackedWidget(_content);
    contentLay->addWidget(_stack);

    // 章节树
    _tree = new QTreeWidget(_stack);
    _tree->setObjectName(QStringLiteral("OutlineTree"));
    _tree->setColumnCount(1);
    _tree->setHeaderHidden(true);
    _tree->setRootIsDecorated(true);
    _tree->setUniformRowHeights(true);   // 100+ 标题性能（S2.18）
    _tree->setIndentation(12);
    _tree->setEditTriggers(QAbstractItemView::NoEditTriggers);
    _tree->setMinimumWidth(0);           // 拖拽/收起时允许压缩，不溢出
    _stack->addWidget(_tree);

    // 无标题占位
    _placeholder = new QLabel(tr("暂无章节"), _stack);
    _placeholder->setObjectName(QStringLiteral("OutlinePlaceholder"));
    _placeholder->setAlignment(Qt::AlignCenter);
    _placeholder->setEnabled(false);
    _stack->addWidget(_placeholder);

    _content->setMinimumWidth(0);
    _stack->setMinimumWidth(0);
    root->addWidget(_content, 1);

    // 右缘 Toggle 把手（位于预览区左边）
    _handle = new SidebarHandle(this);
    _handle->setCollapsed(!_expanded);
    root->addWidget(_handle);

    setFixedWidth(_expanded ? _contentWidth + SidebarHandle::HANDLE_WIDTH
                            : SidebarHandle::HANDLE_WIDTH);
    _content->setVisible(_expanded);

    // 点击章节：仅平滑滚动预览（规范 5.2：编辑器不动），随后面板自动收起
    connect(_tree, &QTreeWidget::itemClicked, this, [this](QTreeWidgetItem* item) {
        bool ok = false;
        const int line = item->data(0, Qt::UserRole).toInt(&ok);
        if (!ok || line <= 0)
            return;
        if (_preview)
            _preview->scrollToSourceLine(line, /*smooth=*/true);
        // 自动收起由设置控制（不写手动状态）
        if (AppSettings::instance().outlineAutoCollapse())
            setExpanded(false, /*animated=*/true);
    });

    // 把手：手动收起/展开（状态重启保持，S2.16）
    connect(_handle, &SidebarHandle::toggled, this, [this]() {
        setExpanded(!_expanded, /*animated=*/true);
        AppSettings::instance().setOutlineExpanded(_expanded);
    });
    // 把手：拖拽调宽，限制 180–220（S2.14）；收起态向右拖即拉出
    connect(_handle, &SidebarHandle::dragged, this, [this](int dx) {
        if (_anim) {
            _anim->stop();
            _anim->deleteLater();
            _anim = nullptr;
        }
        const int content = qBound(0, width() - SidebarHandle::HANDLE_WIDTH + dx,
                                   MAX_CONTENT);
        _content->setVisible(content > 0);
        setFixedWidth(SidebarHandle::HANDLE_WIDTH + content);
    });
    connect(_handle, &SidebarHandle::dragFinished, this, [this]() {
        const int content = width() - SidebarHandle::HANDLE_WIDTH;
        AppSettings& st = AppSettings::instance();
        if (content < MIN_CONTENT) {
            setExpanded(false, /*animated=*/true);
            st.setOutlineExpanded(false);
            return;
        }
        setFixedWidth(SidebarHandle::HANDLE_WIDTH + content);
        _content->setVisible(true);
        _expanded = true;
        _handle->setCollapsed(false);
        _contentWidth = content;
        st.setOutlineWidth(content);
        st.setOutlineExpanded(true);
    });
}

void OutlinePanel::bind(EditorWidget* editor, PreviewWidget* preview)
{
    _editor = editor;
    _preview = preview;
    if (_preview) {
        // 标题序列与自动高亮均由预览渲染管线权威推送
        connect(_preview, &PreviewWidget::headingsAvailable,
                this, &OutlinePanel::setHeadings);
        connect(_preview, &PreviewWidget::activeHeadingChanged,
                this, &OutlinePanel::setActiveHeadingLine);
    }
}

void OutlinePanel::refreshNow()
{
    // 标题由 PreviewWidget 渲染后经 headingsAvailable 推送（含首次加载），
    // 此处无需手动解析；保留接口供文档载入/刷新流程调用。
}

void OutlinePanel::setPanelWidth(int w)
{
    setFixedWidth(w);
}

void OutlinePanel::setExpanded(bool expanded, bool animated)
{
    // 状态相同且可见性已一致才跳过（拖拽后状态未变但内容可能仍显示）
    if (_expanded == expanded && _anim == nullptr
        && _content->isVisible() == expanded)
        return;
    _expanded = expanded;
    _handle->setCollapsed(!expanded);

    const int target = expanded ? _contentWidth + SidebarHandle::HANDLE_WIDTH
                                : SidebarHandle::HANDLE_WIDTH;
    if (!animated) {
        setFixedWidth(target);
        _content->setVisible(expanded);
        return;
    }

    if (expanded)
        _content->setVisible(true);
    if (_anim) {
        _anim->stop();
        _anim->deleteLater();
    }
    _anim = new QPropertyAnimation(this, "panelWidth", this);
    _anim->setDuration(200);
    _anim->setStartValue(width());
    _anim->setEndValue(target);
    _anim->setEasingCurve(QEasingCurve::OutCubic);
    connect(_anim, &QPropertyAnimation::finished, this, [this, expanded]() {
        if (!expanded)
            _content->setVisible(false);
        else
            AppSettings::instance().setOutlineWidth(_contentWidth);
        _anim->deleteLater();
        _anim = nullptr;
    });
    _anim->start();
}

void OutlinePanel::setHeadings(
    const QVector<MarkdownConverter::BlockInfo>& headings)
{
    _headings.clear();
    for (const auto& h : headings) {
        if (h.kind == MarkdownConverter::BlockInfo::Heading
            && h.level >= 1 && h.level <= 4) {
            _headings.push_back({ h.text, h.level, h.srcLine });
        }
    }
    rebuild();
}

void OutlinePanel::rebuild()
{
    _tree->setUpdatesEnabled(false);
    _tree->clear();
    _items.clear();

    if (_headings.isEmpty()) {
        _stack->setCurrentWidget(_placeholder);
    } else {
        // 按层级挂树：H1 顶层，H2 挂最近的 H1，以此类推
        QTreeWidgetItem* lastAt[5] = { nullptr, nullptr, nullptr, nullptr, nullptr };
        for (const Heading& h : _headings) {
            QTreeWidgetItem* parent = nullptr;
            for (int lv = h.level - 1; lv >= 1; --lv) {
                if (lastAt[lv]) {
                    parent = lastAt[lv];
                    break;
                }
            }
            // QTreeWidgetItem(QTreeWidget*) 构造时已自动追加为顶层项
            auto* item = parent ? new QTreeWidgetItem(parent)
                                : new QTreeWidgetItem(_tree);
            item->setText(0, h.text);
            item->setToolTip(0, h.text);
            item->setData(0, Qt::UserRole, h.line);
            // H1/H2 加粗，强化视觉层级
            QFont f = item->font(0);
            f.setBold(h.level <= 2);
            item->setFont(0, f);
            lastAt[h.level] = item;
            for (int lv = h.level + 1; lv <= 4; ++lv)
                lastAt[lv] = nullptr;
            _items.append(item);
        }
        _tree->expandAll();
        _stack->setCurrentWidget(_tree);
    }

    _tree->setUpdatesEnabled(true);
    // 重建后等待预览侧下一次 activeHeadingChanged 推送恢复高亮
}

void OutlinePanel::setActiveHeadingLine(int line)
{
    if (_headings.isEmpty() || _items.size() != _headings.size())
        return;
    if (line <= 0) {
        _tree->clearSelection();
        _tree->setCurrentItem(nullptr);
        return;
    }
    // 预览侧按 80px 阈值规则给出激活标题的精确源行，这里精确匹配
    for (int i = 0; i < _headings.size(); ++i) {
        if (_headings[i].line == line) {
            // 程序化选中不触发 itemClicked，不会造成跳转/自动收起
            _tree->setCurrentItem(_items[i], QItemSelectionModel::ClearAndSelect);
            return;
        }
    }
}
