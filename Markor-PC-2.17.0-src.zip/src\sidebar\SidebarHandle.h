#pragma once
#include <QWidget>

// 侧边栏右缘窄条把手：单击收起/展开，按住左右拖拽调宽度。
// 内容均在把手左侧，向右拖=加宽。背景/悬停色由主题 QSS（#SidebarHandle）提供。
class SidebarHandle : public QWidget {
    Q_OBJECT
public:
    static constexpr int HANDLE_WIDTH = 8;   // 把手/收起态宽度

    explicit SidebarHandle(QWidget* parent = nullptr);

    // 收起态画 »（提示向左展开内容），展开态画 «（提示收起）
    void setCollapsed(bool collapsed);

signals:
    void toggled();              // 单击（未发生拖拽）
    void dragged(int deltaX);    // 按住拖拽中，dx 为本帧水平增量（右正）
    void dragFinished();         // 拖拽结束

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;

private:
    bool _collapsed = false;
    bool _pressed = false;
    bool _dragging = false;
    int _pressX = 0;
    int _lastX = 0;
};
