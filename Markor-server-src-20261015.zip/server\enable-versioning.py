#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Markor 服务器端初始化：确保 markor-vault 文件夹存在，并默认开启
Syncthing 回收站版本控制（保留 10 天）。

用法（在 NAS 上执行一次即可，可重复运行）：
  SYNCTHING_URL=http://127.0.0.1:8384 \
  SYNCTHING_APIKEY=<Web GUI 的 API Key> \
  SYNCTHING_FOLDER_PATH=/vol1/1000/Markor \
  python3 enable-versioning.py

仅用 Python 标准库，无第三方依赖。
"""
import json
import os
import sys
import urllib.request

URL = os.environ.get("SYNCTHING_URL", "http://127.0.0.1:8384").rstrip("/")
APIKEY = os.environ.get("SYNCTHING_APIKEY", "")
FOLDER_ID = "markor-vault"
FOLDER_PATH = os.environ.get("SYNCTHING_FOLDER_PATH", "/vol1/1000/Markor")
CLEANOUT_DAYS = "10"


def rest(method, path, data=None):
    req = urllib.request.Request(URL + path, method=method)
    req.add_header("X-API-Key", APIKEY)
    body = None
    if data is not None:
        req.add_header("Content-Type", "application/json")
        body = json.dumps(data).encode("utf-8")
    with urllib.request.urlopen(req, body, timeout=15) as resp:
        raw = resp.read()
    return json.loads(raw) if raw else None


def main():
    if not APIKEY:
        print("错误：请设置环境变量 SYNCTHING_APIKEY（Syncthing Web GUI 的 API Key）",
              file=sys.stderr)
        sys.exit(1)

    my_id = rest("GET", "/rest/system/status")["myID"]

    folders = rest("GET", "/rest/config/folders")
    target = next((f for f in folders if f.get("id") == FOLDER_ID), None)

    if target is None:
        target = {
            "id": FOLDER_ID,
            "label": "Markor",
            "path": FOLDER_PATH,
            "devices": [{"deviceID": my_id}],
            "type": "sendreceive",
            "rescanIntervalS": 3600,
            "fsWatcherEnabled": True,
            "fsWatcherDelayS": 10,
        }
        rest("POST", "/rest/config/folders", target)
        print("已创建文件夹 %s -> %s" % (FOLDER_ID, FOLDER_PATH))
    else:
        print("文件夹 %s 已存在（%s）" % (FOLDER_ID, target.get("path")))

    # 回收站版本控制：保留 10 天
    target = rest("GET", "/rest/config/folders/" + FOLDER_ID)
    target["versioning"] = {
        "type": "trashcan",
        "params": {"cleanoutDays": CLEANOUT_DAYS},
    }
    rest("PUT", "/rest/config/folders/" + FOLDER_ID, target)
    print("已开启回收站版本控制（保留 %s 天）" % CLEANOUT_DAYS)

    print("完成。设备 ID：", my_id)


if __name__ == "__main__":
    main()
