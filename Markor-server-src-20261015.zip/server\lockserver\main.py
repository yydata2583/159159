#!/usr/bin/env python3
# Markor file-lock server (stdlib only, no pip deps)
# Tracks which device currently has which file open, for the
# "XXX端已经打开文件" hint and the overwrite/save-as-copy dialog.
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PORT = int(os.environ.get("MARKOR_LOCK_PORT", "8910"))
API_KEY = os.environ.get("MARKOR_API_KEY", "")
TTL = 70.0  # seconds without heartbeat -> lock expires

_lock = threading.Lock()
# (vault_id, path) -> {"device_id": str, "device_name": str, "ts": float}
LOCKS = {}


def _now():
    return time.time()


def _gc():
    cutoff = _now() - TTL
    with _lock:
        stale = [k for k, v in LOCKS.items() if v["ts"] < cutoff]
        for k in stale:
            del LOCKS[k]


def _holders(vault_id, path, device_id):
    """Other devices holding the same file."""
    with _lock:
        return [
            {"device_id": v["device_id"], "device_name": v["device_name"]}
            for k, v in LOCKS.items()
            if k[0] == vault_id and k[1] == path and v["device_id"] != device_id
        ]


def _open(body):
    vault_id = str(body.get("vault_id", "default"))
    path = str(body.get("path", "")).replace("\\", "/")
    device_id = str(body.get("device_id", ""))
    device_name = str(body.get("device_name", device_id))
    if not path or not device_id:
        return 400, {"ok": False, "error": "path and device_id required"}
    with _lock:
        LOCKS[(vault_id, path)] = {
            "device_id": device_id, "device_name": device_name, "ts": _now()
        }
    return 200, {"ok": True, "holders": _holders(vault_id, path, device_id)}


def _heartbeat(body):
    vault_id = str(body.get("vault_id", "default"))
    path = str(body.get("path", "")).replace("\\", "/")
    device_id = str(body.get("device_id", ""))
    with _lock:
        key = (vault_id, path)
        if key in LOCKS and LOCKS[key]["device_id"] == device_id:
            LOCKS[key]["ts"] = _now()
        else:
            return 404, {"ok": False, "error": "not held"}
    return 200, {"ok": True, "holders": _holders(vault_id, path, device_id)}


def _close(body):
    vault_id = str(body.get("vault_id", "default"))
    path = str(body.get("path", "")).replace("\\", "/")
    device_id = str(body.get("device_id", ""))
    with _lock:
        key = (vault_id, path)
        if key in LOCKS and (not device_id or LOCKS[key]["device_id"] == device_id):
            del LOCKS[key]
    return 200, {"ok": True}


def _locks(vault_id):
    _gc()
    with _lock:
        items = [
            {"vault_id": k[0], "path": k[1], "device_id": v["device_id"],
             "device_name": v["device_name"], "ts": int(v["ts"])}
            for k, v in LOCKS.items()
            if not vault_id or k[0] == vault_id
        ]
    return 200, {"locks": items}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _auth(self):
        if not API_KEY:
            return True
        auth = self.headers.get("Authorization", "")
        return auth == "Bearer " + API_KEY

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/health":
            return self._send(200, {"ok": True, "service": "markor-lockserver"})
        if not self._auth():
            return self._send(401, {"ok": False, "error": "unauthorized"})
        if u.path == "/api/v1/locks":
            q = parse_qs(u.query)
            code, obj = _locks((q.get("vault_id") or [""])[0])
            return self._send(code, obj)
        self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        if not self._auth():
            return self._send(401, {"ok": False, "error": "unauthorized"})
        u = urlparse(self.path)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            return self._send(400, {"ok": False, "error": "bad json"})
        if u.path == "/api/v1/open":
            code, obj = _open(body)
        elif u.path == "/api/v1/heartbeat":
            code, obj = _heartbeat(body)
        elif u.path == "/api/v1/close":
            code, obj = _close(body)
        else:
            return self._send(404, {"ok": False, "error": "not found"})
        self._send(code, obj)

    def log_message(self, fmt, *args):
        print("[lockserver]", self.address_string(), fmt % args, flush=True)


def _gc_loop():
    while True:
        time.sleep(30)
        _gc()


def main():
    threading.Thread(target=_gc_loop, daemon=True).start()
    print(f"markor-lockserver listening on :{PORT}, api_key={'set' if API_KEY else 'DISABLED'}",
          flush=True)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
