# Markor 同步服务器（NAS 端）部署说明

三个服务：Syncthing 存储节点（持久保存文件副本，另一端离线也可靠）、私有中继 relaysrv（设备不在同网时兜底转发）、文件锁 API（打开提示/冲突检测）。

## 〇、三端同步目录规则（结构完全统一）

| 端 | 同步根目录 |
|---|---|
| PC（EXE） | `文档\Markor`（`%USERPROFILE%\Documents\Markor`） |
| 飞牛 NAS | `/vol1/1000/Markor` |
| 手机（APK） | `/storage/emulated/0/Markor` |

同步范围：**根目录下所有子文件夹和文件**（递归双向同步）。
根目录内部结构三端完全一致：

```
Markor\
├── QuickNote.md      ← 快记（应用默认）
├── To-Do.md          ← 待办（Markdown 勾选式，应用默认）
├── Journal\          ← 日记
├── Snippets\         ← 代码片段/模板（应用片段目录）
└── file\             ← 其他所有文件一律放这里
```

同步链路：**PC ↔ 飞牛 ↔ 手机**（星型经 NAS 中转；任一端离线时 NAS 持有完整副本，上线即续传）。

## 一、部署方式 A：飞牛 fnOS / systemd 原生（推荐）

以 `markor-syncthing.service` / `markor-lockserver.service` 为例（参考根目录 `代码.txt`，已修正笔误）：

1. 上传文件：
   - `markor-syncthing.service`、`markor-lockserver.service` → `/etc/systemd/system/`
   - `lockserver/` 目录 → `/opt/markor/lockserver/`
   - `enable-versioning.py` → `/opt/markor/`
2. 修改两个 service 文件里的 `MARKOR_API_KEY`（改成随机长字符串，两端客户端要填同一值）；如目录属主不是 root，把 `User` 改成 `1000`
3. 启用并启动：
   ```sh
   systemctl daemon-reload
   systemctl enable --now markor-syncthing
   systemctl enable --now markor-lockserver
   ```
4. 验证锁服务：`curl http://NAS_IP:8910/health` 返回 `{"ok": true}`

Syncthing 程序：`/usr/bin/syncthing`（fnOS 自带或 `apt install syncthing`，v2.x）。配置/索引存放在 `/vol1/1000/.config/syncthing`（由 `HOME=/vol1/1000` 决定）。

## 二、部署方式 B：Docker / 群晖 Container Manager

1. 把本目录整个上传到 NAS（如 `/vol1/1000/docker/markor-server`）
2. 复制 `.env.example` 为 `.env`，修改：
   - `DATA_PATH`：**同步根目录**（文件持久保存在这里，飞牛：`/vol1/1000/Markor`）
   - `CONFIG_PATH`：Syncthing 配置目录（如 `/vol1/1000/markor-config`，勿与 DATA_PATH 相同）
   - `MARKOR_API_KEY`：改成随机长字符串
3. 启动：`docker compose up -d`（群晖：Container Manager → 项目 → 新增 → 选本目录）
4. 验证：`curl http://NAS_IP:8910/health` 返回 `{"ok": true}`

## 三、Syncthing 初始化（一次性）

1. 浏览器打开 `http://NAS_IP:8384`，首次进入设置 GUI 管理员账号/密码
2. 操作 → 显示 ID：复制 **NAS 节点设备 ID**（客户端要用）
3. **一键初始化（推荐）**：在 NAS 上运行 `enable-versioning.py`（只用标准库）：
   ```sh
   SYNCTHING_URL=http://127.0.0.1:8384 \
   SYNCTHING_APIKEY=<GUI 的 API Key> \
   SYNCTHING_FOLDER_PATH=/vol1/1000/Markor \
   python3 /opt/markor/enable-versioning.py
   ```
   脚本会自动：创建 `markor-vault` 文件夹（路径 `/vol1/1000/Markor`，Docker 部署填 `/data`）→ **默认开启回收站版本控制、保留 10 天** → 打印设备 ID。可重复运行。
   手动等价操作：Web GUI → 添加文件夹（ID `markor-vault`，路径 `/vol1/1000/Markor`，Docker 填 `/data`）→ 文件夹选项 → 文件夹版本控制 → 回收站 → 保留 10 天。
4. 取中继 ID：`docker logs markor-relay 2>&1 | grep -i "id:"`（Docker 部署；形如 `relay://0.0.0.0:22067/?id=XXXX...`）。systemd 原生部署如需中继，另行运行 `relaysrv`（`-pools ""`）。

## 四、客户端配置（经 Tailscale 访问）

> 服务仅通过 **Tailscale** 访问（`100.64.0.2` 为 NAS 的 Tailscale 地址）。EXE / 手机 / Syncthing 客户端都必须先加入同一个 Tailscale 网络。

EXE / APK 设置里填同样内容：

| 配置项 | 值 |
|---|---|
| 服务器地址 | `http://100.64.0.2:8910` |
| API Key | 服务端 `MARKOR_API_KEY` |
| NAS 设备 ID | 第三步复制的 Syncthing 设备 ID |
| 中继地址 | 留空（经 Tailscale 直连，无需中继） |

手机端文件同步（用 Syncthing 安卓版 / Syncthing-Fork）：
1. 添加设备：NAS 设备 ID；**设备地址填 `tcp://100.64.0.2:22001`**（Tailscale 直连，局域网内也兼容 dynamic 自动发现）
2. 添加文件夹：路径 `/storage/emulated/0/Markor`，文件夹 ID `markor-vault`，共享给 NAS 设备

PC ↔ NAS 由 EXE 内嵌 Syncthing 自动配置（已自动写入 Tailscale 直连地址 `tcp://100.64.0.2:22001`，dynamic 作局域网兜底）。

> 升级提示：新版 APK 的笔记本目录为 `/storage/emulated/0/Markor`。首次启动会自动：把旧 `Documents/markor` 的内容迁移到新目录；`.app/snippets` 迁到 `Snippets/`；`todo.txt` 改名为 `To-Do.md`（若无同名文件）；并创建 `Journal/`、`Snippets/`、`file/` 三个目录——保证三端结构一致。

## 五、锁 API 协议（三端共用）

所有请求带 `Authorization: Bearer <API_KEY>`，body 为 JSON。

- `GET /health` → `{"ok":true}`（无鉴权，探活）
- `POST /api/v1/open` `{device_id, device_name, vault_id, path}` → `{ok, holders:[{device_id,device_name}]}` —— 打开文件登记；`holders` 为**其他设备**占用者（用于"XXX端已经打开文件"提示）。同设备重复调用=刷新。
- `POST /api/v1/heartbeat` 同参数 → `{ok, holders}` —— 每 30 秒刷新，70 秒无心跳自动过期
- `POST /api/v1/close` `{device_id, vault_id, path}` → `{ok}` —— 关闭/保存后注销
- `GET /api/v1/locks?vault_id=x` → `{locks:[...]}` —— 全表（轮询兜底）

`path` 一律为同步根内相对路径（`/` 分隔，例如 `file/报告.md`）。锁仅存内存，重启丢失无害——真正的写冲突由 Syncthing 的 `.sync-conflict-*` 文件兜底。

## 六、安全说明

- 锁 API 默认 HTTP 明文 + Bearer key，适合内网/自用。暴露公网建议前面加反代（Nginx/Caddy）上 HTTPS。
- Syncthing 数据传输本身全程 TLS 加密；中继也看不到内容。
- 22000/TCP+UDP（数据）、21027/UDP（本地发现）、22067/TCP（中继）、8384/TCP（GUI，建议仅内网）、8910/TCP（锁 API）。
- 回收站版本控制：NAS 端已默认开启（保留 10 天），被误删/覆盖的文件在 `/vol1/1000/Markor/.stversions` 里可找回。
