# 数据模型（data-model.md）— Markor 同步服务器

## 1. 锁服务数据模型（lockserver/main.py）

```
LOCKS: (vault_id, path) → { device_id: {"device_name": str, "ts": float} }
```
- **按设备多持有者**：同文件多设备并存，各自独立心跳/注销（旧单值覆盖模型已废弃）。
- TTL=70s：无心跳自动过期（每 30s GC 一轮 + 每 30s 后台清理）。
- 纯内存：重启丢失无害（提示层，不承担正确性）。

### 协议（三端共用）

| 端点 | 请求体 | 返回 |
|---|---|---|
| `GET /health` | — | `{ok:true, service:"markor-lockserver"}`（无鉴权） |
| `POST /api/v1/open` | `{device_id, device_name, vault_id, path}` | `{ok, holders:[其他设备…]}` |
| `POST /api/v1/heartbeat` | 同 open | `{ok, holders}`（不持有→404 `{ok:false,error:"not held"}`） |
| `POST /api/v1/close` | `{device_id, vault_id, path}` | `{ok}` |
| `GET /api/v1/locks?vault_id=x` | — | `{locks:[{vault_id,path,device_id,device_name,ts}]}` |

- 鉴权：`Authorization: Bearer <MARKOR_API_KEY>`（除 /health；**key 为空=不鉴权**，仅限隔离环境）。
- `path`：同步根内相对路径，`/` 分隔（如 `file/报告.md`）；`\` 会被规范化为 `/`。
- `vault_id`：约定 `markor-vault`。

## 2. 环境变量 / 配置

| 变量 | 默认 | 说明 |
|---|---|---|
| `MARKOR_API_KEY` | 无 | 锁 API 密钥（部署必改；三端填一致；占位符勿回填真实值） |
| `MARKOR_LOCK_PORT` | `8910` | 锁 API 监听端口 |
| `DATA_PATH` | `/vol1/1000/Markor` | 同步根（Docker 挂载为容器 `/data`） |
| `CONFIG_PATH` | `/vol1/1000/markor-config` | Syncthing 配置/索引（不参与同步） |
| `TZ` | `Asia/Shanghai` | 时区 |
| `STGUIADDRESS` | `0.0.0.0:8385` | Syncthing 管理 GUI（仅内网/VPN） |
| `HOME`（systemd） | `/vol1/1000` | 决定 Syncthing 配置目录 |

## 3. Syncthing 关键配置

| 项 | 值 |
|---|---|
| 共享文件夹 | id=`markor-vault`，label=`Markor`，path=同步根，type=sendreceive |
| 版本控制 | trashcan，`cleanoutDays=10`（enable-versioning.py 设置） |
| 端口 | 22000/TCP+UDP（数据）、21027/UDP（本地发现，可关）、8385（GUI）、8910（锁 API） |
| 引擎自升级 | `autoUpgradeIntervalH=0`（关闭，产品不需要"更新同步版本"） |
| 中继 | `relaysEnabled=false`（星型不需要；relaysrv 不部署） |
| 设备 | PC/手机各一台；客户端只配服务器地址（`tcp://NAS:22000`），互相不配置 |

## 4. 三端目录契约（同步内容）

```
Markor/                 ← 同步根（PC 文档\Markor / NAS /vol1/1000/Markor / 手机笔记本目录）
├─ QuickNote.md  To-Do.md  Journal/  Snippets/  file/
```
特殊文件：`.stfolder`（Syncthing 标记）、`.sync-conflict-*`（冲突副本）、`.stversions/`（回收站）。
