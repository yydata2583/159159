# 架构说明（architecture.md）— Markor 同步服务器

## 1. 服务构成

| 服务 | 实现 | 职责 |
|---|---|---|
| Syncthing 存储节点 | `syncthing`（v2.x，fnOS 自带或 apt） | 持有 vault 完整副本；与 PC/手机交换文件（22000） |
| 文件锁 API | `lockserver/main.py`（Python 标准库） | 打开提示/占用检测（8910）；**不存文件内容** |
| ~~私有中继 relaysrv~~ | **已移除** | 星型拓扑直连，不需要中继 |

## 2. 拓扑（星型中枢）

```
 PC(内嵌ST) ──tcp://NAS:22000──► [ NAS: Syncthing 存储节点 ] ◄──tcp://NAS:22000── 手机(内嵌ST)
                                    │
                                    └─ lockserver :8910 ◄── HTTP ── PC / 手机（锁登记）
```
- 设备之间（PC↔手机）**不互连**：客户端设备表只有服务器、introducer 关、自动发现/中继关。
- 跨网访问走 Tailscale/专网（客户端"服务器同步地址"填 Tailscale 地址即可）。
- 任一端离线，NAS 持有完整副本，上线续传。

## 3. 锁 API 流程

```
客户端打开文件 → POST /open   → 服务端登记 (vault,path)→{device:…,ts}，返回 holders(其他设备)
每 30s          → POST /heartbeat → 刷新自己的 ts（70s 无心跳过期）
保存/关闭       → POST /close  → 删除自己的登记
查全表          → GET  /locks?vault_id=x
探活            → GET  /health（无鉴权）
```
- **多持有者模型**：一个文件可被多设备同时打开，各自独立心跳/注销（holders 才能互相提示）。
- 锁只存内存（重启丢失无害）；真正的写冲突由 Syncthing `.sync-conflict-*` 兜底。
- 版本找回：回收站版本控制（`.stversions`，保留 10 天）。

## 4. 部署形态

- **A（推荐）systemd**：`markor-syncthing.service`（`STGUIADDRESS=0.0.0.0:8385`）+
  `markor-lockserver.service`（`MARKOR_API_KEY`、`MARKOR_LOCK_PORT=8910`）。
- **B Docker**：`docker-compose.yml`（syncthing: `DATA_PATH`→`/data`、`CONFIG_PATH`→`/var/syncthing`；
  lockserver: build ./lockserver）。
- 初始化：`enable-versioning.py`（建 `markor-vault` 文件夹 + 回收站版本 + 关中继/自升级 + 打印设备 ID）。

## 5. 安全边界

- 锁 API 为 HTTP 明文 + Bearer key（内网/自用）；暴露公网需反代上 HTTPS。
- Syncthing 传输全程 TLS；管理 GUI 8385 建议仅内网/VPN。
- API Key 自生成共享口令（无申请流程），服务端与三端客户端填一致。
