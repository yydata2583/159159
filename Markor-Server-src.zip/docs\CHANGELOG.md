# 需求与变更记录（CHANGELOG.md）— Markor 同步服务器

> **本文档由 AI 维护。** 工作方式：**用户提需求 → AI 改代码/脚本 → AI 同步更新本记录**。
> 维护规则见 [README.md](README.md)；技术决策见 [decisions.md](decisions.md)。

## 需求追溯表

| 日期 | 需求（用户原始诉求摘要） | 实现 | 涉及文件 |
|---|---|---|---|
| 10-15 | ②不需要"更新同步版本" | 初始化脚本关闭引擎自升级 `autoUpgradeIntervalH=0` | `enable-versioning.py` |
| 10-15 | ③服务器信息不写死 | 硬编码 API Key 清理为占位符（部署时替换）；文档强调自生成 | `markor-lockserver.service` `README-server.md` |
| 10-15 | ④PC 管理地址改 8385 | 服务端 GUI 统一 8385（README/初始化脚本与 systemd 对齐，修 8384/8385 不一致） | `README-server.md` `enable-versioning.py` `docker-compose.yml` |
| 10-15 | ⑤只连服务器、不互连；删中继 | 移除 relaysrv（docker-compose）；`enable-versioning.py` 关 `relaysEnabled`；README 删中继步骤 | `docker-compose.yml` `README-server.md` `enable-versioning.py` |
| 10-15 | ⑥审查三端代码（后取消） | 过程中修复锁服务真 BUG（见下） | `lockserver/main.py` |
| 10-15 | （用户追问）"多持有者模型和原生同步冲突吗？" | 不冲突；锁=提示层，多持有者是修 BUG 后的正确语义 | 见 A-203、PC CHANGELOG 答疑 |
| 10-15 | （用户追问）"API Key 怎么申请？" | 无申请流程，自生成共享口令；文档补说明 | `README-server.md` |

## 变更日志

- **2026-10-15**：
  - `lockserver/main.py` **修复单值覆盖 BUG** → 按设备多持有者（holders 提示生效、各设备独立心跳/注销/过期）；
  - 去中继（relaysrv 移除）、GUI 统一 8385、关中继/引擎自升级；
  - `markor-lockserver.service` 真实 API Key → 占位符（安全）；
  - README 重写客户端配置表（四项设置+弹窗说明）、端口表、星型说明。
- **此前**：lockserver 初版（单值模型，有 BUG）、relaysrv 部署件、README 初版。
