# 规范与操作手册（conventions.md）— Markor 同步服务器

## 1. 纪律（红线）

- **不实际操作服务器/不部署**（等用户通知）；改仓库内脚本/文档即可。
- **星型拓扑不破坏**：不重新引入 relaysrv/自动发现；不给客户端写死地址。
- **锁服务保持多持有者模型**（A-203）；改协议必须**三端联改**。
- 真实密钥/地址不进仓库（模板用占位符）。
- Python 只用标准库（lockserver / enable-versioning.py 的既定约束）。

## 2. 部署 Checklist（每次交付核对）

- [ ] `MARKOR_API_KEY` 已改随机长串（service 或 .env），与三端客户端一致
- [ ] `DATA_PATH` / `CONFIG_PATH` 指向正确（不同目录）
- [ ] 端口放行：22000/TCP+UDP（数据）、8910（锁 API）、8385（GUI，仅内网/VPN）
- [ ] `enable-versioning.py` 跑过一次（folder `markor-vault` + 回收站版本 + 关中继/自升级）
- [ ] `curl http://NAS:8910/health` → `{"ok": true}`
- [ ] 管理页 `http://NAS:8385` 可开；"操作→显示 ID" 的设备 ID 已给客户端
- [ ] 客户端设置四项：服务器地址 / API Key / 服务器设备 ID / 服务器同步地址

## 3. 修改 Checklist

| 改动 | 必须同步 |
|---|---|
| 锁协议/字段/语义 | `lockserver/main.py` + `README-server.md` §五 + PC `LockClient` + 手机 `LockClient` + 两端 data-model |
| 端口 | service/.env + `README-server.md` 端口表 + 两端 AGENTS/data-model |
| 目录规则 | `README-server.md` §〇 + 客户端迁移逻辑说明 |
| 部署方式 | `README-server.md` 部署 A/B 相应小节 |

## 4. 验证命令（部署后人工执行）

```sh
curl http://127.0.0.1:8910/health
curl -H "Authorization: Bearer $KEY" -X POST http://127.0.0.1:8910/api/v1/open \
     -d '{"device_id":"test","device_name":"t","vault_id":"markor-vault","path":"file/a.md"}'
curl -H "Authorization: Bearer $KEY" 'http://127.0.0.1:8910/api/v1/locks?vault_id=markor-vault'
```
预期：open 返回 holders 数组；同文件第二台设备 open 后，第一台再查 holders 能看到第二台
（多持有者验证）；停心跳 70s 后自动消失。
