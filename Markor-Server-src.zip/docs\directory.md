# 目录与部署位置（directory.md）— Markor 同步服务器

## 仓库文件

| 文件 | 职责 |
|---|---|
| `README-server.md` | 部署总纲（步骤/配置表/协议/端口/安全）★ 先读 |
| `AGENTS.md` | AI 入口 |
| `docs/` | 分层知识库 ★ |
| `docker-compose.yml` | Docker 部署（syncthing + lockserver；中继已移除） |
| `markor-syncthing.service` | systemd 单元：Syncthing（GUI 8385） |
| `markor-lockserver.service` | systemd 单元：锁 API（API Key 占位符，部署必改） |
| `enable-versioning.py` | 一次性初始化脚本（标准库；可重复运行） |
| `lockserver/main.py` | 锁 API 实现（ThreadingHTTPServer，多持有者模型） |
| `lockserver/Dockerfile` | python:3.12-alpine |
| `.env.example` | Docker 环境变量模板（DATA_PATH/CONFIG_PATH/MARKOR_API_KEY/LOCK_PORT/TZ） |

## 部署位置（systemd 形态，fnOS/群晖 Linux）

| 内容 | 位置 |
|---|---|
| 两个 service | `/etc/systemd/system/` |
| lockserver | `/opt/markor/lockserver/`（WorkingDirectory） |
| enable-versioning.py | `/opt/markor/` |
| Syncthing 程序 | `/usr/bin/syncthing`（自带或 `apt install syncthing`） |
| Syncthing 配置/索引 | `$HOME/.config/syncthing`（service 里 `HOME=/vol1/1000`） |
| **同步根（vault）** | `/vol1/1000/Markor`（Docker: `DATA_PATH`→容器 `/data`） |
| 回收站版本 | `/vol1/1000/Markor/.stversions` |

## 改动定位

| 想改什么 | 动哪里 |
|---|---|
| 锁协议/字段 | `lockserver/main.py` + `README-server.md` §五 + **两端客户端 LockClient**（三处同改） |
| 端口 | 锁 API：service/.env 的 `MARKOR_LOCK_PORT`；GUI：`STGUIADDRESS`；数据：Syncthing 默认 22000 |
| 版本控制策略 | `enable-versioning.py`（`cleanoutDays`） |
| 部署说明 | `README-server.md`（注意与实际文件保持一致——曾有 8384/8385 不一致教训） |
