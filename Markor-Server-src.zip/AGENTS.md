# AGENTS.md — Markor 同步服务器（NAS 端）· AI 工作入口

> 项目知识库入口。**文档由 AI 维护**（用户提需求 → AI 写代码 → AI 更新文档与需求记录）。部署与协议总纲见 **`README-server.md`**（先读它）；
> 客户端知识库：`markor-android/AGENTS.md`（手机）、`Markor V2.17.0/AGENTS.md`（PC）。

## 0. 30 秒速览

| 项 | 值 |
|---|---|
| 组成 | Syncthing 存储节点（文件副本）+ lockserver 文件锁 API（打开提示） |
| 拓扑 | **星型中枢**：PC ↔ 服务器 ↔ 手机；设备之间不互连；**不部署中继** |
| 部署 | A：systemd（`markor-syncthing.service` / `markor-lockserver.service`）；B：Docker（`docker-compose.yml`） |
| 端口 | 22000/TCP+UDP（同步数据）、8910/TCP（锁 API）、8385/TCP（管理 GUI，仅内网/VPN） |
| 同步根 | `/vol1/1000/Markor`（Docker 挂载为容器 `/data`） |
| 版本控制 | 回收站 10 天（`.stversions`），由 `enable-versioning.py` 开启 |
| 引擎升级 | **关闭**（`autoUpgradeIntervalH=0`；产品不需要"更新同步版本"） |

## 1. 文件地图

| 文件 | 内容 |
|---|---|
| `README-server.md` | 部署步骤、三端目录规则、客户端配置表、锁 API 协议、端口/安全说明 |
| `docker-compose.yml` | Docker 部署：syncthing + lockserver（relaysrv 已移除——星型不需要） |
| `markor-syncthing.service` | systemd：Syncthing（`STGUIADDRESS=0.0.0.0:8385`） |
| `markor-lockserver.service` | systemd：锁 API（`MARKOR_API_KEY` 部署必改，勿提交真实密钥） |
| `enable-versioning.py` | 一键初始化：建 `markor-vault` 文件夹 + 回收站版本控制 + 关中继/自升级；打印设备 ID |
| `lockserver/main.py` | 锁 API 实现（纯 Python 标准库）：open/heartbeat/close/locks + health |
| `lockserver/Dockerfile` | 锁服务镜像（python:3.12-alpine） |

## 2. 锁 API 协议（三端共用，详见 README §五）

```
鉴权：Authorization: Bearer <MARKOR_API_KEY>（除 /health）
GET  /health                      → {ok:true}            探活
POST /api/v1/open      {device_id,device_name,vault_id,path} → {ok,holders:[其他设备…]}
POST /api/v1/heartbeat 同 open（每 30s；70s 无心跳过期）
POST /api/v1/close     {device_id,vault_id,path}            → {ok}
GET  /api/v1/locks?vault_id=x                               → {locks}
path = 同步根内相对路径（/ 分隔）；锁只存内存，重启丢失无害
holders = 其他设备占用者（按设备多持有者模型，各自独立心跳/注销）
```

## 3. 红线（Do / Don't）

- **等用户通知才编译/部署变更**；文档/脚本修改即可，不实际操作服务器。
- **保持星型**：不重新引入 relaysrv/自动发现；客户端只配服务器地址。
- **锁服务按设备多持有者**：一个文件允许多设备同时打开（互相提示），勿改回单值覆盖模型。
- `MARKOR_API_KEY` 是自生成共享口令（无申请流程）；示例文件里只放占位符，不写真实密钥。
- 修改端口/协议 → **三端同步改**（PC LockClient、手机 LockClient、README 协议表）。

## 4. 维护协议

改脚本/协议 → 同步更新 `README-server.md` 与两端 AGENTS.md 的协议摘要；
不确定标 ⚠️ 待核对。

## 5. 变更日志（供 AI 续写）

- 2026-10：去中继（relaysrv 移除）、GUI 统一 8385、`enable-versioning.py` 关中继/引擎自升级；
  `lockserver` 修复单值覆盖 BUG → 按设备多持有者（holders 提示生效、心跳互不干扰）；
  `markor-lockserver.service` 硬编码 API Key 换占位符。
