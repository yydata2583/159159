# docs/ — Markor 同步服务器知识库（分层文档）

> 与上级 `AGENTS.md`、`README-server.md`（部署与协议总纲）构成完整知识库。**全部文档由 AI 维护**（用户提需求 → AI 改代码 → AI 更新文档）。

## 文档地图

| 文档 | 内容 |
|---|---|
| [../AGENTS.md](../AGENTS.md) | AI 入口：速览、文件地图、锁协议、红线 |
| [../README-server.md](../README-server.md) | **部署总纲**：三端目录规则、部署 A/B、客户端配置表、协议、端口/安全 |
| [architecture.md](architecture.md) | 服务构成、星型拓扑、连接链路、锁 API 流程 |
| [directory.md](directory.md) | 文件职责与部署位置 |
| [data-model.md](data-model.md) | 锁记录模型、环境变量、端口、Syncthing 配置要点 |
| [decisions.md](decisions.md) | ADR（A-2xx） |
| [conventions.md](conventions.md) | 部署/修改 checklist、协议变更纪律 |
| [CHANGELOG.md](CHANGELOG.md) | **需求与变更记录**（需求→实现追溯、变更史） |

## 维护协议

改脚本/协议 → 同步更新 `README-server.md` 与两端客户端知识库（PC、Android）的协议摘要；
决策追加 ADR；不确定标 ⚠️ 待核对。

## 教训 / 勘误

- 2026-10：`lockserver` 单值覆盖 BUG（holders 恒空、先开者心跳 404）→ 已改按设备多持有者；
  **改锁模型必须三端联看**（协议表 + PC LockClient + 手机 LockClient）。
- `markor-lockserver.service` 曾把真实 API Key 提交进仓库 → 现为占位符；
  部署文档要求部署时替换，勿回填真实值。
- 端口曾在 README（8384）与 systemd（8385）不一致 → 已统一 8385。
