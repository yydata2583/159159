#!/bin/sh
# Markor 服务器卸载脚本（幂等）；不会删除 /vol1/1000/Markor 笔记目录
# 用法：sudo /opt/markor/uninstall.sh
set -e
BASE=/opt/markor
if [ "$(id -u)" != "0" ]; then echo "请用 root 运行：sudo $0"; exit 1; fi
systemctl disable --now markor-lockserver.service markor-syncthing.service 2>/dev/null || true
rm -f /etc/systemd/system/markor-lockserver.service /etc/systemd/system/markor-syncthing.service
rm -rf /etc/systemd/system/markor-lockserver.service.d /etc/systemd/system/markor-syncthing.service.d
systemctl daemon-reload
systemctl reset-failed 2>/dev/null || true
rm -rf "$BASE"
echo "[uninstall] 端口："; ss -ltnp | grep -E ':(8910|8385|23000)\b' || echo '  8910/8385/23000 已释放'
echo "[uninstall] 程序目录："; ls -ld "$BASE" 2>&1 || true
echo "[uninstall] 单元："; systemctl status markor-lockserver.service markor-syncthing.service --no-pager 2>&1 | head -4
echo "[uninstall] 笔记目录保留："; ls -la /vol1/1000/Markor
