#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Markor 服务器端初始化 + 设备名同步

功能：
  1. 确保 markor 文件夹存在（ID 必须与客户端引擎一致），并默认开启
     Syncthing 回收站版本控制（保留 10 天）。
  2. 设备名写回 Syncthing 配置：优先从锁服务 /api/v1/clients 读取
     （客户端上报的真实机型名），锁服务不可用时回退 .markor/*.devicename。

用法（systemd 安装后自动执行，无需手工运行）：
  SYNCTHING_URL=http://127.0.0.1:8385 \
  SYNCTHING_APIKEY=<Web GUI 的 API Key> \
  SYNCTHING_FOLDER_PATH=/vol1/1000/Markor \
  python3 enable-versioning.py

守护模式（持续监听设备名变更）：
  python3 enable-versioning.py --daemon

仅用 Python 标准库，无第三方依赖。
"""
import argparse
import glob
import json
import os
import ssl
import sys
import time
import urllib.request
import xml.etree.ElementTree as ET

URL = os.environ.get("SYNCTHING_URL", "http://127.0.0.1:8385").rstrip("/")
APIKEY = os.environ.get("SYNCTHING_APIKEY", "")
FOLDER_ID = "markor"          # 必须与客户端引擎写死的文件夹 ID 一致
LEGACY_FOLDER_IDS = ["markor-vault"]   # 旧 ID（不一致会导致同步 0%、反复提示"添加新文件夹"）
FOLDER_PATH = os.environ.get("SYNCTHING_FOLDER_PATH", "/vol1/1000/Markor")
CLEANOUT_DAYS = "10"
DEVICE_NAME_SCAN_INTERVAL = 60   # 守护模式扫描间隔（秒）
# 纯被动模式：客户端设备的地址不允许为 "dynamic"（引擎会把空列表强制回退成
# dynamic，再按发现/回拨得到的地址主动外拨）。改为回环黑洞地址：服务器不会
# 向任何客户端发起连接，入站连接不受影响；用户手填的真实地址原样保留。
NO_DIAL_ADDR = "tcp://127.0.0.1:1"


def _find_apikey():
    """从 Syncthing 的 config.xml 自动提取 API Key（标准库解析，无需正则）。"""
    candidates = [
        os.environ.get("SYNCTHING_CONFIG", ""),
        "/opt/syncthing/markor/config/config.xml",   # 标准部署路径
        "/opt/syncthing/config/config.xml",          # fnOS 实际部署路径
        os.path.join(os.path.expanduser("~"), ".local", "state", "syncthing", "config.xml"),
        os.path.join(os.path.expanduser("~"), ".config", "syncthing", "config.xml"),
    ]
    for path in candidates:
        if not path or not os.path.isfile(path):
            continue
        try:
            root = ET.parse(path).getroot()
            gui = root.find("gui")
            if gui is not None:
                node = gui.find("apikey")
                if node is not None and node.text:
                    return node.text.strip()
        except Exception:
            pass
    return ""


def rest(method, path, data=None):
    req = urllib.request.Request(URL + path, method=method)
    req.add_header("X-API-Key", APIKEY)
    body = None
    if data is not None:
        req.add_header("Content-Type", "application/json")
        body = json.dumps(data).encode("utf-8")
    # NAS 的 Syncthing GUI 默认开 TLS 且用自签证书，本地 127.0.0.1 访问需跳过校验
    ctx = ssl._create_unverified_context() if URL.startswith("https") else None
    with urllib.request.urlopen(req, body, timeout=15, context=ctx) as resp:
        raw = resp.read()
    return json.loads(raw) if raw else None


def wait_ready(timeout=120):
    """等待 Syncthing REST 就绪，避免服务刚启动时连接拒绝。"""
    print("等待 Syncthing REST API 就绪（%ds）…" % timeout, flush=True)
    for _ in range(timeout // 3):
        try:
            rest("GET", "/rest/system/status")
            print("Syncthing REST API 已就绪。", flush=True)
            return True
        except Exception:
            time.sleep(3)
    print("错误：Syncthing REST API 在 %d 秒内未就绪" % timeout, file=sys.stderr)
    return False


def ensure_marker():
    """确保同步根有规范的 .stfolder（空目录）与含 /.markor 的 .stignore。

    背景：Syncthing 只在文件夹首次扫描（DB 序号 == 0）时自动建 marker；
    只要该文件夹已有索引，marker 被删除后引擎不会重建，会持续报
    "folder marker missing" 且首扫失败。删除旧 ID 文件夹配置（RemoveFolder）
    会连带删除同一路径下的 marker，因此每次初始化都要做一次幂等兜底。
    """
    os.makedirs(FOLDER_PATH, exist_ok=True)
    marker = os.path.join(FOLDER_PATH, ".stfolder")
    if os.path.isfile(marker):
        try:
            os.remove(marker)
        except Exception as exc:
            print("删除文件型 .stfolder 失败：%s" % exc, file=sys.stderr)
    if not os.path.isdir(marker):
        os.makedirs(marker, exist_ok=True)
        print("已补建 .stfolder 空目录：%s" % marker, flush=True)

    ignore = os.path.join(FOLDER_PATH, ".stignore")
    try:
        content = ""
        if os.path.isfile(ignore):
            with open(ignore, "r", encoding="utf-8") as fh:
                content = fh.read()
        lines = [line.strip() for line in content.splitlines()]
        # 2026-11-18：与 PC/Android 客户端保持一致，额外忽略临时文件；
        # 否则 QSaveFile/原子写留下的 *.tmp 会被服务器收下并扩散。
        required = ["/.markor", "*.tmp"]
        missing = [pat for pat in required if pat not in lines]
        if missing:
            with open(ignore, "a", encoding="utf-8") as fh:
                if content and not content.endswith("\n"):
                    fh.write("\n")
                for pat in missing:
                    fh.write(pat + "\n")
            print("已补写 .stignore 规则：%s" % ", ".join(missing), flush=True)
    except Exception as exc:
        print("补写 .stignore 失败：%s" % exc, file=sys.stderr)


def enforce_passive_devices(my_id=None):
    """把「仅 dynamic / 空地址」的设备改成回环黑洞地址，禁止服务器主动外拨。"""
    if my_id is None:
        my_id = rest("GET", "/rest/system/status")["myID"]
    for dev in rest("GET", "/rest/config/devices"):
        did = dev.get("deviceID")
        if not did:
            continue
        addrs = [a for a in (dev.get("addresses") or []) if a and a != "dynamic"]
        if addrs:
            continue
        # 本机条目只用于配置展示（拨号循环跳过自身），同样不保留 dynamic。
        dev["addresses"] = [NO_DIAL_ADDR]
        rest("PUT", "/rest/config/devices/" + did, dev)
        print("设备 %s 地址设为被动模式（%s）" % (did, NO_DIAL_ADDR), flush=True)
        if did == my_id:
            continue
        # 改地址不会断开已按 dynamic 建立的出站 socket，这里 pause/resume 一次
        # 逼它按新地址重建；客户端随即以入站方式重新连上。
        try:
            rest("POST", "/rest/system/pause?device=" + did)
            rest("POST", "/rest/system/resume?device=" + did)
        except Exception as exc:
            print("（重建设备 %s 连接失败：%s）" % (did, exc), file=sys.stderr)

    # 新建设备的默认模板同样不允许 dynamic：GUI「添加设备」不填地址时直接
    # 得到回环黑洞地址，既不会外拨，也不会在 config.xml 里留下 dynamic。
    try:
        tmpl = rest("GET", "/rest/config/defaults/device")
        addrs = [a for a in (tmpl.get("addresses") or []) if a and a != "dynamic"]
        if not addrs:
            tmpl["addresses"] = [NO_DIAL_ADDR]
            rest("PUT", "/rest/config/defaults/device", tmpl)
            print("新建设备默认地址设为 %s（不再回退 dynamic）" % NO_DIAL_ADDR,
                  flush=True)
    except Exception as exc:
        print("（调整新建设备默认地址失败：%s）" % exc, file=sys.stderr)


def init_folder_and_options():
    """一次性初始化：文件夹、版本控制、端口、中继/自升级。"""
    ensure_marker()
    my_id = rest("GET", "/rest/system/status")["myID"]

    # 设备被暂停时握手能成功但不传任何索引（表现为"已连接、0%"），这里统一恢复
    for dev in rest("GET", "/rest/config/devices"):
        did = dev.get("deviceID")
        if did and did != my_id and dev.get("paused", False):
            dev["paused"] = False
            rest("PUT", "/rest/config/devices/" + did, dev)
            print("已恢复被暂停的设备 %s" % did)

    # 纯被动：仅含 dynamic（或为空）的客户端设备改为回环黑洞地址，服务器不再
    # 外拨；手动填过真实地址的设备跳过。
    enforce_passive_devices(my_id)

    folders = rest("GET", "/rest/config/folders")

    # 迁移：先移除旧 ID 的文件夹配置（只删配置，磁盘上的文件原地保留；
    # 同一路径不能同时存在两个文件夹，删旧后才能按客户端 ID 重建）
    for legacy in LEGACY_FOLDER_IDS:
        if any(f.get("id") == legacy for f in folders):
            try:
                rest("DELETE", "/rest/config/folders/" + legacy)
                print("已移除旧文件夹配置 %s（磁盘文件保留，将按 ID=%s 重建）"
                      % (legacy, FOLDER_ID))
            except Exception as exc:
                print("移除旧文件夹 %s 失败：%s" % (legacy, exc), file=sys.stderr)
                sys.exit(1)
            # DELETE 会触发 RemoveFolder 删除同路径的 .stfolder；立即补回，
            # 否则后面按 ID=markor 重建时（DB 序号 > 0）引擎不会自动重建
            ensure_marker()

    # 星型拓扑：文件夹要共享给所有已登记的设备（PC / 手机），否则客户端虽然连上
    # 服务器，也会停在 0%（服务器不发送文件夹索引）
    share_ids = [d["deviceID"] for d in rest("GET", "/rest/config/devices")
                 if d.get("deviceID") and not d.get("paused", False)]
    if my_id not in share_ids:
        share_ids.append(my_id)

    folders = rest("GET", "/rest/config/folders")

    target = next((f for f in folders if f.get("id") == FOLDER_ID), None)
    created = target is None

    if created:
        target = {
            "id": FOLDER_ID,
            "label": "Markor",
            "path": FOLDER_PATH,
            "devices": [{"deviceID": did} for did in share_ids],
            "type": "sendreceive",
            "rescanIntervalS": 3600,
            "fsWatcherEnabled": True,
            "fsWatcherDelayS": 10,
        }
        rest("POST", "/rest/config/folders", target)
        print("已创建文件夹 %s -> %s（共享给 %d 台设备）"
              % (FOLDER_ID, FOLDER_PATH, len(share_ids)))
    else:
        # 已存在：补齐"共享给"列表（不缺设备就原样不动）
        have = [d.get("deviceID") for d in target.get("devices", [])]
        missing = [did for did in share_ids if did not in have]
        if missing:
            target.setdefault("devices", []).extend(
                {"deviceID": did} for did in missing)
            rest("PUT", "/rest/config/folders/" + FOLDER_ID, target)
            print("文件夹 %s 已存在，补共享 %d 台设备" % (FOLDER_ID, len(missing)))
        else:
            print("文件夹 %s 已存在（%s），共享设备齐全" % (FOLDER_ID, target.get("path")))

    # 回收站版本控制：仅对“本次新建”的文件夹应用默认值（保留 10 天）。
    # 已存在的文件夹一切以用户 GUI 设置为准——包括用户手动改成“无版本控制”；
    # ExecStartPost 每次重启都会跑本脚本，绝不能覆盖用户设置。
    # 客户端不下发 versioning（见引擎 main.go），服务器副本由这里/ GUI 管。
    if created:
        target = rest("GET", "/rest/config/folders/" + FOLDER_ID)
        target["versioning"] = {
            "type": "trashcan",
            "params": {"cleanoutDays": CLEANOUT_DAYS},
        }
        rest("PUT", "/rest/config/folders/" + FOLDER_ID, target)
        print("新文件夹已默认开启回收站版本控制（保留 %s 天）" % CLEANOUT_DAYS)
    else:
        current = rest("GET", "/rest/config/folders/" + FOLDER_ID).get("versioning") or {}
        print("文件夹已存在：保留现有版本控制设置 type=%s（不应用默认值）"
              % (current.get("type") or "none"))

    # 星型拓扑 + 不需要“更新同步版本”：关闭中继、关闭引擎自动升级；
    # 数据监听端口写死 23000（客户端 dial tcp://NAS:23000，默认 22000 会连不上）
    # 自动发现：本地（UDP 21027，同广播域）+ 全局（discover.syncthing.net，可跨网段）
    # 都打开——客户端只开「启用自动发现」、不填同步地址时，靠这里被找到。
    try:
        opts = rest("GET", "/rest/config/options")
        changed = False
        for key, val in (("relaysEnabled", False), ("autoUpgradeIntervalH", 0),
                         ("localAnnounceEnabled", True),
                         ("globalAnnounceEnabled", True),
                         ("listenAddresses",
                          ["tcp://0.0.0.0:23000", "quic://0.0.0.0:23000"])):
            if opts.get(key) != val:
                opts[key] = val
                changed = True
        if changed:
            rest("PUT", "/rest/config/options", opts)
            print("已关闭中继/同步引擎自动升级，开启本地+全局发现，"
                  "数据监听改为 23000（TCP+QUIC）")
    except Exception as exc:   # 老版本 Syncthing 无 options 分支端点，忽略
        print("（跳过 options 调整：%s）" % exc)

    print("完成。设备 ID：", my_id)


def lockserver_name_map():
    """2026-11-18：从锁服务 /api/v1/clients 读取 device_id→device_name。

    这是设备名的权威来源（客户端每次请求都会上报真实机型名）。返回空字典
    表示锁服务不可用，调用方回退到 .markor/*.devicename 旧通道。
    """
    key_file = ""
    for cand in (os.environ.get("MARKOR_KEY_FILE", ""),
                 "/opt/markor/lockserver/server-api-key",
                 "/opt/syncthing/markor/lockserver/server-api-key",
                 os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "lockserver", "server-api-key")):
        if cand and os.path.isfile(cand):
            key_file = cand
            break
    if not key_file:
        return {}
    try:
        with open(key_file, "r", encoding="utf-8") as f:
            api_key = f.read().strip()
        if not api_key:
            return {}
        req = urllib.request.Request(
            "http://127.0.0.1:8910/api/v1/clients",
            headers={"Authorization": "Bearer " + api_key})
        with urllib.request.urlopen(req, timeout=5,
                                    context=ssl._create_unverified_context()) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        result = {}
        for row in data.get("clients", []):
            did = (row.get("device_id") or "").strip()
            name = (row.get("device_name") or "").strip()
            if did and name:
                result[did] = name
        return result
    except Exception as exc:
        print("读取锁服务设备名失败，回退 .markor：%s" % exc, flush=True)
        return {}


def sync_device_names():
    """设备名写回 Syncthing 配置：锁服务优先，.markor/*.devicename 兜底。"""
    name_map = lockserver_name_map()

    pattern = os.path.join(FOLDER_PATH, ".markor", "*.devicename")
    files = glob.glob(pattern)
    for fpath in files:
        did = os.path.basename(fpath).replace(".devicename", "")
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                name = f.read().strip()
        except Exception:
            continue
        if did and name and did not in name_map:
            name_map[did] = name

    if not name_map:
        return

    devices = rest("GET", "/rest/config/devices")
    changed = False

    for dev in devices:
        did = dev.get("deviceID")
        if did in name_map and dev.get("name") != name_map[did]:
            dev["name"] = name_map[did]
            changed = True
            print("已更新设备 %s 的名称为 %s" % (did, name_map[did]))

    if changed:
        rest("PUT", "/rest/config/devices", devices)


def main():
    global APIKEY
    parser = argparse.ArgumentParser(description="Markor NAS 初始化与设备名同步")
    parser.add_argument("--daemon", action="store_true",
                        help="守护模式：持续从锁服务/.markor 同步设备名到 Syncthing 配置")
    parser.add_argument("--passive", action="store_true",
                        help="只把仅含 dynamic/空地址的设备改为回环黑洞地址后退出")
    args = parser.parse_args()

    if not APIKEY:
        APIKEY = _find_apikey()
    if not APIKEY:
        print("错误：无法从 config.xml 自动获取 API Key，请设置环境变量 SYNCTHING_APIKEY",
              file=sys.stderr)
        sys.exit(1)

    if not wait_ready():
        sys.exit(1)

    # 轻量模式：只做设备地址的被动化（由 markor-passive-guard.timer 周期调用），
    # 不碰文件夹、版本控制与 options，避免运行期反复写配置。
    if args.passive:
        enforce_passive_devices()
        return

    # 初始化逻辑（幂等，可重复执行）
    init_folder_and_options()

    # 设备名同步（至少执行一次）
    try:
        sync_device_names()
    except Exception as exc:
        print("（设备名同步出错：%s）" % exc, file=sys.stderr)

    if not args.daemon:
        return

    print("进入守护模式，每 %d 秒扫描一次设备名文件…" % DEVICE_NAME_SCAN_INTERVAL, flush=True)
    while True:
        time.sleep(DEVICE_NAME_SCAN_INTERVAL)
        try:
            sync_device_names()
        except Exception as exc:
            print("（设备名同步出错：%s）" % exc, file=sys.stderr)


if __name__ == "__main__":
    main()
