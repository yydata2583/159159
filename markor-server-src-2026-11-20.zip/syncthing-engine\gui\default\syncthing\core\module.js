angular.module('syncthing.core', []);
