#!/bin/sh
# Markor 服务器安装/修复脚本（幂等）
# 用法：sudo /opt/markor/install.sh [--build]
#   --build  强制从 lockserver/main.py 重新编译锁服务二进制
set -e
BASE=/opt/markor
if [ "$(id -u)" != "0" ]; then echo "请用 root 运行：sudo $0 $*"; exit 1; fi
mkdir -p "$BASE/lockserver" "$BASE/scripts" "$BASE/config" "$BASE/systemd"
if [ "$1" = "--build" ] || [ ! -x "$BASE/lockserver/markor-lockserver" ]; then
    echo "[install] 编译锁服务二进制 ..."
    TMP=$(mktemp -d)
    python3 -m PyInstaller --onefile --clean --noconfirm --name markor-lockserver \
        --distpath "$TMP/dist" --workpath "$TMP/build" --specpath "$TMP" \
        "$BASE/lockserver/main.py"
    install -m 0755 "$TMP/dist/markor-lockserver" "$BASE/lockserver/markor-lockserver"
    rm -rf "$TMP"
fi
install -m 0644 "$BASE/systemd/markor-lockserver.service" /etc/systemd/system/
install -m 0644 "$BASE/systemd/markor-syncthing.service" /etc/systemd/system/
install -m 0644 "$BASE/systemd/markor-passive-guard.service" /etc/systemd/system/
install -m 0644 "$BASE/systemd/markor-passive-guard.timer" /etc/systemd/system/
# 笔记目录只保证存在与忽略规则，不删除任何内容
mkdir -p /vol1/1000/Markor
grep -qxF '/.markor' /vol1/1000/Markor/.stignore 2>/dev/null || echo '/.markor' >> /vol1/1000/Markor/.stignore
grep -qxF '*.tmp' /vol1/1000/Markor/.stignore 2>/dev/null || echo '*.tmp' >> /vol1/1000/Markor/.stignore
systemctl daemon-reload
systemctl enable markor-lockserver.service markor-syncthing.service markor-passive-guard.timer
systemctl restart markor-lockserver.service markor-syncthing.service
systemctl restart markor-passive-guard.timer
sleep 4
systemctl is-active markor-lockserver.service markor-syncthing.service
systemctl is-enabled markor-lockserver.service markor-syncthing.service
ss -ltnp | grep -E ':(8910|8385|23000)\b' || true
curl -s --max-time 5 http://127.0.0.1:8910/health || true
echo
