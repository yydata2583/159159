// Android JNI 桥接层（方案 B：同步引擎以 .so 形式随 APK 分发，进程内直调）。
//
// 文件名后缀 _android.c 使该文件只在 GOOS=android 时参与编译，
// PC 端（windows）构建 markorsync.dll 时不会包含它，也不需要 jni.h。
//
// 对应 Java 类：net.gsantner.markor.sync.NativeSync
// 引擎 C 接口定义在同目录 main.go（MarkorSyncStart / Stop / Restart / Status / Free / Version）。
#include <jni.h>
#include <stdlib.h>
#include <string.h>

extern int MarkorSyncStart(char *dir, char *cfgJSON);
extern void MarkorSyncStop(void);
extern int MarkorSyncRestart(char *dir, char *cfgJSON);
extern char *MarkorSyncStatus(void);
extern void MarkorSyncFree(char *p);
extern char *MarkorSyncVersion(void);

// jstring -> 新建 C 字符串（调用方负责 free）
static char *markor_jstr_dup(JNIEnv *env, jstring s)
{
    if (s == NULL) {
        return NULL;
    }
    const char *utf = (*env)->GetStringUTFChars(env, s, NULL);
    if (utf == NULL) {
        return NULL;
    }
    const size_t len = strlen(utf);
    char *copy = (char *) malloc(len + 1);
    if (copy != NULL) {
        memcpy(copy, utf, len + 1);
    }
    (*env)->ReleaseStringUTFChars(env, s, utf);
    return copy;
}

JNIEXPORT jint JNICALL
Java_net_gsantner_markor_sync_NativeSync_nativeStart(JNIEnv *env, jclass cls,
                                                    jstring dir, jstring cfgJSON)
{
    char *d = markor_jstr_dup(env, dir);
    char *c = markor_jstr_dup(env, cfgJSON);
    const int rc = MarkorSyncStart(d != NULL ? d : (char *) "", c != NULL ? c : (char *) "");
    free(d);
    free(c);
    return (jint) rc;
}

JNIEXPORT jint JNICALL
Java_net_gsantner_markor_sync_NativeSync_nativeRestart(JNIEnv *env, jclass cls,
                                                      jstring dir, jstring cfgJSON)
{
    char *d = markor_jstr_dup(env, dir);
    char *c = markor_jstr_dup(env, cfgJSON);
    const int rc = MarkorSyncRestart(d != NULL ? d : (char *) "", c != NULL ? c : (char *) "");
    free(d);
    free(c);
    return (jint) rc;
}

JNIEXPORT void JNICALL
Java_net_gsantner_markor_sync_NativeSync_nativeStop(JNIEnv *env, jclass cls)
{
    (void) env;
    (void) cls;
    MarkorSyncStop();
}

JNIEXPORT jstring JNICALL
Java_net_gsantner_markor_sync_NativeSync_nativeStatus(JNIEnv *env, jclass cls)
{
    (void) cls;
    char *raw = MarkorSyncStatus();
    if (raw == NULL) {
        return NULL;
    }
    jstring out = (*env)->NewStringUTF(env, raw);
    MarkorSyncFree(raw);
    return out;
}

JNIEXPORT jstring JNICALL
Java_net_gsantner_markor_sync_NativeSync_nativeVersion(JNIEnv *env, jclass cls)
{
    (void) cls;
    char *raw = MarkorSyncVersion();
    if (raw == NULL) {
        return NULL;
    }
    jstring out = (*env)->NewStringUTF(env, raw);
    MarkorSyncFree(raw);
    return out;
}
