# 决策记录（decisions.md / ADR）— Markor 同步服务器（A-2xx）

### A-201：星型拓扑，不部署中继（Accepted）
- **背景**：产品要求 PC/手机只与服务器连接、设备间不互连；客户端已禁自动发现/中继。
- **决策**：docker-compose 移除 relaysrv；`enable-versioning.py` 关 `relaysEnabled`；跨网走 Tailscale/专网直连服务器地址。
- **后果**：部署更简、连通路径唯一；需要网络可达（填对服务器地址）。
- **替代方案**：私有中继兜底（否决：与"设备不互连"无冲突但产品明确删中继）。

### A-202：管理 GUI 统一 8385（Accepted）
- **背景**：README 写 8384、systemd 单元写 8385，文档与实际不一致；客户端 PC 端曾因参数/HTTPS 问题"打不开"。
- **决策**：全端统一 8385（服务端 `STGUIADDRESS=0.0.0.0:8385`；文档/初始化脚本同步改）；客户端内嵌引擎同样 8385（127.0.0.1、tls=false）。
- **后果**：端口心智统一；GUI 建议仅内网/VPN。
- **替代方案**：保持 8384（否决：与已有部署不一致）。

### A-203：锁服务按设备多持有者（Accepted，修复单值覆盖 BUG）
- **背景**：原实现 `LOCKS[(vault,path)] = 单设备`，后开者覆盖先开者 → holders 恒空（提示永不触发）、先开者心跳 404。
- **决策**：`LOCKS[(vault,path)] = {device_id: {...}}`，各设备独立心跳/注销/过期；holders=其他设备。锁语义=**提示层**（非互斥），写冲突靠 `.sync-conflict-*`。
- **后果**：协议行为与 README §五 定义一致；多设备同开合法且互相提示。
- **替代方案**：互斥硬锁（否决：未获产品确认；如需另立 ADR 并三端联改）。

### A-204：同步引擎不自升级（Accepted，产品要求）
- **背景**："不需要更新同步版本"。
- **决策**：`enable-versioning.py` 设置 `autoUpgradeIntervalH=0`（与两端客户端一致）；升级走人工。
- **后果**：版本稳定可控。

### A-205：API Key 为自生成共享口令（Accepted）
- **背景**："不需要写死服务器信息"；锁 API 需要简单鉴权。
- **决策**：`MARKOR_API_KEY` 由部署者随机生成（如 `openssl rand -hex 32`），服务端与三端客户端一致；仓库模板只放占位符（曾误提交真实 key，已清理）。
- **后果**：无申请/注册流程；key 泄露需自行轮换。
- **替代方案**：OAuth/证书鉴权（否决：内网自用过度设计）。

### A-206：锁只保护内存一致性——磁盘 IO 全部锁外 + 写操作身份校验入临界区 + 落盘前 rev 复核（Accepted，2026-10-31）
- **背景**：复审发现 SV-C2/SV-H7 修复的三处盲区——①publish 源合并分支在源会话不在内存时 `guard = _lock`，os.stat 与两次 `_flush_to_disk` 在全局锁内执行（Syncthing 目录慢盘卡顿时单请求冻结全服务器）；②`_entry_revalidate` 在 oplock 外执行，校验通过后到进锁之间 close/delete/GC 仍可删除 entry，op 写入孤儿对象、返回 200 但编辑静默丢失；③close/GC/save 先快照 content/rev、锁外落盘、之后才校验 rev，快照后到达的 op 会被旧快照覆盖写回磁盘。
- **决策**：
  1. **源会话不在内存的 publish 合并**：无内存状态要保护，stat/落盘全部锁外执行；源会话存活时维持其 oplock 串行化。
  2. **身份校验与状态变更同临界区**：op/struct/save 把 `FILES.get(key) is entry` 校验移入 `with entry.oplock: with _lock:` 内、改状态之前；失效则 `_entry_revalidate` 换当前 entry 重试（循环直到命中）。
  3. **落盘前 rev 复核**：GC/close/save 在锁外落盘前先锁内确认 `entry.rev` 未变，已变则放弃本次旧快照落盘，由 GC 下轮用新快照重试。
- **后果**：全局锁内零磁盘 IO；TOCTOU 窗口闭合，编辑不再静默丢失；磁盘内容不会因旧快照短暂回退。
- **替代方案**：①revalidate 后在锁内直接换 entry 继续（否决：换出的 entry 未持其 oplock，广播顺序无法保证）；②落盘后比对再补写（否决：旧版本已被 Syncthing 传播，事后补写产生冲突副本）。

### A-207：publish 单一权威值 + 会话迁移订阅 + 副本删除互斥（Accepted，2026-10-31）
- **背景**：第三轮复审（`code-review-2026-10-31b-srv.md`）发现两处此前未命中的系统性缺陷，以及一批锁内 IO/生命周期问题：
  1. publish 的权威值自相矛盾：先把副本内存/广播/副本磁盘写成 `content`，随后又用"更新前的副本内存" `live` 覆盖源文件与副本磁盘。副本仅被打开、未被编辑时 `live` 是旧快照 → 本次 publish 内容被丢弃、源文件回滚，并经 Syncthing 扩散到所有设备（数据回退）。
  2. 副本→源会话切换（`_resolve_session_path` 重定向）不迁移已有 SSE 订阅：源设备上线后，副本端的 SSE 仍挂在旧 entry，其 op 被重解析到源会话，而源端广播只发给源会话的 subs → 副本端收不到源端编辑（协作单向静默失联），旧 entry 永不回收。
  3. 另有：锁内写 socket（close 常见路径/op 越界）、锁内读盘（`_entry_get_or_create`/revalidate/GC ALIAS）、有订阅者时永不落盘、rev 复核与写盘分属两个临界区、save 刷新副本内存不广播、重试循环无上限可被 close 刷成活锁、SSE 退出不关连接、publish/SSE 建连缺身份校验、publish 吞落盘失败、delete 与 publish 可"先删后复活"。
- **决策**：
  1. **publish 唯一权威值**：`authoritative = content`（本次请求内容即为到达序的权威）；是否把副本内容合并回源文件只由副本磁盘 mtime（`old_mtime`）与源文件 mtime 比较决定，不再以"内存中存在副本会话"作为覆盖信号。
  2. **会话迁移带订阅**：新增 `_migrate_subs(src, dst)`，在锁内把 src 的订阅并入 dst、同步改写每个 SSEHandler 的 `entry` 绑定、随后弹出 src entry；dst 已消失时返回 False，调用方留在副本会话。
  3. **锁只保护内存**：`_lock` 内不写 socket、不读盘；错误响应在锁外发送。落盘与 rev 复核放在同一 oplock 临界区内（复核后立即写）。
  4. **重试有界**：身份校验重试最多 5 次，超出返回 409；`ts` 在锁内取，避免重试使用过期时间戳。
  5. **副本删除与 publish 互斥**：新增 `_recent_io_lock` 与删除墓碑，delete 先登记墓碑再删文件，墓碑期内的 publish 直接视为已删除，杜绝复活。
- **后果**：publish 不再造成数据回退；源设备上线后协作双向可达；全局锁内零 IO/零网络写；重试不会活锁；已删副本不会被紧邻的 publish 复活。
- **替代方案**：①按"内存会话存在即视为副本更新"（否决：正是 R1 的根因，副本被打开但未编辑时必然回退）；②会话切换时让客户端重连（否决：需改三端协议，服务端迁移订阅可零成本解决）；③删除用文件锁/fs lock（否决：跨平台与容器环境下行为不一致，进程内互斥 + 墓碑足够）。

## A-208：adopt 快照合并 + 订阅迁移互斥 + hello 超时兜底（2026-10-31）

- **状态**：已接受
- **背景**：第四轮复审（code-review-2026-10-31c-srv.md）三条高危——①adopt 合并用本次 publish content 作权威值，源设备上线 publish 旧内容时离线期间他端对副本的编辑被三处回滚；②_migrate_subs 直接丢弃副本 entry，未落盘编辑丢失且与在途 op 无互斥；③hello 在全局锁内写 socket 且此前已 settimeout(None)，半开客户端可冻结全服分钟级。
- **决策**：
  1. **adopt 快照合并**：publish 覆盖副本前先快照 copy_snapshot（内存 entry 优先，无会话读磁盘）；adopt 判定成立时改用快照合并回源文件并广播；快照缺失放弃 adopt（不回滚副本编辑）。
  2. **迁移互斥**：_migrate_subs 整段持 _recent_io_lock → src.oplock → _lock（与 publish 锁序一致）；entry 销毁前 rev>0 先落盘；迁移后向被迁移订阅者补发 struct 全量对齐基线。
  3. **hello 超时兜底**：settimeout 放宽推迟到 hello 写完之后，hello 期间沿用 30s 超时。
  4. **墓碑期拒建**：_recent_tombstoned() 让 entry 创建/复活在墓碑期内返回 None（410/SSE 拒连）。
- **后果**：他端离线编辑任何路径下不被回滚；会话迁移无静默 op 丢失；单客户端异常不再冻结全服。
- **替代方案**：①adopt 时三路内容三路比对取最新（否决：无可靠时间戳，磁盘 mtime 已足够且快照方案更简）；②hello 完全异步写（否决：首包乱序风险，30s 超时已可兜底）。

## A-209：adopt 新旧信号内存优先 + 先判定后写副本（2026-10-31）

- **状态**：已接受（Supersedes A-208 中 adopt 判定部分）
- **背景**：第五轮复审（code-review-2026-10-31d-srv.md）两条 High——①adopt 仍用磁盘 mtime 判新旧，副本内存中未落盘的编辑会被漏判并遭 publish 覆盖；源会话在线时又可能被旧副本快照反向覆盖；②adopt 成立后副本侧不回写且旧内容已先广播，来源端编辑器被回退，随后 save 可整篇覆盖刚合并进源的内容。
- **决策**：
  1. **新旧信号内存优先**：副本侧快照与 mtime 采集整体移入 _recent_io_lock+oplock 临界区；副本 rev>0 时新旧信号取 entry.mtime 与磁盘 mtime 的最大值；源侧 rev>0 用 oentry.mtime，rev==0 用源文件磁盘 mtime。
  2. **先判定后落盘**：adopt 判定完成后再落盘与广播；adopt 成立时副本内存 entry 与磁盘统一写快照，只有非 adopt 路径才广播 publish content。
  3. **迁移先合并**：_migrate_subs 迁移前把副本编辑并入 dst（抬 rev、锁外广播），保证迁移后首条 op 基线对齐。
- **后果**：副本未落盘编辑不再被覆盖；adopt 后来源端编辑器内容与服务器一致；迁移首条 op 不错行。
- **替代方案**：①"有订阅者就不 adopt"（否决：源设备刚打开即漏判副本编辑，用 mtime 上限更精确）；②adopt 后延迟广播等客户端确认（否决：增加往返与状态机复杂度）。

## A-210：publish 基线区分他端编辑 + 迁移三态 + 锁等待有界（2026-10-31）

- **状态**：已接受（Supersedes A-209 的 adopt 判定细节）
- **背景**：第六轮复审（code-review-2026-10-31e-srv.md）——①adopt 一律以副本旧快照为唯一权威，本次 publish 内容被静默丢弃，稳态下源文件"隔一次发布落后一次"；②_migrate_subs 无条件合并，副本旧内容回滚源端较新内容；③合并/基线广播在 oplock 外，并发 op 可致客户端先收新 rev 后收旧全文。
- **决策**：
  1. **副本基线 _PUBLISHED_LOCAL**：记录上次由该设备发布的内容，用于区分"副本含他端编辑"与"本次 publish 只是设备重申"；无法判定时返回 conflict:true 并附权威内容，由客户端决策，不静默丢弃。
  2. **迁移三态**：_migrate_subs 返回 合并成功 / 无需合并 / conflict；合并前比较 src_mtime 与 dst 新近度，副本不新则返回 conflict（调用方 409）。
  3. **广播入锁**：合并广播与基线 struct 移入 dst.oplock 持锁区间，保证 rev 单调与客户端接收顺序一致。
  4. **锁等待有界**：oplock 获取 10s 超时（超时 503），SSE 帧独立 15s 写超时；MAX_FILE_BYTES=16MB 在 op/struct/save 与落盘处复核。
- **后果**：publish 不再双向丢内容；迁移不会回滚较新内容；客户端不再收到乱序全文。
- **替代方案**：①依赖客户端每次 publish 全量覆盖（否决：无基线无法判定冲突）；②锁永不超时（否决：慢客户端可拖垮全服）。

## A-211：内容时间戳拆分、基线摘要化与锁区间收缩（第七轮复审）

- **状态**：已接受
- **日期**：2026-11-01
- **背景**：第七轮复审（code-review-2026-10-31f-srv.md）——①save 镜像写不更新 _PUBLISHED_LOCAL，基线落后致回声误判 adopt 回滚；②基线存整篇内容无生命周期，长期运行 OOM；③entry.mtime 兼作活动/内容时间戳，"刚打开过"被误判"内容更新"致 409 卡死；④迁移广播在全局锁内，慢订阅者堵全服；⑤未配对代理字符可毒化单文件全部订阅；⑥publish 无会话落盘与并发 op 竞态。
- **决策**：
  1. **基线摘要化**：_PUBLISHED_LOCAL 改存 sha256 摘要 + 插入序淘汰（8192 上限）；凡服务端主动写副本（save 镜像、publish adopt/落盘）成功后都更新基线。
  2. **content_mtime 拆分**：FileEntry 新增 content_mtime，仅内容真实变化时刷新；迁移与 publish 的新旧判定一律用它；op/struct/save 内容无变化不抬 rev、不广播。
  3. **锁区间收缩**：_migrate_subs 保持锁序 _recent_io_lock→oplock，但全局锁只覆盖状态变更+落盘，提前释放后再广播（仍持 oplock 保序）；publish 无会话落盘后回锁复核新建 entry，内存较新值覆回。
  4. **输入净化与字节口径**：_clean_surrogates 统一拦截未配对代理字符；上限全部按 UTF-8 字节；_load_from_disk 前置 stat 拦截超大文件。
- **后果**：回声不再被误判成他端编辑；基线内存有界；活动时间不再污染新旧判定；慢订阅者不再堵全服；毒化输入在入口被拒；内存/磁盘分叉窗口封闭。
- **替代方案**：①基线带 TTL 全量清理（否决：摘要化后单条仅 64 字节，插入序淘汰足够）；②迁移不广播改由客户端重连（否决：断连重连成本高于持 oplock 广播）。

## A-212：publish 全局锁收缩与读入侧口径统一（第八轮复审）

- **日期**：2026-11-01
- **背景**：第八轮复审（docs/code-review-2026-11-01-srv.md）——①SV-U4 修复把 publish 广播连同 _recent_io_lock 一起持有，慢订阅者堵全服（SV-U7 同类问题在 publish 上重现）；②SV-U6 的 content_mtime 在副本侧漏改，活动时间仍可冒充内容时间触发错误 adopt；③_recent_file 端点锁内发送响应；④publish 直读副本快照绕过大小拦截；⑤解码失败与文件不存在归一为空串致不可读文件被静默覆盖。
- **决策**：
  1. **publish 锁区间收缩**：_recent_io_lock 显式 acquire/release+try/finally，只覆盖状态变更+落盘；广播前释放、仅持双 oplock，与迁移同款。
  2. **副本侧时间戳对称**：rev>0 时 copy_mtime=centry.content_mtime，不再与磁盘 mtime 取 max。
  3. **读入侧统一口径**：副本快照改调 _load_from_disk；解码失败返回 None 并独立记日志，全端点 415 拒绝建空 entry。
- **后果**：慢订阅者不再堵全服 publish；旧副本不再回滚较新源内容；读入侧上限/解码口径一致；不可读文件不再被静默覆盖。
- **替代方案**：①广播异步队列（否决：引入新线程与保序复杂度，提前释放已足够）；②解码失败按 GBK 回退（否决：服务端只认 UTF-8 协议口径，拒绝比猜错编码安全）。

## A-213：超大文件 None 口径 + publish 换入 entry 换锁保序（2026-11-01）
- 用户诉求：第九轮复审 SV-W1~W3 修复（审查-修复收敛协议）
- 根因：SV-V5 三态拆分漏「超 16MB」第四态，超大既有文件按空串建空 entry，后续 op/save 落盘静默覆盖并经 Syncthing 扩散；SV-V1 保序边界只覆盖 c0/o0，复核分支换入的 cur/appeared 广播时未持其 oplock，窗口内并发 op 可先送达高 rev 再被旧全文帧回退；hello 写超时注释 30s 与实现 15s 漂移
- 方案：超限分支返回 None 与解码失败同口径（publish 快照点 if snap: 天然兼容）；三处复核分支换入时 stack.enter_context(_timed_lock(x.oplock)) 持有至广播，_LockTimeout 按放弃校正处理（不升级为 busy，避免落盘已完成却回 503）；注释改 15s
- 锁序复核：换入 oplock 带超时获取，与 c0/o0 持锁方不成环（对侧 op/save/GC/close 不反向索取 _recent_io_lock），超时各自回退无死锁
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）

## A-214：_load_from_disk None 口径注释收口（2026-11-01）
- 用户诉求：第十轮复审 SV-X1 修复
- 根因：SV-W1 修改超限分支返回值与紧邻内联注释，漏改同函数 docstring 三态说明与 publish 快照点引用该口径的注释，文档表述会把维护者误导回旧三态模型
- 方案：docstring 改「None（文件存在但不是合法 UTF-8，或超过 16MB 上限——SV-W1）」；快照点注释改「失败返回空串、超限/不可解码返回 None（SV-V5/SV-W1）」
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）

## A-215：死导入清理 + 日志直写点统一 isprintable 过滤（2026-11-01）
- 用户诉求：第十一轮复审 SV-Y1~Y2 修复
- 根因：SV-M1 移除 unquote 全部调用点时漏清导入，import re 更早失去最后使用点；P3 只给 log_message 汇聚点加控制字符过滤，15 处业务直写 print 未纳入同一口径，_safe_path/_req_text 不剔除段内控制字符，query 解码后的 \n（Linux 合法文件名字符）可截断/伪造日志行
- 方案：删除 import re、unquote 导入（L848/L904 说明性注释保留）；新增 _log() 帮助函数复用 isprintable 过滤（非打印字符替换为 ?），gc/flush/load/recent/sse/delete 及启动横幅共 15 处直写点全部改走 _log；log_message 保持原有过滤不变
- 备选否决：在 _safe_path/_req_text 层拒绝控制字符（更彻底、顺带净化落盘文件名）——会改变请求处理行为，本轮仅修日志完整性，行为变更另议
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）

## A-216：SSE keepalive 崩溃修复 + 共享状态加锁口径统一（2026-11-01）
- 用户诉求：第十三轮复审 SV-AA1~AA4 修复（审查-修复收敛协议）
- 根因与方案：
  1. **SV-AA1（Critical）SSE keepalive 崩溃**：keepalive 循环中 `current.write(b": keepalive\n\n")` 作用于 `current = sse.entry`（FileEntry 实例，`__slots__` 仅含 content/mtime/content_mtime/subs/rev/oplock，无 write 方法），抛出 `AttributeError`；而 `except (BrokenPipeError, ConnectionResetError, OSError)` 不捕获 `AttributeError`，异常向上抛至 socketserver 框架后关连——**每个 SSE 连接在首次保活（约 30s）后必定崩溃断开，实时协同长连接无法维持**。根因为引入 `sse.entry` 绑定时把 `sse.write` 误写为 `current.write`。→ 改为 `sse.write(b": keepalive\n\n")`。
  2. **SV-AA2（Low）LAST_SEEN 无锁读取**：`_handle_recent_devices` 中 `LAST_SEEN.get()` 在 `_lock` 外，写入在 `_handle_recent_heartbeat` 的 `_lock` 内，口径不统一 → 移入 `_lock` 内做快照后在锁外计算。
  3. **SV-AA3（Low）_PLATFORM_CACHE 无锁保护**：`_build_recent_devices` 读与 `_handle_recent_heartbeat` 读写均在 `_lock` 外，并发心跳可重复写 `.platform` 文件 → 三处加 `_lock`（磁盘 IO 放锁外）。
  4. **SV-AA4（Low）死字段**：`SSEHandler.__init__` 中 `self._write_called = False` 赋值后全文无读取 → 删除。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：python -m py_compile main.py 退出码 0

## A-217：publish 侧 .platform 写盘后回填 _PLATFORM_CACHE（2026-11-01）
- 用户诉求：第十四轮复审 SV-AB1 修复（审查-修复收敛协议）
- 根因：`_PLATFORM_CACHE` 的写入路径只有 `_handle_recent_heartbeat`，`_handle_recent_publish` 写 `.platform` 文件后遗漏了缓存回填，导致共享缓存与磁盘数据源分叉。设备通过 publish 上报新 platform（如从 desktop 切到 phone）时，缓存仍保留旧值，`_build_recent_devices` 返回过期平台图标，直到下次心跳（≤3s）才刷新；若设备此后不再发心跳，缓存永久不一致（每次回退读盘但不回填）。
- 方案：在 `.platform` 写盘成功后，于 `with _lock:` 内执行 `_PLATFORM_CACHE[dev] = plat`（与 `_handle_recent_heartbeat` 同口径）；写盘失败不回填。写盘与回填同在 `_recent_io_lock` 保护区内。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：python -m py_compile main.py 退出码 0

## A-218：第十六轮复审——锁超时统一、字段上限与 Docker 落盘修复（2026-11-03，仅本地未部署）

- 用户诉求：审查—修复收敛协议第十六轮，收口锁超时口径遗漏、内存/磁盘边界校验残留与 Docker 部署路径的落盘位置缺陷。
- 根因与方案：
  1. **SV-AD1（Low）**：publish 的 SV-U9 副本侧复核分支在持 `_recent_io_lock` 期间以 `with appeared.oplock:` 无超时取锁，是全文件唯一一处该区间内的无超时 oplock 获取（迁移、publish 主获取、三处换锁分支、delete 均已按 SV-T6 带 10s 超时）。该 oplock 可被慢 SSE 广播或落盘占用，期间全服 publish/delete/迁移在 `_recent_io_lock` 上无限期串行 → 改 `_timed_lock`，捕获 `_LockTimeout` 时跳过本轮覆回校正（`restore` 保持 None），rev 差由后续 publish/GC 收敛。
  2. **SV-AD2（Low）**：recent 端点只做形状校验、无长度上限。超长 dev 名以键驻留 `LAST_SEEN` 24h（换名重发线性膨胀）；超长 dev/name 令 `_flush_to_disk` 因 ENAMETOOLONG 失败（persisted=False），但 `ALIAS[recent]=origin` 在其前登记且 origin 指向真实文件时 GC 存活校验不清除，零磁盘代价留下大键 → 新增 `MAX_DEV_LEN=128`/`MAX_NAME_LEN=255`/`MAX_ORIGIN_LEN=1024`，heartbeat/publish/delete/list/file 全部前置校验。
  3. **SV-AD3（Low）**：`headers.get("Content-Length", "0")` 把"缺失"与"显式 0"归一，读取 0 字节后若客户端实际发送了 body（含 chunked，stdlib 不解析），残留字节被当作下一条请求解析 → 缺 CL 或存在 `Transfer-Encoding` 时显式 400 并 `close_connection=True`。
  4. **SV-AD4（Low）**：delete 的 name 校验缺 publish 已有的 `.` 前缀与 `.tmp.` 中段拦截，可 unlink `.platform` 设备形态文件或 `_flush_to_disk` 在途 tmp → 与 publish 对齐。
  5. **SV-AD5（Medium）**：docker-compose 的 lockserver 服务无 volumes、无 `MARKOR_DISK_ROOT`/`MARKOR_RECENT_ROOT`，`DISK_ROOT` 落到容器内 `/root/Markor`、`RECENT_ROOT` 落到 `/app/recent-sync`，协作落盘与最近页副本均不进入 vault，容器重建即丢失 → 增加 `${DATA_PATH}:/data`、命名卷 `lockserver-recent:/app/recent-sync` 与两个环境变量；systemd 部署路径显式设置过 `MARKOR_DISK_ROOT`，不受影响。
- 未改动铁律：锁序 `_recent_io_lock → oplock → _lock`、`_lock` 内禁磁盘 IO/socket 写（hello 例外）、心跳 3s/在线窗口 12s、单级 API Key 均保持不变。
- 涉及文件：server/lockserver/main.py、server/docker-compose.yml（均仅本地，部署需用户确认）
- 验证：`compile()` 内存编译通过（未生成 .pyc）

## A-219：第十七轮复审——路径字节上限、落盘读取保护与缓存生命周期（2026-11-03，仅本地未部署）

- 用户诉求：审查—修复收敛协议第十七轮，收口核心路径/设备字段的无界输入、既有超大文件的整篇读取、ALIAS/形态缓存的无界增长与 SSE 迁移竞争。
- 根因与方案：
  1. **SV-AE1（Medium）**：`_safe_path` 只做形状校验，不限制长度；`path/device_id/device_name` 可达 MB 级。超长路径必然 ENAMETOOLONG，op/save 抬升 rev 后 GC 永远无法落盘成功，entry 永久驻留 FILES（单请求近 16MB 内存）。→ `_safe_path` 增加单组件 ≤255 字节、整路径 ≤4096 字节与控制字符拒绝；新增 `_valid_device` 并接入 SSE/open/op/struct/save；GC 在落盘失败且无订阅者时，对结构上不可落盘的历史 entry 直接回收（`_path_persistable`）。
  2. **SV-AE2（Low）**：`_flush_to_disk` 的“内容一致跳过”分支对既有目标文件整篇 `read()`，既有 >16MB 文件（其它同步端/管理员产生）会被完整读入，且 publish 在 `_recent_io_lock` 内调用 flush，慢盘大文件同时阻塞全服。→ 比较前 `os.path.getsize`，超限则不读、不覆盖并返回 False。
  3. **SV-AE3（Low，REGRESSION SV-AD2）**：AD2 的上限按字符非 UTF-8 字节（255 个中文 = 765 字节），仍会 ENAMETOOLONG；且 ALIAS 仍在落盘前登记、无容量上限。→ 字节口径由 `_safe_path` 统一保证；ALIAS 移到 `flush_ok` 之后登记，新增 `_remember_alias`（8192 条 FIFO）并淘汰最旧条目。
  4. **SV-AE4（Low）**：POST 鉴权失败在读取请求体前 401 且不断连，keep-alive 上未消费 body 会被当作下一条请求行解析。→ 401 前设置 `close_connection=True`。
  5. **SV-AE5（Low）**：`_PLATFORM_CACHE` 无淘汰、心跳创建的设备目录无生命周期，持 Key 客户端可用唯一设备名持续膨胀内存与磁盘。→ 新增 `_remember_platform`（4096 条 FIFO）；GC 每 60s 清理 24h 无心跳且仅剩 `.platform` 的空设备目录并淘汰对应缓存，心跳/publish 会按需重建。
  6. **SV-AE6（Low）**：SSE 注册释放 `_lock` 后、join 广播前，另一请求的 `_resolve_session_path` 可把该订阅迁移到源会话并清空旧 `entry.subs`，join 仍按旧 entry 发送导致迁移后 peers 收不到新 peer。→ join 前在锁内重读 `sse.entry`，按当前绑定广播并记录实际 peers 数。
- 未改动铁律：锁序 `_recent_io_lock → oplock → _lock`、`_lock` 内禁磁盘 IO/socket 写（hello 例外）、心跳 3s/在线窗口 12s、单级 API Key 均保持不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`compile()` 内存编译通过（未生成 .pyc）

## A-220：第二十二轮复审——publish 缺省 origin 崩溃与不可读文件语义（2026-11-03，仅本地未部署）

- 用户诉求：审查—修复收敛协议第二十二轮，服务器端全量逐段复查发现 2 项（SV-AG1/AG2）。
- 根因与方案：
  1. **SV-AG1（Medium）**：`origin = _safe_path(_req_text(...))` 对空串/非法值返回 `None`，紧接着 `len(origin)` 抛 `TypeError`，请求线程异常退出、连接被断开；不带 `origin_rel` 的上报（第三方调用/旧客户端/相对路径算不出）全部命中。→ 空值与非法的 origin 归一为 `""`（视为不绑定源会话），只有非空值参与长度上限校验。
  2. **SV-AG2（Low）**：`_load_from_disk` 对既有但不可读的文件（权限/IO）落入外层兜底返回 `""`，与"文件不存在"归一，会为不可读文件建空 entry；目录可写时后续落盘 `os.replace` 会静默覆盖原内容。→ 读取阶段区分 `FileNotFoundError`（仍返回空串）与其它 `OSError`（记日志返回 `None`，调用方按 415 拒绝建 entry），与 SV-V5 不可解码口径一致。
- 否决方案：对 origin 非法值直接 400——旧客户端/可选字段语义会从"可选"变"必填"，破坏兼容；归一为空串更安全。
- 未改动铁律：锁序、`_lock` 内禁 IO、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（校验后清理 `__pycache__`）

## A-221：第二十三轮复审——既有文件 stat 失败语义（2026-11-03，仅本地未部署）

- 用户诉求：审查—修复收敛协议第二十三轮，服务器端全量逐段复查发现 1 项（SV-AH1）。
- 根因：SV-AG2 只把 `open/read` 的 `OSError` 改为返回 `None`；同一函数的 `os.path.getsize(full)` 仍在外层 `except Exception` 内，`PermissionError`/`ESTALE` 等 stat 失败被兜底成 `""`，于是为实际存在的不可 stat 文件建空 entry，后续 op/save 落盘会静默覆盖原文件。
- 方案：`getsize` 单独 `try`——`FileNotFoundError`（isfile 与 stat 之间被删）仍返回空串；其它 `OSError` 记日志并返回 `None`（调用方 415 拒绝建 entry）；超限日志复用已取到的 `size`，避免二次 stat。
- 否决方案：把整个 `isfile+getsize+open` 合并成一个 `try`——`FileNotFoundError` 与"不存在"语义会无法区分，且超限日志中的二次 getsize 仍可能抛错。
- 未改动铁律：锁序、`_lock` 内禁 IO、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（校验后清理 `__pycache__`）

## A-222：第二十七轮复审——副本读取基线与超限 entry 回收（2026-11-03，SV-AI1/AI2，仅本地未部署）

- 用户诉求：审查—修复收敛协议第二十七轮，服务器端全文复查发现 2 项（均为 P2）。
- 根因与方案：
  1. **SV-AI1**：`_handle_recent_file` 以 `resolved` 会话的 entry 取内容，但只在 `rev>0` 时用内存内容；源会话 `rev==0` 时退回读副本磁盘。副本磁盘与源文件是两份视图，导致 GET 预览基线与 `/open`/hello 不一致，后续 op 行号错位。→ 条件改为 `entry.rev > 0 or resolved != recent`。
  2. **SV-AI2**：`_flush_to_disk` 对超限既有文件一律拒写（设计正确，避免截断外部大文件），但 GC 只对"路径不可落盘"的 entry 做丢弃，目标文件被外部扩到超限的 entry 永远落不了盘，常驻内存并每 10s 刷 SKIP 日志。→ 新增 `_disk_file_too_large`，GC 失败分支在无订阅者时把此类 entry 一并删除并记 `[gc] drop`。
- 否决方案：让 `_flush_to_disk` 覆盖超限外部大文件——会把外部大文件静默截断，违反既有设计。
- 未改动铁律：锁序、`_lock` 内禁 IO、GC 异常不得杀线程、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（校验后清理 `__pycache__`）

## A-223：第三十二轮审查——非有限数值与副本覆盖（2026-11-04，SV-BK1/BK2）

- 用户诉求：收敛标准提高为连续 5 轮零问题，自第三十二轮起重新编号。
- 根因与方案：
  1. **SV-BK1**：Python 的 `json.loads` 接受 `Infinity`/`NaN`；`int(float('inf'))` 抛 `OverflowError`，原先只捕获 `(ValueError, TypeError)`，异常穿透请求处理导致连接被重置。→ 两处转整数/整型字段的 except 补 `OverflowError`，按 400 返回。
  2. **SV-BK2**：publish 的 `okey` 依赖 `origin_rel`；客户端未上报该字段时走 else 分支，`authority=content` 会把副本里他端的编辑静默覆盖且不返回 conflict。→ `copy_foreign and okey is None` 时保留副本为权威（`authority = copy_snapshot`）并标记 conflict。
- 否决：给冲突态副本开放读/hello——写入必被 409，开放读只会让客户端基于即将被拒的基线继续算 op，维持既有语义。
- 涉及文件：server/lockserver/main.py（仅本地）
- 验证：`python -m py_compile` 通过，Infinity 请求实测返回 400

## A-224：第三十三轮审查——副本快照条件、基线未知与墓碑优先级（2026-11-04，SV-BL1~BL5）

- 用户诉求：连续 5 轮零问题才算收敛，第三十三轮发现即修复并自该轮后重新计数。
- 根因与方案：
  1. **SV-BL1**：副本快照读取被写成 `elif okey is not None and copy_mtime > 0`，`okey` 依赖客户端上报 `origin_rel`；未上报时根本不读副本，`copy_foreign` 恒 False，他端编辑被覆盖。→ 去掉 `okey` 前置条件，只按 `copy_mtime > 0` 读盘。
  2. **SV-BL2**：`copy_base is None` 时无法判定副本是否被他端改过，旧实现仍以 `content` 覆盖副本。→ 基线未知时保留副本为权威并标记 conflict，源端重试。
  3. **SV-BL3**：`/save` 只在 `save_json is not None` 时落盘，先 op 后 save 的场景 `rev>0` 但磁盘未更新，却回报 `persisted=true`。→ 落盘条件扩为 `save_json is not None or (not stale and rev > 0)`。
  4. **SV-BL4**：最近设备/副本列举未捕获 `OSError`，并发删除会让整次请求 500。→ 两处跳过单个失效项。
  5. **SV-BL5**：`_DELETED_RECENT` 墓碑判定放在别名/同名兜底之后；删除副本后别名已摘除，同名兜底可能解析到别的目录的同名源文件。→ 墓碑判定前移到 `_lock` 内最先执行。
- 否决：读取侧重复实现 16MB 上限——`/recent/publish` 侧已有大小限制。
- 未改动铁律：锁序、`_lock` 内禁 IO、GC 异常不得杀线程、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（校验后清理 `__pycache__`）

## A-225：第三十四轮审查——副本刷新基线、GC 落盘推进与迁移锁超时（2026-11-04，SV-BM1~BM6，仅本地未部署）

- 用户诉求：连续 5 轮三端零问题才算收敛；第三十四轮发现问题即修复，并从该轮之后重新计数。
- 根因与方案：
  1. **SV-BM1（SRV34-1）**：`_handle_save` 对 `_recent_copies_of(path)` 的副本会话只要内容不同就覆盖、`rev+1` 并广播全量 struct；副本会话若有他端未合并编辑会被静默覆盖。→ 用 `_PUBLISHED_LOCAL` 摘要基线判定：`rev>0` 且副本内容偏离基线（`copy_foreign`）时保留副本、不广播、不刷新副本磁盘；基线未知/内容一致时维持原镜像行为。初版按 `content_mtime` 跨时钟比较会误判正常刷新，已改回摘要口径（与 SRV34-6 同一结论）。
  2. **SV-BM2（SRV34-2）**：GC 落盘成功不推进 `entry.mtime`，有 SSE 订阅但空闲的文件每 10s 重复整篇读盘比较。→ 成功且 rev 未变时推进 `entry.mtime`，不动 `content_mtime`。
  3. **SV-BM3（SRV34-3）**：`_migrate_subs` 对 `_recent_io_lock` 无超时获取，与 publish/delete/save 的跨 IO 持锁叠加会造成 recent 请求串行堆积。→ 带超时获取，失败返回 False 留在副本会话。
  4. **SV-BM4（SRV34-4）**：`/recent/file` 先判墓碑再取 entry/读盘，并发 delete 后可返回 200+空串。→ 两阶段复核墓碑，命中 410。
  5. **SV-BM5（SRV34-5）**：publish 落盘后的校正仅覆盖 `centry is None`，快照 entry 被 GC 回收后重建会漏校正。→ 落盘后无条件重读 entry，持 oplock 复核身份后按源侧口径校正。
  6. **SV-BM6（SRV34-7）**：`LAST_SEEN` 无条目上限。→ 与 `_remember_platform` 同款上限淘汰。
- 判定不修（SRV34-6）：新旧判定依赖服务端 `time.time` 与磁盘 mtime 跨时钟比较；彻底修复需客户端上报接收时间戳链，本轮不做设计级改动，记录为已知限制。
- 未改动铁律：锁序 `_recent_io_lock → entry.oplock → _lock`、`_lock` 内禁 IO、GC 异常不得杀线程、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（已清理 `__pycache__`）

## A-226：第三十五轮审查——副本刷新摘要基线扩展、GC 永久错误分类与 SSE 注册顺序（2026-11-04，SV-BN1~BN3，仅本地未部署）

- 用户诉求：连续 5 轮三端零问题才算收敛；第三十五轮发现问题即修复，并从该轮之后重新计数。
- 根因与方案：
  1. **SV-BN1（SRV35-1）**：`_handle_save` 刷新副本时，无内存会话分支直接 `_flush_to_disk` 覆盖；有会话分支只在 `rev>0` 时才看基线。两次源端上报之间若副本被他端改过（copy_foreign），内容被静默覆盖。→ 无会话分支在 `_recent_io_lock` 内 `_load_from_disk(rp)`，与 `_PUBLISHED_LOCAL` 摘要比对，偏离或读盘失败即跳过（不覆盖、不更新基线）；有会话分支去掉 `rev>0`——rev==0 时内存内容只是打开时从磁盘加载的旧值，同样可能已被他端编辑。
  2. **SV-BN2（SRV35-2）**：GC 只识别“路径不可落盘/磁盘文件超限”，而 ENOTDIR/EISDIR/EACCES/EPERM/EROFS/ENAMETOOLONG/EINVAL/UnicodeError 属不可恢复错误，无订阅 entry 会永久驻留并每 10s 重试刷日志。→ `_flush_to_disk` 增加 `err_out` 回传异常；`_flush_error_permanent` 只按白名单判定（ENOSPC/EIO/EAGAIN/EMFILE 等临时错误不在表内，继续保留重试），永久错误且无订阅才回收。
  3. **SV-BN3（SRV35-3）**：SSE 注册先把同设备旧连接从 `subs` 摘除再写 hello；hello 抛异常时旧连接已不在集合，形成“被踢出却没收到 closed”的幽灵在线。→ 先加入新连接并成功写完 hello，再摘除旧连接；失败保留旧连接，新连接由 `except` 清理。
- 挂起项：SRV34-6（跨时钟新旧判定）按用户指示保持挂起，本轮不动、不计修复数。
- 未改动铁律：锁序 `_recent_io_lock → entry.oplock → _lock`、`_lock` 内禁 IO、GC 异常不得杀线程、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（已清理 `__pycache__`）

## A-227：第三十六轮审查——落盘临时名、重启基线、副本回写校正与路径边界（2026-11-04，SV-BO1~BO11，仅本地未部署）

- 用户诉求：连续 5 轮三端零问题才算收敛；第三十六轮发现问题即修复，并从该轮之后重新计数。
- 根因与方案：
  1. **SV-BO1（SRV36-2）**：落盘临时名 `<原名>.tmp.<tid>` 在单段 255 字节时 ENAMETOOLONG，被判永久错误后 GC 丢内容。→ 改用 `tempfile.mkstemp(prefix=".mktmp-")` 的目录内短名，`chmod 0644` 后 `os.replace`。
  2. **SV-BO2（SRV36-3）**：`_PUBLISHED_LOCAL` 仅内存，重启后为 None 时 save 直接用源内容覆盖副本。→ 两个副本刷新分支在基线 None 时一律跳过（与 publish SV-BL2 同口径）。
  3. **SV-BO3（SRV36-4）**：无内存会话分支落盘后不复核 `FILES`，并发 GET/open 建的 rev==0 旧 entry 会与磁盘分叉。→ 落盘后重查并对 rev==0 的新 entry 持 oplock 校正内存内容。
  4. **SV-BO4（SRV36-5）**：目录被归一为“不存在”空串而建空 entry。→ `_load_from_disk` 对目录返回 None。
  5. **SV-BO5（SRV36-7~SRV36-13）**：`_send` 断连异常、删除错误信息泄露、`_as_text` 容器 repr、`.platform` 非原子、dev 点前缀不对称、删除窗口返回已删内容、symlink 越界读取 → 逐项最小修复（见 CHANGELOG）。
- 判定不修（SRV36-1）：SSE hello 在 `_lock` 内写属 SV-H6 有意设计（hello 与订阅登记同临界区保证 op 不先行），写超时已由 `SSE_WRITE_TIMEOUT=15s` 封顶；改为锁外写破坏先行序，属设计级改动。
- 判定不修（SRV36-6）：`FILES` 条目/字节与 SSE 并发上限需专门容量设计，私有部署（持 Key 受信）无实际触发场景，记录为已知限制。
- 挂起项：SRV34-6（跨时钟新旧判定）按用户指示保持挂起，本轮不动、不计修复数。
- 未改动铁律：锁序 `_recent_io_lock → entry.oplock → _lock`、`_lock` 内禁 IO、GC 异常不得杀线程、心跳/在线窗口、API Key 单级模型不变。
- 涉及文件：server/lockserver/main.py（仅本地，部署需用户确认）
- 验证：`python -m py_compile lockserver\main.py` 通过（已清理 `__pycache__`）

## 2026-11-04 第三十八轮：路径字段字面值（SV-BQ1）
- 背景：SRV37-4 把 `_safe_path` 的 `strip()` 去掉以保留合法首尾空白，但入口校验 `_req_text` 仍 strip，协作 key 与真实文件名不一致（`a.md ` 落到 `a.md`），POST 与会话/GET 两侧也对不上。
- 决策：新增 `_req_raw()`（只处理代理项，全空白按缺失），路径类字段（`path`/`origin_rel`/`file_name`/`name`）一律字面值；设备名保持 strip，并在 `/recent/list`、`/recent/file` 的读取侧同步 strip，与 publish/heartbeat/delete 一致。
- 不改动：锁序、`_lock` 内禁 IO、墓碑语义、容量上限、16 项挂起/不修项。
- 验证：`python -m py_compile lockserver\main.py` 通过。

## 2026-11-04 第四十轮：struct 重试裁剪局部化（SV-BR1）
- 背景：`_handle_struct` 的失效重试循环把裁剪结果写回 `start`/`delete`，第二次尝试在新 entry（行数可能不同）上沿用旧裁剪值，会把结构变更应用到错误行并广播错误行号。
- 决策：裁剪只写入本次尝试的 `apply_start`/`apply_delete`，广播帧同样使用裁剪后的局部值；原始请求值在整次请求内保持不变，每次重试都按当前 entry 内容重新裁剪。
- 不改动：重试上限 5 次、409/410/415 语义、锁序与广播时机、16 项挂起/不修项。
- 验证：`python -m py_compile lockserver\main.py` 通过（已清理 `__pycache__`）。

## 2026-11-05 第四十八轮：close 的 discard 语义（SV-BS1）
- 背景：`_handle_close` 对 rev>0 的 entry 一律先 `_flush_to_disk` 再销毁。PC 文件树删除/重命名源文件后才广播，MainWindow 随后的 closePath 会按内存内容把刚删的文件（或改名前的旧名）重新创建，形成"删除后复活/重命名留幽灵"。
- 决策：`/close` 支持 `discard: true`。客户端在"磁盘上的旧路径已被自己处理"时传入；服务端持 entry.oplock 并在 `_lock` 内复核 entry 身份与 `subs` 为空后直接 `del FILES[key]`，不落盘。默认 false 保持原有落盘语义；存在其它订阅者时 discard 同样跳过，避免抽走别人正在编辑的会话（其保存仍会按正常路径写盘）。
- 不改动：落盘原子替换、rev 判据、SV-H7 竞态处理、16 项挂起/不修项。
- 涉及文件：lockserver/main.py
- 验证：`python -m py_compile lockserver\main.py` 通过。

## 2026-11-05 第四十九轮：落盘不重建已删除目标（SV-BS2）
- 背景：SV-BS1 的 discard 只能覆盖客户端"自己知道"的删除/改名。安卓在后台保留会话（120s 保活）期间文件被外部/SAF 删除，或 recent 副本被 delete 后仍有会话，GC/close 调 `_flush_to_disk` 仍会 mkstemp + os.replace 把路径重建出来，复活问题在安卓与 recent 上重演。
- 决策：在 `_flush_to_disk` 解析出 `full` 并通过同步根校验后，若目标已不存在则记 `[flush] SKIP` 并返回 True（视为无需写入），不再创建。若客户端确实重新保存，会先在本机重建文件，下一次落盘路径存在即正常写入；不会影响 publish 的 `_write_text_atomic`（其创建副本走独立函数）。
- 取舍：外部删除后的内存态内容不再落盘（这是删除语义的本意）；网络/同步盘瞬时不可见可能跳过本次落盘，但客户端本地仍有副本，且 GC 后续可重试。
- 不改动：SV-BS1 的 discard 语义（客户端显式意图仍保留）、16MB 上限、SV-AE2 大文件拒写、16 项挂起/不修项。
- 涉及文件：lockserver/main.py
- 验证：`python -m py_compile lockserver\main.py` 通过。

## 2026-11-05 第五十轮：锁服务零写同步根（A-206，阶段①）
- 背景：T3/T4/T6 显示锁服务 `flush` 与客户端 Syncthing 同时写同一路径会触发 `.sync-conflict-*`、原文件名三端消失。产品要求实时协同编辑（op/SSE）保留，但内容落盘职责必须唯一。
- 决策：**锁服务不承担落盘职责**。`_flush_to_disk` 改名 `_flush_recent`，只允许写 `RECENT_ROOT`（`recent-sync`，不在同步根）；所有 DISK_ROOT 写入分支（GC、迁移、publish 覆盖/采纳/回写、save、close）全部删除或条件化；非 recent 路径抛 `RuntimeError`，启动自检探测并被拒绝后 fail-fast，`/health` 暴露 `write_scope` 计数。
- 决策：**取消 writer token**（**已被第五十二轮修订**：writer token 以“服务端发令牌 + 客户端单写者落盘”的形式重启，见下）。在线各端各自保存本地文件，内容由 op 通道同步；服务端只维护内存权威值并广播。
- 决策：recent 快照**不设 TTL/容量上限**，只在三种情况删除：显式删除、设备删除、所有参与设备上报的本地内容 hash 均等于快照 hash（`/recent/ack`）。关闭弹窗/断开连接不构成删除条件。
- 决策：**“同一份文件”与“设备已处理”分离**。前者用 Syncthing 路径 + 版本标识（`rev` + `/open` 返回的 `content_hash`），后者只用 ack 上报的 SHA-256。
- 后果：服务端不再参与用户文件写入，消除双写竞争的一半诱因；跨端一致性依赖 Syncthing。快照可能长期保留（旧客户端不上报 hash），需后续监控体积；`SNAP_META` 仅内存，重启后“处理完”状态丢失但不误删。
- 替代方案：writer token 单写者（否决：用户定稿取消；**第五十二轮已重启该方案**）；完全不保留 recent 快照（否决：最近页与跨端副本依赖）。
- 涉及文件：lockserver/main.py
- 验证：py_compile 通过；本地 open/op/save/close 全程同步根零写入、仅 recent 落盘；ack 未收敛不删/收敛即删；自检 fail-fast 生效。报告 docs/code-review-2026-11-05-server-write-scope.md。未部署。

### A-207：最近副本的发布端是天然参与者，且发布端未 ack 前不得 settled（Accepted，2026-11-05）
- **背景**：阶段②回归发现 `_handle_recent_publish` 只在“已有内存 entry 且内容变化”的分支登记发布端。常态（publish 新建副本、entry 为 None）下发布端不在 `SNAP_META.participants`，另一端 open 后成为唯一参与者，其一 ack 就 `settled:true` 删除快照，发布端随后 ack 得 410。真实日志 02:39:46 / 02:42:29 两次 410（来自安卓）与该模型吻合。
- **决策**：
  1. publish 落盘成功后**无条件**登记发布端（`dev`）为参与者；
  2. ack 收敛判定以副本路径 `recent/<dev>/<name>` 的第一段为发布端（路径是持久事实，`SNAP_META` 是内存态、重启即丢失），把发布端并入 participants 并要求它已上报与快照一致的 hash。
- **后果**：只有“所有参与端（含发布端）都上报同 hash”才删快照；发布端未回执时保持 `settled:false`，另一端的提前删除与发布端 410 消失。仍零写同步根，未放宽任何阶段①不变量。
- **替代方案**：把发布端写进 `SNAP_META` 只在 publish 时登记（否决：服务重启后 meta 丢失，旧快照仍会被单端 ack 立刻删除）。

## 2026-11-05 第五十二轮：writer token 协议与服务端实现（batch83，仅本地未部署）
- 背景：阶段 4b 三个 P0（离线分叉恢复后被静默覆盖、点“取消”后 60~90s 仍被覆盖、原路径被改名成 `.sync-conflict-*`）的根因是 Syncthing 文件级同步与锁服务协作写入双通道并存。第五十轮“取消 writer token”只解决了服务端一侧，客户端仍两端同时落盘。
- 决策：**重启 writer token**，协议定稿在 `docs/design-2026-11-05-writer-token.md`，PC/安卓按该文各自实现，不依赖隐含约定。
  1. 首个 `open` / SSE join 隐式申请 writer；新增 `/api/v1/writer/claim`（可 `force=true`）与 `/api/v1/writer/release`；`op/struct/save` 不隐式申请。
  2. 移交按**最后活跃**（排除当前 writer，只考虑在线参与者）；掉线判定 `WRITER_OFFLINE_SEC=15s` + watchdog `2s`，close 时立即移交；无候选则置 null，下次 open/claim 重新分配。
  3. `writer_device_id` / `writer_device_name` / `writer_since` / `writer_rev` / `writer_changed` 出现在 open 响应、SSE hello、op/struct/save/close 响应；SSE 新增 `writer_changed` 事件（reason: claim/offline/timeout/leave/release/force/migrate），op/struct/peer 事件附带 writer 快照。
  4. 服务端**不因非 writer 拒绝** op/struct/save（旧客户端兼容）；writer token 只是“谁落盘”的协作约定与提示，仍零写 DISK_ROOT。
  5. SSE 保活循环改为 1s 粒度 `select + MSG_PEEK` 探测 EOF：静默断开的 writer 在 ~1s 内被识别，避免原 30s keepalive 周期导致移交最长 45s。
  6. `/health.writers` 暴露 `active/changes/transfers/timeouts/offline_sec/watch_sec`；日志 `[writer] path=... dev=... reason=... rev=...`。
- 后果：客户端升级后同一文件同一时刻只有一个设备落盘，从源头消除双端同时保存；旧客户端行为不变（两端仍写，仅多出字段）。
- 取舍：非 writer 端内容只在内存/服务器权威值中，writer 异常退出时依赖移交或 baseline 兜底；`writer_rev` 服务重启后归零，客户端不得跨重启比较。
- 验证：`python -m py_compile` 通过；本地 18/18 用例通过（W1 申请、W2 不抢、W3 busy、W4 force+双端事件、W5 掉线移交、W6 close 移交、W7 release、W8 旧客户端、W9 多端并发、W10 同步根零写）。快照 `backups\batch83-server-writer-token-20261105.zip`。
- 涉及文件：`server/lockserver/main.py`、`docs/design-2026-11-05-writer-token.md`、`server/docs/CHANGELOG.md`、`server/docs/decisions.md`、`backups/备份说明.md`。
- 未改 PC/安卓代码。已部署：2026-11-05 18:30 CST 飞牛上线（回滚点 `markor-lockserver.bak.20261105-183043` / `main.py.bak.20261105-183043`，步骤见 `docs/deploy-2026-11-05-lockserver.md` 第 12 节）。
