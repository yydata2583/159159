# Markor 同步服务器（NAS 端）部署说明

两个服务：Syncthing 存储节点（持久保存文件副本，另一端离线也可靠）、文件锁 API（打开提示/冲突检测）。

> **拓扑：星型**——PC 与手机**只与服务器连接同步，设备之间不直连**。客户端（EXE/APK）关闭中继与引擎自动升级。**发现开关属于服务器端**：服务器 GUI 的「本地发现 / 全局发现」决定服务器是否广播与查询——本地发现覆盖本机所有网卡所在网段（不写死 192.x），全局发现覆盖所有网段（discover.syncthing.net，跨网段时服务器需出网 8443）；客户端套用这些开关，任一侧关闭都发现不了。客户端设置页不再提供发现开关：客户端本地发现常开（客户端之间的编辑/文件/最近同步），全局发现保持查询；客户端监听 23000，服务器可反向连入。客户端打开后持续查询/重连，服务器稍后才打开发现开关也能被找到。本仓库不再部署中继（relaysrv）。

## 〇、三端同步目录规则（结构完全统一）

| 端 | 同步根目录 |
|---|---|
| PC（EXE） | `文档\Markor`（`%USERPROFILE%\Documents\Markor`） |
| 飞牛 NAS | `/vol1/1000/Markor` |
| 手机（APK） | `/storage/emulated/0/Markor` |

同步范围：**根目录下所有子文件夹和文件**（递归双向同步）。
根目录内部结构三端完全一致：

```
Markor\
├── QuickNote.md      ← 快记（应用默认）
├── To-Do.md          ← 待办（Markdown 勾选式，应用默认）
├── Journal\          ← 日记
├── Snippets\         ← 代码片段/模板（应用片段目录）
└── file\             ← 其他所有文件一律放这里
```

同步链路：**PC ↔ 飞牛 ↔ 手机**（星型经 NAS 中转；任一端离线时 NAS 持有完整副本，上线即续传）。

## 一、部署方式 A：飞牛 fnOS / systemd 原生（推荐）

以 `markor-syncthing.service` / `markor-lockserver.service` 为例（参考根目录 `代码.txt`，已修正笔误）：

1. 上传文件：
   - `markor-syncthing.service`、`markor-lockserver.service` → `/etc/systemd/system/`
   - `lockserver/` 目录 → `/opt/markor/lockserver/`（属主 1000:1000）
   - `enable-versioning.py` → `/opt/markor/`
2. **不要**再在 service 里配置 `MARKOR_API_KEY`：锁服务首次启动会在程序目录生成 12 位密钥并持久化到 `server-api-key`（0600），重启/升级沿用；旧静态值只写入 `server-api-key.prev` 留档、**不参与鉴权**，客户端从 `GET /api/v1/serverkey` 自动获取
3. 启用并启动：
   ```sh
   systemctl daemon-reload
   systemctl enable --now markor-syncthing
   systemctl enable --now markor-lockserver
   ```
4. 验证锁服务：`curl http://NAS_IP:8910/health` 返回 `{"ok": true}`

Syncthing 程序：`/usr/bin/syncthing`（fnOS 自带或 `apt install syncthing`，**版本固定 v2.1.6，与 PC 端、手机端一致**）。配置/索引存放在 `/vol1/1000/.config/syncthing`（由 `HOME=/vol1/1000` 决定）。

## 二、部署方式 B：Docker / 群晖 Container Manager

1. 把本目录整个上传到 NAS（如 `/vol1/1000/docker/markor-server`）
2. 复制 `.env.example` 为 `.env`，修改：
   - `DATA_PATH`：**同步根目录**（文件持久保存在这里，飞牛：`/vol1/1000/Markor`）
   - `CONFIG_PATH`：Syncthing 配置目录（如 `/vol1/1000/markor-config`，勿与 DATA_PATH 相同）
   - `MARKOR_KEY_FILE`：服务器密钥的持久化路径（必须放在挂载卷里，如 `/config/server-api-key`）；不填则用容器内程序目录，重建容器会换新
3. 启动：`docker compose up -d`（群晖：Container Manager → 项目 → 新增 → 选本目录）
4. 验证：`curl http://NAS_IP:8910/health` 返回 `{"ok": true}`

## 三、Syncthing 初始化（已自动化，无需手工执行）

> `enable-versioning.py` 会在 Syncthing 服务启动后 **自动运行**（systemd `ExecStartPost` / Docker `syncthing-init` 一次性容器），安装后无需再手工执行。
>
> 脚本自动：从 `config.xml` 读取 API Key → 等待 REST 就绪 → 创建 `markor` 文件夹（**ID 必须与客户端引擎写死的 `markor` 一致**）→ 回收站版本控制（保留 10 天）→ 关中继/自升级、**开启本地+全局发现** → 数据监听端口 23000 → 同步客户端上报的设备名到 Syncthing 配置。

如需手动排查或重装，仍可单独运行（fnOS 实际部署：GUI 为 **HTTPS + 自签证书**，配置在 `/opt/syncthing/config/config.xml`，脚本在 `/opt/markor/`）：
```sh
SYNCTHING_URL=https://127.0.0.1:8384 \
SYNCTHING_FOLDER_PATH=/vol1/1000/Markor \
python3 /opt/markor/enable-versioning.py
```

浏览器打开 `https://NAS_IP:8384`（自签证书，需手动信任；建议仅内网/VPN 开放），首次进入设置 GUI 管理员账号/密码后，操作 → 显示 ID：复制 **NAS 节点设备 ID**（客户端要用）。

2026-11-16 实测：修复了脚本对 HTTPS 自签证书与 `/opt/syncthing/config/config.xml` 路径的适配；服务器此前 `localAnnounceEnabled/globalAnnounceEnabled` 均为 false、且配置中缺少 `markor` 文件夹，已通过该脚本补齐（`markor` 文件夹 + 3 台已配置设备 + trashcan 10 天 + 两个发现开关 true）。

~~取中继 ID~~：已废弃——星型拓扑直连服务器，不需要中继。

## 四、客户端配置（经 Tailscale 访问）

> 服务仅通过 **Tailscale** 访问（`100.64.0.2` 为 NAS 的 Tailscale 地址）。EXE / 手机 / Syncthing 客户端都必须先加入同一个 Tailscale 网络。

EXE / APK 设置里填同样内容（默认全部为空，请逐项填写）：

| 配置项（PC 设置→同步 / 手机 设置→同步） | 值 |
|---|---|
| 启用同步 | ✅（仅软件运行/前台期间生效） |
| 服务器地址 | `http://100.64.0.2:8910`（锁 API，服务器信息不写死，按实际部署填） |
| API Key | 留空：启动时自动从服务器获取（12 位，加密保存，显示为 ●） |
| 服务器设备 ID | 第三步复制的 Syncthing 设备 ID |
| 服务器同步地址 | `tcp://100.64.0.2:23000`（服务器的监听/同步地址） |

连接服务器**成功或失败都会弹窗提示**；服务器信息未填完整也会弹窗提醒。

手机端文件同步（新版 APK **内置同步**；退到后台约 15 秒内保持同步，之后随系统冻结停止；旧版/第三方可用 Syncthing 安卓版）：
1. 添加设备：服务器设备 ID；**设备地址填 `tcp://100.64.0.2:23000`**（新版 APK 已内置同步，无需另装 Syncthing 客户端）
2. 添加文件夹：路径 `/storage/emulated/0/Markor`，文件夹 ID `markor`，共享给 NAS 设备
3. 只填「锁服务地址 + API Key」时，客户端自动把同步地址回填为 `tcp://<锁服务主机>:23000`

所有客户端只与服务器组成星型拓扑：PC/手机端文件同步、编辑同步（锁服务 SSE）、最近同步（服务器副本）都只经服务器，**客户端之间不互连、不互建文件夹、不互传文件**。引擎设备表只登记本机与配置的服务器设备 ID，其它设备连接一律 `unknown device`；文件夹需在服务器 GUI 添加并共享给各客户端。客户端只有一个「启用自动发现」总开关，仅控制 23001 局域网广播（设备现身/配对/地址回填），只有广播方设备 ID == 已配置服务器设备 ID 时才参与回填。地址为空但引擎已连接时，客户端会按实际连接地址自动回填；用户明确清空后不再回填。

> 升级提示：新版 APK 的笔记本目录为 `/storage/emulated/0/Markor`。首次启动会自动：把旧 `Documents/markor` 的内容迁移到新目录；`.app/snippets` 迁到 `Snippets/`；`todo.txt` 改名为 `To-Do.md`（若无同名文件）；并创建 `Journal/`、`Snippets/`、`file/` 三个目录——保证三端结构一致。

## 五、锁 API 协议（三端共用）

所有请求带 `Authorization: Bearer <API_KEY>`，body 为 JSON。

- `GET /health` → `{"ok":true}`（无鉴权，探活）
- `POST /api/v1/open` `{device_id, device_name, vault_id, path}` → `{ok, holders:[{device_id,device_name}]}` —— 打开文件登记；`holders` 为**其他设备**占用者（用于"XXX端已经打开文件"提示）。同设备重复调用=刷新。
- `POST /api/v1/heartbeat` 同参数 → `{ok, holders}` —— 每 30 秒刷新，70 秒无心跳自动过期
- `POST /api/v1/close` `{device_id, vault_id, path}` → `{ok}` —— 关闭/保存后注销
- `GET /api/v1/locks?vault_id=x` → `{locks:[...]}` —— 全表（轮询兜底）

`path` 一律为同步根内相对路径（`/` 分隔，例如 `file/报告.md`）。锁仅存内存，重启丢失无害——真正的写冲突由 Syncthing 的 `.sync-conflict-*` 文件兜底。

### 客户端构建号上报（2026-11-06，三端对齐第③项）

所有客户端请求（`POST` 的 open/op/close/save/recent/* 与 `GET` 的 `/api/v1/events` 等）带请求头：

```
X-Markor-Client: <platform>/<build>
```

- `platform`：`desktop` | `phone` | `tablet`
- `build`：十进制非负整数（构建号 / Android `versionCode`），用于数值比较
- 例：`X-Markor-Client: desktop/21701`、`X-Markor-Client: phone/169`（当前构建；
  最低可接受版本见 `min_builds`：desktop 21700 / phone 168）
- 服务端只在内存登记（**上限 1024 条、24h 无请求即淘汰**），**不写同步根、不写 `recent-sync`**
- 同一台设备只保留一行：先以设备名上报、之后拿到 `device_id` 时自动并入
  `id:` 行（保留较新的 `last_seen`、累加 `requests`）；不同设备即使同名也不合并
- 客户端在同步引擎 ID 就绪前可能把**设备名当 `device_id` 上报**（`device_id`
  与 `device_name` 完全相同，安卓 `LockClient._deviceId = _deviceName`）。这种
  伪 id 没有独立身份，服务端按“仅有名称”归档，并在拿到真实 id 后并入同一行，
  因此 `device_id_short` 可能暂时显示为设备名前 8 位，但同一台设备始终只有一行。
  两个**真实** id 行即使同名也永不互并。
- 上述“同名但不同真实 id”的行在 `/api/v1/clients` 里**不再强行合并**：按返回顺序
  第一项保持原名，后续依次显示 `名字(1)`、`名字(2)`……仅作用于展示字段
  `device_name`（空名时用短 id），内部键、`device_id` 与登记合并逻辑不变；
  大小写按现状区分。

只读查看最近上报（需鉴权，最多返回最近 50 条，不含密钥）：

```
GET /api/v1/clients
→ {"ok":true,"require_client_header":true,
   "min_builds":{"desktop":21700,"phone":168,"tablet":0},
   "min_client_version":0,"tracked":2,"rejected":0,
   "clients":[{"device_id_short":"ABCDEFGH","device_name":"PC-1",
               "platform":"desktop","build":21701,
               "last_seen_sec":3,"requests":12}]}
```

`/api/v1/clients` 与 `/health` 不受下面的客户端防护开关影响（但仍需鉴权）。

### 老客户端防护（默认关闭）

1. **必须带头**：环境变量 `REQUIRE_CLIENT_HEADER=1`（默认未设置/关闭）。开启后
   `/api/v1/*` 的每个请求都必须带合法的 `X-Markor-Client` 头；缺失或格式非法
   直接返回 400（`reason` 区分 `missing` / `invalid`）：

   ```
   HTTP 400 {"ok":false,"error":"client header required","reason":"missing",
             "header":"X-Markor-Client",
             "expected":"X-Markor-Client: <platform>/<build>",
             "platforms":["desktop","phone","tablet"]}
   ```

2. **平台阈值**：`MIN_BUILD_DESKTOP` / `MIN_BUILD_PHONE` / `MIN_BUILD_TABLET`，
   缺省 `0` = 该平台不拦。确实上报了 `build` 且低于本平台阈值时返回 403：

   ```
   HTTP 403 {"ok":false,"error":"client too old","platform":"desktop",
             "client_build":21699,"min_build":21700}
   ```

两种拒绝的 `error` 字段不同（`client header required` vs `client too old`），
客户端可据此分别提示“升级/换客户端”与“升级到指定构建号”。

**判定顺序**：先「必须带头」→ 再「平台阈值」。`/health`、`/api/v1/clients` 豁免。

兼容与默认值：

- `MIN_CLIENT_VERSION` 已弃用：某平台未单独设置 `MIN_BUILD_*` 时沿用它的值，
  老配置不会失效；启动日志会打印弃用提示。
- `REQUIRE_CLIENT_HEADER` 关闭时，未带/非法头仍按“未上报”放行；阈值只在
  确实上报 `build` 时生效（老客户端默认放行）。
- 门槛只决定请求是否被拒，不改变任何既有字段语义。

### 最近副本按 device_id 分段（2026-11-06）

物理布局由 `recent-sync/<设备名>/<文件名>` 改为：

```
recent-sync/<segment>/<文件名>
segment = 请求里的 device_id（合法时）否则 device_name（旧客户端回落）
```

**命名与由来**：段名直接取 `device_id`（Syncthing 设备 ID / 客户端持久化 ID）原文，
不哈希、不加前缀。理由：① 真实 ID 是 56 位 base32（`A-Z`/`2-7`）+ `-`，天然是
文件系统安全字符，无需转义；② 设备改名（用户可随时改“小明的手机”）不会搬目录；
③ 与设备一一对应，同名两台设备物理隔离。id 目录内写隐藏标记 `.name`（设备名），
供服务重启后按名字反查 id 目录；`.platform`、`.pub-*.json`、`.origin-*.json` 语义不变。

- `POST /api/v1/recent/publish` 按请求 `device_id` 落盘（缺失/非法才用 `device_name`）。
- `GET /api/v1/recent/devices` 每项新增 `device_id` 字段（与 `device_name` 并列）；
  旧客户端忽略未知字段即可，字段语义与顺序不变。
- **旧目录只读兼容**：升级前的 `recent-sync/<设备名>/` 原样保留，**不迁移、不删除**。
  读请求的 `device` 可传 id 段或名字段：先找 id 目录，缺失时回落同设备的旧名字目录；
  `recent/list`、`recent/file`、`recent/ack`、`recent/delete`、`recent/device/delete`、
  `GET /api/v1/file?path=recent/...`、`/recent/heartbeat` 均覆盖。
- `recent/ack` 的 `device_name` 是“副本所属段”（发布端），`device_id` 是上报端自身
  身份（用于收敛判定），不会拿上报端 id 去定位目录。
- 删除语义：带 `device_id` 只删该 id 目录；旧客户端只报名字时删名字目录及其名下
  唯一的 id 目录（同名多 id 无法区分，保持旧行为不猜）；`device/delete` 只把目标
  id 的参与/上报记录从其它快照中清除，不连带同名另一台设备。
- `/recent/heartbeat` 带 `device_id` 时 `.platform` 写 id 目录并补 `.name`；不带时
  维持旧行为写名字目录。

**上线顺序**：先服务端、后客户端更安全。服务端先上时旧客户端继续按名字读写，
行为不变（发布可能经 `device_id→device_name` 别名映射落到自己的 id 目录，读/删均有
名字段回落）；客户端随后在 `publish/list/file/delete` 里带上 `device_id` 后，同名
不同 id 的两台设备才严格互不可见。旧客户端（不带 `device_id` 上报）始终落在名字段/
或经别名落到自己的 id 段，不会与其它设备串目录；但**同名两台设备在旧客户端上仍
共享名字视图**（按名字查询会合并同名的多个 id 目录），这是升级前无法消除的歧义。

### 设备重命名 / 删除（2026-11-07）

**重命名**（只改展示名，不移动目录/文件）：

```
POST /api/v1/recent/device/rename
{"device_id":"<目标>","device_name":"<目标名>","new_name":"<新名>",
 "requester_device_id":"...","requester_device_name":"..."}
→ 200 {"ok":true,"device_id":"...","device_name":"<新名>","renamed_files":0}
```

- 目标定位：`device_id` 优先；为空时按 `device_name`，**只有唯一匹配才执行**，
  同名多台返回 409；目标不存在 404。
- `new_name`：strip 后 1–64 字符，禁控制字符、禁 `/`、禁为空（否则 400）。
- 落盘：目标段目录写 `.name-override`（人工改名覆盖），`.name` 继续保存设备
  自报名不变。展示优先级 **人工 override > 设备自报 > device_id**。
- 被改名的设备后续 heartbeat/publish 自报原名（或其它名）**不会覆盖 override**，
  只有再次调用 rename 才能改；重启后 override 仍有效。
- 无 id 的旧名字目录同样支持：只写 override，不移动目录、不写 `.name`。
- 副本仍按原段读取：`recent/list`、`recent/file`、`recent/ack`、`recent/delete`、
  `GET /api/v1/file?path=` 同时接受 id 段、自报名、override 新名与旧名字段。

**删除**（扩展已有 `POST /api/v1/recent/device/delete`）：

```
POST /api/v1/recent/device/delete
{"device_id":"<目标>","device_name":"<目标名>",
 "requester_device_id":"...","requester_device_name":"..."}
→ 200 {"ok":true,"deleted_files":N}
```

- 删除范围：目标设备段下全部副本、`.name`/`.platform`/`.name-override` 标记、
  设备名别名（`DEV_NAME_ALIAS`）、客户端登记行（`CLIENT_REPORTS` 中该 id 与
  该名字的行）；旧的 `deleted` 字段保留，数值与 `deleted_files` 相同。
- 只删目标设备，其它段一律不动；无 id 的旧名字段同样支持且必须唯一匹配
  （同名多台 409，目标不存在 404）。
- 只参与过其它设备快照、从未 publish（没有段目录）的设备也允许注销：按 id
  或唯一名字清理其参与端/登记记录，`deleted_files` 可为 `0`；完全没有服务端
  记录才返回 404。这类设备不能 rename（没有目录可写 override）。
- 不删除磁盘上的真实笔记（同步根只读红线不变），不踢在线连接，只清服务端记录。
- 与单文件 `POST /api/v1/recent/delete`（只删一个副本文件）语义区分，不混用。
- 两个端点都受既有客户端头门禁约束；成功/失败都会在 journal 落审计行
  （谁改的、目标、结果计数），不打印密钥等敏感信息。

## 六、安全说明

- 锁 API 默认 **HTTP 明文 + Bearer key**，且 `GET /api/v1/serverkey` 对私网来源免认证下发密钥：**只在内网/可信网段使用**。8910 不得直接暴露到公网；如确需外网访问，必须前置 Nginx/Caddy 反向代理并强制 HTTPS，同时在防火墙上只放行 VPN/Tailscale 网段。当前版本不提供配对码或请求签名。
- Syncthing 数据传输本身全程 TLS 加密。
- 同步引擎**自动升级已关闭**（产品不需要“更新同步版本”）：客户端 `autoUpgradeIntervalH=0`，服务器由 `enable-versioning.py` 一并关闭。
- 23000/TCP+UDP（数据，服务器监听；避让客户端本机原 Syncthing 的 22000）、21027/UDP（**本地发现**，仅本机所在网段的广播/组播）、8443/TCP（**全局发现**，discover.syncthing.net，可跨网段）、8385/TCP（服务器 GUI，建议仅内网/VPN）、8910/TCP（锁 API）。中继 22067 不使用。
- 回收站版本控制：NAS 端已默认开启（保留 10 天），被误删/覆盖的文件在 `/vol1/1000/Markor/.stversions` 里可找回。

### 连不上服务器排查（23000 是数据端口，不是发现端口）

不部署中继。客户端引擎写死 `localAnnounceEnabled=false`、`globalAnnounceEnabled=true`，服务器地址集合为
`[显式地址, "dynamic"]`：常规路径是按手填的「服务器同步地址」`tcp://100.64.0.2:23000` 直连，
地址为空时靠全局发现兜底。23000 是 Syncthing 的**数据交换端口**（TCP+QUIC）。
客户端「启用自动发现」只控制局域网 23001 广播，不影响已填地址的连接；地址为空但引擎已连接时，
客户端会按实际连接地址自动回填。

1. **NAS 是否真的监听 23000**：`ss -tlnp | grep -E '22000|23000|8385'`。若只看到 22000，
   说明 NAS 还在用默认端口 → 重跑 `enable-versioning.py`（已内置把 `listenAddresses` 改为
   `tcp://0.0.0.0:23000` + `quic://0.0.0.0:23000`），或在该 GUI 8385 的「设置 → 连接」里手改后重启服务。
2. **客户端「服务器同步地址」建议显式填写**：`tcp://100.64.0.2:23000`。地址为空时引擎仅靠
   `dynamic`（全局发现）兜底，跨网/VPN 环境可能定位不到；可依赖锁服务主机自动回填。
3. **防火墙**：NAS 仅对 Tailscale 网段放行 23000 TCP+UDP（8385/8910 同理）。
4. **Tailscale 通路**：PC `Test-NetConnection 100.64.0.2 -Port 23000` 应 TCP 可达。

### 已连接但进度 0%（握手成功、不传文件）

表现为：8385 GUI 里设备显示已连接，客户端设置页圆点为绿，但同步进度 0%；
NAS 上反复弹「XXX 想要共享文件夹 Markor（markor）添加新文件夹？」。三个成因按顺序排查：

1. **文件夹 ID 不一致（最常见）**：客户端引擎写死 `markor`，旧脚本建的是 `markor-vault`。
   PC 端日志 `%LOCALAPPDATA%\Markor\sync\data\sync-engine.log` 会持续打印
   `Unexpected folder ID in ClusterConfig ... folder.id=markor-vault`。
   → 在 NAS 重跑 `enable-versioning.py`（会把旧 ID 删除、按 `markor` 重建，磁盘文件原地保留）。
2. **文件夹没共享给客户端设备**：文件夹的「共享给」里没有 PC/手机的设备 ID。
   → 新版脚本已自动把文件夹共享给所有已登记且未暂停的设备。
3. **设备被暂停**：日志里出现 `closed by remote: device is paused`。暂停状态下握手成功但不发索引。
   → 新版脚本会把除自己外所有暂停设备恢复为启用。

> 脚本需要 Markor 同步实例的 Syncthing API Key：
> `KEY=$(grep -oP '(?<=<apikey>)[^<]+' /opt/syncthing/markor/config/config.xml)`，
> 再 `SYNCTHING_APIKEY=$KEY python3 /opt/syncthing/markor/scripts/enable-versioning.py`。
