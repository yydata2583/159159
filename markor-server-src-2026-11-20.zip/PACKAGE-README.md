# Markor 服务端源码包（2026-11-20）

本包仅含**源码与配置**，不含任何构建产物，用于交付有 NAS 权限的部署会话。
生成时间：2026-11-20（Asia/Shanghai）
生成位置：`C:\Users\Administrator\Desktop\Markor\markor-server-src-2026-11-20.zip`

## 包含内容

| 路径 | 说明 |
|---|---|
| `lockserver/main.py` | 锁服务主程序（实时协作、打开提示、冲突检测） |
| `lockserver/Dockerfile` | 容器构建文件（现网走 systemd，仅随包保留） |
| `enable-versioning.py` | Syncthing 初始化、设备名回填、被动地址守护（支持 `--daemon` 与 `--passive`） |
| `markor-lockserver.service` | 锁服务 systemd 单元 |
| `markor-syncthing.service` | Markor 专用 Syncthing 实例 systemd 单元（GUI 8385、同步 23000） |
| `markor-passive-guard.service` | 被动地址守护（`enable-versioning.py --passive`，oneshot） |
| `markor-passive-guard.timer` | 每 2 分钟执行一次被动地址守护 |
| `install.sh` | 幂等安装/修复脚本（安装单元、启用自启、启动服务） |
| `uninstall.sh` | 卸载脚本（停用并删除单元与程序目录，保留笔记目录） |
| `docker-compose.yml` | 可选容器编排 |
| `.env.example` | 环境变量示例（不含真实密钥） |
| `README-server.md` | 服务端说明 |
| `AGENTS.md` | 服务端约束与部署口径 |
| `docs/` | 服务端架构、数据模型、决策、约定、目录、变更记录 |

## 明确排除

- 构建产物/二进制：`markor-lockserver`、`syncthing`、`*.pyc`、`__pycache__/`
- 历史补丁副本：`lockserver/main.py.pre-batch77`
- 运行数据：`recent-sync/`、`index-v2/`、同步根数据、`.stversions`
- 密钥与身份：`server-api-key`、`server-api-key.prev`、`.env`、Syncthing 证书/私钥
- 备份：`backups/`、`recent-sync.tar.gz`

## 服务器被动连接口径

- 服务器只接受客户端拨入，自身不对客户端发起连接。
- 设备地址不写 `dynamic`，统一为回环黑洞 `tcp://127.0.0.1:1`：拨号必然失败，监听与入站握手不受影响；用户手填的真实地址保留。
- `enable-versioning.py` 的 `enforce_passive_devices()` 同时处理：远端设备、本机设备条目、`defaults/device` 新建设备模板。
- GUI/API 新增设备后，`markor-passive-guard.timer` 在 2 分钟内把仅含 `dynamic` 或空地址的设备改为黑洞地址，并 `pause`/`resume` 一次以断开按 `dynamic` 建立的旧出站连接。
- 安装后核查：`grep -c dynamic <config.xml>` 为 0；`/rest/system/connections` 中客户端连接类型为 `tcp-server`（入站）。

## 部署提醒（给部署会话）

- systemd 实际运行的是 PyInstaller 产物，**必须用本包 `lockserver/main.py` 重建二进制**，只替换 `.py` 不生效：
  `python3 -m PyInstaller --onefile --clean --noconfirm --name markor-lockserver lockserver/main.py`
- Syncthing 二进制由 `third_party/syncthing-engine` 源码编译，推荐：
  `CGO_ENABLED=0 go run build.go -version v2.1.6 -no-upgrade build`（产出静态二进制，标签含 `modernc-sqlite, noupgrade`）
- 本包单元按扁平结构存放；部署时对应关系为：
  `markor-*.service|timer` → `/opt/markor/systemd/`，`enable-versioning.py` → `/opt/markor/scripts/`，其余脚本 → `/opt/markor/`。
- 配置目录固定为 `/opt/markor/config`（Markor 独立目录，不与系统 Syncthing 的 `/opt/syncthing/config` 共用）。
- 防火墙口径：23000（TCP/UDP）、8385、8910 仅放行 `192.168.3.0/24`、`127.0.0.0/8` 与 `tailscale0`，其余 DROP，并通过 `netfilter-persistent`（`/etc/iptables/rules.v4`、`rules.v6`）持久化。
- 全新配置首次启动后，需重新登记客户端设备 ID，并在客户端添加新的服务器设备 ID，双方配对后才建立同步。

## 校验值

```
892A580D587CFF705F2217F3B4A9C335AB677F26CAE645DF792154F0EFD69DCF  lockserver/main.py
62DE3A45C244E82D67E42627EB188AEC3D363209A5ABD680C284BAA9F6306317  enable-versioning.py
```

## 校验

- `python -m py_compile lockserver/main.py enable-versioning.py`：均通过。
- 锁服务二进制实测（临时端口 18910、临时密钥文件）：`/health` 返回 `ok=true`，密钥加载、磁盘根写保护自检正常。
