# 需求与变更记录（CHANGELOG.md）— Markor 同步服务器

> **本文档由 AI 维护。** 工作方式：**用户提需求 → AI 改代码/脚本 → AI 同步更新本记录**。
> 维护规则见 [README.md](README.md)；技术决策见 [decisions.md](decisions.md)。

## 需求追溯表

| 日期 | 需求（用户原始诉求摘要） | 实现 | 涉及文件 |
|---|---|---|---|
| 10-15 | ②不需要"更新同步版本" | 初始化脚本关闭引擎自升级 `autoUpgradeIntervalH=0` | `enable-versioning.py` |
| 10-15 | ③服务器信息不写死 | 硬编码 API Key 清理为占位符（部署时替换）；文档强调自生成 | `markor-lockserver.service` `README-server.md` |
| 10-15 | ④PC 管理地址改 8385 | 服务端 GUI 统一 8385（README/初始化脚本与 systemd 对齐，修 8384/8385 不一致） | `README-server.md` `enable-versioning.py` `docker-compose.yml` |
| 10-15 | ⑤只连服务器、不互连；删中继 | 移除 relaysrv（docker-compose）；`enable-versioning.py` 关 `relaysEnabled`；README 删中继步骤 | `docker-compose.yml` `README-server.md` `enable-versioning.py` |
| 10-15 | ⑥审查三端代码（后取消） | 过程中修复锁服务真 BUG（见下） | `lockserver/main.py` |
| 10-15 | （用户追问）"多持有者模型和原生同步冲突吗？" | 不冲突；锁=提示层，多持有者是修 BUG 后的正确语义 | 见 A-203、PC CHANGELOG 答疑 |
| 10-15 | （用户追问）"API Key 怎么申请？" | 无申请流程，自生成共享口令；文档补说明 | `README-server.md` |

## 变更日志

- **2026-10-15**：
  - `lockserver/main.py` **修复单值覆盖 BUG** → 按设备多持有者（holders 提示生效、各设备独立心跳/注销/过期）；
  - 去中继（relaysrv 移除）、GUI 统一 8385、关中继/引擎自升级；
  - `markor-lockserver.service` 真实 API Key → 占位符（安全）；
  - README 重写客户端配置表（四项设置+弹窗说明）、端口表、星型说明。
- **此前**：lockserver 初版（单值模型，有 BUG）、relaysrv 部署件、README 初版。
- **2026-10-31 三端全量代码审查与修复（P0→P3 + 复审，batch16–21）**：按仓库根 `docs/code-review-2026-10-30.md` 分批修复（清单见 `backups/备份说明.md`）；复审报告 `docs/code-review-2026-10-31-srv.md`：27 项通过 / 2 残留 / 7 新发现。复审修复（batch21，py_compile 通过）：
  1. N1（SV-C2 残留）：publish 源合并在源会话不在内存时不再退化为全局锁内做磁盘 IO，stat/落盘全部锁外（慢盘不再冻结全服务器）。
  2. N2（SV-H7 残留）：op/struct/save 身份校验（`FILES.get(key) is entry`）移入 oplock+_lock 同一临界区，失效经 `_entry_revalidate` 换当前 entry 重试——校验到进锁之间 entry 被 close/GC 删除导致的孤儿写入（编辑静默丢失）彻底闭合。
  3. N3：`hmac.compare_digest` 遇非 ASCII Authorization 头抛 TypeError，按鉴权失败处理。
  4. N4：400/413 拒绝前置 `close_connection = True`，keep-alive 上未消费 body 不再被当下一条请求解析。
  5. N5：GC/close/save 落盘前复核 rev——快照后到达的 op 不再被旧快照覆盖写回磁盘（避免 Syncthing 传播旧版本）。
  6. N6：`_broadcast` 清死连接后向其余 peers 补发 leave（与 GC 路径对齐，不再幽灵在线）。
  7. N7：`/api/v1/open` 响应补 `rev` 字段，与 SSE hello 协议对齐。
  涉及 `lockserver/main.py`。部署仍走既有 PyInstaller + systemd 流程（本轮未部署）。
- **2026-10-31 第三轮全量复审修复（13 条，batch22）**：复审报告 `docs/code-review-2026-10-31b-srv.md`，py_compile EXIT=0（R1/R2/R7/R12 另做进程内冒烟）：
  1. SV-R1（Critical）：publish 先写副本、随后又用"更新前的副本内存 `live`"覆盖源文件与副本磁盘——副本仅被打开未编辑时，**本次 publish 内容被丢弃、源文件回滚**并经 Syncthing 扩散。改为唯一权威值 = 本次 content，只用副本磁盘 mtime（old_mtime）作新旧信号。
  2. SV-R2（High）：副本→源会话切换时不迁移已有 SSE 订阅（旧 entry 永不回收、副本端收不到源端广播，协作单向失联）→ 新增 `_migrate_subs`，并入 subs 并改写各 SSEHandler 绑定的 entry。
  3. SV-R3：`_lock` 内写 socket 常见路径（close/op 越界错误响应）全部改为锁内只置标志、锁外发送。
  4. SV-R4：`_entry_get_or_create`/`_entry_revalidate` 的读盘移出 `_lock`（回锁二次确认）；GC 的 ALIAS 存活校验改锁外 stat + 回锁复核。
  5. SV-R5：有订阅者也按空闲阈值落盘，长连接下编辑不再长期只存内存。
  6. SV-R6：GC/close/save/publish 落盘整段持 oplock，rev 复核与写盘收进同一临界区。
  7. SV-R7：save 刷新副本内存时持 `rentry.oplock` 并广播 struct，内容未变不抬 rev。
  8. SV-R8：三个重试循环限 5 次并返回 409，`ts` 移入锁内，防活锁与过期时间戳。
  9. SV-R9：SSE 退出显式关闭连接并恢复 socket 超时，移除 keep-alive 头。
  10. SV-R10：SSE 建连与入订阅双重复核、publish 入锁复核身份，不写孤儿 entry。
  11. SV-R11：publish 检查落盘结果并返回 `persisted`，内存 entry 留给 GC 重试。
  12. SV-R12：新增 `_recent_io_lock` + 删除墓碑，delete 与 publish 串行化，杜绝"先删后复活"。
  13. SV-R13：body 读取异常置 `close_connection`，未消费字节不再被当下一条请求解析。
  涉及 `lockserver/main.py`。

- **2026-10-31（第四轮复审修复，10 条，batch23，未部署）**：依据 docs/code-review-2026-10-31c-srv.md 全量修复。
  1. SV-Q1（High）：adopt 合并取错权威值会回滚他端离线编辑 → publish 覆盖副本前快照 copy_snapshot（内存优先否则读盘），adopt 成立时以快照合并回源并广播，快照缺失放弃 adopt。
  2. SV-Q2（High）：_migrate_subs 丢未落盘编辑且与在途 op 无互斥 → 整段持 _recent_io_lock → src.oplock → _lock，销毁前 rev>0 先落盘，迁移后补发 struct 对齐基线。
  3. SV-Q3（High）：hello 全局锁内写 socket 遇半开客户端冻结全服 → settimeout 放宽推迟到 hello 写完后，期间沿用 30s 超时。
  4. SV-Q4（Medium）：_recent_tombstoned() 墓碑期内拒绝重建 entry（410/SSE 拒连）。
  5. SV-Q5~Q10（Low）：insert 非 list 400；ALIAS/.platform 副作用移入墓碑判定后；save 落盘失败汇总 persisted:false；adopt _send 移出 oplock；GC 仅 rev>0 落盘；SSE 超时 120s。
- **涉及文件**：lockserver/main.py。
- **验证**：python -m py_compile main.py 退出码 0。

- **2026-10-31（第五轮复审修复，10 条，batch24，未部署）**：依据 docs/code-review-2026-10-31d-srv.md。
  1. SV-S1（High）：adopt 新旧信号移入 _recent_io_lock+oplock 内采集；rev>0 取内存 mtime 与磁盘 mtime 最大值，避免副本未落盘编辑被漏判覆盖。
  2. SV-S2（High）：adopt 先判定后落盘/广播；成立时副本 entry 与磁盘统一写快照，仅非 adopt 才广播 publish content，来源端编辑器不再被回退。
  3. SV-S3/S4（Medium）：delete 持 _recent_io_lock→副本 oplock 再 unlink/pop；墓碑判定与查/建 entry 同处 _lock（新增 _recent_tombstoned_nolock）。
  4. SV-S5/S6/S7（Medium/Low）：迁移前把副本编辑并入 dst 并锁外广播对齐基线；先落盘成功才 pop；写盘后回锁复核并以快照校正新建 entry。
  5. SV-S8~S10（Low）：顶层非 dict 返回 400；同名兜底排除 
ecent/；新增 _as_text 归一化 publish/save/op/struct 文本字段。
- **涉及文件**：lockserver/main.py。
- **验证**：python -m py_compile main.py 退出码 0；本地冒烟（adopt 回写、迁移合并、旧快照不回滚、删除复活拦截、4 线程并发无死锁）通过。

- **2026-10-31（第六轮复审修复，10 条，batch25，未部署）**：依据 docs/code-review-2026-10-31e-srv.md。
  1. SV-T1（High）：adopt 以副本旧快照为唯一权威、本次 publish 内容被丢弃 → 新增副本基线 _PUBLISHED_LOCAL 区分"他端编辑"与"本次发布"，无法判定时返回 conflict:true + 权威内容。
  2. SV-T2（High）：_migrate_subs 无条件合并回滚源端较新内容 → 改三态返回，比较 src_mtime 与 dst 新近度，不更新返回 conflict（调用方 409）。
  3. SV-T3（Medium）：合并与基线 struct 在 oplock 外广播 → 移入 dst.oplock 持锁区间。
  4. SV-T4~T10：别名已登记跳过同名兜底；close 仅 
ev>0 落盘；oplock 10s 超时 503 + SSE 独立 15s 写超时；unlink 失败回滚墓碑；adopt 落盘后回锁复核 rev；_req_text 防 null 变 "None"；MAX_FILE_BYTES=16MB 总量校验。
- **涉及文件**：lockserver/main.py。
- **验证**：python -m py_compile main.py 退出码 0 + publish/migrate/close 冒烟通过。

- **2026-11-01（第七轮复审修复，10 条，batch26，未部署）**：依据 docs/code-review-2026-10-31f-srv.md。
  1. SV-U1（High）：_handle_save 镜像写副本从不更新 _PUBLISHED_LOCAL，基线落后于副本磁盘，下次 publish 把服务端自己的回声判成"他端编辑"并 adopt 回滚 → save 两条副本镜像路径成功后 _remember_published；publish 侧基线更新改看本次 flush_ok（persisted 是累积标志会误判）。
  2. SV-U2（High）：_PUBLISHED_LOCAL 以整篇内容为值且无清理，设备数×文件数×大小永久驻留内存（OOM 风险）→ 改存 sha256 摘要（_content_digest/_remember_published），插入序淘汰上限 8192；copy_foreign 判据改摘要比对。
  3. SV-U4（Medium）：publish 的 adopt/副本刷新广播在 oplock 已释放后发送，并发 op 可先送达更高 rev 再被旧全文回退 → 两次 _broadcast 移入 ExitStack 区间持 oplock 发送。
  4. SV-U5（Medium）：json.loads 接受未配对代理字符，ensure_ascii=False 后 encode 抛 UnicodeEncodeError，op 已写入后 _broadcast 炸掉会毒化该文件全部订阅/落盘 → 新增 _clean_surrogates 挂 _as_text/_req_text 统一拦截。
  5. SV-U6（Medium）：entry.mtime 兼作活动时间戳（hello/leave/无变化 save 都刷新），迁移新旧判定把"刚打开过"误判成"内容更新"致 409 卡死 → FileEntry 新增 content_mtime 仅内容真实变化时刷新（op/struct/save/publish adopt/迁移合并全覆盖），判定一律用它；op/struct/save 内容无变化不抬 rev、不广播。
  6. SV-U7（Medium）：迁移合并广播与基线帧在 _recent_io_lock 内发送，慢订阅者（单写最长 15s）把全服 publish/delete/迁移串行堵住 → 保持锁序 recent→oplock 但全局锁只覆盖状态变更+落盘，提前释放后再广播（仍持两把 oplock 保序）。
  7. SV-U8（Low）：_handle_recent_file 只读磁盘，副本 rev>0 未落盘编辑（最长 30s）对他端不可见，客户端按旧行号发 op 错位 → 先墓碑/会话解析，rev>0 返回 entry.content，无 entry 再读盘。
  8. SV-U9（Low）：publish 无内存会话（c0 is None）时不持副本 oplock 落盘，并发 op 可建出 entry 写入后被旧 authority 覆盖 → 落盘后回锁复核 FILES.get(ckey)，entry 内容与 authority 不同时以内存较新值覆回磁盘。
  9. SV-U10（Low）：上限按字符数比较（16M 字符≈32-64MB 字节），_load_from_disk 无上限（超大文件冻结为只读）→ op/struct/save/_flush_to_disk 统一 len(content.encode("utf-8")) 字节口径；_load_from_disk 前置 stat 超限返回空并记日志。
  10. SV-U3（协议对接）：409/conflict 三端客户端已补齐消费逻辑（PC/安卓随本批闭环），服务端语义维持不变。
- **涉及文件**：lockserver/main.py。
- **验证**：python -m py_compile main.py 退出码 0。
- **2026-11-01（第八轮复审修复，5 条，batch27，未部署）**：依据 docs/code-review-2026-11-01-srv.md。
  1. SV-V1（Medium）：SV-U4 把 publish 广播移入 oplock 时连同 _recent_io_lock 一起持有，慢 SSE 订阅者（单写最长 15s×K）堵全服 publish/delete/迁移 → 全局锁改显式 acquire/release+try/finally，广播前提前释放仅持双 oplock（与迁移 SV-U7 同款）。
  2. SV-V2（Medium）：副本侧 rev>0 仍用活动 mtime 判新旧（hello/leave 刷新、GC 不清 rev），旧副本可回滚较新源内容 → 改 centry.content_mtime，与源侧 origin_ts 口径对称。
  3. SV-V3（Low）：_handle_recent_file 在 oplock 内 _send，慢客户端阻塞该文件协作最长约 30s → 锁内只拷贝快照，锁外发送。
  4. SV-V4（Low）：publish 无会话副本快照裸 open 绕过 16MB 前置拦截 → 改调 _load_from_disk，失败/超限按快照不可得。
  5. SV-V5（Low）：_load_from_disk 把解码失败与文件不存在归一为空串，不可读文件被建空 entry 后静默覆盖 → 解码失败独立记日志返回 None，open/GET/SSE/op/struct/save 全线 415 拒绝。
- **涉及文件**：lockserver/main.py。
- **验证**：python -m py_compile main.py 退出码 0；锁序 _recent_io_lock→oplock→_lock 无回退。

## 2026-11-01 第九轮复审修复（SV-W1~W3，报告 docs/code-review-2026-11-01b-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 超 16MB 既有文件不得被静默覆盖 | _load_from_disk 超限分支与解码失败同口径返回 None，open/GET/SSE/op/struct/save 全线 415 拒绝建空 entry（main.py） |
| publish 广播对换入 entry 保序 | SV-T8/SV-S7 复核分支换入 cur/appeared 时其 oplock 一并 _timed_lock 入 ExitStack 持有至广播，超时放弃校正（main.py 三处） |
| 注释与实现一致 | SSE hello 写超时注释 30s 改 SSE_WRITE_TIMEOUT=15s（main.py） |
验证：python -m py_compile 通过。快照 backups\batch28-round9-review-fixes-20261101.zip

## 2026-11-01 第十轮复审修复（SV-X1，报告 docs/code-review-2026-11-01c-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 注释与实现一致 | _load_from_disk docstring 三态表述改「None（非合法 UTF-8 或超 16MB 上限——SV-W1）」；publish 快照点注释改「失败返回空串、超限/不可解码返回 None」（main.py） |
验证：python -m py_compile 通过。快照 backups\batch29-round10-review-fixes-20261101.zip

## 2026-11-01 第十一轮复审修复（SV-Y1~Y2，报告 docs/code-review-2026-11-01d-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 清理死导入 | 删除 import re（全文件零调用）与 urllib.parse unquote（SV-M1 残留）（main.py） |
| 业务日志防伪造 | 新增 _log() 统一入口与 log_message 同口径 isprintable 过滤，gc/flush/load/recent/sse/delete 及启动横幅共 15 处直写 print 全部改走 _log，path/device_name 等客户端可控字段控制字符无法再截断/伪造日志行（main.py） |
验证：python -m py_compile 通过。快照 backups\batch30-round11-review-fixes-20261101.zip

## 2026-11-01 第十三轮复审修复（SV-AA1~AA4，报告 docs/code-review-2026-11-01f-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 修复 SSE keepalive 崩溃（Critical） | SSE keepalive 循环 `current.write(b": keepalive\n\n")` 改为 `sse.write(b": keepalive\n\n")`：`current` 是 FileEntry 实例无 write 方法，导致每个 SSE 连接首次保活（~30s）后 AttributeError 崩溃断开，实时协同长连接无法维持（main.py） |
| 共享状态加锁口径统一 | `_handle_recent_devices` 中 `LAST_SEEN` 读取移入 `_lock` 内做快照，避免无锁读取共享 dict（main.py） |
| 共享状态加锁口径统一 | `_PLATFORM_CACHE` 三处读写加 `_lock` 保护（磁盘 IO 放锁外），消除并发心跳重复写 .platform 文件（main.py） |
| 清除死字段 | 删除 `SSEHandler.__init__` 中赋值后全文无读取的 `self._write_called = False`（main.py） |
验证：python -m py_compile 通过。快照 backups\batch32-round13-review-fixes-20261101.zip

## 2026-11-01 第十四轮复审修复（SV-AB1，报告 docs/code-review-2026-11-01g-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 缓存与磁盘一致性 | `_handle_recent_publish` 写 `.platform` 后未回填 `_PLATFORM_CACHE`，设备切换 platform 后缓存返回旧值直到下次心跳 → 写盘成功后在 `_lock` 内执行 `_PLATFORM_CACHE[dev] = plat`（与 heartbeat 同口径）（main.py） |
验证：python -m py_compile 通过。快照 backups\batch33-round14-review-fixes-20261101.zip

## 2026-11-03 第十六轮复审修复（SV-AD1~SV-AD5，报告 docs/code-review-2026-11-02a-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 锁超时口径统一 | publish 的副本侧复核分支（SV-U9 新增）在持 `_recent_io_lock` 期间无超时获取 `appeared.oplock` → 改 `_timed_lock`，超时跳过本轮覆回校正（rev 差由后续 publish/GC 收敛），与同函数其余 oplock 获取点及 SV-T6 注释口径一致（main.py） |
| 字段长度上限 | recent 系列端点的 `device_name`/`file_name`/`origin_rel` 无长度上限：超长 dev 名以键驻留 LAST_SEEN 24h，超长 dev/name 使副本落盘 ENAMETOOLONG 失败但 ALIAS 已登记 → 新增 `MAX_DEV_LEN=128`、`MAX_NAME_LEN=255`、`MAX_ORIGIN_LEN=1024`，heartbeat/publish/delete/list/file 全部校验，超限 400（main.py） |
| keep-alive 串包防护 | POST 缺 `Content-Length` 或被 `Transfer-Encoding` 替代时按 0 读体且不断连，实际发送的 body 会残留在连接上被当作下一条请求 → 显式 400 + `close_connection = True`（与 N4/R13 同口径）（main.py） |
| delete 校验对齐 | `_handle_recent_delete` 缺 SV-M7 的 `.` 前缀与 `.tmp.` 拦截，可删 `.platform` 等设备形态文件 → 与 publish 校验对齐（main.py） |
| Docker 部署落盘 | docker-compose 的 lockserver 服务无 volumes、无 `MARKOR_DISK_ROOT`/`MARKOR_RECENT_ROOT`，协作落盘与副本均写入容器临时层，重建即丢失 → 挂 `${DATA_PATH}:/data` 与命名卷 `lockserver-recent:/app/recent-sync`，设两个环境变量（docker-compose.yml） |
验证：compile() 内存编译通过（未写 .pyc）。快照 backups\batch35-round16-review-fixes-20261103.zip

## 2026-11-03 第十七轮复审修复（SV-AE1~SV-AE6，报告 docs/code-review-2026-11-03a-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 路径/设备字段字节上限 | 核心端点 `path`、`device_id`、`device_name` 无界，超长路径必然 ENAMETOOLONG，rev>0 entry 永不落盘也就永不被 GC 回收 → `_safe_path` 统一限制单组件 ≤255 字节、整路径 ≤4096 字节并拒绝控制字符；新增 `_valid_device`（字符/字节/控制字符）接入 SSE/open/op/struct/save；GC 对无订阅者且结构上不可落盘的历史 entry 直接回收（main.py） |
| 落盘读取上限 | `_flush_to_disk` 对既有目标文件整篇 read 比较，既有文件 >16MB 时会大内存读入且 publish 在 `_recent_io_lock` 内阻塞全服 → 比较前先 `getsize`，超限不读不覆盖并返回 False（main.py） |
| 别名登记与容量上限 | ALIAS 在副本落盘前登记，落盘失败后永久残留且无容量上限 → 仅在 `flush_ok` 后登记；新增 `_remember_alias` 8192 条 FIFO 上限（main.py） |
| 鉴权早退串包防护 | POST 鉴权失败在读取请求体前直接 401 且未断连，keep-alive 残留 body 会被当作下一条请求 → 401 前置 `close_connection=True`（main.py） |
| 形态缓存与设备目录生命周期 | `_PLATFORM_CACHE` 无淘汰、心跳创建的设备目录无回收 → 新增 `_remember_platform` 4096 条上限；GC 每 60s 清理 24h 无心跳且仅剩 `.platform` 的空设备目录（main.py） |
| SSE join 归属 | 注册与 join 之间订阅可被迁移到源会话，join 仍用旧 entry 导致迁移后 peers 收不到 → join 前在锁内重读 `sse.entry` 并按当前绑定广播（main.py） |
验证：compile() 内存编译通过（未写 .pyc）。

## 2026-11-03 第二十二轮复审修复（SV-AG1~AG2，报告 docs/code-review-2026-11-03f-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| publish 缺省 origin_rel 崩溃 | `origin_rel` 未提供/为空/非法时 `_safe_path` 返回 None，随后 `len(origin)` 抛 TypeError → 500 断连，客户端 publish 静默失败 → 空/非法值归一为空串（视为不绑定源会话），仅非空值校验长度上限（main.py） |
| 不可读文件被当空文件 | `_load_from_disk` 对既有文件读取抛 OSError（权限/IO）时落入兜底返回空串，会为不可读文件建空 entry，后续落盘静默覆盖原内容 → `FileNotFoundError` 仍按不存在（空串），其它 OSError 记日志返回 None（415 拒绝建 entry）（main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（校验后已清理 __pycache__）。快照 backups\batch39-round22-review-fixes-20261103.zip

## 2026-11-03 第二十三轮复审修复（SV-AH1，报告 docs/code-review-2026-11-03g-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 既有文件 stat 失败语义 | `_load_from_disk` 的 `os.path.getsize` 抛非 `FileNotFoundError` 的 `OSError` 时仍落入外层兜底返回空串，会为不可 stat 的既有文件建空 entry，后续落盘覆盖原文件 → `getsize` 单独捕获：被删返回空串，其它错误记日志返回 `None`（415 拒绝建 entry）；超限日志复用已取到的 size（main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（校验后已清理 __pycache__）。快照 backups\batch40-round23-review-fixes-20261103.zip


## 2026-11-03 第二十七轮复审修复（SV-AI1~AI2，报告 docs/code-review-2026-11-03k-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 副本读取基线不一致 | `_handle_recent_file` 解析到源会话且源 entry `rev==0` 时仍读副本磁盘，与 `/open`、SSE hello 的源磁盘基线不同，客户端按该基线算 op 行号会错位 → `entry.rev > 0 or resolved != recent` 时返回会话内容，仅 `resolved == recent && rev==0` 保留读盘（main.py） |
| 超限落盘不可回收 | 目标磁盘文件被外部扩到 16MB+ 后 `_flush_to_disk` 永久 SKIP，`rev>0` 且无订阅者的 entry 常驻内存并每 10s 刷日志 → 新增 `_disk_file_too_large`，GC 落盘失败且无订阅者时，路径不可落盘或目标文件超限的 entry 一并丢弃并记 `[gc] drop`（main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（校验后已清理 __pycache__）。快照 backups\batch41-round27-review-fixes-20261103.zip

## 2026-11-04 第三十二轮审查修复（SV-BK1~BK2，报告 docs/code-review-2026-11-04p-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| Infinity 请求断连 | `json.loads` 接受 `Infinity`，`int(inf)` 抛 `OverflowError` 未捕获，异常穿透 `do_POST` 直接断连 → `/op` 与 `/struct` 的 except 补 `OverflowError`，统一返回 400（main.py） |
| 副本编辑被静默覆盖 | 上报无 `origin_rel`（`okey is None`）时 `copy_foreign` 不被消费，`authority=content` 直接覆盖副本且无 conflict → 该场景置 `conflict=True` 且 `authority = copy_snapshot`，保留副本内容（main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch44-round32-review-fixes-20261104.zip

## 2026-11-04 第三十三轮审查修复（SV-BL1~BL5，报告 docs/code-review-2026-11-04q-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 无 origin_rel 时副本快照不读 | 读取副本磁盘快照原先要求 `okey` 非空，未上报 `origin_rel` 时 `copy_foreign` 恒 False、他端编辑被覆盖 → 条件放宽为 `copy_mtime > 0`（main.py） |
| 基线未知仍覆盖副本 | `copy_base is None`（服务重启/首次上报）无法判定新旧，仍以 `content` 覆盖副本 → 置 `conflict=True` 且 `authority = copy_snapshot`，以副本为权威（main.py） |
| save 未落盘却报持久化 | 内容与内存一致但 `rev>0`（先 op 后 save）时跳过落盘，回报 `persisted=true` 而磁盘是旧内容 → 落盘条件改为 `save_json is not None or (not stale and rev > 0)`，广播仍只在 save 请求时执行（main.py） |
| 并发删除导致 500 | `_build_recent_devices` 的 `os.listdir` 与 `_handle_recent_list` 的 `os.stat` 未捕获 `OSError` → 两处 `except OSError: continue`（main.py） |
| 墓碑判定晚于同名兜底 | `_resolve_session_path` 先走别名/同名兜底，删除副本后可能解析到同名源文件并改写 → `_lock` 内先判 `_DELETED_RECENT`（main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch45-round33-review-fixes-20261104.zip

## 2026-11-04 第三十四轮审查修复（SV-BM1~BM6，报告 docs/code-review-2026-11-04r-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 源端保存覆盖他端副本编辑 | `/save` 对 `_recent_copies_of` 无条件覆盖并广播 → 改用 `_PUBLISHED_LOCAL` 摘要基线判定（与 publish `copy_foreign` 同口径），副本偏离基线时保留副本、不广播；正常镜像路径不变（main.py） |
| 空闲订阅文件重复读盘 | GC 落盘成功后不推进 `entry.mtime`，有订阅但空闲的文件每 10s 整篇读盘比较 → 成功且 rev 未变时推进 `mtime`，失败保留重试（main.py） |
| 迁移锁无超时阻塞 | `_migrate_subs` 对 `_recent_io_lock` 无超时获取 → `acquire(timeout=OPLOCK_WAIT_SEC)`，超时留在副本会话可重试，锁序不变（main.py） |
| 并发删除返回空内容 | `/recent/file` 墓碑判定与读盘之间无复核 → 内存快照与磁盘读取后各复核一次，命中返回 410（main.py） |
| 副本 entry 漏校正 | publish 落盘后仅在 `centry is None` 时校正重建 entry → 无条件重读当前 entry，持 oplock 复核身份后按源侧口径校正（main.py） |
| LAST_SEEN 无上限 | 心跳可换名无限扩张 → 新增 `MAX_LAST_SEEN=8192`，LRU 淘汰最久未心跳条目（main.py） |
| 跨时钟新旧判定 | 判定不修：服务端 `time.time` 与磁盘 mtime 混用，需引入客户端 RECEIVED_TS 链，属设计级改动，记录为已知限制 |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch46-round34-review-fixes-20261104.zip

## 2026-11-04 第三十五轮审查修复（SV-BN1~BN3，报告 docs/code-review-2026-11-04s-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 副本刷新覆盖他端编辑 | `/save` 无内存会话分支直接写盘、有会话分支只在 `rev>0` 判基线，两次上报之间被其它设备改过的副本会被静默覆盖 → 无会话分支在 `_recent_io_lock` 内 `_load_from_disk` 并比对 `_PUBLISHED_LOCAL` 摘要，偏离或读盘失败即不覆盖不更新基线；有会话分支去掉 `rev>0`，统一按摘要比对（main.py） |
| 永久落盘错误导致 entry 常驻 | GC 只识别路径不可落盘/文件超限，ENOTDIR/EISDIR/EACCES/EPERM/EROFS/ENAMETOOLONG/EINVAL/UnicodeError 永久失败无订阅时仍每 10s 重试 → `_flush_to_disk` 增加 `err_out`，`_flush_error_permanent` 白名单判定，仅永久错误且无订阅才丢弃；ENOSPC/EIO 等临时错误继续保留重试（main.py） |
| SSE 重连踢掉旧连接 | 注册新连接时先摘除同设备旧连接再写 hello，hello 失败旧连接成幽灵在线 → 先写 hello 成功再摘除旧连接，失败保留旧连接，新连接由 except 清理（main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch47-round35-review-fixes-20261104.zip

## 2026-11-04 第三十六轮审查修复（SV-BO1~BO11，报告 docs/code-review-2026-11-04t-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| tmp 名超长导致合法文件永不落盘 | 落盘临时名由 `<原名>.tmp.<tid>` 改为 `tempfile.mkstemp(prefix=".mktmp-")` 的目录内短名，写入后 `chmod 0644` 再 `os.replace`（main.py，SRV36-2） |
| 重启后 save 覆盖副本 | `_PUBLISHED_LOCAL` 基线为 None 时，有/无内存会话两个副本刷新分支均跳过写盘，与 publish 的 SV-BL2 同口径（main.py，SRV36-3） |
| 副本落盘后内存分叉 | 无内存会话分支落盘后重查 `FILES`，对 rev==0 且内容不同的新 entry 持 oplock 校正内存（main.py，SRV36-4） |
| 目录路径被当空文件 | `_load_from_disk` 对 `os.path.isdir` 返回 None，拒绝建空 entry（main.py，SRV36-5） |
| 断连 traceback 刷屏 | `_send` 捕获 BrokenPipeError/ConnectionResetError 并置 `close_connection`（main.py，SRV36-7） |
| 删除错误泄露服务器路径 | delete 失败响应改通用 `delete failed`，OSError 详情只写日志（main.py，SRV36-8） |
| 容器字段写成 Python repr | `_as_text` 仅接受 str/int/float/null；publish/op/struct/save 对容器按 400 拒绝（main.py，SRV36-9） |
| `.platform` 非原子写 | 新增 `_write_text_atomic`，publish 与心跳统一原子写（main.py，SRV36-10） |
| 点开头设备名不对称 | publish/delete/heartbeat 的 `device_name` 统一拒绝 `.` 开头（main.py，SRV36-11） |
| 删除窗口返回已删内容 | `/api/v1/file`、`/open` 返回前复核删除墓碑，命中 410（main.py，SRV36-12） |
| 符号链接逃出同步根 | 新增 `_path_inside_root`（realpath+commonpath），读/写落点越界即拒绝（main.py，SRV36-13） |
判定不修：SRV36-1（hello 全局锁内写为 SV-H6 有意设计，写超时已封顶 15s）、SRV36-6（FILES/SSE 容量上限需专门设计，私有部署无触发场景）。
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch48-round36-review-fixes-20261104.zip

## 2026-11-04 第三十七轮审查修复（SV-BP1~BP4，报告 docs/code-review-2026-11-04u-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| GC 删除有订阅者的 entry | `elif not entry.subs` 为锁外快照，并发 hello 注册后仍会删除 entry，订阅者成孤儿 → 删除条件在 `_lock` 内追加 `not entry.subs` 复核（main.py，SRV37-1） |
| 副本回声不广播 | save 刷新 rev==0 副本 entry 只改内存，不抬 rev 不广播，订阅端保留旧基线 → 抬 rev 并生成整篇 struct，广播在 `_recent_io_lock`/oplock 释放后执行并复核 rev（main.py，SRV37-2） |
| recent 写路径无结构约束 | op/struct/save/open 可建嵌套或点开头的副本 entry，list/delete/GC 均不可见 → 新增 `_recent_write_valid`，仅允许 `recent/<设备>/<文件名>` 两层，四个写端点统一 400（main.py，SRV37-3） |
| 文件名首尾空白被吞 | `_safe_path` 的 `strip()` 把 `a.md ` 映射成 `a.md` → 仅 `lstrip("/")`，保留合法首尾空白（main.py，SRV37-4） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch49-round37-review-fixes-20261104.zip

## 2026-11-04 第三十八轮审查修复（SV-BQ1，报告 docs/code-review-2026-11-04v-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 路径入口仍吞首尾空白 | SRV37-4 只修了 `_safe_path`，open/op/save/close 的 `path`、publish 的 `origin_rel`/`file_name`、delete 与 `/recent/file` 的 `name` 仍经 `_req_text` strip，`a.md ` 被映射成 `a.md` 并读写到另一个文件 → 新增 `_req_raw`（只清代理项、全空白按缺失），路径类字段改字面值；`/recent/list`、`/recent/file` 的 `device` 与写入侧统一 strip（main.py，SRV38-1） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch50-round38-review-fixes-20261104.zip

## 2026-11-04 第四十轮审查修复（SV-BR1，报告 docs/code-review-2026-11-04x-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| struct 失效重试落错行 | `_handle_struct` 重试循环把 `min(start, len(lines))`/`min(delete, ...)` 写回 `start`/`delete`，失效重试拿到行数不同的新 entry 时沿用旧裁剪值，结构变更与广播帧行号错位 → 每次尝试改用局部 `apply_start`/`apply_delete`，原始请求值保持不变（main.py，SRV40-1） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch52-round40-review-fixes-20261104.zip

## 2026-11-05 第四十八轮审查修复（SV-BS1，报告 docs/code-review-2026-11-05f-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 删除/改名后 close 落盘把文件复活 | `/close` 新增可选 `discard=true`：表示磁盘旧路径已被客户端处理（删除/改名），持 entry.oplock 复核无订阅者后直接丢弃会话、**不落盘**；默认 false 保持原有"落盘后再销毁"，避免 PC 删除/重命名已打开的文件后在旧路径凭空重建内容（lockserver/main.py `_handle_close`） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch60-round48-review-fixes-20261105.zip

## 2026-11-05 第四十九轮审查修复（SV-BS2，报告 docs/code-review-2026-11-05g-srv.md，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 目标文件已被删除时 GC/close 落盘仍将其重建 | `_flush_to_disk` 在路径解析通过后增加存在性检查：`os.path.exists(full)` 为假时记日志并返回 True，不调用 mkstemp/os.replace。覆盖"外部工具/SAF 删除文件后会话关闭"、"Android 后台超时关闭"、"recent 副本刚被 delete 但仍有会话"三类复活路径；客户端若确实重新保存，会先在本机重建文件，届时落盘照常生效（lockserver/main.py） |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）。快照 backups\batch61-round49-review-fixes-20261105.zip

## 2026-11-05 第五十轮：服务端写路径收口（阶段①，零写同步根；batch73，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 锁服务绝不写同步根 DISK_ROOT | `_flush_to_disk` 改名并重写为 `_flush_recent`（全服唯一内容落盘入口）：只接受 `recent/` 前缀，非 recent 路径记 `[flush] DENY write to DISK_ROOT` 并抛 `RuntimeError`（不静默跳过）；`_write_text_atomic`（`.platform`）同样强制 `RECENT_ROOT` 校验。新增 `_startup_selfcheck()`：启动时用 DISK_ROOT 路径探测，未被拒绝则 fail-fast；`/health` 增加 `write_scope` 计数（`disk_denied` 应恒为 0） |
| 删除所有落 DISK_ROOT 的分支 | GC（原 313）、`_migrate_subs`（502）、`_handle_recent_publish`（1702/1759/1803/1848）、`_handle_save`（2431）、`_handle_close`（2627）不再写同步根：源路径只更新内存 + 广播；recent 副本调用点（1853/1918/2480/2568）改走 `_flush_recent` |
| 死代码清理 | 删除 `_flush_error_permanent`、`_PERMANENT_FLUSH_ERRNOS`、`_disk_file_too_large`、`_path_persistable` 与 `import errno`（同步根写路径不存在后不再需要永久失败分类） |
| recent 快照生命周期 | 不设 TTL、不设容量上限；仅三种删除：显式 `/recent/delete`、设备删除 `/recent/device/delete`（新增）、所有参与设备通过 `/recent/ack`（新增）上报的本地 hash 均等于快照 hash。参与集合/上报记录放在 `SNAP_META`（独立于 FILES，不长期占用内容内存）；关闭弹窗/断开连接不作为删除条件 |
| 版本标识与 hash 分离 | `/api/v1/open` 响应新增 `content_hash`（路径 + rev + hash = 同一份文件的版本标识）；“设备已处理”只用 ack 上报的 hash，二者分开 |
| 向后兼容 | `open/op/struct/save/close`、SSE、join/leave、断线补发、行级三分支语义不变；旧客户端忽略新增字段；`save.persisted` 现仅表示 recent 副本是否落盘（源路径恒 true）。最坏退化为“服务端不落盘” |
验证：`python -m py_compile lockserver\main.py` 通过（已清理 __pycache__）；本地临时 DISK/RECENT 目录跑 open/op/save/close + publish + ack：同步根文件列表全程为空，唯一写入为 `recent/<dev>/<name>`，ack 未收敛不删、收敛后删除；自检拒绝探针并 fail-fast（守卫被拆时确实会写同步根，证明自检有效）。报告 docs/code-review-2026-11-05-server-write-scope.md。快照 backups\batch73-server-no-syncroot-write-20261105.zip（未部署）

## 2026-11-05 第五十一轮：ack 发布端登记修复（P1，batch77，已部署）
| 需求 | 变更 |
|---|---|
| 单端 ack 即 settled、发布端随后 410 | `_handle_recent_publish` 在落盘成功后**无条件**调用 `_mark_participant_nolock(recent, dev)`，不再依赖“已有内存 entry 且内容变化”分支（原实现中 publish 新建副本时发布端从不登记，另一端 open 后成为唯一参与者，一 ack 就收敛删快照） |
| 发布端未 ack 前不得 settled | `_handle_recent_ack` 以副本路径 `recent/<dev>/<name>` 的第一段作为发布端（不依赖内存态 `SNAP_META`，服务重启后仍成立），把发布端并入 participants，并要求 `acked[owner] == snapshot_hash` 才判定 converged |
| 不变量不变 | 仍只写 `RECENT_ROOT`、仍零写同步根；`/health.write_scope` 保持 `disk_root: deny` |
验证：`python -m py_compile lockserver\main.py` 退出码 0；线上复现场景 A（publish→无 PC open→安卓 ack）返回 `settled:false`、`pending:["DESKTOP-PCHPJ8S"]`，PC ack 后才 `settled:true`；重启自检 `[flush] DENY ...` 与 `/health` 正常。快照 backups\batch77-server-ack-publisher-20261105.zip

## 2026-11-05 第五十二轮：writer token（写入权）协议与服务端实现（batch83，仅本地未部署）
| 需求 | 变更 |
|---|---|
| 定义 PC/安卓可独立实现的 writer token 协议 | 新增 `docs/design-2026-11-05-writer-token.md`：谁申请、按最后活跃移交、15s 掉线判定 + 2s watchdog、`writer_device_id/writer_device_name/writer_since/writer_rev/writer_changed` 的接口与 SSE 位置、非 writer 职责、旧客户端兼容、失败降级、可观测字段 |
| 服务端发放/移交写权 | `FileEntry` 增加 writer 字段与参与者表；首个 `open`/SSE join 隐式申请；新增 `POST /api/v1/writer/claim`（force 抢占，在线 writer 时返回 409 `writer busy`）与 `POST /api/v1/writer/release`；`close` 时立即移交；新增 `_writer_watch_loop`（2s）按最后活跃移交超时 writer |
| 事件与响应字段 | `/open`、SSE `hello`、`op/struct/save/close` 响应新增 writer 字段；新增 SSE `writer_changed`（reason: claim/offline/timeout/leave/release/force/migrate）；`op/struct/peer` 事件附带 writer 快照；`/health.writers` 增加 active/changes/transfers/timeouts |
| 掉线检测时效 | SSE 保活循环改 1s 粒度 `select + MSG_PEEK` 探测 EOF（原 30s 才写 keepalive，静默断开最坏 30+15s 才移交）；会话别名/副本迁移时 writer 随逻辑会话迁移并广播 |
| 兼容与不变量 | 旧客户端 `open/op/save/close` 全部 2xx，新增字段忽略即可；服务端不因非 writer 拒绝写入；仍零写 `DISK_ROOT`，只写 `RECENT_ROOT` 白名单 |
验证：`python -m py_compile lockserver\main.py` 退出码 0；本地 18/18 用例通过（申请/不抢/busy/force 双端事件/掉线移交/close 移交/release/旧客户端/多端并发/同步根零写）。快照 backups\batch83-server-writer-token-20261105.zip（未改 PC/安卓）。
部署：2026-11-05 18:30 CST 已上线飞牛（PyInstaller 重建、备份见 deploy 文档第 12 节；健康检查 writers.active=8、disk_denied=0；W1/W4 冒烟通过；部署前后同步根 97 个文件 diff 为空）。

## 2026-11-05 第五十三轮：缺席三态 + 外部键设备命名空间（batch92，已部署）

| 需求 | 变更 |
|---|---|
| 消灭「200 + 空 body」表达不存在 | `/api/v1/file`、`/api/v1/open` 对从未有快照的键返回 404 + `{"ok":false,"state":"absent","path":...}`（不含 `content`）；有快照且内容为空返回 `state:"empty"` + 空文件 `content_hash` + `size:0`；正常返回 `state:"present"` + `content_hash` + `size`（UTF-8 字节）。`recent/file` 副本缺失（无墓碑）同口径 404 absent；SSE `hello` 附带 `state`（未登记键为 absent） |
| 快照判定口径 | 新增 `_has_snapshot`：内存会话 `rev>0`（客户端确实推送过内容，含显式清空）或磁盘文件存在（0 字节也算）；外部键无磁盘，仅 `rev>0` 才算快照 → 服务重启/会话回收后回到 absent（设计如此） |
| 外部路径键命名空间 | 新增 `ext2-<device_id 前 8 位>-<sha1(绝对路径) 前 10 位>-<文件名>`；`_is_external_key` 同时识别旧 PC `ext-<sha1 前 10 位>-<文件名>` 与旧安卓 `_ext/<hashCode>/<文件名>`（只读兼容，不删不迁移）；`_load_from_disk` 对这三类键恒返回空，绝不误读同步根同名文件；“是否同一份文件”只由 `content_hash` 判定 |
| 客户端红线（规格） | 新增 `docs/proto-2026-11-05-absent-and-namespace.md`：收到 absent/empty 绝不可删盘、移盘、归档；absent 后须先 `/save` 建快照再建 SSE；键不得参与内容身份判定 |
验证：`python -m py_compile` 通过；本地隔离实例 13/13 PASS（absent/empty/present、旧 `ext-`/`_ext/` 兼容、同步根 present/空/缺失、SSE hello absent、同步根零新增写入、无 ext 快照文件）。线上 PyInstaller 重建后部署重启：`/health` 正常（`disk_root: deny`），`ext2-` 与旧 `ext-` 未登记键探针均返回 HTTP 404 `state=absent`。快照 `backups\batch92-server-absent-namespace-20261105.zip`（未改 PC/安卓）。
部署：2026-11-05 22:22:04 CST 飞牛 `markor-lockserver.service` 重启生效（旧启动 18:30:43）；二进制 SHA256 `1036D5B0ABEF5DAA4010E87C8674ED1720D5BB09FA1A8C42A86CF937B4E75D22`，`main.py` SHA256 `6B42C6FB2B95EFE17831C6D85C9A91DE16732304B631063CF13F2781519B3200`。

## 2026-11-05 第五十四轮：服务端连续 5 轮审查 Round 1 修复（batch94，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 1 发现 4 项 + 复审补充 1 项）。

| 需求 | 变更 |
|---|---|
| R1-1（P1）ack 身份命名空间混用 | 新增有界 `DEV_NAME_ALIAS`（device_id → device_name，FIFO 上限 8192）：`/open`（含 absent）、SSE、writer claim/release、安卓 publish 处登记；`/recent/ack` 在别名命中时同步写设备名 ack 并补入 participants。修复真机上 `acked.get(owner)` 恒缺失 → `converged` 恒 False → 快照永不删除、RECENT_ROOT 无界增长（batch77 的 owner 门槛此前仅靠“无 device_id 回落设备名”偶然成立） |
| R1-2（P2）锁内发送 | `/recent/ack` 的 410/415、writer claim/release 的 409 改为锁内只置结果、锁外 `_send`，慢客户端不再持 `_recent_io_lock`/`_lock` 阻塞全服 |
| R1-3（P2）ack 旧对象收敛误删 | ack 取锁后复核 `FILES` 身份：当前会话已换且 `rev>0`（有未落盘编辑）时返回 503 busy 退避；否则切到当前对象并持其 oplock 再判定收敛 |
| R1-4（P3）ext2 正则过严 | `EXT2_KEY_RE` 放宽为 `^ext2-[A-Za-z0-9-]{1,8}-[0-9a-fA-F]{10}-[^/]+$`，匹配安卓 Syncthing ID 前 8 位含 `-` 与不足 8 位的 `android` 回退，外部键不再被当作同步根相对路径 |
| R1-5（P1，复审补充）空会话覆盖发布内容 | `/file`、`/open` 先查内存会话与磁盘快照，绝不为“从未有快照”的键建空 entry；publish 新增 `copy_real` 判定（`rev>0` 或副本磁盘存在才算真实快照）。修复 absent open 留下的 `rev==0` 空会话被 SV-BL2 当作“他端旧副本”→ 首次 publish 把发布内容替换成空串的数据丢失 |
| R2-1（P2，回归）墓碑降级 | `/file`、`/open` 的 absent 预检并入 `_recent_tombstoned_nolock`：墓碑期内不再短路 404，交由 `_entry_get_or_create` 返回 410，与 `/recent/file` 口径一致 |
| R2-2（P2，回归）锁序反转 | ack 切换当前会话时不再在 `_lock` 内取 oplock：`_lock` 内只取 `cur/cur_rev`，旧对象 oplock 释放后在锁外获取；内容阶段身份复核失败即 503 退避（`oplock → _lock` 锁序恢复） |

验证：`python -m py_compile` 退出码 0；本地隔离实例（端口 18912，临时 DISK/RECENT）15/15 PASS——ext2 带 `-`/短前缀 absent→save→present、owner ack 收敛 settled、非 owner 单端 ack 不 settled、settled 后 410 墓碑、显式删除 410 且 `/file`/`/open` 同为 410、empty 三态、启动零写自检 `disk_root=deny`。快照 `backups\batch94-...`（R1）与 `batch95-...`（R2）（未改 PC/安卓）。

## 2026-11-05 第五十五轮：服务端连续 5 轮审查 Round 3 修复（batch96，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 3 发现 2 项，均 P2）。

| 需求 | 变更 |
|---|---|
| R3-1（P2）外部键源会话存在性判定错误 | 新增 `_origin_exists(origin)`：外部键（`ext2-…`/`ext-…`/`_ext/…`）在服务器上没有磁盘快照，存在性只由在线源会话决定，不做同步根 `isfile`。`_resolve_session_path`（ALIAS 命中与同名兜底）与 GC 的 ALIAS 存活校验统一改用它；同名兜底排除外部键；`_disk_mtime` 对外部键返回 0.0。修复：信根外文件发布副本后 ALIAS 在 10s 内被 GC 删除 → 多端各自使用副本会话、源端 `/save` 不再镜像回副本（实时协同整体失效）；publish 新旧判定可能 stat 到同步根同名无关文件 |
| R3-2（P2）ack 收敛未复核采样身份 | `/recent/ack` 在 `entry is None` 分支读盘计算 `snap_hash` 后，收敛判定前于 `_lock` 内复核 `FILES.get(ckey) is entry`；不一致则 `busy=True` 返回 503 重试。修复并发 `open`/`op`/`save` 在采样窗口内建出新会话并写入 `rev>0` 编辑时，ack 以过期样本 settle → `unlink` + `FILES.pop` 丢弃未落盘编辑并删快照 |

验证：`python -m py_compile` 退出码 0；本地隔离 R3 回归 13/13 PASS（外部源副本经 `_resolve_session_path` 与越过 GC 周期仍镜像、副本 open/op 并入外部源会话、ack 收敛与重放 410）；上一轮 15/15 PASS 无回归。快照 `backups\batch96-server-round3-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试）。

## 2026-11-05 第五十六轮：服务端连续 5 轮审查 Round 4 修复（batch97，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 4 发现 4 项：2×P2、2×P3）。

| 需求 | 变更 |
|---|---|
| R4-1（P2）无快照源会话遮蔽副本 | `_resolve_session_path` 并入源会话前增加 `_has_snapshot(origin, origin_entry)` 判定（stat 在 `_lock` 外）；`_migrate_subs` 取锁后以同口径复核 `dst`；`/recent/file` 对“外部键源会话 `rev==0`”不再返回空内容，回落到副本磁盘快照。修复副本键在 `/open`、`/file`、`/recent/file` 分别得到 absent/empty/present 的矛盾口径 |
| R4-2（P2）absent→empty 缺失 | `_handle_save` 锁外计算 `had_snapshot`：无快照的键首次显式 `/save` 空内容也抬 `rev` 并广播。修复空文件永远建不出 `empty` 快照（`/file`、`/open`、SSE hello 仍报 absent），多端无法建立空文件基线。已有快照的重复空 save 不抬 rev |
| R4-3（P3）墓碑后仍登记参与者 | `/open` 的 `_mark_participant_nolock` 移入 `if not gone:`。修复 delete 已 pop `SNAP_META` 后并发 open 又重建参与设备，导致同名副本下次 publish 后 ack 永不收敛、RECENT_ROOT 无界增长 |
| R4-4（P3）discard close 未复核 rev | `/close` 的 discard 分支删除条件追加 `entry.rev == rev`。修复 close 采样后到达的他端 `/op` 未落盘编辑随会话被丢弃（与非 discard 分支口径一致） |

验证：`python -m py_compile` 退出码 0；本轮新增 R4 回归 18/18 PASS（absent→empty、空快照不重复抬 rev、无快照源会话不遮蔽副本且源端推送后恢复并入、最近页 absent/empty/410、discard close 保留快照）；R3 13/13 PASS；rd1 15/15 PASS。快照 `backups\batch97-server-round4-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试）。

## 2026-11-05 第五十七轮：服务端连续 5 轮审查 Round 6 修复（batch99，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 6 分块 C+D，发现 3 项：2×P2、1×P3）。

| 需求 | 变更 |
|---|---|
| R6-1（P2）重启后外部源副本被并进同步根同名文件 | publish 落盘成功且源为外部键时写隐藏标记 `.origin-<sha1(basename)[:16]>.json`（内容为源键，走 RECENT_ROOT 白名单）；`_resolve_session_path` 别名缺失时见有效标记即留在副本会话，不走同名兜底；`/recent/delete` 成功后清除标记；GC 空设备目录判定忽略标记并在 `rmdir` 前一并删除。修复 `ALIAS` 重启丢失后副本按 basename 并入同步根同名会话（`_migrate_subs` 在 src 不存在时直接成功），导致串文件/内容写进错误文件，违反“外部键永不读同步根同名文件”规格 |
| R6-2（P2）落盘前的 rev 复核与写盘分属两个临界区 | GC 空闲回收、`/save` 主落盘、publish 副本回声刷新、`/close` 末次落盘四处，把 rev 复核与 `_flush_recent` 收进同一 `entry.oplock` 临界区（复核在 `_lock` 内、写盘在 `_lock` 外仍在 oplock 内）。修复复核后到写盘之间到达的 op 被旧快照覆盖回磁盘，`/save` 仍回报 `persisted=true` 而磁盘为旧内容 |
| R6-3（P3）`writer_changed` 广播乱序 | `_broadcast` 对 `type=="writer_changed"` 且 `writer_rev < entry.writer_rev` 的帧直接丢弃（claim/release/watchdog 均在释放 `_lock` 后才广播，顺序可能与 rev 相反）。修复客户端收到过期写权帧后误判写权回退、提示抖动 |

验证：`python -m py_compile` 退出码 0；本轮新增 R6 回归 9/9 PASS（外部源副本 publish→重启→同步根同名会话 open 后副本仍为 `EXTERNAL-COPY`、标记不进 `/recent/list`、delete 后标记清除）；rd1 15/15、R3 13/13、R4 18/18 PASS。快照 `backups\batch99-server-round6-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。

## 2026-11-05 第五十八轮：服务端连续 5 轮审查 Round 7 修复（batch100，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 7 分块 E+F，发现 2 项：2×P3）。

| 需求 | 变更 |
|---|---|
| R7-1（P3）设备删除不清理外部源标记 | `/recent/device/delete` 在 `rmdir` 前遍历删除 `.origin-*.json`；GC 空设备目录判定改为“无用户文件（`entries` 为空）或仅 `.platform`”均可清理（`entries and entries != [".platform"]` → continue）。修复标记以 `.` 开头不在删除列表内 → `rmdir` ENOTEMPTY，而 GC 只清理“仅剩 `.platform`”的目录（`.platform` 已被设备删除移除）→ 目录与标记永久残留、`/recent/devices` 出现 0 副本幽灵设备 |
| R7-2（P3）GC 目录清理与 publish/delete 无互斥 | GC 设备目录清理整段用 `_recent_io_lock.acquire(blocking=False)` 串行化，锁被占用则本轮跳过（60s 后重试）。修复 `rmdir` 插在“建目录 → 写副本”之间令在途 publish 落盘 ENOENT、或先删 `.platform` 后 rmdir 失败留下缺元数据目录。锁序仍为 `_recent_io_lock → _lock` |

验证：`python -m py_compile` 退出码 0；本轮新增 R7 回归 11/11 PASS（标记写入、`/recent/list` 隐藏、publish 改源清除旧标记、设备删除后目录与标记消失、无幽灵设备）；rd1 15/15、R3 13/13、R4 18/18、R6 9/9 PASS。快照 `backups\batch100-server-round7-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。

## 2026-11-05 第五十九轮：服务端连续 5 轮审查 Round 8 交叉复核修复（batch101，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 8 全量复核轮，发现 1 项 P3；另附 5 组交叉点逐条结论）。

| 需求 | 变更 |
|---|---|
| R8-1（P3）GC 设备目录清理漏判「无心跳但仍有内存会话」的设备 | GC 存活判定追加 `busy_devs`（`FILES` 中 `recent/<dev>/…` 的设备名），与 `LAST_SEEN` 一同跳过。`/save`、`/close` 落盘只持 `entry.oplock` 不持 `_recent_io_lock`，原判定会在设备 24h 无心跳但仍有内存 entry、且副本文件不在磁盘（落盘失败/被外部删除）时对其目录 `rmdir`，与在途 `_flush_recent` 的「`makedirs` → `mkstemp`」交叉 → 保存 ENOENT 回报 `persisted:false`，或留下缺 `.platform` 的目录。publish/delete/迁移由 `_recent_io_lock` 挡住，save/close 由会话存在性挡住，两类写入均与清理互斥 |

验证：`python -m py_compile` 退出码 0；rd1 15/15、R3 13/13、R4 18/18、R6 9/9、R7 11/11 PASS；交叉点结论（标记四象限、写盘临界区 × `_recent_io_lock`、writer token × SSE 断连 × 帧序、三态 × 重启 × 墓碑、自检 × 标记目录）均无新增缺陷。快照 `backups\batch101-server-round8-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。

## 2026-11-05 第六十轮：服务端连续 5 轮审查 Round 9 修复（batch102，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 9：`/op`/`/struct`、`/recent/ack`、`/file`、writer claim，发现 1 项 P3）。

| 需求 | 变更 |
|---|---|
| R9-1（P3）已注销设备残留于其它副本的 participants，快照永久无法收敛 | `/recent/device/delete` 在 `_lock` 内扫描 `SNAP_META`，把该设备名及 `DEV_NAME_ALIAS` 中映射到该名的 device_id 从 `participants` 移除、并从 `acks` 删除；清理先于「`recent/<dev>/` 是否存在」的早退（设备可能只参与过别人的副本、从未 publish 自己的目录，实测 `deleted:0` 仍清理）。修复残留参与者使 `all(acked.get(d)==snap_hash ...)` 恒 False → 该副本永不删除、`RECENT_ROOT` 无界增长 |

其余核对项均无缺陷：`/op`/`/struct` 的 rev 递增与广播同处 `entry.oplock`（顺序严格）、重复投递幂等、行号越界夹取、`\r\n` 原样保留、单行/总量双上限；ack 无「部分设备已取回」误判（owner 门槛 + `all()`）；ack 收敛删除后 `/recent/file` 先 410（10s 墓碑）再 absent（R9 实测）；`/file` 读盘 16MB 上限、非 UTF-8 → 415、BOM 口径与 `/save`/ack 一致；writer force 接管 rev 单调、旧 holder 不自动抢回、`_touch_participant_nolock` 不改 writer。

验证：`python -m py_compile` 退出码 0；R9 新增回归 10/10 PASS；rd1 15/15、R3 13/13、R4 18/18、R6 9/9、R7 11/11 PASS。快照 `backups\batch102-server-round9-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。


## 2026-11-05 第六十一轮：服务端连续 5 轮审查 Round 10 修复（batch103，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 10：`/save`×op、SSE 重连×回收、`/health` 审计、异常路径、资源上限，发现 4 项：2×P3 + 2×P4）。

| 需求 | 变更 |
|---|---|
| R10-1（P3）SNAP_META 无独立回收，长期无界增长 | 新增 `_prune_stale_snap_meta()`：清理「既无磁盘快照、也无 `FILES` 会话」的参与者记录；stat 在 `_lock` 外、回锁复核 `FILES`，调用点在 GC 的 `tick%6` 段内（持 `_recent_io_lock`，与 publish/delete/ack 互斥）。修复 SSE 对任意 `recent/<dev>/<name>`（含 absent/已删文件）登记参与者后，会话回收而 meta 永久驻留、按文件名累积 |
| R10-2（P3）SNAP_META["acks"] 无上限 | ack 仅在 `device_id`/`alias` 属于 `participants` 时记录（alias 先并入 participants 再判）。修复 `participants` 有 256 上限而 `acks` 无上限，任意 device_id 反复 ack 使单条快照 dict 无界增长；收敛语义不变 |
| R10-3（P4）`recent_writes` 漏计 meta 写入 | `_write_text_atomic` 成功 `os.replace` 后 `_note_write("recent", full)`，使 `/health` 口径覆盖 `.platform` 与 `.origin-*.json` 写入；失败路径不计数 |
| R10-4（P4）hello 的 `disk_ok` 一次性探测过期 | SSE 注册循环每次尝试重算 `_disk_snapshot_exists(path)`（仍在锁外），避免 entry 被 delete/GC 换掉重建后 hello 以 absent 报出非空 content（或反之） |

其余核对无缺陷：`/save` 与 op 共用 `entry.oplock`，rev 复核与落盘同临界区，save 不会覆盖更新的 op、`persisted` 与真实落盘一致；SSE 注册有身份/墓碑复核与 5 次重试，老订阅随 delete/ack 清 subs、迁移改写 `sse.entry`，无残留；审计计数无漏计/重复（R10-3 修复后）；异常路径的锁均经 `with`/`finally` 释放，半建 entry 由 GC 回收、writer 由 watchdog 清空；`LAST_SEEN`/`DEV_NAME_ALIAS`/`ALIAS` 等均有界，`SNAP_META` 由本轮补齐回收。

验证：`python -m py_compile` 退出码 0；R10 新增回归 14/14 PASS；rd1 15/15、R3 13/13、R4 18/18、R6 9/9、R7 11/11、R9 10/10 PASS。快照 `backups\batch103-server-round10-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。

## 2026-11-05 第六十二轮：服务端连续 5 轮审查 Round 12 修复（batch104，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 12：主链端到端连读、外部键全流程、三组并发时序，发现 1 项 P3）。

| 需求 | 变更 |
|---|---|
| R12-1（P3）`/open` 在孤儿 entry 上申领 writer / 登记参与者 | `_handle_open` 取样整段改为最多 5 次「锁内复核 `FILES.get(key) is entry` + 失效重解析」，与 SSE hello 建连口径一致；重解析后重判墓碑 410 / 不可解码 415 / 无快照 404，5 次仍失效则 503。修复 open 从 `_entry_get_or_create` 返回到取样之间 entry 被 GC/close 换掉时，在已不在 `FILES` 的对象上申领 writer（返回指向本端的假令牌，真实 entry 由另一台设备持有 → 双端同时保存）、登记参与者（随孤儿对象丢弃，ack 收敛漏设备）、`peers` 漏在线设备。内容本身不受影响（pop 前一律已落盘，孤儿与磁盘同内容），属令牌/参与者状态中断 |

其余核对无缺陷：主链 open→op→save→SSE 重连→close→另一台 open→ack→删快照逐跳一致（rev 与 content 同临界区、save 落盘前复核 rev、hello 与订阅同临界区且 `_broadcast` 锁外写帧、close 落盘后才 pop）；外部键 publish→`.origin`→重启→open 副本→保存→源外部删除闭环（别名/标记先于/后于落盘时机正确、重启后按标记拒绝同名兜底、外部键不 stat 同步根、settle 后保留标记防串内容）；三组并发（publish×GC、delete×SSE hello、ack×另一设备 open）均由 `_recent_io_lock`/`oplock`/`_lock` 给出确定性顺序，仅存在有界且自纠正的 hello→closed 窗口，不丢编辑、不复活快照。

验证：`python -m py_compile` 退出码 0；R12 新增回归 13/13 PASS；rd1 15/15、R3 13/13、R4 18/18、R6 9/9、R7 11/11、R9 10/10、R10 14/14 PASS。快照 `backups\batch104-server-round12-fixes-20261105.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。
## 2026-11-06 第六十三轮：服务端连续 5 轮审查 Round 14 修复（batch105，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 14：数据正确性与磁盘一致性，发现 2 项 P3）。

| 需求 | 变更 |
|---|---|
| R14-1（P3）落盘残留 `.mktmp-*` 被 GC 当作用户文件，空设备目录永不回收 | GC 设备目录回收段把 `.mktmp-*` 与 `.origin-*.json` 一并从 `entries` 剔除，并在回收时 `unlink`。原实现只剔除 origin 标记，进程在 `os.replace` 前被杀/崩溃留下的 tmp 会让 `entries != [".platform"]` 恒成立，设备目录永久残留；`/recent/delete` 与 device-delete 的 `rmdir` 也因 ENOTEMPTY 静默失败。残留本身不会被任何读端点误读（list/devices/device-delete 均过滤 “.” 开头，`_full_path` 只按精确名寻址） |
| R14-2（P3）`_flush_recent` 在 `os.replace` 前未 fsync，断电窗口可把副本写成 0 字节 | 临时文件写完内容后 `f.flush()` + `os.fsync(f.fileno())` 再 `replace`；`OSError` 容忍并记日志，不支持 fsync 的文件系统不因此把落盘整体判失败。原实现断电/宿主机崩溃时重命名可能先持久化而数据块未落盘，副本变 0 字节被读成 `empty`，而内存 entry 往往已被 GC 回收，权威内容不可恢复。`_write_text_atomic` 只写 `.platform`/`.origin` 元数据（可重建），未加 fsync |

其余核对无缺陷：tmp 与目标同目录、`replace` 原子、kill 在 replace 前/后状态确定，`finally` 只清理未 rename 的 tmp；`_load_from_disk`↔`_flush_recent` 为 utf-8 严格、BOM 保留、LF 内容往返 hash 不变（含 CRLF 的副本会被归一，但 `RECENT_ROOT` 仅本服务写入且三端 publish 内容已 LF 归一，不可达；同步根只读，保持通用换行才与客户端 hash 同口径）（Round 27 注：自 R16 起三读三写统一为**剥离前导 U+FEFF**，`content_hash`/`size` 按剥离后的内容计算；“BOM 保留”的表述已被取代，以 `docs/proto-2026-11-05-absent-and-namespace.md` 为准）；路由 `recent/<dev>/<name>` 跨设备隔离、外部键与同步根同名由 `.origin` 标记 + 同名兜底排除隔离（同设备同名不同源按协议同名覆盖，记为已知限制）；GC 只回收仅含 `.platform`/标记/tmp 且 24h 无活动的目录，不会删正在被 `/file` 读取的内容文件；长期运行的内存/磁盘背离均有明确回收与重建路径。

验证：`python -m py_compile` 退出码 0；R14 新增回归 17/17 PASS；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16 PASS。快照 `backups\batch105-server-round14-fixes-20261106.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。
## 2026-11-06 第六十四轮：服务端连续 5 轮审查 Round 15 修复（batch106，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 15：fsync 成本与语义 / tmp 误删窗口 / 三端哈希口径 / oplock 排队，发现 1 项 P2）。

| 需求 | 变更 |
|---|---|
| R15-1（P2）副本内容在磁盘往返中被行尾归一改写，`content_hash` 与客户端口径不一致 | `_flush_recent` 的比较读与写盘、`_load_from_disk` 三处内容 I/O 统一加 `newline=""`。原实现用默认 `newline=None`：LE 环境读回把 CRLF 归成 LF（他端 `/recent/file` 拿到的内容与发布端原文不同、`size` 与实际字节不符，归一后的快照 hash 与客户端 ack 的原文 hash 永不相等 → 快照永不收敛）；Windows 环境写盘把 `\n` 翻成 `\r\n`，原文 `\r\n` 落盘成 `\r\r\n`、读回成 `\n\n`。触发入口是 PC `FileSidebar.cpp:526-546`：以 `TextEncoding::decodeForDisplay` 读原始文件内容后直接 `publishRecent`（编辑器之外的第二条发布入口，不做行尾归一）。客户端比较侧不受影响（PC `BaselineStore::normalize`、安卓 `BaselineConflict.normalize` 判定前都会剥 BOM/CRLF→LF/尾部单 LF） |

其余核对无缺陷：R14 的 fsync 在 GC 路径于 `_recent_io_lock` 之外、只持该文件 oplock（实测阻塞 fsync 期间他端 publish 0.018s 完成、`recent_io_lock` 立即可取），且成功落盘即回收 entry，无重复 fsync，无需批量合并；fsync 失败容忍后 `persisted:true` 的语义正确（`persisted` 指“已 replace、进程重启可读”，fsync 只影响断电持久，失败仅见于不支持 fsync 的 FS，改判 false 会让 GC 永不回收、客户端反复重试）；`.mktmp-*` 剔除无在途误删窗口（名单取 listdir 快照，先建 tmp 必刷新目录 mtime 触发 86400s 门槛，后建 tmp 不在名单内）；三端哈希规则一致（UTF-8 原文 SHA-256 小写，BOM/CRLF/尾换行均不归一）；`/op`、`/save`、`/close` 共用 oplock 无饿死路径，仅有既有的队头阻塞（SV-T6 权衡，不改）。

验证：`python -m py_compile` 退出码 0；R15 新增回归 11/11 PASS；R14 17/17、rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16 PASS，合计 130 项。快照 `backups\batch106-server-round15-fixes-20261106.zip`（未改 PC/安卓，未清理临时测试，未部署服务器）。


## 2026-11-06 第六十五轮：R16-F4 服务端内容规范化 + Round 17 审计（batch107，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md`（Round 16：多入口发布/读取路径与 BOM/行尾口径，发现 5 项，本轮只修服务端 F4；Round 17：单权威形态复核 + `.platform` GC 残余，发现 1 项 P3）。

| 需求 | 变更 |
|---|---|
| R16-F4（P2）服务端内容规范化不统一：`_load_from_disk` 保留 BOM、`_content_digest` 按含 U+FEFF 的串算 hash | 统一契约：规范内容 = 无前导 U+FEFF 的文本，行尾与尾部换行按收到原样保留；`content_hash = sha256(utf8(规范内容))`，`size` 为规范内容 UTF-8 字节数。新增 `_normalize_content`（剥掉全部前导 U+FEFF），接入 `_load_from_disk`、`_content_digest`、`_state_fields`、`/file`、`/open`、`/recent/file`、SSE `hello`、`/save`、`/recent/publish`、`/op`（仅 row 0）、`/struct`（仅文档开头插入）、`_flush_recent`；行中/行尾 U+FEFF 与 CRLF/CR/LF 原样保留。`/recent/list` 的 `size` 改用 `_canonical_utf8_size`（前 3 字节探测 BOM，命中按 `st_size-3`），与内容端点同口径 |
| 存量 BOM 副本与旧 ack | 基线 `_PUBLISHED_LOCAL`、`SNAP_META` 均为内存态，重启即清空，无需迁移 hash；客户端 ack 一直是规范 hash，修复前服务端 `snap_hash` 含 BOM 导致永不收敛，修复后旧快照可直接收敛（回归 H5 验证）。磁盘存量副本由启动时的 `_migrate_bom_snapshots()` 一次性改写为无 BOM 形态（只探测前 3 字节，命中才走 `_flush_recent`；失败不阻断启动，读路径归一仍保证 hash/size 一致） |
| R17-1（P3）`.platform` 不存在时 GC 的 `unlink` 抛 ENOENT，`rmdir` 永不执行 | GC 空设备目录回收段的 `.platform` 删除改为独立 `try/except OSError`，失败不影响随后的 `os.rmdir`。原实现无条件 `unlink`，目录无 `.platform`（device-delete/外部清理先行删除）时抛 `FileNotFoundError` 被外层 `except OSError` 吞掉，紧邻的 `rmdir` 永远执行不到，无主设备目录永久残留 |

其余核对无缺陷：写入侧 `/save`、`/recent/publish`、`/op`（含 struct）、`_migrate_subs`、publish 的 adopt/conflict 回传内容进入 `entry.content` 前均已归一，`_flush_recent` 再兜底；读取侧 `/file`、`/open`、`/recent/file`、SSE `hello`、conflict `content` 同源同口径；摘要侧基线、`copy_foreign` 判定、ack `snap_hash`、`/save` 镜像判定全部走 `_content_digest`，无第二套 hash；磁盘侧启动迁移 + 落盘归一一，RECENT_ROOT 同一副本只剩一种字节形态。R16-F1/F2/F3/F5（PC/安卓多入口编码差异）属客户端代码，按指令未改，待客户端同步。

验证：`python -m py_compile` 退出码 0；R16 新增回归 39/39、R17 新增回归 10/10；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12，合计 180 项全部 PASS。快照 `backups\batch107-server-round16-17-20261106.zip`（未改 PC/安卓，未部署服务器）。


## 2026-11-06 第六十六轮：Round 18 专项审计（`_normalize_content` + 启动迁移，batch108，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 18。结论：发现 1 项 P3，已修复 → 连续零问题计数清零（当前 0 轮）。

| 需求 | 变更 |
|---|---|
| R18-1（P3）启动迁移改写 BOM 副本后 mtime 变为启动时刻，`/recent/list` 按 mtime 倒序导致存量副本集体跳到最近页顶部 | `_migrate_bom_snapshots()` 迁移前捕获原 `st_atime_ns/st_mtime_ns`；`_flush_recent` 成功改写后 `os.utime(full, ns=(原 atime, 原 mtime))` 还原，失败只忽略（内容已规范，优先可读）。回归 A2 验证逐纳秒不变且 list 顺序/mtime 字段不变 |
| 专项复核（无其它缺陷） | ① 前导 U+FEFF 归一符合统一契约（无前导 BOM），行中/行尾 U+FEFF 与行尾符保留；`/op` 仅 row 0、`/struct` 仅文档开头插入剥文档 BOM；各写入入口统一归一后再入 `entry.content`，落盘再兜底，无内存/磁盘双形态。② 迁移在 HTTP 服务启动前执行，无并发读；半途失败时读路径归一 + list 的 `_canonical_utf8_size` 仍同口径。③ `_canonical_utf8_size` 对 <3 字节、纯 BOM、打开失败均安全；BOM+非法 UTF-8 的残余仅在 list 显示 size-3、内容端点本身 415 且无摘要可比，记录不改（合法性识别需整篇解码，轮询成本不可接受）。④ 旧 BOM 副本迁移后 `/file` content 与磁盘字节一致、hash/size 规范；客户端本地 3 字节差异仅为本地 BOM，baseline/ack 同函数同口径，无误报冲突。⑤ 多点连续 BOM 服务端全部剥掉；`/save` 响应不含 `content_hash`，`/file` hash 与 ack 规范 hash一致并可收敛；客户端必须同样剥“全部前导 BOM”，并入 R16-F1/F2/F3 客户端同步任务 |

验证：`python -m py_compile` 退出码 0；R18 新增回归 37/37；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12、R16 39/39、R17 10/10，合计 190 项全部 PASS。快照 `backups\batch108-server-round18-20261106.zip`（未改 PC/安卓，未部署服务器）。


## 2026-11-06 第六十七轮：Round 19 专项审计（SSE 半开连接 / release-close / GC 时钟 / 启动顺序，batch109，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 19。结论：发现 1 项 P2，已修复 → 连续零问题计数清零（当前 0 轮）。

| 需求 | 变更 |
|---|---|
| R19-1（P2）SSE 半开连接（NAT 静默失效、无 FIN）无法在 120s 内识别 | `hello` 写完后调用 `_enable_tcp_keepalive`：`SO_KEEPALIVE=1` + `TCP_KEEPIDLE=30/TCP_KEEPINTVL=10/TCP_KEEPCNT=3`；Linux 另设 `TCP_USER_TIMEOUT=60000`（选项 18），因重传期间内核会抑制 keepalive 探针，而应用层 30s 保活帧会制造未确认数据。最坏 30+60≈90s 报错并移除订阅、触发 writer 移交，落入 120s 预算。每个细粒度选项独立 `try/except`，单个不支持不影响其余。修复前 `last_active` 被“成功”小帧写持续刷新，`subs` 与 writer 在线态僵尸到 `tcp_retries2` 放弃（≈15 分钟），期间存在双写风险 |

其余分区无缺陷：① 10 订阅者开销 ≈10 次唤醒/秒，实测广播 0.001s；正常断开 ~1s 移除订阅，半开由 R19-1 兜住；同设备重连先 hello 后摘旧连接、无重复投递；GC + 广播失败清理保证 `subs` 不无界增长（残余：只连不读的慢客户端按 15s/个串行占用 oplock，属既有 SV-T6 权衡）。② release 在存在在线候选时立即移交（非空出），无候选才置 null；真空期 op 仍写权威内容且不改 `writer_rev`；release/close 交替只在真实变更时 +1，非 writer 调用幂等；close 会把设备移出 participants，最后一任 close → null +1。③ GC 为 10s tick 上叠加 30s 空闲落盘 / 60s 目录清理；全部用墙钟，回拨只会延后清理/落盘/掉线判定、不会误删误移交（不切 monotonic 的原因：`content_mtime` 需与磁盘 mtime 比较、`writer_since`/`entry.mtime` 是暴露给客户端的 epoch，记录为残余）。④ 启动顺序为自检 → BOM 迁移 → 线程/HTTP；迁移失败只记日志、不阻断，读路径归一保证 hash/size 同口径；自检不验证 RECENT_ROOT 可写（只读时降级启动、以 `persisted:false`/`[flush]` 暴露，记录不改）。⑤ 部署无需改 systemd/环境变量/端口/目录；`MARKOR_WRITER_*` 有默认值，`recent-sync` 默认在 `ReadWritePaths` 内；单元第 27 行“需写 DISK_ROOT”注释与阶段①不符，仅注释、建议下次顺手更正；部署/回滚步骤见审查报告 Round 19 第 5 项。

验证：`python -m py_compile` 退出码 0；新增 `markor_r19_test.py` 50/50；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12、R16 39/39、R17 10/10、R18 37/37，合计 267 项全部 PASS。`main.py` SHA256 `FEEF2BCD87203772C5510F4BA84AFFE2F63DA90FC8C76672914DBDEACDCFB240`（221231 字节）。快照 `backups\batch109-server-round19-20261106.zip`（未改 PC/安卓，未部署服务器）。


## 2026-11-06 第六十八轮：Round 20 专项审计（TCP keepalive 生效性 / 半开移除 / 客户端心跳 / 令牌真空期，batch110，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 20。结论：发现 2 项 P3，已修复 → 连续零问题计数清零（当前 0 轮）。

| 需求 | 变更 |
|---|---|
| R20-1（P3）systemd 单元注释“需写 DISK_ROOT”与 `ReadWritePaths` 仍授予同步根写权限，违背阶段①零写硬不变式 | 注释改为“同步根只读，唯一可写范围是程序目录下 recent-sync”；`ReadWritePaths` 只保留 `/opt/syncthing/markor/lockserver`，撤掉 `/vol1/1000/Markor`；`MARKOR_DISK_ROOT` 保留供读取。部署需 `systemctl daemon-reload`。回归静态断言单元只含单一可写项且注释与零写口径一致 |
| R20-2（P3）`SO_KEEPALIVE` 失败时提前 `return`，未再尝试 `TCP_KEEPIDLE/INTVL/CNT` 与 Linux `TCP_USER_TIMEOUT` | 改为所有选项独立尝试：`SO_KEEPALIVE` 失败只 `pass`，逐项 `getattr` + 独立 `try/except OSError`。避免受限环境下退化为内核 `tcp_retries2`（≈15 分钟）才识别半开。回归用 fake socket 验证 `SO_KEEPALIVE` 失败后仍下发 `(6,4,30)/(6,5,10)/(6,6,3)/(6,18,60000)`，单选项失败不跳过其余 |

其余四项无缺陷：① 设置在 `accept()` 返回的 `self.connection` 上，父监听 socket 选项不被连接继承、无需重复；Windows 只 `SO_KEEPALIVE`（默认 2h），Linux 30/10/3+`TCP_USER_TIMEOUT=60000`。② 半开时 `select` 返回后 `recv(MSG_PEEK)` 得 `b""`/抛错 → `break` → `finally` 摘订阅并广播 leave；写帧卡住最长 `SSE_WRITE_TIMEOUT=15s`，期间仍视在线（避免误判），失败移除后 watchdog 2s 内移交，正常掉线 ≤17s、静默半开 ≈90s。③ 服务端 keepalive 是注释帧 `: keepalive\n\n`，PC 只处理 `event:`/`data:` 不派发，安卓空行结束事件、注释行忽略，两端均不会当事件；PC `_lastSseEventMs` 仅诊断口径、心跳不刷新，记录不改。④ release/close 仅在真实变更时 `writer_rev+1`；真空期 op 仍被接受（协议 §8），半开窗口内旧 writer 写入不丢、由下一次响应/hello 的 writer 字段与内容 rev 收敛；真正分区双写属 §7.4 客户端职责，记录为残余。⑤ unit 矛盾已修；只读 RECENT_ROOT 维持降级启动（`persisted:false` + `[flush] FAIL`），不 fail-fast。

验证：`python -m py_compile` 退出码 0；新增 `markor_r20_test.py` 35/35；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12、R16 39/39、R17 10/10、R18 37/37、R19 50/50，合计 302 项全部 PASS。`main.py` SHA256 `73B59A8D2A6AD66E4230B6331736319A448C32FBA4F07CE0E721926E2E33615C`（221410 字节）；`markor-lockserver.service` SHA256 `C42738EFE25ECFEF66BDE31AB6D74A920B6FA36B5F75CDB2E463AE132B8148AB`（1009 字节）。快照 `backups\batch110-server-round20-20261106.zip`（未改 PC/安卓，未部署服务器；部署需 `daemon-reload`）。


## 2026-11-06 第六十九轮：Round 21 专项审计（可观测性 / 异常吞吐 / 状态自愈 / 单元一致性 / R6–R20 交叉回归，batch111，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 21。结论：发现 6 项（1×P2 + 5×P3），已修复 → 连续零问题计数清零（当前 0 轮）。

| 需求 | 变更 |
|---|---|
| R21-1（P2）外部来源标记 `_set_external_origin_marker` 的 `_write_text_atomic` 异常会穿透 publish/delete 的 `try/finally`，连接被重置、响应丢失，且 R6-1 的同名兜底保护被静默撤销 | 标记写改为 best-effort：捕获 `OSError` 并记 `[flush] FAIL marker <path>: <err>`，内容落盘与 publish 响应不受影响 |
| R21-2（P3）`_broadcast` 写失败摘除订阅者无日志，SSE 线程 `finally` 因 `removed=False` 也不再打 LEAVE；GC 僵尸清理、设备删除 closed 推送同样无痕 | `FileEntry` 增加 `path` 槽；新增 `[sse] DROP path=<文件> dev=<设备> reason=write_fail err=<repr>`；GC 记 `reason=idle>60s`；设备删除记 `reason=device_deleted` |
| R21-3（P3）keepalive 选项设置失败完全静默，`TCP_USER_TIMEOUT` 失败时半开识别可能悄悄退化到 ≈15 分钟 | 新增 `_keepalive_warn`：每选项每进程仅告警一次，含选项名与异常；常量不存在（平台本就不支持）仍静默 |
| R21-4（P3）删除设备时 `listdir` 失败静默返回 `deleted=0`，调用方误以为无副本 | 记 `[recent] device delete listdir FAIL <dev>: <err>` |
| R21-5（P3）`_send` 只捕获 BrokenPipe/ConnectionReset，`ConnectionAborted`/`socket.timeout` 冒泡到 `handle_error`，每失败请求打一整段栈 | 改为捕获 `OSError` 并 `close_connection=True`，不再刷 traceback |
| R21-6（P3）会话迁移（副本→源）无任何日志，难以排查“打开 A 实际编辑 B” | 记 `[sse] MIGRATE <src> -> <dst> subs=<n> merged=<bool> writer_moved=<bool>` |

其余分区无缺陷：① `/health` 的 `write_scope`（含 `last_recent`）与 `writers` 计数为聚合口径，具体归属由 `[writer]`/`[sse]`/`[flush]` 日志补齐（本轮新增 DROP/MIGRATE 后，掉线与迁移可定位到文件+设备+原因）；剩余静默点仅 `.platform` 高频元数据写（避免刷屏）、旧文件读取失败（随后写失败会打 FAIL）、平台常量缺失。② 请求体 16MB 上限、Content-Length 非法 411/400、错误 JSON 400 关连接、未知路由 404、超大 row 400、超长 path/dev 前置拒绝，均有界；未做每 IP 限流/日志节流，`ThreadingHTTPServer` 线程无上限，公网暴露需前置代理限速（记录为残余）；SSE hello 在全局锁内写最多占锁 15s 属 SV-H6 既有权衡。③ entry 被 GC 后 open 走“墓碑 410 / 磁盘快照重建 rev=0 / 404 absent”，服务端从不把旧内容推给客户端；publish 基线缺失/过期时以磁盘副本为 authority 返回冲突，旧内容不会覆盖较新副本；重建条目可被选 writer，但只有无其他订阅时才会 GC，不会抢活跃写权；客户端 baseline 脏净判断属客户端职责。④ unit 与代码一一对上：`ExecStart` → `sys.argv[0]` → `RECENT_ROOT=<程序目录>/recent-sync`，在 `ReadWritePaths` 内；`MARKOR_DISK_ROOT` 只读、`MARKOR_LOCK_PORT` 同值；BOM 迁移写 recent-sync；`PrivateTmp` 适配 PyInstaller；`MARKOR_API_KEY` 占位符部署必须替换。本轮 unit 未改，无需 `daemon-reload`。⑤ R6–R20 逐项复核无修复被后续改动直接抵消：R6-1 因 marker 写失败可退化，本轮已转为“publish 仍成功 + 明确日志”；R14-2/R15-1 的 fsync/newline 未覆盖元数据 `_write_text_atomic`，但元数据可重建且值不含换行，记录为残余；其余（R6-2/6-3、R7-1/7-2、R8-1、R9-1、R10-1~4、R12-1、R14-1、R16-F4、R17-1、R18-1、R19-1、R20-1/20-2）均完好。

验证：`python -m py_compile` 退出码 0；新增 `markor_r21_test.py` 16/16（Windows 宿主；Linux 另有真实 socket 两项）；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12、R16 39/39、R17 10/10、R18 37/37、R19 50/50、R20 35/35，合计 318 项全部 PASS。`main.py` SHA256 `48ECF8A34F45645A4029116B5EFE84CD4A87001223C1DEB467925EF04E677AFE`（224568 字节）；`markor-lockserver.service` 未改。快照 `backups\batch111-server-round21-20261106.zip`（未改 PC/安卓，未部署服务器；本轮无需 `daemon-reload`）。

## 2026-11-06 第七十轮：Round 22 专项审计（新日志与容错自审，batch112，本地验证，未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 22。结论：发现 1 项 P3，已修复 → 连续零问题计数清零（当前 0 轮）。

| 需求 | 变更 |
|---|---|
| R22-1（P3）并发广播对同一个写失败的订阅者会重复记 `[sse] DROP` 并重复广播 `peer leave` | 删除订阅改为“仅当 `s in entry.subs` 时才 discard 并加入 `removed`”，DROP 日志与补发 leave 只遍历 `removed`。同一连接一次故障至多 1 条日志、1 帧 leave；已被 GC/设备删除先摘的连接不重复记录 |

其余五点无缺陷：① 速率与泄露：DROP 每连接每次故障 1 条，客户端重连最坏约 1 条/3s/路径；GC/设备删除每订阅者 1 条；MIGRATE 每次真实迁移 1 条；`[flush] FAIL marker` 每次 publish 1 条（publish 成功路径本就逐次记录，非新增放大面）；keepalive 告警一次性。无按设备/原因节流，但由连接生命周期天然有界。日志只含相对会话键、设备名、异常 repr，不含 API key/Authorization/内容；`_log` 过滤非打印字符。② `_send`：`json.dumps/encode` 在 `try` 外，`TypeError`/`UnicodeEncodeError` 仍冒泡；`try` 内只有响应写，`OSError` 语义均为“连接不可写”，调用方都把它作为最后语句，无 `finally` 依赖异常清理；`send_response` 的访问日志失败被并入连接已坏，可接受。③ 写失败摘订阅：15s 写超时内的短暂拥塞会被吸收；摘除时机是 SV-T6 既有设计，R21/R22 未改变；重连不会因日志放大。残余：16MB `struct` 帧 + 极慢链路可能误踢、大量同时重连时 `hello` 在全局锁内排队（均既有）。④ marker best-effort：每次 publish（`flush_ok and okey is not None`）都重写 marker，下次 publish 自愈；进程内 ALIAS 仍有效；仅“失败后、下次 publish 前立刻重启”的窗口有风险。判断不新增周期重试（会引入跨线程状态与持续噪声），把 `[flush] FAIL marker` 作为运维告警。⑤ 口径一致：`[sse] DROP` 的 `path=/dev=/reason=/err=` 与既有 `JOIN/LEAVE` 同构，reason 词表（`write_fail`/`idle>60s`/`device_deleted`）与 `[writer]` 无冲突；`[sse] MIGRATE` 与 Round 21 文档一致；仓库内无按 `[sse]`/`[flush]` 字段解析的脚本；`FileEntry.path` 不进入 HTTP/SSE JSON；`main.py.pre-batch77` 为旧备份不参与运行。

验证：`python -m py_compile` 退出码 0；新增 `markor_r22_test.py` 14/14；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12、R16 39/39、R17 10/10、R18 37/37、R19 50/50、R20 35/35、R21 16/16，合计 332 项全部 PASS。`main.py` SHA256 `819D12FBDB8570A30619E6A392CF36F4964DECF2BF35E8ADCA2B2837B6063A79`（225084 字节）；`markor-lockserver.service` 未改。快照 `backups\batch112-server-round22-20261106.zip`（未改 PC/安卓，未部署服务器；本轮无需 `daemon-reload`）。

## 2026-11-06 第七十一轮：Round 23 专项审计（SNAP_META 与 FILES 两套状态机 + 三类恢复态，batch113，本地验证；R23-1 未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 23。结论：发现 1 项 P3，已修复 → 连续零问题计数清零（当前 0 轮）。前置：R6–R22 版本已于 2026-11-06 10:04:58 上线并通过冒烟（`ok:true`、`disk_denied:0`、`NRestarts=0`、`[selfcheck] sync_root=DENY recent=ALLOW`）。

| 需求 | 变更 |
|---|---|
| R23-1（P3）进程重启后 `DEV_NAME_ALIAS` 丢失，owner 的 ack（Syncthing ID）无法映射到路径 owner（设备名），batch77 门槛永不满足 → 快照永不收敛、`RECENT_ROOT` 静默增长 | 新增 `.pub-<sha1(basename)[:16]>.json` 持久发布端标记：publish 落盘成功写入（PC 无 `device_id` 时用别名表反查）；ack 在别名缺失时读标记，**标记 id 与 ack id 相同**才记 `acks[owner]`（其他设备 id 对不上，门槛不被绕过）；settle、`/recent/delete`、device-delete、GC 同步清理标记；GC 与 device-delete 的元数据过滤识别 `.pub-` |

其余三点无缺陷：① `SNAP_META` 写入点为 `_mark_participant_nolock`（SSE/open/publish×2/op/struct/save/copy）、ack、delete、settle、device-delete、prune；读取点为 ack/device-delete/prune。所有整体删除都是整条 pop，participants 与 acks 同生同灭；`participants` 不是独立表，不存在跨表孤儿；无主条目由 prune（≤60s）回收。`_drop_snap_meta` 无调用者（死代码，观察项）。② `FILES` 与磁盘 `recent/`：创建走 `_entry_get_or_create/_entry_revalidate`（`_lock` 内写、读盘锁外），删除有 GC（rev==0/落盘成功）、close、delete、settle、device-delete、迁移六类；目录创建由 `_write_text_atomic` 的 `makedirs`，删除由 delete/device-delete/GC。锁序 `_recent_io_lock → entry.oplock → _lock` 保持，锁内无 `_send`；两套状态机通过 `busy_devs`、rev 复核、`_recent_io_lock` 串行三条约束互相知晓，未见“互不知道”的写路径。③ 恢复态：重启后 open 重建 entry(rev=0)、publish 以磁盘副本为 authority、ack 重建 SNAP_META，唯一缺陷是 R23-1（已修）；`participants` 从空重建会放宽收敛阻塞（可接受，删除依据是磁盘当前 hash）。迁移半途失败时 src entry 与订阅保留、目标副本下次 open 重建基线，是单请求内同步完成，不留半迁移会话。只读 RECENT_ROOT 下 publish 返回 `persisted:false`、save/close 保留内存编辑并重试、收敛判定不依赖写成功，不会误删；唯一静默面是 `.platform` 写失败（既有残余）。残余另记：`.pub-` 标记写失败后立即重启的窗口、device-delete 不清 `entry.participants`（≤15s 瞬时）。

验证：`python -m py_compile` 退出码 0；新增 `markor_r23_test.py` 19/19；rd1 13/13、R3 12/12、R4 17/17、R6 9/9、R7 11/11、R9 9/9、R10 15/15、R12 16/16、R14 17/17、R15 12/12、R16 39/39、R17 10/10、R18 37/37、R19 50/50、R20 35/35、R21 16/16、R22 14/14，合计 351 项全部 PASS。`main.py` SHA256 `2BA88ACA4B485085327B5176AFFEBE7D002220C63970D7DC16C8D5827FD148F1`（229263 字节）；`markor-lockserver.service` 未改，SHA256 仍为 `C42738EFE25ECFEF66BDE31AB6D74A920B6FA36B5F75CDB2E463AE132B8148AB`（1009 字节）。快照 `backups\batch113-server-round23-20261106.zip`（未改 PC/安卓；R23-1 未部署，unit 未变无需 `daemon-reload`）。

部署与冒烟（2026-11-06 10:22–10:26，已上线）：R6–R23 全部上线。新二进制 SHA256 `63673E802420F316248B7F63DE2522B52AB7C7174B6E116B406BA94630796CAA`（7774336 字节），线上源码 `2BA88ACA…48F1`（229263 字节），最终启动 `Fri 2026-11-06 10:26:18 CST`、`NRestarts=0`、`active`。unit 沿用线上原文（`MARKOR_API_KEY=ht5936`，无占位符；`ReadWritePaths` 仅 lockserver 目录；override 无同步根 `ReadWritePaths`），已 `daemon-reload` + `systemctl cat` 复核。备份目录 `/opt/syncthing/markor/lockserver/backups/20261106-102220/`（含 `main.py.r22` 供源码级回滚）；备份步骤首次因普通用户对 root:root 755 的 `backups/` 无权限而失败，当时尚未覆盖线上文件，后续用 root 补齐；覆盖前的 R23 二进制未单独留存（回滚可用 `backups/20261106-100247` 或重建 r22）。`/health` `ok:true`、`disk_denied:0`、`writers.active:1`；`[selfcheck] write scope OK: sync_root=DENY recent=ALLOW`；`[migrate]` 0（存量 BOM 0）；journal `Traceback` 0。冒烟：单 writer、非 writer op 200、静默 16.5s 完成移交（≤17s）、R23-1 重启后 `.pub-` 保留且 owner 单端 ack `settled:true`、快照与标记删除。

## 2026-11-06 第七十二轮：Round 24 `.pub-` 标记族专项（四路齐备 / 命中判定 / 与 `.origin-` 共存，batch114，本地验证；R24-1 未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 24。结论：发现 1 项 P3，已修复 → 连续零问题计数 0（本轮未累积到 1）。前置：R6–R23 已上线（二进制 `63673E80…6CA`，启动 10:26:18，`NRestarts=0`）。

| 需求 | 变更 |
|---|---|
| R24-1（P3）device-delete 部分失败（oplock 忙 / unlink 失败）时仍无条件清除设备目录下全部 `.origin-`/`.pub-` 标记，存活快照丢失发布端标识 → 重启后 owner ack 永不满足 batch77 门槛（与 R23-1 同型），且 `.origin` 丢失可让同名兜底重新吸收外部副本（R6-1 回归面） | 有失败时改为只清“成功删除”文件的标记（按 `names - failed` 逐个反算 `_external_origin_marker`/`_publisher_marker` 精确 unlink）；全部成功时沿用整目录清扫（覆盖无文件的隐藏残留）；rmdir/`.platform` 行为不变 |

六处审计结论：publish 写（`flush_ok`，PC 无 id 时别名反查，无 id 清旧标记）、ack 读（仅别名缺失时、`_lock` 外）、settle 清（unlink 成功后）、delete 清（删除成功后）、device-delete 清（修复后按成功项）、GC 清（`markers` 识别两族、空目录先删标记再 rmdir）——齐备。命中判定：标记读取有界（`MAX_DEV_BYTES`、`_valid_device` 拒控制字符、损坏返回空）；`pub_hint == device_id` 且 `owner in participants` 才记 owner ack；非 owner id、近似 id、owner 名当 id 均不能命中（回归覆盖）；`device_id` 自报属既有共享密钥信任模型，未扩大攻击面；64 位哈希碰撞只会在同一设备目录内合并标记，同目录发布端恒为该设备，不会跨设备误归属。共存：`.origin-<h>.json` 与 `.pub-<h>.json` 前缀不同、哈希后缀相同，互不覆盖；读取各用独立 helper 与各自校验，交叉写不串读；delete/device-delete/GC 同时清理两族，list/devices/rmdir 均以 `.` 过滤。残余：标记清除失败无日志（`.origin` 同型，窗口极窄）、device-delete 失败时仍删 `.platform`（既有）、快照创建由 publish 驱动（迁移/GC 只更新既有快照，无需补标记）。

验证：`python -m py_compile` 退出码 0；新增 `markor_r24_test.py` 40/40；rd1/R3–R23 共 351 项全部 PASS，合计 391 项。`main.py` SHA256 `27AE2180C17B09062FBE4BF5FE020854C66D854669BE425D18E1FB6DDB3C88DE`（230389 字节）；unit 未改。快照 `backups\batch114-server-round24-20261106.zip`。未改 PC/安卓；R24-1 未部署。
## 2026-11-06 第七十三轮：Round 25 R24 部分失败标记清理专项（孤儿标记 / 失败可见性 / 与 GC 交界，batch115，本地验证；R24-1 + R25-1 未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 25。结论：发现 1 项 P3，已修复 → 连续零问题计数 0。前置：R6–R23 已上线（二进制 `63673E80…6CA`，启动 10:26:18，`NRestarts=0`）；R24-1 与 R25-1 均本地未部署（用户明确本轮不部署，攒批上线）。

| 需求 | 变更 |
|---|---|
| R25-1（P3）标记按 `sha1(basename)[:16]` 命名，文件被外部清理/改名或 delete/settle 标记 unlink 失败后留下孤儿；GC 原先只在“目录为空/仅剩 `.platform`”时清标记，目录还有其它用户文件时孤儿长期残留；同名副本若由镜像落盘重建，会继承旧发布端 id（owner 门槛被非真正发布者满足）或被旧 origin 吸收（R6-1 同型） | 新增 `_clean_orphan_markers`：GC 目录清理每个周期按当前可见文件名反算两族有效标记名，删除无对应文件的孤儿；调用点位于 `.mktmp-` 过滤前、`live_devs`/`busy_devs` 跳过之后，不改变空目录 rmdir 判定与 86400s mtime 门槛 |
| 清理 | 删除无调用者的死代码 `_drop_snap_meta`（非缺陷，仅避免误导） |

五问答复：① 反查逐名用与写入侧同一 helper 重算标记路径，精确命中；经 publish 改名走正常清标记，外部改名留下的孤儿由 R25-1 清理；同 basename 每族只有一份标记，不存在同名不同源。② 部分失败不吞：文件 + 两族标记 + 墓碑回滚，`failed` 随响应返回并记日志；目录因仍有用户文件不会被 GC 删（有意保留等重试）；标记本就不算用户文件，`entries`/`busy_devs` 判定与标记无关，不会“永不回收”。③ 返回 `{"ok":true,"deleted":n,"failed":[...]}`，缺目录时 `{"ok":true,"deleted":0}`（**无 `failed` 键**，消费方按缺省空处理）；`failed` 非空即未删净，可幂等重试；PC/Android 未见调用该路由。④ `_prune_stale_snap_meta` 不碰标记，标记不占内存；目录未清而 entry 被 GC 回收只留磁盘标记，R25-1 后下个清理周期按可见文件删除（活跃设备按既有安全跳过）。⑤ `_drop_snap_meta` 确认无调用者，直接删除。

残余：活跃设备（`LAST_SEEN` 24h 内有心跳）与有内存会话的目录跳过清理，孤儿最长保留 24h；孤儿 unlink 失败仍静默；device-delete 部分失败仍删 `.platform` 并尝试 rmdir（既有）；`deleted` 对“列目录后并发消失”计为成功（幂等）。

验证：`python -m py_compile` 退出码 0；新增 `markor_r25_test.py` 20/20；rd1/R3–R24 + R25 共 411 项全部 PASS。`main.py` SHA256 `A486B6EB73B88C74896916746FBA69FB2F60004DF3C1460944A2597C3B8F076B`（232047 字节）；unit 未改。快照 `backups\batch115-server-round25-20261106.zip`。未改 PC/安卓；**R24-1 + R25-1 未部署（攒批上线）**。

## 2026-11-06 第七十四轮：Round 26 长期运行稳定性审计（内存上限 / 线程与 fd / GC 跳过 / 计时器漂移 / 冷启动，batch116，本地验证；未部署）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 26。结论：发现 2 项 P3，均已修复 → 连续零问题计数 0。前置：R6–R23 已上线（二进制 `63673E80…6CA`）；R24-1、R25-1、R26-1、R26-2 均本地未部署。

| 需求 | 变更 |
|---|---|
| R26-1（P3）`LAST_SEEN` 过期只在心跳路径清理；设备永久下线且再无心跳时，GC 的 `live_devs` 永久把它当活跃设备，目录/孤儿标记无法回收 | GC 每 10s tick 在 `_lock` 内清 `now - ts > 86400` 的条目（与心跳同口径），`live_devs` 取清理后的集合 |
| R26-2（P3）深层清理用 `tick % 6` + `_recent_io_lock` 非阻塞抢占，失败即整个 60s 周期丢弃、无补跑；持续 publish/delete 时可无限期饿死清理，单轮耗时长还会使周期漂移 | 改为墙钟 `next_deep_gc`：成功抢锁并执行后（finally，含异常路径）才推 +60s；抢占失败下一 tick（10s）补跑，不再漏周期、不累积漂移 |

容量结论：`FILES` 无条数上限（单条 ≤16MB），仅“持续落盘失败”时 `rev>0` 条目无界（数据保全取舍，靠 `[flush] FAIL` 监控）；`SNAP_META` 无条数上限但受磁盘副本数与收敛约束；`LAST_SEEN` 8192、`DEV_NAME_ALIAS` 8192、`ALIAS` 8192、`_PLATFORM_CACHE` 4096、`_PUBLISHED_LOCAL` 8192 均有界；`_DELETED_RECENT` 每 10s 清理；`busy_devs`/`live_devs` 为临时集合。线程/fd：每 SSE 连接 1 线程 + 1 fd，连接结束即回收，3s 重连 24h 无累积，残余为并发连接无上限。30 天最坏场景（每日心跳 + 每日发布且不 ack）≤91 项，线性于未 ack 次数而非时间。冷启动：每文件首条 `/open`/SSE 即建 entry 并申领 writer，服务端不会双 writer；双“无 writer”仅存在于无 entry/无快照状态。

验证：`py_compile` 0；`markor_r26_test.py` 17/17（含真实 GC 循环的补跑测试）；rd1/R3–R25 全 exit=0，合计 428 项 PASS。`main.py` SHA256 `E881C175E9413AFD191F822798193846F740AFEB70F7969C18EF9A15B068623F`（233416 字节）；unit 未改。快照 `backups\batch116-server-round26-20261106.zip`。**未部署**（R24-1 + R25-1 + R26-1 + R26-2 攒批）。

## 2026-11-06 第七十五轮：Round 27 文档契约与代码实现一致性（batch117，文档同步，无代码改动）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 27。结论：**代码零缺陷**；发现 4 份契约文档共 11 处过期/表述不精确，已全部按最终代码同步 → 连续零问题计数 **1**（本轮起重新累计）。前置：R6–R23 已上线（二进制 `63673E80…6CA`，启动 10:26:18，`NRestarts=0`）；R24-1、R25-1、R26-1、R26-2 本地未部署。

| 文档 | 过期/缺失内容 | 已同步为 |
|---|---|---|
| `docs/proto-2026-11-05-absent-and-namespace.md` | 未写 SSE `hello` 恒 200 的例外；`content_hash`/`size` 仍按原样字节；hello 帧是否带 `content` 不明；`ext2-` 正则兼容性未写；§4 固定行号已失效 | 规则 1 补 hello 例外（absent 无 hash/size、客户端以 `state` 为准）；规则 2/3 改 R16 口径（剥前导 U+FEFF，size 为剥后字节，带 BOM 存量副本比 `st_size` 少 3）；规则 5 明确 hello 恒保留 `content`；§2.2 补正则兼容含 `-` 的 1–8 位前缀与大小写 hex；§4 改为按函数名定位 |
| `docs/design-2026-11-05-writer-token.md` | §5.2 未列 `writer_since`；§10 日志写成 `writer_rev=` | §5.2 的 `op`/`struct`/`save` 与 `close` 行补 `writer_since`；§10 改实际 `[writer] path=... dev=... reason=... rev=...` 并注明 rev 即 writer_rev |
| `docs/design-2026-11-05-sync-presence-conflict.md` | 早期 v2 的 24h TTL / 512MB 从未实施；`_write_allowed`/`_is_under` 不存在；save 落盘、recent 单层命名、按 join 顺序/仅首个 open 移交、writer token 运行时开关等描述过期 | §0、§2.1–2.4、§3.1、§9、§11.4、§12 全部按代码：无 TTL/无上限、ack 收敛 + 显式删除 + GC 86400s；`_assert_recent_full_path`+`_note_write`；save 只改内存；`RECENT_ROOT/<设备名>/<文件名>` 两层；首个 open **或 SSE join** 申领、按最后活跃移交 15s+2s；回滚只能换旧二进制 |
| `docs/deploy-2026-11-05-lockserver.md` | 仍暗示 `ReadWritePaths=/vol1/1000/Markor`；升级/备份流程与 `backups/` root:root 权限坑未写；旧日志文本/ack 语义过期；缺今日部署记录 | §3 override 删除线标注（2026-11-06 已移除，unit 只留 lockserver 目录，DISK_ROOT 仅由 `Environment=` 注入）；§7/§8 改 sudo 整链备份 + 确认落盘 + `daemon-reload` + 冒烟；§10.1/§10.5 改 `_assert_recent_full_path`/`DENY write`/owner 已 ack（R23-1）/R24 部分失败；新增 §13（R6–R23 上线记录、备份目录、冒烟、回滚、§13.5 未上线项） |
| `server/docs/CHANGELOG.md` | 早期轮“BOM 保留/原始字节 hash”与 R16 冲突 | L428 已加行内勘误（R16 起剥离前导 U+FEFF；以 proto 文档为准） |
| `docs/code-review-2026-11-05-server-rounds.md` | Round 6 的 close“先落盘再释放”、Round 9/10/14/15 的 BOM 表述、各处 TTL/512MB 与最终代码不一致 | 顶部新增「文档契约同步横幅」统一说明（不改写历史）；追加 Round 27 分节逐份对照。close 最终实现：服务端 `_lock` 内先按最后活跃移交 writer，锁外仅落 `recent/` 副本；源路径不落盘，“先落盘再释放”为客户端职责 |

代码侧复核结论：三态/HTTP 码/absent 无 `content`/`ext2-` 与旧键兼容/外部键不读同步根/hello 字段/五 writer 字段/`force` 抢占与 409/15s+2s/close 移交/`/health.writers` 六字段/零写同步根守卫与日志，全部与代码一致，未发现缺陷。

验证：本轮未改 `main.py`（`python -m py_compile` 退出码 0；仍 233416 字节、SHA256 `E881C175E9413AFD191F822798193846F740AFEB70F7969C18EF9A15B068623F`，沿用 Round 26 的 428 项 PASS 基线，未重跑全套）。unit / drop-in 未改。快照 `backups\batch117-server-round27-20261106.zip`（含四份契约文档与审查报告）。**未部署**（R24-1 + R25-1 + R26-1 + R26-2 仍攒批）。

## 2026-11-06 第七十六轮：Round 28 老客户端兼容降级（batch118，代码零改动）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 28。**结论：零代码缺陷 → 当前连续零问题 2 轮。** 唯一改动为 `docs/proto-2026-11-05-absent-and-namespace.md` §2.2 兼容规则 4/5（会话隔离、`recent/list`/`ack` 不覆盖外部键）。

实测：隔离实例端口 18912/18913（临时 `DISK_ROOT`/`RECENT_ROOT`，未触碰现网）；客户端行为依据为仓库 APK/EXE 的 DEX 反汇编 + 两端 CHANGELOG（PC batch90 / 安卓 batch91 引入 `DeletePolicy`）。

| 审查项 | 结论 |
|---|---|
| 旧键 `ext-` / `_ext/` | `GET /file`、`/open`、`save/op/struct`、SSE 全部正常：外部键不读同步根、无会话时 404 `state:absent` 且无 `content`、写入只进内存（实测同步根 `disk_files=[]`）；`recent/list` 只列副本（旧客户端用 `?device=`，已字节码确认）；`recent/ack` 只针对副本；`heartbeat`/`devices` 老接口仍在 |
| 同路径双键分裂 | **会分裂且为设计**：`ext-…` 与 `ext2-…` 是两条独立会话（实测 `hello`/`world` 各自演化）；不自动合并，跨端协作靠 `recent/<设备>/<文件>` + `origin_rel` 别名；同机同时跑新旧客户端属不支持场景 |
| 缺字段请求 | `/open` 不读 `content_hash`；`/recent/publish` 不读 `content_hash`/`baseline_hash`（服务端自行摘要）；`/recent/ack` 不读 `alias`（服务端 `DEV_NAME_ALIAS` + 持久发布端标记兜底）；SSE 缺 `path`/`device_id` → 显式 400。均无“永不收敛/永远冲突”的静默降级；无 hash publish、无 alias ack 实测通过（后者 `settled:true`） |
| 新响应字段 | `/open` 的 `state`、`/file` 404 absent、`hello` 的 `state`、`writer_changed`、额外 writer 字段：JSON 未知键/未知 event 均被忽略；aa 的 `classifyHttp` 非 200→absent，z 仅 `code==200` 才解析，均不删盘。404 反而绕开了旧“200+空 content”事故分支 |
| `hello` 空内容 | aa+ `classifyHello` 判 absent（保留本地）；postDeletePolicy 构建安全。**pre-DeletePolicy（PC < batch90 y、安卓 < batch91 z）仍会把 `content:""` 当“服务器已删除”而删本地盘**——客户端侧风险，服务端无法识别兜底 |
| 可观测性 | 部分可见：`[sse] JOIN path=… dev=…`、`[writer] path=… dev=… reason=… rev=…` 会暴露 `ext-`/`_ext/` 旧键；但无 `client_build`/`User-Agent`，`/open`/`publish`/`ack` 无常规日志，**无法定位到具体构建**。建议后续客户端上报 `client_build` 后再做版本日志/门槛 |
| 兼容开关/最低版本 | **不需要开关**（404/`state` 已是降级路径，开关改不了老客户端对 `hello` 空内容的解释）；**现在无法做最低版本拒绝**（协议无版本字段，UA 不可映射构建）。正确动作是分发侧要求两端升级；如要 gate，先加 `client_build` |

验证：`main.py` 未改（233416 字节、SHA256 `E881C175E9413AFD191F822798193846F740AFEB70F7969C18EF9A15B068623F`，`py_compile` 0，沿用 428 项 PASS 基线）。unit / drop-in 未改。快照 `backups\batch118-server-round28-20261106.zip`。**未部署**（R24-1 + R25-1 + R26-1 + R26-2 仍攒批）。


## 2026-11-06 第七十七轮：Round 29 接口模糊输入与并发压力（batch119，代码零改动）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 29。**结论：零缺陷 → 当前连续零问题 3 轮。** 隔离实例端口 18921–18924（临时 `DISK_ROOT`/`RECENT_ROOT`），未触碰现网与真实同步目录。

| 项目 | 结果 |
|---|---|
| 模糊输入 62 例 | 400×26、404×19、200×7、413×3、401×7；500/EXC=0、`Traceback`=0、磁盘写入=0 |
| path | `../` 400；GET 的 `..%2f`/`%2e%2e/` 解码后 400；NUL/5000 字节 400；`CON`/`NUL`/`aux` 404 absent 且不读不写；空格与 Emoji 保留；`dir/`→`dir`、`a//b.md`→`a/b.md` |
| body | 非 JSON/空体/`{`/数组/字符串/数字/null 400；深嵌套 3000/5000 层无崩溃；`row="abc"` 400；`text=123` 200（设计允许标量转字符串）；`content` 对象 400；16MiB-1000 200；恰好 16MiB 与 +1 均 413（请求体上限先生效） |
| 头/鉴权 | 无 CL、chunked、负 CL、非数字 CL 均 400；20MiB CL 413；缺失/错 key/双空格/小写/尾随空格/空/非 ASCII 全 401；`/health` 无鉴权 200 |
| SSE | 空 path 400；500 字符 device 400；Unicode device 200；20 路径 20×200；同设备同路径 5 次后 `total_peers=1`，旧连接 closed 32/32 到达 |
| S1 writer | 32 线程×3 轮：每轮 32×200、0×500，恰好 1 writer（`W0-04`），`writer_rev` 恒 1，`rev` 恒 1 |
| S2 op/save/close 60s | op 1160（丢失 0）、save 12、close 12，全 200；rev 1→1173，1172 帧严格递增；落盘与末帧一致（hash `59c838b2…9360`、size 139） |
| S3 20 SSE 60s | 线程 5→25→3、句柄 137→237→138，6 次采样恒定；探测 peers=[]，无泄漏 |
| S4 publish/ack | 交叉 10s：publish 1784 全 200、ack 1784（2×200 + 1782×410 墓碑）、0×500；先 ack 后 publish 410 deleted 不收敛；正常/重复/墓碑后均能收敛，无“永不收敛” |

验证：`main.py` 未改（233416 字节、SHA256 `E881C175E9413AFD191F822798193846F740AFEB70F7969C18EF9A15B068623F`，`py_compile` 0，沿用 428 项 PASS 基线）。快照 `backups\batch119-server-round29-20261106.zip`。**未部署**（R24-1 + R25-1 + R26-1 + R26-2 仍攒批）。

## 2026-11-06 第七十八轮：Round 30 降级回滚与磁盘故障注入（batch120，代码零改动）

审查报告：`docs/code-review-2026-11-05-server-rounds.md` Round 30。**结论：当前代码零缺陷 → 连续零问题 4 轮。** 全部为隔离实例（端口 18941–18964，临时 `DISK_ROOT`/`RECENT_ROOT`）；老二进制取自 `backups\batch92-server-absent-namespace-20261105.zip` 内的 `main.py`（R1/R6 之前构建）；未触碰现网与真实同步目录。

| 项目 | 注入方式 | 结果 |
|---|---|---|
| 降级 LF 副本 | 新写 LF 无 BOM，老二进制读 | `content_hash 4a1e67f2…0f92`、`size 12`，与新版/客户端一致 |
| 降级 CRLF 副本 | 新写 CRLF 无 BOM（6 字节），老二进制读 | 老返回 `a\nb\n`、`hash 911169dd…59a2`、`size 4`；list 仍报 `size 6`；客户端 hash `58055bdc…0cab` → **永不收敛（R15 前行为）** |
| 标记/残留 | 目录含 `.origin-`/`.pub-`/`.mktmp-` | 老 `recent/list` 全部隐藏，不误列；老 GC 不清理，孤儿目录有界残留 |
| 空目录回收 | 3 天前 mtime 的 GhostDev/MarkerDev | GhostDev（仅 `.platform`）删；MarkerDev（带 `.origin`）留 → 无“误回收” |
| 降级写回 | 老 `/save` | Windows 写成 `old-save\r\n`（hash `ddd89e…fdf4`/10B，LF 版 `fadc6f…8f31`/9B）→ R15 前 newline 问题 |
| `.pub` / writer_rev | 老进程重启、ack | `.pub` 老版本忽略但 ack 仍可 `settled:true`（`device_id`=目录名）；残留标记回新版本首次深清即删，无需人工；`writer_rev` 仅内存、任何重启重置 |
| `.origin` 吸收 | 同名源 `root\n` + 带 `.origin` 的外部副本 | 老 open 副本返回 `root\n`（`hash 53175b…969a`）→ R6-1 风险复活 |
| ack 别名 | `device_id:devA0001` + `device_name:DevA` | 老 ack `settled:false`、`pending:["DevA"]` → 新客户端+老服务端永不收敛 |
| BOM 迁移正常/中断/被杀 | `os.replace` 注入 ENOSPC / `os._exit(9)` | 最坏“一半 BOM 一半没有”，读路径始终剥 BOM，hash 唯一；重启补齐；kill 窗口仅导致一个文件 mtime 跳变，内容无损；无新增 `.mktmp-` |
| ENOSPC | 包装器 `os.replace` 抛 `OSError(28)` | `save` `200 persisted:false`、磁盘保持旧版、无 tmp；5 次 save → `[flush] FAIL` +5，35s GC 再 +1；恢复后 `save` `persisted:true` 自动补落盘；同 key 不叠 entry |
| 只读 | 真实 `icacls /deny (OI)(CI)(W)` | 启动**降级**非 fail-fast；`/health` 仍 `ok`、`recent_writes:0`、`recent_root:"allow"`（策略非可写探测）；publish+10 save 全 `persisted:false`、`[flush] FAIL` 11；恢复 ACL 后自愈 |
| `os.replace` 失败 | 注入 `EACCES` / 同名目录占位 | 注入：旧文件完好、无 tmp、`persisted:false`，重试自愈；目录占位：`415 not utf-8`（load 先拒），删目录后 200 |
| `unlink` 失败 | `PermissionError(13)` | delete/ack 均 `500 delete failed`；墓碑弹出，紧接 GET `200`（非 410）；恢复后 delete/ack 成功、文件与 `.pub` 删除 |

**降级约束（老二进制已固化，非新代码可修）**：不要回滚到 R15 之前（CRLF 不收敛）、R6 之前（`.origin` 吸收）、R1 之前（新客户端 ack 别名不收敛）；建议回滚下限为当前 R23，若必须更旧先停客户端、备份并清空 `recent-sync`，且不要“新客户端 + 老服务端”混跑。`.pub` 与 `writer_rev` 本身不阻塞收敛。

验证：`main.py` 未改（233416 字节、SHA256 `E881C175E9413AFD191F822798193846F740AFEB70F7969C18EF9A15B068623F`，`py_compile` 退出码 0，沿用 428 项 PASS 基线）；unit/drop-in 未改。快照 `backups\batch120-server-round30-20261106.zip`。**未部署**（R24-1 + R25-1 + R26-1 + R26-2 仍攒批）。
