// Markor 内嵌同步引擎入口（方案 B）
//
// 只使用 Syncthing 的同步内核：config + model + protocol + connections + discover。
// 不启用 GUI / REST / 自动升级 / 使用报告，因此进程内没有任何管理监听端口，
// 仅有同步数据监听 23000（TCP+QUIC，避让本机原 Syncthing 服务的 22000），
// 也没有独立可执行文件——引擎以 goroutine 形式运行在 Markor 进程内。
//
// 构建（产物为可被 LoadLibrary 加载的 DLL）：
//
//	go build -tags noassets -buildmode=c-shared -o markorsync.dll ./cmd/markor-engine
package main

/*
#include <stdlib.h>
*/
import "C"

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
	"unsafe"

	"github.com/syncthing/syncthing/internal/db"
	"github.com/syncthing/syncthing/lib/config"
	"github.com/syncthing/syncthing/lib/events"
	"github.com/syncthing/syncthing/lib/locations"
	"github.com/syncthing/syncthing/lib/model"
	"github.com/syncthing/syncthing/lib/protocol"
	"github.com/syncthing/syncthing/lib/svcutil"
	st "github.com/syncthing/syncthing/lib/syncthing"
)

const defaultFolderID = "markor"

// engineConfig 是 C++ 端传入的同步参数，仅包含 Markor 设置页暴露的字段。
type engineConfig struct {
	DeviceName     string `json:"deviceName"`
	ServerDeviceID string `json:"serverDeviceID"`
	ServerAddress  string `json:"serverAddress"`
	FolderPath     string `json:"folderPath"`
}

type engineStatus struct {
	Running         bool   `json:"running"`
	MyID            string `json:"myID"`
	FolderState     string `json:"folderState"`
	ServerConnected bool   `json:"serverConnected"`
	// ConnectedPeers 是当前已建立连接的设备数量（仅服务器；客户端之间不互连）。
	ConnectedPeers int `json:"connectedPeers"`
	// ServerAddress 是引擎当前与服务器实际建立的连接地址（host:port）。
	ServerAddress string `json:"serverAddress"`
	// DeviceAddresses 记录每个已连接设备可用的最佳地址（按 IPv4 优先）。
	// 宿主只能按设备 ID 精确取址，不能拿别的对端地址顶替。
	// 同一设备可能同时有多条连接（如主连接 IPv6、次要连接局域网 IPv4），
	// 主连接地址不一定是最可用的那一条，聚合时所有连接都要参与比较。
	DeviceAddresses map[string]string `json:"deviceAddresses,omitempty"`
	Error           string            `json:"error"`
}

var (
	mu         sync.Mutex
	app        *st.App
	cfgWrap    config.Wrapper
	evLogger   events.Logger
	sdb        db.DB
	svcCancel  context.CancelFunc
	myID       protocol.DeviceID
	serverID   protocol.DeviceID
	haveServer bool
	lastErr    string
	folderID   = defaultFolderID
	startedAt  time.Time
)

// MarkorSyncStart 启动同步引擎。dir 为引擎数据目录，cfgJSON 为同步参数。
// 返回 0 表示成功，非 0 为错误码。
//
//export MarkorSyncStart
func MarkorSyncStart(dir *C.char, cfgJSON *C.char) C.int {
	mu.Lock()
	defer mu.Unlock()

	if app != nil {
		return 0
	}
	lastErr = ""

	dataDir := C.GoString(dir)
	if dataDir == "" {
		lastErr = "empty data dir"
		return 1
	}
	if err := os.MkdirAll(dataDir, 0o755); err != nil {
		lastErr = err.Error()
		return 2
	}

	var ec engineConfig
	if s := C.GoString(cfgJSON); s != "" {
		if err := json.Unmarshal([]byte(s), &ec); err != nil {
			lastErr = "bad config json: " + err.Error()
			return 3
		}
	}
	if ec.FolderPath == "" {
		lastErr = "empty folder path"
		return 4
	}
	if err := os.MkdirAll(ec.FolderPath, 0o755); err != nil {
		lastErr = err.Error()
		return 5
	}

	setupLogging(dataDir)
	setBaseDirs(dataDir)

	// 加载已有证书；仅在首次运行时生成。
	// 注意：tlsutil.NewCertificate 每次调用都会重新生成证书，会导致本机
	// 设备 ID 每次启动都变化（服务器无法信任该设备），必须用 LoadOrGenerate。
	cert, err := st.LoadOrGenerateCertificate(
		locations.Get(locations.CertFile),
		locations.Get(locations.KeyFile))
	if err != nil {
		lastErr = "cert: " + err.Error()
		return 6
	}

	evLogger = events.NewLogger()
	ctx, cancel := context.WithCancel(context.Background())
	svcCancel = cancel
	go func() {
		_ = evLogger.Serve(ctx)
	}()

	cfgWrap, err = st.LoadConfigAtStartup(locations.Get(locations.ConfigFile), cert, evLogger, false, true)
	if err != nil {
		lastErr = "config: " + err.Error()
		stopLocked() // 取消后台服务并释放已取得资源
		return 7
	}
	// 配置服务必须先运行，否则 Modify 会永久阻塞。
	go func() {
		_ = cfgWrap.Serve(ctx)
	}()

	sdb, err = st.OpenDatabase(locations.Get(locations.Database), 0)
	if err != nil {
		lastErr = "database: " + err.Error()
		stopLocked()
		return 8
	}

	myID = protocol.NewDeviceID(cert.Certificate[0])

	applyDesiredConfig(ec)

	a, err := st.New(cfgWrap, sdb, evLogger, cert, st.Options{NoUpgrade: true})
	if err != nil {
		lastErr = "engine: " + err.Error()
		stopLocked()
		return 9
	}
	if err := a.Start(); err != nil {
		lastErr = "start: " + err.Error()
		_ = a.Stop(svcutil.ExitError)
		stopLocked()
		return 10
	}

	app = a
	startedAt = time.Now()
	return 0
}

// MarkorSyncStop 停止同步引擎并释放资源。
//
//export MarkorSyncStop
func MarkorSyncStop() {
	mu.Lock()
	defer mu.Unlock()
	stopLocked()
}

func stopLocked() {
	// 2026-11-18：失败路径（app 尚未建立）也要释放配置/事件/数据库句柄；
	// 原先 app==nil 直接 return，重启时会重复打开同一个 SQLite 库。
	if app != nil {
		app.Stop(svcutil.ExitSuccess)
		app = nil
	}
	if svcCancel != nil {
		svcCancel()
		svcCancel = nil
	}
	cfgWrap = nil
	evLogger = nil
	if sdb != nil {
		_ = sdb.Close()
		sdb = nil
	}
}

// MarkorSyncRestart 以新参数重启引擎（设置变更时调用）。
//
//export MarkorSyncRestart
func MarkorSyncRestart(dir *C.char, cfgJSON *C.char) C.int {
	mu.Lock()
	stopLocked()
	mu.Unlock()
	return MarkorSyncStart(dir, cfgJSON)
}

// MarkorSyncStatus 返回引擎状态 JSON。调用方需用 MarkorSyncFree 释放。
//
//export MarkorSyncStatus
func MarkorSyncStatus() *C.char {
	mu.Lock()
	defer mu.Unlock()

	s := engineStatus{
		Running: app != nil,
		MyID:    myID.String(),
		Error:   lastErr,
	}
	if app != nil && app.Internals != nil {
		if state, _, err := app.Internals.FolderState(folderID); err == nil {
			s.FolderState = state
		}
		if haveServer {
			s.ServerConnected = app.Internals.IsConnectedTo(serverID)
		}
		if stats := app.Internals.ConnectionStats(); stats != nil {
			conns, _ := stats["connections"].(map[string]model.ConnectionStats)
			serverKey := serverID.String()
			s.DeviceAddresses = map[string]string{}
			// 按设备聚合地址：IPv4 优先；无 IPv4 时才取全局 IPv6；
			// 跳过 fe80 链路本地与带 % zone 的地址，避免宿主拿到不可解析值。
			for id, cs := range conns {
				if !cs.Connected || cs.Paused {
					continue
				}
				s.ConnectedPeers++
				// 主连接 + 次要连接一起参与选优：实测服务器同时存在
				// IPv6 主连接与局域网 IPv4 次要连接，只看主连接会把
				// 唯一可用的 IPv4 丢掉（宿主随后只能看到不可用的 IPv6）。
				candidates := make([]string, 0, 1+len(cs.Secondary))
				candidates = append(candidates, cs.Address)
				for _, sec := range cs.Secondary {
					candidates = append(candidates, sec.Address)
				}
				cur, ok := s.DeviceAddresses[id]
				for _, addr := range candidates {
					if !usableGlobal(addr) {
						continue
					}
					if !ok || (usableV4(addr) && !usableV4(cur)) {
						cur = addr
						ok = true
					}
				}
				if ok {
					s.DeviceAddresses[id] = cur
				}
			}
			if haveServer && s.ServerConnected {
				s.ServerAddress = s.DeviceAddresses[serverKey]
			}
		}
	}
	b, _ := json.Marshal(s)
	return C.CString(string(b))
}

// MarkorSyncFree 释放 MarkorSyncStatus 返回的字符串。
//
//export MarkorSyncFree
func MarkorSyncFree(p *C.char) {
	C.free(unsafe.Pointer(p))
}

// MarkorSyncVersion 返回内嵌引擎版本标识。
//
//export MarkorSyncVersion
func MarkorSyncVersion() *C.char {
	return C.CString("syncthing-v2.1.6-markor")
}

func setupLogging(dataDir string) {
	f, err := os.OpenFile(filepath.Join(dataDir, "sync-engine.log"),
		os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return
	}
	slog.SetDefault(slog.New(slog.NewTextHandler(f, &slog.HandlerOptions{Level: slog.LevelInfo})))
}

func setBaseDirs(dir string) {
	_ = locations.SetBaseDir(locations.ConfigBaseDir, dir)
	_ = locations.SetBaseDir(locations.DataBaseDir, dir)
}

// applyDesiredConfig 把 Markor 的同步语义写死进引擎配置：
//   - 关闭 GUI / REST（无监听端口）
//   - 关闭中继、自动升级、使用报告
//   - 「启用自动发现」只是辅助开关，不进入引擎配置：关闭它不影响服务器连接。
//     客户端的局域网互发现由 23001 UDP 广播（宿主实现）提供地址提示；
//     Syncthing 自身的本地发现固定关闭（会产生带网卡 zone 的不可拨地址），
//     全局发现固定开启用于跨网段定位服务器与客户端（dynamic 兜底）
//   - 设备表：本机 + 服务器（服务器设备 ID 是唯一准绳）；服务器 introducer=false
//   - 无版本控制、忽略权限、默认块索引（xxhash）
//
// usableV4 判断连接地址是否是可直接回填的 IPv4 host:port。
func usableV4(addr string) bool {
	return addr != "" && !strings.HasPrefix(addr, "[") && !strings.Contains(addr, "%")
}

// usableGlobal 允许 IPv4 与全局 IPv6；排除 fe80 链路本地和带 zone 的地址。
func usableGlobal(addr string) bool {
	if addr == "" || strings.Contains(addr, "%") {
		return false
	}
	if strings.HasPrefix(addr, "[") {
		host := strings.TrimPrefix(addr, "[")
		return !strings.HasPrefix(strings.ToLower(host), "fe80")
	}
	return true
}

// normalizeSyncAddress 容忍常见笔误（ctp://、缺少 tcp:// 前缀）。
func normalizeSyncAddress(addr string) string {
	a := strings.TrimSpace(addr)
	if a == "" {
		return ""
	}
	// 带网卡 zone 的链路本地地址（如 [fe80::1%以太网]:23000）不可拨，
	// 直接丢弃，避免 dialer 报 invalid URL escape。
	if strings.Contains(a, "%") {
		return ""
	}
	low := strings.ToLower(a)
	if strings.HasPrefix(low, "ctp://") {
		return "tcp://" + a[len("ctp://"):]
	}
	if !strings.Contains(a, "://") {
		return "tcp://" + a
	}
	return a
}

func applyDesiredConfig(ec engineConfig) {
	sid, serverErr := protocol.DeviceIDFromString(ec.ServerDeviceID)

	// 星型拓扑：只登记一个服务器设备（不是 introducer，避免设备间互连）。
	// 空字符串会被 DeviceIDFromString 解析为“空设备 ID”，必须显式排除，
	// 否则会向集群配置写入 id="" 的非法设备。
	serverID = sid
	haveServer = serverErr == nil && strings.TrimSpace(ec.ServerDeviceID) != "" && sid != myID

	_, _ = cfgWrap.Modify(func(cfg *config.Configuration) {
		cfg.GUI.Enabled = false
		cfg.GUI.RawAddress = ""

		cfg.Options.RelaysEnabled = false
		// 「启用自动发现」只控制宿主的局域网广播（同网段设备现身/地址提示），
		// 不能顺带切断与服务器的链路，也不进入本配置：
		//   - Syncthing 本地发现固定关闭：它会广播/解析带网卡 zone 的链路本地
		//     地址（如 fe80::1%以太网），宿主拨号时会报 invalid URL escape；
		//   - 全局发现固定开启：服务器往往只在一个网卡/端口上可达（例如专网地址），
		//     关掉它会让已配置地址失效时彻底无法定位服务器，也无法被服务器回连。
		cfg.Options.LocalAnnEnabled = false
		cfg.Options.GlobalAnnEnabled = true
		cfg.Options.AutoUpgradeIntervalH = 0
		cfg.Options.URAccepted = 0
		// 监听端口写死 23000（TCP+QUIC）：避让本机原 Syncthing 服务的 22000，
		// 不用 "default"（含 22000 与动态中继地址）
		cfg.Options.RawListenAddresses = []string{"tcp://0.0.0.0:23000", "quic://0.0.0.0:23000"}

		// 设备表：本机 + 服务器。服务器不设为 introducer；客户端之间不互连，
		// 只有该服务器设备 ID 会被登记，其它 ID 一律不进入设备表。
		devices := make([]config.DeviceConfiguration, 0, 2)
		for _, d := range cfg.Devices {
			if d.DeviceID == myID {
				d.Name = ec.DeviceName
				if d.Name == "" {
					d.Name = "markor-pc"
				}
				devices = append(devices, d)
			}
		}
		if len(devices) == 0 {
			devices = append(devices, config.DeviceConfiguration{DeviceID: myID, Name: ec.DeviceName})
		}
		if serverErr == nil && serverID != myID {
			// 地址集合：已填地址排在最前（主动拨号优先），始终保留 dynamic。
			// 显式地址可能只对某个网卡/端口有效（实测局域网 23000 被拦、
			// 专网地址可用），dynamic 负责发现兜底，与「启用自动发现」开关无关。
			addresses := []string{}
			if addr := normalizeSyncAddress(ec.ServerAddress); addr != "" {
				addresses = append(addresses, addr)
			}
			addresses = append(addresses, "dynamic")
			devices = append(devices, config.DeviceConfiguration{
				DeviceID:     serverID,
				Name:         "markor-server",
				Addresses:    addresses,
				Introducer:   false,
				IntroducedBy: protocol.EmptyDeviceID,
			})
		}
		cfg.Devices = devices

		// 文件夹：整库同步，无版本控制、忽略权限。成员只有本机与服务器。
		folderDevices := []config.FolderDeviceConfiguration{{DeviceID: myID}}
		if serverErr == nil && serverID != myID {
			folderDevices = append(folderDevices, config.FolderDeviceConfiguration{DeviceID: serverID})
		}
		cfg.Folders = []config.FolderConfiguration{{
			ID:              folderID,
			Label:           "Markor",
			Path:            ec.FolderPath,
			Type:            config.FolderTypeSendReceive,
			Devices:         folderDevices,
			RescanIntervalS: 10,
			IgnorePerms:     true,
			// 版本保留不在客户端决定：客户端不写入 Versioning（即"无版本控制"），
			// 保留策略由服务器 GUI（Syncthing 文件夹设置）统一配置，只作用于服务器副本。
			FSWatcherEnabled: true,
		}}
	})
}

func main() { fmt.Print("") }
