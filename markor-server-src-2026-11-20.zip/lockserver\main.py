#!/usr/bin/env python3
# Markor 实时协作编辑服务器（Python stdlib only，无 pip 依赖）
#
# 架构：
#   - 权威文件存储在服务器内存（FILES dict），定期落盘到磁盘
#   - 客户端通过 SSE (GET /api/v1/events) 订阅文件变化
#   - 客户端通过 POST /api/v1/op 发送行级 append 操作
#   - 服务器广播 op 给所有订阅者，各自更新本地编辑器
#
# 协议（JSON over SSE / HTTP POST）：
#   客户端 → 服务器：
#     POST /api/v1/open   {"path":"A.md", "device_id":"pc1", "device_name":"PC"}
#     POST /api/v1/op     {"path":"A.md", "row":5, "text":"你好", "device_id":"pc1"}
#     POST /api/v1/close  {"path":"A.md", "device_id":"pc1"}
#   服务器 → 客户端（SSE event: ... data: {...}）：
#     hello    {"content":"# 会议记录\n...", "peers":[...]}
#     op       {"row":5, "text":"你好", "device_id":"pc1", "ts":1234567890}
#     peer     {"device_id":"phone1", "action":"join|leave"}
#
# 冲突模型：
#   - 不同行号：无冲突，各自 append 到对应行
#   - 同一行号：服务器到达序，后到的 append 在同一行末尾
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import select
import socket
import string
import sys
import tempfile
import threading
import time
from contextlib import ExitStack, contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PORT = int(os.environ.get("MARKOR_LOCK_PORT", "8910"))
# ======================== 服务器自管 API Key ========================
# 2026-11-17：不再读取静态 MARKOR_API_KEY 环境变量。密钥由锁服务自己生成
# （长度 12，[a-z0-9]）并持久化到本地文件；重启只加载、不换新，避免所有
# 客户端同时 401。客户端通过 /api/v1/serverkey 自动获取（仅限私网来源）。
# 文件位置可用 MARKOR_KEY_FILE 覆盖；默认放在程序目录（systemd ProtectSystem
# =strict 只放行 lockserver 目录）。
API_KEY_LENGTH = 12
KEY_FILE = (os.environ.get("MARKOR_KEY_FILE")
            or os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])),
                            "server-api-key"))
# 迁移期留档：旧静态值（以及轮换前的旧密钥）只写入 .prev 存档，不再参与鉴权
# （见 _init_api_key：RETIRED）。客户端通过 /api/v1/serverkey 重新获取新密钥；
# 迁移完成后可直接删除该文件。每行一把。
LEGACY_KEY_FILE = KEY_FILE + ".prev"
LEGACY_API_KEYS = set()
_LEGACY_ACCEPTED = set()   # 已在日志里提示过的旧密钥（按来源 IP）
API_KEY = ""   # 由 _init_api_key() 在 main() 内加载/生成
# 引导接口允许的来源网段（显式列举，避免 Python 版本对 100.64/10 的差异）
_PRIVATE_NETS = [ipaddress.ip_network(x) for x in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10",
    "127.0.0.0/8", "169.254.0.0/16", "fc00::/7", "fe80::/10", "::1/128")]
VAULT_ID = "markor-vault"
DISK_ROOT = os.environ.get("MARKOR_DISK_ROOT",
                           os.path.expanduser("~/Markor"))  # Syncthing 同步目录
# 多端最近页的服务器副本：放在程序目录下（不在 Syncthing 同步目录内），
# 目录树 recent-sync/<设备段>/<文件名>；设备段优先 device_id（id 目录内用
# 隐藏标记 .name 记录设备名），旧客户端/旧目录按设备名，且旧名字目录只读兼容。
# 故意独立存放：放进同步目录会被 Syncthing 扩散到所有设备，与"被同步端不落盘"
# 的要求冲突。
_RECENT_ROOT_ENV = os.environ.get("MARKOR_RECENT_ROOT")
# 默认放在程序所在目录（/opt/syncthing/markor/lockserver/recent-sync）：
# systemd 的 ProtectSystem=strict 只放行 lockserver 目录，写到上级目录会失败。
RECENT_ROOT = _RECENT_ROOT_ENV or os.path.join(
        os.path.dirname(os.path.abspath(sys.argv[0])), "recent-sync")
SESSION_STORE = os.path.join(RECENT_ROOT, ".sessions")
FLUSH_IDLE_SEC = 30.0   # 文件空闲 30s 后落盘
GC_SESSIONS_SEC = 60.0  # 订阅者无活动超时
# SV-T6：publish/delete/迁移都在 _recent_io_lock 内等待 per-file oplock，而
# oplock 会被 op/save 的"持锁广播"（慢 SSE 客户端最长阻塞到 socket 超时）长期
# 占用，原实现会让全服 publish/delete/迁移一起串行阻塞。改为带超时获取
# oplock，超时即放弃本轮（客户端稍后重试），不再无限期占住全局锁。
OPLOCK_WAIT_SEC = 10.0
# SV-T6：SSE 广播帧的独立写超时——比 keepalive 周期与 socket 的 120s 上限短，
# 快速淘汰只连不读的慢连接，缩短 oplock 被占用的最长时间
SSE_WRITE_TIMEOUT = 15.0
# SV-T10：单文件内容总量上限（与请求体上限同口径）。单请求各有上限，但
# op/struct 在已有内容上累加，反复插入可让 entry.content 与每条广播帧无界膨胀
MAX_FILE_BYTES = 16 * 1024 * 1024

# SRV36-1：hello 不再持全局 _lock 发送。订阅登记后到 hello 写完之间到达的
# 广播帧进入该连接的有界待发队列，hello 写完后按到达序补发——既保证 hello
# 严格先于后续事件，又不会让慢客户端在 15s 写超时内冻结全服请求。
SSE_PENDING_MAX_BYTES = 2 * MAX_FILE_BYTES
SSE_PENDING_MAX_FRAMES = 256

_lock = threading.Lock()
# FILES: (vault_id, path) -> FileEntry
class FileEntry:
    __slots__ = ("content", "mtime", "content_mtime", "subs", "rev", "oplock",
                 "writer_device_id", "writer_device_name", "writer_since",
                 "writer_rev", "participants", "path")
    def __init__(self, content, path=""):
        self.content = content        # 内存中完整内容
        # R21-1：会话 key——_broadcast 丢订阅者等日志需要“具体文件”
        self.path = path
        self.mtime = time.time()      # 最后活动时间（订阅进出/保存都会刷新）
        # SV-U6：内容最后变更时间——只在内容真正变化时更新，迁移/publish 的
        # 新旧判定一律用它；mtime 只是活动时间（hello/leave/无变化 save 也刷新），
        # 混用会把"刚有人打开过"误判成"内容更新"
        self.content_mtime = self.mtime
        self.subs = set()             # set of SSEHandler 实例
        self.rev = 0                  # 内容版本号（每次修改 +1，用于丢弃旧快照）
        # 每文件一把顺序锁：状态变更（全局锁内）→ 广播（锁外）整段串行，
        # 保证同文件 op 的广播顺序与 rev 递增一致（SV-C2 修复后广播移到全局锁外）
        self.oplock = threading.Lock()
        # writer token：见 docs/design-2026-11-05-writer-token.md
        self.writer_device_id = None
        self.writer_device_name = ""
        self.writer_since = 0.0
        self.writer_rev = 0
        # dev -> {"device_name": str, "last_active": float}
        self.participants = {}

FILES = {}
# 阶段①：最近副本的“参与设备 / 各设备上报的本地内容 hash”。
# 独立于 FILES，避免为了保留参与关系而长期占用整篇内容内存；条目在快照
# 删除、设备删除或 ack 收敛后清除。仅记录小集合，按设备数增长（有上限）。
SNAP_META = {}
MAX_SNAP_PARTICIPANTS = 256
# 设备最近心跳时间（秒）：最近页在线状态 = 有心跳或正打开文件
LAST_SEEN = {}
ONLINE_WINDOW_SEC = 12.0   # 心跳 3s，容忍丢 4 次
# 设备形态缓存（dev -> desktop/phone/tablet）：心跳高频调用时避免重复写 .platform
_PLATFORM_CACHE = {}
# SV-M5：/recent/devices 结果缓存——两端停留最近页时每 5s 轮询，全量目录遍历
# + stat + 读 .platform 重复执行纯属浪费；缓存 3s（轮询周期内最多一次真遍历）
_DEVICES_CACHE = {"ts": 0.0, "data": None}
_DEVICES_CACHE_SEC = 3.0
# SV-AD2：recent 端点字段长度上限——_safe_path 只净化不截断，超长 dev 名会
# 以键驻留 LAST_SEEN 24h、超长 dev/name 使副本落盘 ENAMETOOLONG 失败但
# ALIAS 已登记（origin 指向真实文件时 GC 不清），构成内存膨胀缺口
MAX_DEV_LEN = 128
MAX_NAME_LEN = 255
# origin_rel 会作为 ALIAS 的值驻留内存，同样需要有界
MAX_ORIGIN_LEN = 1024
# SV-AE1：核心协作路径没有长度上限——超长 path 必然 ENAMETOOLONG，rev>0 的
# entry 永远落不了盘，GC 便永远不会回收（单请求可留下近 16MB 常驻内存）。
# 按 Linux 文件系统口径限制：单组件 ≤255 字节、整路径 ≤4096 字节
MAX_PATH_BYTES = 4096
MAX_SEG_BYTES = 255
# SV-AE3：设备名在字符上限之外还需字节上限（255 个中文字符 = 765 字节）
MAX_DEV_BYTES = 255
# SV-AE3/SV-AE5：ALIAS / _PLATFORM_CACHE 容量上限（FIFO 淘汰）
MAX_ALIAS = 8192
MAX_PLATFORM_CACHE = 4096
# SRV34-7：LAST_SEEN 同样需要有界——设备名可随意更换，心跳会无限新增键
MAX_LAST_SEEN = 8192
# 复审 rd1：device_id（Syncthing 设备 ID）→ device_name（recent/<设备>/ 目录段）
# 别名表。publish/ack 用设备名，open/SSE/claim/release 用 Syncthing ID；ack
# 收敛要求 owner（设备名）已上报，若不建立映射，真机上 owner 的 ack 永远对不上
# 键名 → 快照永不删除（RECENT_ROOT 无界增长）。有界（FIFO 淘汰）。
DEV_NAME_ALIAS = {}
MAX_DEV_ALIAS = 8192

# ======================== 客户端构建号上报（三端对齐第③项） ========================
# 契约：客户端在每个 API 请求上带请求头
#     X-Markor-Client: <platform>/<build>
# platform ∈ desktop / phone / tablet；build 为十进制非负整数（构建号/versionCode）。
# 服务端只在内存登记，绝不把版本信息写进同步根或 RECENT_ROOT。
CLIENT_HEADER = "X-Markor-Client"
# 最近上报的设备表：键为 "id:<device_id>" 或 "name:<device_name>"，有界（FIFO）
CLIENT_REPORTS = {}
MAX_CLIENT_REPORTS = 1024
CLIENT_REPORT_TTL_SEC = 86400.0   # 24h 无任何请求即淘汰（与 LAST_SEEN 同口径）
_CLIENT_AUDIT = {"reports": 0, "rejected": 0}
# 老客户端防护（默认全关，见 README）：
#   REQUIRE_CLIENT_HEADER=1  要求 /api/v1/* 必须带合法 X-Markor-Client 头
#   MIN_BUILD_DESKTOP/PHONE/TABLET=<n>  按平台最低构建号，缺省 0=不拦
#   MIN_CLIENT_VERSION 已弃用：某平台未单独设置阈值时沿用它的值（兼容老配置）
_REQUIRE_CLIENT_HEADER_RAW = os.environ.get(
        "REQUIRE_CLIENT_HEADER", "").strip().lower()
_MIN_BUILD_VARS = {"desktop": "MIN_BUILD_DESKTOP",
                   "phone": "MIN_BUILD_PHONE",
                   "tablet": "MIN_BUILD_TABLET"}
_MIN_BUILD_RAWS = {plat: os.environ.get(var, "").strip()
                   for plat, var in _MIN_BUILD_VARS.items()}
_MIN_CLIENT_VERSION_RAW = os.environ.get("MIN_CLIENT_VERSION", "").strip()
MIN_CLIENT_VERSION = 0
MIN_BUILDS = {"desktop": 0, "phone": 0, "tablet": 0}
REQUIRE_CLIENT_HEADER = False

# ======================== writer token（写入权） ========================
# 协议见 docs/design-2026-11-05-writer-token.md。目标：同一会话同一时刻只有
# 一个客户端写本地文件，从源头消除“双端同时保存 → Syncthing 冲突副本”。
# 服务端只发令牌、不落盘（阶段①零写同步根不变）。
WRITER_OFFLINE_SEC = float(os.environ.get("MARKOR_WRITER_OFFLINE_SEC", "15"))
WRITER_WATCH_SEC = float(os.environ.get("MARKOR_WRITER_WATCH_SEC", "2"))
_WRITER_AUDIT = {"changes": 0, "transfers": 0, "timeouts": 0}

# ======================== 写盘范围（阶段①硬不变式） ========================
# 锁服务零写同步根（DISK_ROOT）：所有落盘只允许 RECENT_ROOT 白名单路径。
# 违规一律抛 RuntimeError（不静默跳过），启动自检主动验证该守卫后 fail-fast。
_WRITE_AUDIT = {"recent_writes": 0, "disk_denied": 0, "last_recent": ""}
_WRITE_AUDIT_LOCK = threading.Lock()


# ======================== 工具 ========================

def _now():
    return time.time()


_KEEPALIVE_WARNED = set()

def _keepalive_warn(opt_name, err):
    """R21-2：选项设置失败每项只告警一次，避免每个 SSE 连接刷屏。

    半开连接兜底依赖这些选项；设置失败会让最坏识别时间从 ≈90s 退化到内核
    重传放弃（Linux 默认 ≈15 分钟），必须在 journal 里留下可检索的痕迹。
    """
    if opt_name in _KEEPALIVE_WARNED:
        return
    _KEEPALIVE_WARNED.add(opt_name)
    _log(f"[sse] keepalive opt {opt_name} failed: {err!r} "
         f"(half-open detection may degrade)")

def _enable_tcp_keepalive(sock):
    """R19-1：给 SSE 长连接开 TCP 保活，兜住“不发 FIN 的半开连接”。

    应用层 keepalive 每 30s 往 SSE 写一帧，但对端 NAT 静默失效时 send() 只会
    把十几字节塞进发送缓冲区就返回成功（内核在后台重传），不会抛错；GC 的
    `last_active` 还会被这些“成功”写持续刷新，于是订阅者既不会被 GC 判死，
    也一直留在 `subs` 里被当作在线（writer token 因此无法按 ≤17s 移交）。
    只靠 socket 的 120s 写超时也兜不住：缓冲区填满前写不会阻塞，真正的
    失败要等内核 TCP 重传放弃（Linux 默认 tcp_retries2=15，约 15 分钟）。

    注意：内核在该连接有未确认数据（正在重传）时会抑制 keepalive 探针，
    而应用层 keepalive 帧恰好会制造这种未确认数据，故不能只靠 30/10/3。
    Linux 上额外设 TCP_USER_TIMEOUT=60s：未确认数据超过 60s 即强制关闭，
    保证最坏 30（首个保活帧）+60≈90s 内报错，落在 120s 预算内。
    SSE handler 随即退出、移除订阅并触发 writer 移交。
    Windows 的 Python 没有 TCP_KEEPIDLE/TCP_KEEPINTVL/TCP_KEEPCNT 常量，
    只开 SO_KEEPALIVE（系统默认 2h）；线上部署目标为 Linux，可拿到 60s 级。
    所有选项独立尝试：任一选项不支持/设置失败都不影响其余选项。
    """
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    except OSError as e:
        # 基础项失败不提前返回：TCP_USER_TIMEOUT 仍可兜住未确认数据
        _keepalive_warn("SO_KEEPALIVE", e)
    for opt_name, val in (("TCP_KEEPIDLE", 30),
                          ("TCP_KEEPINTVL", 10),
                          ("TCP_KEEPCNT", 3)):
        opt = getattr(socket, opt_name, None)
        if opt is None:
            continue
        try:
            sock.setsockopt(socket.IPPROTO_TCP, opt, val)
        except OSError as e:
            # 某些平台/受限环境不支持细粒度参数；至少 SO_KEEPALIVE 已开启
            _keepalive_warn(opt_name, e)
    if sys.platform.startswith("linux"):
        # TCP_USER_TIMEOUT = 18（include/uapi/linux/tcp.h）；Python 未必导出该常量
        opt = getattr(socket, "TCP_USER_TIMEOUT", 18)
        try:
            sock.setsockopt(socket.IPPROTO_TCP, opt, 60000)
        except OSError as e:
            _keepalive_warn("TCP_USER_TIMEOUT", e)

def _is_recent_path(path):
    """协作 key 是否属于服务器副本区（RECENT_ROOT）——唯一允许落盘的范围。"""
    return isinstance(path, str) and path.startswith(RECENT_PREFIX)

def _note_write(kind, path):
    """写盘审计计数（/health 可读），用于验证“同步根零写”。"""
    with _WRITE_AUDIT_LOCK:
        if kind == "recent":
            _WRITE_AUDIT["recent_writes"] += 1
            _WRITE_AUDIT["last_recent"] = path
        else:
            _WRITE_AUDIT["disk_denied"] += 1

def _assert_recent_full_path(full):
    """硬不变式：绝对路径解析后必须仍在 RECENT_ROOT 内，否则抛错。"""
    root = os.path.realpath(RECENT_ROOT)
    real = os.path.realpath(full)
    try:
        inside = os.path.commonpath([root, real]) == root
    except ValueError:
        inside = False
    if not inside:
        _note_write("disk_denied", full)
        _log(f"[flush] DENY write outside RECENT_ROOT path={full}")
        raise RuntimeError(f"write outside RECENT_ROOT denied: {full}")

def _snap_meta_nolock(path):
    """取/建某快照的参与者与上报记录（调用方必须已持 _lock）。"""
    meta = SNAP_META.get(path)
    if meta is None:
        meta = {"participants": set(), "acks": {}, "last_active": {}}
        SNAP_META[path] = meta
    # 兼容旧内存结构（热重载/调试时可能残留无该键的字典）
    meta.setdefault("last_active", {})
    return meta

def _mark_participant_nolock(path, dev):
    """登记快照参与设备（调用方必须已持 _lock）。只对 recent/ 生效。"""
    if not dev or not _is_recent_path(path):
        return
    meta = _snap_meta_nolock(path)
    if dev in meta["participants"]:
        meta["last_active"][dev] = _now()
        return
    if len(meta["participants"]) < MAX_SNAP_PARTICIPANTS:
        meta["participants"].add(dev)
        meta["last_active"][dev] = _now()


def _merge_client_rec_nolock(cur, old):
    """把一条同设备上报记录并入 cur（调用方必须已持 _lock）。

    保留较新的 last_seen、累加 requests、取最早 first_seen；平台/构建号/名称/id
    只补空值，不覆盖已确认的信息。
    """
    cur["requests"] += old.get("requests", 0)
    cur["first_seen"] = min(cur.get("first_seen", old.get("first_seen", 0.0)),
                            old.get("first_seen", cur.get("first_seen", 0.0)))
    cur["last_seen"] = max(cur.get("last_seen", 0.0), old.get("last_seen", 0.0))
    if not cur.get("platform"):
        cur["platform"] = old.get("platform", "")
    if cur.get("build") is None:
        cur["build"] = old.get("build")
    if not cur.get("device_name"):
        cur["device_name"] = old.get("device_name", "")
    if not cur.get("device_id"):
        cur["device_id"] = old.get("device_id", "")


def _pop_fallback_row_nolock(device_name, keep_key):
    """取出「把设备名当 device_id 上报」的旧回退行（调用方必须已持 _lock）。

    客户端在同步引擎 ID 就绪前会用设备名填补 device_id（Android LockClient
    `_deviceId = _deviceName`），于是上报里出现 `id:<设备名>` 这种伪 id 行。
    它的 device_id 就是设备名，没有独立身份；同名的另一行才是真实 id 行。
    只在“该行确实由回退产生（device_id == device_name）”时取出并入，绝不把
    两个真实 id 行互并。返回该记录或 None（取出的记录已从表中移除）。
    """
    if not device_name or keep_key == "id:" + device_name:
        return None
    key = "id:" + device_name
    old = CLIENT_REPORTS.get(key)
    if old is None or old.get("device_id") != device_name:
        return None
    CLIENT_REPORTS.pop(key, None)
    return old


def _remember_dev_alias_nolock(device_id, device_name):
    """复审 rd1：登记 device_id → device_name 映射（调用方必须已持 _lock）。

    只接受完整、合法的双字段请求（open/SSE/claim/release/publish）：这些请求里
    device_name 是本机自身名称，与 publish 的 recent/<设备>/ 目录段同口径。
    ack 的 device_name 是「快照所属设备」而非本机，不能用于登记。
    """
    if (not device_id or not device_name or device_id == device_name
            or not _valid_device(device_id)
            or not _valid_device(device_name)):
        return
    DEV_NAME_ALIAS.pop(device_id, None)
    DEV_NAME_ALIAS[device_id] = device_name
    while len(DEV_NAME_ALIAS) > MAX_DEV_ALIAS:
        try:
            DEV_NAME_ALIAS.pop(next(iter(DEV_NAME_ALIAS)))
        except StopIteration:
            break
    # 客户端上报表去重（三端对齐第③项）：设备在拿到 device_id 之前只带名称
    # 上报（心跳常见），会留下 "name:<设备名>" 行；建立别名后把该行并入
    # "id:<device_id>"，保留较新的 last_seen、累加 requests、取最早 first_seen，
    # 使 /api/v1/clients 每台设备只一行。两个不同 id 的行永不互并。
    id_key = "id:" + device_id
    name_key = "name:" + device_name
    old = CLIENT_REPORTS.pop(name_key, None)
    if old is not None:
        if old.get("device_id") and old["device_id"] != device_id:
            # 该名称行已归属另一台同名设备（防御性归还，不挪用）
            CLIENT_REPORTS[name_key] = old
            old = None
        elif CLIENT_REPORTS.get(id_key) is None:
            # 没有真实 id 行：名称行直接改名归位
            old["device_id"] = device_id
            old["device_name"] = device_name
            CLIENT_REPORTS[id_key] = old
            old = None
    # 回退行：客户端在引擎 ID 就绪前把设备名当 device_id 上报（id==name），
    # 会在 /api/v1/clients 留下同名的第二行；这里并入真实 id 行
    fb = _pop_fallback_row_nolock(device_name, id_key)
    cur = CLIENT_REPORTS.get(id_key)
    for extra in (old, fb):
        if extra is None or extra is cur:
            continue
        if cur is None:
            extra["device_id"] = device_id
            extra["device_name"] = device_name
            CLIENT_REPORTS[id_key] = cur = extra
        else:
            _merge_client_rec_nolock(cur, extra)

def _prune_stale_snap_meta():
    """复审 R10：回收「既无磁盘快照、也无内存会话」的 SNAP_META 条目。

    SNAP_META 只在快照删除/ack 收敛/设备注销时清理。SSE/open/op/struct 可对
    任意 recent/<dev>/<name> 登记参与设备，而这些路径可能从未有过快照（absent
    会话）或快照已被外部删除——会话回收后条目仍常驻内存，随访问过的文件名
    累积，长期运行无界增长。

    调用方必须持 _recent_io_lock（与 publish/delete/ack 的副本写互斥）；stat
    一律在 _lock 外执行。save/op 建出内存会话时不持 _recent_io_lock，故回锁后
    还要复核 FILES——有会话（即将落盘）时必须保留。
    """
    with _lock:
        candidates = [p for p in SNAP_META
                      if _is_recent_path(p) and (VAULT_ID, p) not in FILES]
    stale = []
    for p in candidates:
        try:
            if not os.path.isfile(_full_path(p)):
                stale.append(p)
        except OSError:
            pass
    if not stale:
        return
    with _lock:
        for p in stale:
            if (VAULT_ID, p) in FILES:
                continue
            SNAP_META.pop(p, None)


def _clean_surrogates(s):
    """SV-U5：替换未配对代理项。json.loads 接受未配对代理转义输入，但
    ensure_ascii=False 后 encode("utf-8") 会抛 UnicodeEncodeError——广播、
    hello、基线帧、落盘全部随之中断，该文件在所有端都无法再订阅/同步。
    encode("replace") 把代理项替换为 '?'，其余内容原样保留。"""
    return s.encode("utf-8", "replace").decode("utf-8")

def _as_text(v):
    """SV-S10：JSON null 不能被 str() 变成字面量 "None" 写进权威内容。

    SRV36-9：dict/list 等容器经 str() 会变成 Python repr（如 "{'a': 1}"）写进
    权威内容并广播/落盘；非标量一律返回 None，由调用方按 400 拒绝。
    """
    if v is None:
        return ""
    if isinstance(v, str):
        return _clean_surrogates(v)
    if isinstance(v, (int, float)):
        return _clean_surrogates(str(v))
    return None

BOM = "\ufeff"

def _normalize_content(text):
    """R16-F4：服务端权威内容的唯一规范形态 = 无前导 U+FEFF 的文本。

    三端统一契约：`content_hash = sha256(utf8(规范内容))`，`size` 为规范内容
    的 UTF-8 字节数，行尾（CRLF/CR/LF）与尾部换行按收到的原样保留。
    两端客户端读本地文件都会剥掉 BOM 再算 hash 上报 ack，而旧版本服务端按
    原样落盘/读盘（保留 BOM），导致同一文件的 `/file`、`/open`、
    `/recent/file` 与 ack 收敛出现两种 hash/size 口径：带 BOM 的副本永远
    收敛不了，客户端也会把 BOM 注入编辑器后保存出双 BOM。

    只处理**前导** U+FEFF（连续多个也一并剥掉，规范形态不允许任何前导 BOM）；
    出现在行中/行尾的 U+FEFF 是合法的零宽不换行字符，必须原样保留。
    """
    if not text:
        return "" if text is None else text
    return text.lstrip(BOM)

def _log(msg):
    """业务日志直写统一入口（SV-Y2）：与 log_message 同口径过滤非打印字符——
    path/device_name 等客户端可控字段里的 \r\n 等控制字符可截断/伪造日志行。"""
    print("".join(ch if ch.isprintable() else "?" for ch in msg), flush=True)


def _init_api_key():
    """加载或生成服务器 API Key，并维护迁移期旧密钥。

    语义（与服务器地址一致：有就用、没有才生成）：
      - `server-api-key` 存在且非空 → 原样沿用（重启/升级不变）；
      - 缺失 → 生成一次 12 位 [a-z0-9]，0600 原子写盘；
      - 环境变量 MARKOR_API_KEY（旧静态值）不再作为主密钥，而是登记到
        `server-api-key.prev` 作为“迁移期可接受密钥”：既有客户端继续可用，
        新客户端从 /api/v1/serverkey 获取 12 位新密钥，不会全量 401。
      - `server-api-key.prev` 每行一把旧密钥；全部客户端重新获取后可删除。
    """
    global API_KEY
    try:
        with open(KEY_FILE, "r", encoding="utf-8") as f:
            loaded = f.read().strip()
    except FileNotFoundError:
        loaded = ""
    except OSError as e:
        loaded = ""
        _log(f"[apikey] read failed file={KEY_FILE} err={e!r}")

    if loaded:
        API_KEY = loaded
        _log(f"[apikey] loaded persisted server key len={len(loaded)} file={KEY_FILE}")
    else:
        alphabet = string.ascii_lowercase + string.digits
        API_KEY = "".join(secrets.choice(alphabet) for _ in range(API_KEY_LENGTH))
        try:
            os.makedirs(os.path.dirname(KEY_FILE) or ".", exist_ok=True)
            tmp = KEY_FILE + ".tmp"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(API_KEY + "\n")
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, KEY_FILE)
            try:
                os.chmod(KEY_FILE, 0o600)
            except OSError:
                pass
            _log(f"[apikey] generated new server key len={len(API_KEY)} file={KEY_FILE}")
        except OSError as e:
            _log(f"[apikey] ERROR persist failed file={KEY_FILE} err={e!r}; "
                 f"key is memory-only and will change on restart")

    # 旧密钥：文件里已有的 + 本轮环境变量（若仍有）
    legacy = set()
    try:
        with open(LEGACY_KEY_FILE, "r", encoding="utf-8") as f:
            legacy.update(line.strip() for line in f if line.strip())
    except FileNotFoundError:
        pass
    except OSError as e:
        _log(f"[apikey] legacy read failed file={LEGACY_KEY_FILE} err={e!r}")

    env_key = os.environ.get("MARKOR_API_KEY", "").strip()
    if env_key and env_key != API_KEY and env_key not in legacy:
        legacy.add(env_key)
        _log(f"[apikey] migrated legacy MARKOR_API_KEY (len={len(env_key)}) "
             f"to accepted-only list; existing clients keep working")
        try:
            os.makedirs(os.path.dirname(LEGACY_KEY_FILE) or ".", exist_ok=True)
            fd = os.open(LEGACY_KEY_FILE, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
            with os.fdopen(fd, "a", encoding="utf-8") as f:
                f.write(env_key + "\n")
        except OSError as e:
            _log(f"[apikey] legacy persist failed file={LEGACY_KEY_FILE} err={e!r}")

    LEGACY_API_KEYS.clear()
    LEGACY_API_KEYS.update(legacy)
    if LEGACY_API_KEYS:
        _log(f"[apikey] legacy file present ({len(LEGACY_API_KEYS)} key(s)) "
             f"but RETIRED: not accepted for auth (archive only)")

def _req_text(v):
    """SV-T9：必填字符串字段统一校验。

    原先 str(body.get(...)) 会把 JSON null 变成字面量 "None"，再经 _safe_path
    成为合法路径："path": null 会建出名为 None 的会话并在同步目录写出 None
    文件；device_name: null 会建出 "None" 设备目录。非字符串一律按缺失处理。
    """
    return _clean_surrogates(v.strip()) if isinstance(v, str) else ""

def _req_raw(v):
    """SRV38-1：路径类字段（path/origin_rel/file_name/name）只清理代理项，
    不做 strip——文件名首尾空白在 Linux 上是合法的，SRV37-4 修掉 _safe_path
    的 strip 后，若入口仍 strip，协作 key 与实际文件名不一致：本机 "a.md "
    会被当成本机的 "a.md" 会话，读写到另一个文件（同名不同空白的两份文件
    互相污染）。全空白仍按缺失处理，避免建出名为空白的文件/设备目录。"""
    if not isinstance(v, str):
        return ""
    s = _clean_surrogates(v)
    return "" if not s.strip() else s

def _utf8_len(s):
    """SV-AE1/SV-AE3：文件系统上限按 UTF-8 字节计，不按字符计。"""
    return len(s.encode("utf-8"))

def _valid_device(s, max_chars=MAX_DEV_LEN):
    """SV-AE1：设备标识/名称统一校验（字符数 + UTF-8 字节 + 控制字符）。"""
    if not s or len(s) > max_chars or _utf8_len(s) > MAX_DEV_BYTES:
        return False
    return not any(ord(ch) < 32 or ord(ch) == 127 for ch in s)


def _parse_min_build(raw, var_name="MIN_CLIENT_VERSION"):
    """解析 MIN_BUILD_* / MIN_CLIENT_VERSION（十进制非负整数）。

    非法/空 → 0（该平台不拦）。配置错误不应让服务起不来：门槛是可选的
    运维开关，打印一条告警即可。
    """
    if not raw:
        return 0
    if not raw.isascii() or not raw.isdigit() or len(raw) > 10:
        _log(f"[clients] {var_name} invalid ({raw!r}), gate disabled")
        return 0
    return int(raw)


MIN_CLIENT_VERSION = _parse_min_build(_MIN_CLIENT_VERSION_RAW)
if _MIN_CLIENT_VERSION_RAW:
    _log("[clients] MIN_CLIENT_VERSION is deprecated; "
         "use MIN_BUILD_DESKTOP/MIN_BUILD_PHONE/MIN_BUILD_TABLET")
REQUIRE_CLIENT_HEADER = _REQUIRE_CLIENT_HEADER_RAW in ("1", "true", "yes", "on")
MIN_BUILDS = {
    plat: (_parse_min_build(_MIN_BUILD_RAWS[plat], _MIN_BUILD_VARS[plat])
           if _MIN_BUILD_RAWS[plat] else MIN_CLIENT_VERSION)
    for plat in _MIN_BUILD_VARS
}


def _parse_client_header(raw):
    """解析 `X-Markor-Client: <platform>/<build>` → (platform, build)。

    任何不合法形态都按“未上报”处理（("", None)），绝不因客户端乱填而抛错；
    `build` 为十进制非负整数，便于用 MIN_BUILDS 做数值比较。
    """
    if not isinstance(raw, str):
        return "", None
    plat, sep, build_s = raw.strip().partition("/")
    if not sep:
        return "", None
    plat = plat.strip().lower()
    build_s = build_s.strip()
    if plat not in ("desktop", "phone", "tablet"):
        return "", None
    if (not build_s or len(build_s) > 10 or not build_s.isascii()
            or not build_s.isdigit()):
        return "", None
    try:
        build = int(build_s)
    except ValueError:
        return "", None
    return plat, build


def _short_device_id(device_id, device_name):
    """设备 id 短名：优先 device_id，缺失时退回设备名；只取前 8 个字符。"""
    s = device_id or device_name or ""
    return s[:8]


def _remember_client_nolock(device_id, device_name, platform, build, now):
    """登记一次客户端版本上报（调用方必须已持 _lock）。只存内存，不落盘。

    键优先用 device_id；只有设备名时经 DEV_NAME_ALIAS 反查 id，查不到才用
    名称键（心跳先于 open 到达的窗口）。后续拿到 id 时合并同名名称键。
    """
    # 24h 无请求即淘汰（与 LAST_SEEN 同口径），避免换名/换设备无限驻留
    for k, v in list(CLIENT_REPORTS.items()):
        if now - v["last_seen"] > CLIENT_REPORT_TTL_SEC:
            CLIENT_REPORTS.pop(k, None)
    # 客户端在同步引擎 ID 就绪前会用设备名填补 device_id（Android LockClient
    # `_deviceId = _deviceName`）：id 与名称相同不代表独立身份，一律按“仅有
    # 名称”归档，交给别名表/回退行合并，避免同一台设备在 /clients 占两行。
    if device_id and device_name and device_id == device_name:
        device_id = ""
    key = ""
    if device_id:
        key = "id:" + device_id
    elif device_name:
        for did, dn in DEV_NAME_ALIAS.items():
            if dn == device_name:
                device_id = did
                key = "id:" + did
                break
        if not key:
            fb_key = "id:" + device_name
            fb = CLIENT_REPORTS.get(fb_key)
            if fb is not None and fb.get("device_id") == device_name:
                # 已有回退行（id==name）：就地累计，不另起 name: 行
                key = fb_key
            else:
                key = "name:" + device_name
    if not key:
        return
    rec = CLIENT_REPORTS.pop(key, None)
    if rec is None:
        rec = {"device_id": device_id, "device_name": device_name,
               "platform": "", "build": None, "first_seen": now,
               "last_seen": now, "requests": 0}
    if device_name:
        rec["device_name"] = device_name
    if device_id:
        rec["device_id"] = device_id
    if platform:
        rec["platform"] = platform
    if build is not None:
        rec["build"] = build
    rec["last_seen"] = now
    rec["requests"] += 1
    CLIENT_REPORTS[key] = rec
    # 名称键 / 回退键 → 真实 id 键合并：同一台设备只保留一行
    if device_id and device_name:
        old = CLIENT_REPORTS.pop("name:" + device_name, None)
        if old is not None and old is not rec:
            _merge_client_rec_nolock(rec, old)
        fb = _pop_fallback_row_nolock(device_name, key)
        if fb is not None and fb is not rec:
            _merge_client_rec_nolock(rec, fb)
    while len(CLIENT_REPORTS) > MAX_CLIENT_REPORTS:
        try:
            CLIENT_REPORTS.pop(next(iter(CLIENT_REPORTS)))
        except StopIteration:
            break
    _CLIENT_AUDIT["reports"] += 1

class _LockTimeout(Exception):
    """SV-T6：oplock 等待超时（放弃本轮，不是错误）。"""

@contextmanager
def _timed_lock(lk, timeout=OPLOCK_WAIT_SEC):
    """SV-T6：带超时的锁上下文，超时抛 _LockTimeout 由调用方降级处理。"""
    if not lk.acquire(timeout=timeout):
        raise _LockTimeout()
    try:
        yield
    finally:
        lk.release()

def _disk_mtime(path):
    """协作 key 对应磁盘文件的 mtime（不存在/不可读返回 0）。

    复审 R3：外部键在服务器上没有磁盘快照（文件在客户端设备上），不得按
    同步根同名路径 stat——publish 的新旧判定与副本迁移会因此读到同步根里
    同名的无关文件（proto-2026-11-05：外部键识别后永不从同步根磁盘读同名文件）。
    """
    if _is_external_key(path):
        return 0.0
    try:
        full = _full_path(path)
        if os.path.isfile(full):
            return os.stat(full).st_mtime
    except OSError:
        pass
    return 0.0

def _gc_loop():
    """定期清理僵尸订阅者 + 落盘文件。

    SV-C1/SV-C2 修复：
    - 循环体整体 try/except：GC 职责就是处理死连接，写死连接几乎必然抛异常，
      不能让任何异常杀死 GC 线程（否则服务永久失去 GC，内存只增不减）
    - 锁内只做状态变更与快照，socket 写与磁盘 IO 全部移到锁外执行
    SV-H2 修复：落盘失败不删 entry，下轮 GC 自动重试
    """
    # R26-2：深层清理按墙钟 60s 调度（不是 tick 计数），见下方注释
    next_deep_gc = _now() + 60.0
    while True:
        try:
            time.sleep(10)
            cutoff_sub = _now() - GC_SESSIONS_SEC
            cutoff_flush = _now() - FLUSH_IDLE_SEC
            leave_events = []   # (entry, device_id)
            flush_jobs = []     # (key, entry, content, rev)
            session_jobs = []   # (path, content)：源会话崩溃恢复副本
            with _lock:
                # 清理无活动订阅者
                for key, entry in list(FILES.items()):
                    dead = [s for s in entry.subs if s.is_dead(cutoff_sub)]
                    for s in dead:
                        entry.subs.discard(s)
                        leave_events.append((entry, s.device_id))
                    # 阶段①（batch73）：服务端零写同步根——源会话内容由各端
                    # 本地保存、由 Syncthing 传播；只有 recent/ 副本允许写
                    # RECENT_ROOT。无订阅者的 entry 不再需要驻留内存，直接回收。
                    if entry.mtime < cutoff_flush:
                        if _is_recent_path(key[1]):
                            if entry.rev > 0:
                                flush_jobs.append((key, entry, entry.content, entry.rev))
                            elif not entry.subs:
                                del FILES[key]
                        else:
                            # 2026-11-18（G17）：源会话内容滚动落盘到
                            # RECENT_ROOT/.sessions（独立命名空间，不写同步根），
                            # 服务器崩溃后可人工恢复。有订阅者时也落盘（只刷新
                            # mtime，避免每 10s 重复写）；无订阅者才回收内存。
                            if entry.rev > 0 and entry.content:
                                session_jobs.append((key[1], entry.content))
                                entry.mtime = _now()
                            if not entry.subs:
                                del FILES[key]
                # 复审 R4：ALIAS 存活校验要 stat 磁盘，不能在全局锁内执行，
                # 先在锁内取快照，锁外 stat 后再回锁复核清理
                alias_snapshot = dict(ALIAS)
                # 复审 R12：清理过期的最近页删除墓碑
                now = _now()
                for rp, ts in list(_DELETED_RECENT.items()):
                    if now - ts >= RECENT_TOMBSTONE_SEC:
                        _DELETED_RECENT.pop(rp, None)
                # R26-1：LAST_SEEN 过期清理原先只在心跳请求里执行——设备永久
                # 下线且再无任何设备发心跳时，GC 的 live_devs 会把它的目录
                # 永远当作活跃设备跳过，空目录与孤儿标记无法回收。与心跳
                # 同口径（24h）在此统一过期，下面的 live_devs 即取清理后的集合。
                for d, ts in list(LAST_SEEN.items()):
                    if now - ts > 86400:
                        LAST_SEEN.pop(d, None)
            stale_alias = []
            for rp, og in alias_snapshot.items():
                try:
                    # 复审 R3：外部键无服务器磁盘快照，不能用同步根 stat 判存活
                    if not _origin_exists(og):
                        stale_alias.append((rp, og))
                except OSError:
                    pass
            if stale_alias:
                with _lock:
                    for rp, og in stale_alias:
                        # 复审 R4：回锁复核别名未被并发改写后再清理
                        if ALIAS.get(rp) == og:
                            ALIAS.pop(rp, None)
            # SV-AE5：每 60s 清理 24h 无心跳、仅剩 .platform 的空设备目录，
            # 并淘汰对应形态缓存——心跳/publish 会按需重建，不影响活跃设备
            # 复审 R7：设备目录清理与 publish/delete/迁移的副本写入串行化——
            # 否则 rmdir 可插在“建目录 → 写副本”之间，令在途 publish 落盘
            # ENOENT 失败。锁被占用时本轮跳过，下一 tick 补跑（R26-2）
            # R26-2：深层清理（设备目录/孤儿标记/SNAP_META）按墙钟 60s 调度，
            # 只有成功拿到 _recent_io_lock 才推进下一次；抢占失败不推进，下一
            # tick（10s 后）补跑。原先用 tick % 6 且失败即整周期跳过——持续
            # publish/delete 占用该锁时清理可被无限期饿死，且 tick 周期会随
            # 单次循环耗时漂移；现在既按真实时间定频，也不会漏跑。
            if _now() >= next_deep_gc and _recent_io_lock.acquire(blocking=False):
                try:
                    with _lock:
                        live_devs = set(LAST_SEEN)
                        # 复审 R8：save/close 的落盘只持 entry.oplock、不持
                        # _recent_io_lock——仅凭 LAST_SEEN 判活会漏掉“没有心跳
                        # 但仍有内存会话”的设备，清理其目录可与在途落盘交叉
                        # （rmdir 落在 makedirs 与写临时文件之间 → persisted:false）
                        busy_devs = {k[1].split("/", 2)[1] for k in FILES
                                     if k[1].startswith(RECENT_PREFIX)
                                     and k[1].count("/") >= 2}
                        cache_snapshot = list(_PLATFORM_CACHE)
                    stale_cache = [d for d in cache_snapshot if d not in live_devs]
                    if stale_cache:
                        with _lock:
                            for d in stale_cache:
                                _PLATFORM_CACHE.pop(d, None)
                    now2 = _now()
                    for name in os.listdir(RECENT_ROOT):
                        if name.startswith(".") or name in live_devs or name in busy_devs:
                            continue
                        ddir = os.path.join(RECENT_ROOT, name)
                        if not os.path.isdir(ddir):
                            continue
                        try:
                            entries = os.listdir(ddir)
                        except OSError:
                            continue
                        # 复审 R6：外部源标记（.origin-*.json）不是用户文件，
                        # 不参与“空设备目录”判定；清理目录时一并删除
                        # R23-1：发布端标记（.pub-*.json）同属辅助元数据
                        markers = [e for e in entries
                                   if (e.startswith(".origin-")
                                       or e.startswith(".pub-"))
                                   and e.endswith(".json")]
                        entries = [e for e in entries
                                   if not ((e.startswith(".origin-")
                                            or e.startswith(".pub-"))
                                           and e.endswith(".json"))]
                        # R25-1：标记按 basename 哈希命名。文件被外部清理/改名、
                        # 或 delete/settle 的标记 unlink 失败时，会留下无人认领
                        # 的孤儿标记；原先只在“目录为空”时才清标记，目录里还有
                        # 其它用户文件时孤儿就长期残留（下次同名副本若由镜像落盘
                        # 而非 publish 创建，会继承旧发布端 id 或被旧 origin 吸收）。
                        _clean_orphan_markers(ddir, name, entries, markers)
                        # 复审 R14：落盘临时文件（.mktmp-*）同样不是用户文件——
                        # 进程在 os.replace 前被杀/崩溃会留下此类残留；原先它被
                        # 当作用户文件，令“只剩 .platform”的设备目录永远无法回收。
                        # 目录 mtime 门槛（下方 86400s）保证此处 tmp 早已无在途写者
                        tmps = [e for e in entries if e.startswith(".mktmp-")]
                        entries = [e for e in entries
                                   if not e.startswith(".mktmp-")]
                        # 复审 R7：device-delete 已删 .platform，若目录只剩标记
                        # （entries 为空）也必须允许清理，否则标记目录永久残留
                        if entries and entries != [".platform"]:
                            continue
                        try:
                            if now2 - os.stat(ddir).st_mtime < 86400:
                                continue
                            for m in markers + tmps:
                                try:
                                    os.unlink(os.path.join(ddir, m))
                                except OSError:
                                    pass
                            # R17-1：.platform 可能已不存在（device-delete 或
                            # 外部清理先行删除）。原先无条件 unlink，ENOENT
                            # 被外层 except OSError 吞掉，紧随其后的 rmdir
                            # 永远执行不到——仅剩标记或已空的无主设备目录
                            # 因此永久残留（最近页幽灵设备）。删除必须单独
                            # 容错，不能影响 rmdir。
                            try:
                                os.unlink(os.path.join(ddir, ".platform"))
                            except OSError:
                                pass
                            os.rmdir(ddir)
                        except OSError:
                            pass
                    # 复审 R10：同一 _recent_io_lock 区间内回收「无磁盘快照且无
                    # 内存会话」的 SNAP_META 条目——SSE 可对任意 recent 路径登记
                    # 参与者，断开后 FILES 被回收，SNAP_META 却会永久驻留（按
                    # 文件名无界增长）
                    _prune_stale_snap_meta()
                except OSError:
                    pass
                finally:
                    _recent_io_lock.release()
                    # R26-2：本次已实际执行（含异常路径），按墙钟排下一次；
                    # 抢占失败的路径不会走到这里，保持到期状态供下一 tick 补跑
                    next_deep_gc = _now() + 60.0
            # 锁外：向其余订阅者广播掉线设备（原来写给已死连接本身，毫无意义），
            # 顺带修复"GC 移除僵尸后其他 peers 不知道"的幽灵在线问题
            for entry, dev_id in leave_events:
                _broadcast(entry, {"type": "peer", "device_id": dev_id,
                                   "action": "leave"})
                # R21-1：GC 摘除僵尸订阅同样要留痕——“文件 + 设备 + 原因”，
                # 否则只能看到对端 peer 消失，无法解释是哪条连接、为何掉线
                _log(f"[sse] DROP path={entry.path} dev={dev_id} "
                     f"reason=idle>{int(GC_SESSIONS_SEC)}s")
            # 锁外：落盘；成功且期间无新改动/无新订阅者才删 entry，
            # 失败保留 entry（SV-H2：原来失败也删 → 静默数据丢失）
            for key, entry, content, rev in flush_jobs:
                # 复审 R6：落盘整段持该 entry 的 oplock，入锁复核 rev 无误后
                # 立即写盘——复核与写盘必须同处一个保护范围，否则期间到达的
                # op 会被旧快照覆盖回磁盘
                with entry.oplock:
                    with _lock:
                        if FILES.get(key) is not entry or entry.rev != rev:
                            continue
                    # 阶段①：只有 recent/ 快照会进入 flush_jobs；源路径零写。
                    if _flush_recent(key[1], content):
                        with _lock:
                            if FILES.get(key) is entry and entry.rev == rev:
                                # SRV34-2：落盘成功即推进活动时间，30s 内不再对
                                # 同一份内容整篇读盘比较；只动 mtime，不影响
                                # content_mtime 的新旧判定。落盘失败仍保留 entry
                                # 供下轮重试
                                entry.mtime = _now()
                                if not entry.subs:
                                    del FILES[key]
            # 锁外：源会话崩溃恢复副本滚动落盘（失败只记日志）
            for spath, scontent in session_jobs:
                _persist_session(spath, scontent)
        except Exception as e:
            _log(f"[gc] loop error: {e}")

RECENT_PREFIX = "recent/"   # 协作 key 前缀：recent/<设备名>/<文件名>，落 RECENT_ROOT
# ALIAS：recent/<设备>/<文件> -> 源设备上该文件的协作 key（如桌面 "a.txt"）。
# 源设备在线时，打开副本的其它设备与源设备共用同一个 FileEntry（内容/rev/订阅者
# 全共享），从而实现"另一端打开最近文件也能实时协同编辑"；源设备离线时副本
# 仍走自己的会话，编辑内容留在副本里，等源设备下次打开时再合并回去。
ALIAS = {}
# SV-T1：每个副本上一次 publish 后的权威内容摘要（"已同步基线"）。
# 副本内容若不是该基线，说明两次上报之间副本被他端（远程会话的 op/save/
# adopt）改过，副本才可能是更新的一方；若副本内容仍等于基线，则它只是上一次
# 上报的回声，本次 publish 的 content 才是源设备当前视图。仅凭副本磁盘 mtime
# 判新旧不成立——那个 mtime 就是上一次 publish 的服务端写盘时间，恒晚于源文件。
# SV-U2：只存 sha256 摘要（不存整篇文本），避免长文本文档 × N 副本的内存膨胀；
# 所有读改写均在 _lock 内进行。
_PUBLISHED_LOCAL = {}
# SV-U2：基线表条目上限，超出按插入序淘汰最旧条目，防止长期运行无界增长
_PUBLISHED_LOCAL_MAX = 8192

def _content_digest(text):
    """SV-U2：内容摘要（与基线比对口径一致，空内容也有确定摘要）。

    R16-F4：入参先剥前导 BOM——基线（_PUBLISHED_LOCAL）与 ack 收敛的
    snap_hash 都经此计算，与两端客户端“剥 BOM 后算 hash”的 ack 口径一致。
    """
    return hashlib.sha256(
        _normalize_content(text).encode("utf-8")).hexdigest()

# ============ 外部路径键命名空间（docs/proto-2026-11-05-absent-and-namespace.md） ============
# 同步根以外的文件在服务器上没有磁盘快照，键只回答“哪个设备的哪个路径”，
# “是不是同一份文件”一律只由 content_hash 判定。
# 新格式：ext2-<device_id 前 8 位>-<sha1(绝对路径) 前 10 位>-<文件名>
# 复审 rd1：安卓 ExternalKey.build 直接取 Syncthing ID 前 8 位（可含 '-'，
# 不足 8 位取全量，回落 "android" 仅 7 位），因此前缀不能要求恰好 8 位纯字母数字。
EXT2_KEY_RE = re.compile(r"^ext2-[A-Za-z0-9-]{1,8}-[0-9a-fA-F]{10}-[^/]+$")
# 旧 PC 键：ext-<sha1 前 10 位>-<文件名>（只读兼容，不删除、不迁移）
EXT_LEGACY_KEY_RE = re.compile(r"^ext-[0-9a-fA-F]{10}-[^/]+$")
# 旧安卓键：_ext/<绝对路径 hashCode>/<文件名>（同上只读兼容）
EXT_ANDROID_LEGACY_RE = re.compile(r"^_ext/[0-9a-fA-F]+/[^/]+$")

def _is_external_key(path):
    """是否为“同步根外文件”的会话键：这类键没有磁盘快照，只有内存会话。"""
    if not path:
        return False
    return bool(EXT2_KEY_RE.match(path)
                or EXT_LEGACY_KEY_RE.match(path)
                or EXT_ANDROID_LEGACY_RE.match(path))

def _state_fields(content):
    """有内容/已清空三态字段：state + content_hash + size（UTF-8 字节）。

    R16-F4：按规范内容（无前导 BOM）计算——size 是剥后字节数，不是磁盘
    st_size（带 BOM 的存量副本会差 3 字节）。
    """
    text = _normalize_content(content)
    size = len(text.encode("utf-8"))
    return {"state": "present" if size else "empty",
            "content_hash": _content_digest(text),
            "size": size}

def _absent_fields(path):
    """absent 统一响应体：显式缺席，绝不携带空 content。"""
    return {"ok": False, "state": "absent", "path": path}

def _canonical_utf8_size(full, st_size):
    """R16-F4：磁盘文件的规范内容字节数——前导 UTF-8 BOM（3 字节）不计入。

    只读前 3 字节探测，不整篇读入。/recent/list 的 size 必须与
    /recent/file、/open 的 size 同口径（否则带 BOM 的存量副本会差 3 字节）。
    """
    try:
        with open(full, "rb") as f:
            if f.read(3) != b"\xef\xbb\xbf":
                return st_size
        return max(0, st_size - 3)
    except OSError:
        return st_size

def _disk_snapshot_exists(path):
    """磁盘上是否存在该键对应的内容文件（外部键恒为 False）。

    SRV36-13：解析符号链接后必须仍在所属根目录内，越界不算快照。
    """
    if _is_external_key(path):
        return False
    try:
        return _path_inside_root(path) and os.path.isfile(_full_path(path))
    except OSError:
        return False

def _has_snapshot(path, entry):
    """该键在服务器上是否已有内容快照（三态判定的依据）。

    - 内存会话 rev>0：客户端确实推送过内容（含显式清空后的空内容）；
    - 同步根/副本磁盘文件存在：磁盘快照本身即基线（0 字节文件算 empty）；
    - 外部键且 rev==0：只有 open/订阅登记，从未有快照 → absent。
    """
    if entry is not None and entry.rev > 0:
        return True
    return _disk_snapshot_exists(path)

def _origin_exists(origin):
    """源会话对应的"源文件"是否仍在（副本是否并入源会话的判据）。

    复审 R3：外部键（同步根外文件）在服务器上没有磁盘快照——文件在客户端
    设备上，存在性无法也不应由同步根磁盘判定。原先 _resolve_session_path 与
    GC 的 ALIAS 存活校验一律 stat 同步根，外部源的副本别名在 10s 内被清掉：
    多端无法共用源会话、源端 save 也不再镜像回副本；且可能误读同步根同名
    文件（proto-2026-11-05：外部键识别后永不从同步根磁盘读同名文件）。
    """
    if _is_external_key(origin):
        return True
    return os.path.isfile(_full_path(origin))

def _remember_published(recent, text):
    """记录副本基线摘要；调用方须已持 _lock。"""
    _PUBLISHED_LOCAL.pop(recent, None)
    _PUBLISHED_LOCAL[recent] = _content_digest(text)
    while len(_PUBLISHED_LOCAL) > _PUBLISHED_LOCAL_MAX:
        try:
            _PUBLISHED_LOCAL.pop(next(iter(_PUBLISHED_LOCAL)))
        except StopIteration:
            break

def _remember_alias(recent, origin):
    """SV-AE3：登记副本别名并限制总量；调用方须已持 _lock。"""
    ALIAS.pop(recent, None)
    ALIAS[recent] = origin
    while len(ALIAS) > MAX_ALIAS:
        try:
            ALIAS.pop(next(iter(ALIAS)))
        except StopIteration:
            break

def _remember_platform(dev, plat):
    """SV-AE5：登记设备形态并限制总量；调用方须已持 _lock。"""
    _PLATFORM_CACHE.pop(dev, None)
    _PLATFORM_CACHE[dev] = plat
    while len(_PLATFORM_CACHE) > MAX_PLATFORM_CACHE:
        try:
            _PLATFORM_CACHE.pop(next(iter(_PLATFORM_CACHE)))
        except StopIteration:
            break

# 复审 R6：外部源副本的持久标记。ALIAS 只在内存，进程重启后丢失；此时同名
# 兜底会按 basename 把副本并进同步根的同名文件，违反 proto 红线“外部键识别
# 后永不从同步根读同名文件”（会串内容/rev/peer，甚至经客户端保存污染同步根）。
# publish 落盘成功且源是外部键时，在副本目录写隐藏标记；_resolve_session_path
# 见到标记即放弃兜底，留在副本会话。标记名取 sha1(basename) 前 16 位，避免
# 超长文件名；以 "." 开头，故 /recent/list、devices、device-delete、GC 设备
# 清理均不会把它当作用户文件。
def _external_origin_marker(recent):
    if not _is_recent_path(recent):
        return ""
    name = recent.rsplit("/", 1)[-1]
    h = hashlib.sha1(name.encode("utf-8")).hexdigest()[:16]
    return os.path.join(os.path.dirname(_full_path(recent)),
                        ".origin-" + h + ".json")

def _persisted_external_origin(recent):
    """读取外部源标记；无标记/损坏/非外部键返回 ""。有读盘，调用方不得持 _lock。"""
    if not _is_recent_path(recent):
        return ""
    marker = _external_origin_marker(recent)
    try:
        if os.path.getsize(marker) > MAX_ORIGIN_LEN:
            return ""
        with open(marker, "r", encoding="utf-8") as f:
            origin = f.read().strip()
    except (OSError, ValueError, UnicodeDecodeError):
        return ""
    return origin if _is_external_key(origin) else ""

def _set_external_origin_marker(recent, origin):
    """维护标记：外部源写入，其余清除。会写盘，调用方不得持 _lock。"""
    if not _is_recent_path(recent):
        return
    marker = _external_origin_marker(recent)
    if origin and _is_external_key(origin):
        try:
            _write_text_atomic(marker, origin)
        except OSError as e:
            # R21-3：标记是辅助元数据，写失败不得让 publish/delete 整个失败
            # （原先异常穿出 publish 的 try，连接被重置且内容已落盘的响应丢失）；
            # 但必须留日志——没有标记时重启后同名兜底可能重新吸收外部副本（R6-1）
            _log(f"[flush] FAIL marker {marker}: {e}")
    else:
        try:
            os.unlink(marker)
        except OSError:
            pass

def _publisher_marker(recent):
    """R23-1：发布端设备标识的持久标记（与 .origin 标记同目录、同名哈希）。"""
    if not _is_recent_path(recent):
        return ""
    name = recent.rsplit("/", 1)[-1]
    h = hashlib.sha1(name.encode("utf-8")).hexdigest()[:16]
    return os.path.join(os.path.dirname(_full_path(recent)),
                        ".pub-" + h + ".json")

def _persisted_publisher(recent):
    """读取发布端标记；无标记/损坏返回 ""。有读盘，调用方不得持 _lock。"""
    if not _is_recent_path(recent):
        return ""
    marker = _publisher_marker(recent)
    try:
        if os.path.getsize(marker) > MAX_DEV_BYTES:
            return ""
        with open(marker, "r", encoding="utf-8") as f:
            pid = f.read().strip()
    except (OSError, ValueError, UnicodeDecodeError):
        return ""
    return pid if _valid_device(pid) else ""

def _set_publisher_marker(recent, device_id):
    """维护发布端标记：有 id 写入，无 id 清除。会写盘，调用方不得持 _lock。"""
    if not _is_recent_path(recent):
        return
    marker = _publisher_marker(recent)
    if device_id:
        try:
            _write_text_atomic(marker, device_id)
        except OSError as e:
            # 辅助元数据写失败不得让 publish/ack/delete 失败，但需留日志：
            # 没有标记时重启后 owner 的 ack 无法满足 batch77 门槛（R23-1）
            _log(f"[flush] FAIL pub-marker {marker}: {e}")
    else:
        try:
            os.unlink(marker)
        except OSError:
            pass

def _clean_orphan_markers(ddir, dev, entries, markers):
    """R25-1：清掉设备目录里没有对应副本文件的标记（调用方持 _recent_io_lock）。

    标记名是 basename 的 sha1[:16]，文件被外部清理、改名，或 delete/settle 的
    标记 unlink 失败后，标记会失去对应文件。原 GC 只在“目录为空”时才删标记，
    目录里还有其它用户文件时孤儿便长期残留；同名副本若以后由镜像落盘（非
    publish 创建）重建，会继承旧发布端 id（owner 门槛被他人满足）或被旧
    origin 吸收（R6-1 同型）。这里只按当前可见文件名保留有效标记。
    """
    if not markers:
        return
    valid = set()
    for n in entries:
        if n.startswith("."):
            continue
        recent = RECENT_PREFIX + dev + "/" + n
        valid.add(os.path.basename(_external_origin_marker(recent)))
        valid.add(os.path.basename(_publisher_marker(recent)))
    for m in markers:
        if m not in valid:
            try:
                os.unlink(os.path.join(ddir, m))
            except OSError:
                pass

# 复审 R12：最近页副本删除墓碑——delete 后短时拦截紧邻的 publish，防止
# "先删后复活"；_recent_io_lock 让 delete 与 publish 的副本文件写入串行化
RECENT_TOMBSTONE_SEC = 10.0
_DELETED_RECENT = {}          # recent 路径 -> 删除时间戳
_recent_io_lock = threading.Lock()

def _recent_tombstoned_nolock(path):
    """SV-S3/SV-S4：墓碑判定的"已持 _lock"版本。

    _recent_tombstoned 自己取 _lock，在 _lock 临界区内调用会自锁；凡是需要
    "墓碑判定与后继状态变更/建 entry 处于同一临界区"的地方都用本函数。
    """
    if not path.startswith(RECENT_PREFIX):
        return False
    ts = _DELETED_RECENT.get(path)
    return ts is not None and _now() - ts < RECENT_TOMBSTONE_SEC

def _recent_tombstoned(path):
    """SV-Q4：recent 路径是否处于删除墓碑期内（delete 后 RECENT_TOMBSTONE_SEC 秒）。"""
    if not path.startswith(RECENT_PREFIX):
        return False
    with _lock:
        return _recent_tombstoned_nolock(path)

def _migrate_subs(src_path, dst_path):
    """复审 R2：副本会话切换为源会话时迁移已有 SSE 订阅。

    只在 dst 仍是 FILES 中的当前会话时迁移并清理旧副本 entry；dst 已被并发
    删除时返回 False，由调用方继续使用副本会话，避免订阅落到孤儿 entry。

    SV-Q2 修复：
    - 迁移整段持 src.oplock（外层再套 _recent_io_lock 与 publish/delete 的
      副本文件写互斥，锁序 _recent_io_lock → oplock → _lock 与 publish 一致），
      与在途 op/struct/save 互斥——原先不持锁，op 在锁内完成变更后、
      _broadcast 取订阅者快照前发生迁移时快照为空，该 op 对所有订阅者
      静默丢失且仍返回 200
    - 副本 entry 销毁前把未落盘的协作编辑（活跃编辑期 mtime 新鲜、GC 不
      落盘）先落盘到副本文件——原先直接 FILES.pop(src)，未落盘编辑随
      对象一并丢弃
    - 迁移后向被迁移订阅者补发一条 struct 全量内容，使其本地缓冲区对齐
      源会话基线——原先订阅者收不到任何同步，期间基于错误基线的行号
      op 会错位

    SV-S5：副本会话的编辑必须**并入源会话**再切换订阅者。调用本函数的
    op/struct/save 的行号/结构是按副本编辑器基线算出的，只落盘副本不合并
    回源时，迁移后这些请求会以副本基线套用到源内容 → 整行替换/结构删除
    落到错误行并污染源文件；没有任何 publish/adopt 兜底弥补这一步。
    SV-S6：落盘必须在摘除 src entry **之前**做，且失败时保留 src entry 并
    返回 False（调用方继续使用副本会话），由 GC 重试；原先先 pop 再落盘，
    磁盘满/权限错误时未持久化的协作编辑随对象一并丢失。

    SV-T2：三态返回。True=已迁移/无需迁移；False=dst 消失或 src 落盘失败
    （调用方留在副本会话）；"conflict"=两侧内容各自更新且无法判定新旧，
    不改任何内容也不迁移，调用方返回 409 要求重新 hello/open 拿基线。
    SV-T3：合并广播与被迁移订阅者的基线 struct 都在 dst.oplock 内发送，
    与 op/struct/save 的"持锁广播"处于同一保序区间。
    """
    if src_path == dst_path:
        return True
    with _lock:
        src = FILES.get((VAULT_ID, src_path))
        dst = FILES.get((VAULT_ID, dst_path))
        if dst is None:
            return False
    if src is None:
        return True
    migrated = []
    merge_json = None
    writer_json = None
    conflict = False
    base_content = base_rev = base_mtime = None
    # SV-U7：保持锁序 _recent_io_lock → oplock（先取全局锁再取两把 oplock），
    # 但全局锁只覆盖"状态变更 + 落盘"，在广播前提前释放——原先合并广播与
    # 基线帧也在全局锁内发送，慢 SSE 订阅者（单个 write 最长 15s）会把全服
    # publish/delete/迁移串行堵住，抵消 SV-T6 超时获取的收益
    with ExitStack() as stack:
        # SRV34-3：改为带超时获取——publish/delete/save 会跨磁盘 IO 长时间持有
        # _recent_io_lock，无超时会让所有 recent 路径请求一起阻塞；超时放弃本轮，
        # 调用方留在副本会话可重试，锁序仍为 _recent_io_lock → oplock → _lock
        if not _recent_io_lock.acquire(timeout=OPLOCK_WAIT_SEC):
            return False
        try:
            # SV-T6：带超时获取两把 oplock，避免慢 SSE 订阅者的持锁广播让本函数
            # 在全局锁内无限等待；超时即放弃本轮，调用方留在副本会话可重试
            try:
                stack.enter_context(_timed_lock(src.oplock))
                stack.enter_context(_timed_lock(dst.oplock))
            except _LockTimeout:
                return False
            with _lock:
                # dst/src 并发消失复核（与 op 同型身份校验）
                if FILES.get((VAULT_ID, dst_path)) is not dst:
                    return False
                if FILES.get((VAULT_ID, src_path)) is not src:
                    # src 已被 delete/GC 清走，订阅集已空，无需迁移
                    return True
                # SV-U6：新旧判定用内容变更时间，不用活动时间（hello/leave/
                # 无变化 save 都刷新 mtime，会把"刚打开过"误判成"内容更新"）
                src_content, src_rev, src_mtime = src.content, src.rev, src.content_mtime
                dst_content, dst_rev, dst_mtime = dst.content, dst.rev, dst.content_mtime
            # 复审 R4：等待锁期间 dst 可能被 GC 换成 rev==0 的新对象（外部键
            # 只有 SSE 订阅时没有任何磁盘快照）。并入会吞掉副本自己的磁盘
            # 快照，口径与 _resolve_session_path 一致：无快照则留在副本会话。
            # stat 在 _lock 外（仍在 _recent_io_lock + 两把 oplock 内）
            if not _has_snapshot(dst_path, dst):
                return False
            # SV-S6：先落盘（持 src.oplock，与"摘除"同处一个临界区），成功才迁移；
            # rev==0 表示从未改过，内容与副本磁盘一致，无需落盘
            if src_rev > 0:
                if not _flush_recent(src_path, src_content):
                    # 保留 src entry 与订阅者，调用方留在副本会话，等 GC 重试落盘
                    return False
            # SV-T2：新近度基线——dst 有过内存改动（rev>0）时用它最后一次修改
            # 时间；否则用源文件磁盘 mtime（口径与 publish 的 origin_ts 一致）。
            # stat 在 _lock 外（锁内禁磁盘 IO），仍在 _recent_io_lock + 两把 oplock 内
            dst_ts = dst_mtime if dst_rev > 0 else _disk_mtime(dst_path)
            with _lock:
                # 落盘期间 dst/src 仍可能被 delete/GC 清走，复核后再合并/迁移
                if FILES.get((VAULT_ID, dst_path)) is not dst:
                    return False
                if FILES.get((VAULT_ID, src_path)) is not src:
                    return True
                # SV-T2：只有 src 内容**确实比 dst 新**时才并入（上一轮建议的
                # 前置条件）。原先"内容不同即合并"把副本旧内容当成更新的一方，
                # 源端较新的内容会被回滚并广播全端
                if src_rev > 0 and src_content != dst_content:
                    if src_mtime > dst_ts:
                        dst.content = src_content
                        dst.mtime = _now()
                        dst.content_mtime = dst.mtime   # SV-U6
                        dst.rev += 1
                        merge_json = {"type": "struct", "start": 0,
                                      "delete": -1, "insert": [],
                                      "content": src_content, "device_id": "",
                                      "ts": int(dst.mtime), "rev": dst.rev}
                    else:
                        conflict = True
                if not conflict:
                    # 复审 R2：把副本端已建立的订阅并入源会话，随后清理旧 entry，
                    # 否则副本端收不到源端广播且旧 entry 永不回收。同步改写每个
                    # SSEHandler 绑定的 entry，使其保活/离开逻辑跟随迁移后的会话
                    migrated = list(src.subs)
                    for s in migrated:
                        s.entry = dst
                    dst.subs.update(migrated)
                    src.subs.clear()
                    # writer token：令牌随逻辑会话迁移。参与者取并集（保留较新
                    # 的 last_active）；dst 无主时沿用 src 的 writer，否则保持 dst。
                    for dev, p in src.participants.items():
                        cur = dst.participants.get(dev)
                        if cur is None:
                            dst.participants[dev] = dict(p)
                        else:
                            if p["last_active"] > cur["last_active"]:
                                cur["last_active"] = p["last_active"]
                            if p.get("device_name"):
                                cur["device_name"] = p["device_name"]
                    if dst.writer_device_id is None and src.writer_device_id:
                        dst.writer_device_id = src.writer_device_id
                        dst.writer_device_name = src.writer_device_name
                        dst.writer_since = src.writer_since
                        dst.writer_rev += 1
                        _WRITER_AUDIT["changes"] += 1
                        writer_json = {
                            "type": "writer_changed",
                            "writer_device_id": dst.writer_device_id,
                            "writer_device_name": dst.writer_device_name,
                            "previous_writer_device_id": None,
                            "previous_writer_device_name": "",
                            "writer_rev": dst.writer_rev,
                            "writer_since": int(dst.writer_since),
                            "reason": "migrate"}
                    FILES.pop((VAULT_ID, src_path), None)
                    base_content, base_rev, base_mtime = (dst.content, dst.rev,
                                                          dst.mtime)
        finally:
            _recent_io_lock.release()
        if conflict:
            # SV-T2：两侧都改过且源内容不比副本新——不做回滚式合并，返回
            # 三态标记由调用方 409，客户端重新 hello 后可基于新基线重试
            return "conflict"
        # SV-T3/SV-U7：合并广播与基线 struct 都在两把 oplock 内发送（全局
        # _recent_io_lock 已提前释放），与 op/struct/save 的持锁广播同区间——
        # 否则并发 op 可先送达 rev=N+2 的新内容，随后到达的合并/基线帧
        # 携带旧全文，客户端按到达序整篇替换即被回退
        if merge_json is not None:
            _broadcast(dst, merge_json)
        if writer_json is not None:
            _broadcast(dst, writer_json)
        if migrated:
            # R21-6：会话迁移原先无任何日志——客户端“打开 A 却在编辑 B”
            # 这类问题只能靠猜。记录文件名、迁移的订阅数与是否合并/移交
            _log(f"[sse] MIGRATE {src_path} -> {dst_path} "
                 f"subs={len(migrated)} merged={merge_json is not None} "
                 f"writer_moved={writer_json is not None}")
            # SV-Q2：补发 struct 对齐基线（事件携带整篇权威内容）
            data = ("data: " + json.dumps(
                {"type": "struct", "start": 0, "delete": -1, "insert": [],
                 "content": base_content, "device_id": "",
                 "ts": int(base_mtime), "rev": base_rev},
                ensure_ascii=False) + "\n\n").encode("utf-8")
            for s in migrated:
                try:
                    s.write(data)
                except Exception:
                    pass
    return True

def _resolve_session_path(path):
    """副本路径 → 实际使用的会话 key。源会话在线则返回源 key。

    SV-T2：返回 None 表示"副本与源会话内容各自更新且无法判定新旧"，调用方
    按 409 处理（要求重新 open/hello 拿基线），不得以被回滚的基线继续写。
    """
    if not path.startswith(RECENT_PREFIX):
        return path
    with _lock:
        if path in _DELETED_RECENT:
            # SV-BL5（第三十三轮复查）：墓碑必须先于别名/同名兜底判定。删除
            # 副本后别名已摘除，若先走同名兜底可能解析到另一目录的同名源
            # 文件，op 会 200 改写无关文件；直接返回原路径交给
            # _entry_get_or_create 判定 410
            return path
    # 2026-11-06：副本目录改为 id 段后，旧客户端/旧副本仍用名字段。当前段
    # 没有任何会话、别名或磁盘副本时，先换到同设备“确有内容”的等价段再
    # 继续解析——必须在别名归并之前换段，否则会绕过 ALIAS 另开会话
    with _lock:
        has_alias = path in ALIAS
        live_here = (VAULT_ID, path) in FILES
    if not has_alias and not live_here and not _disk_snapshot_exists(path):
        parts = path.split("/")
        if len(parts) == 3:
            alt = _recent_alt_key(path, parts[2])
            if alt is not None:
                with _lock:
                    if alt in _DELETED_RECENT:
                        return path
                path = alt
            else:
                # 段内无任何活副本：等价段若是刚删除（墓碑期内），返回该墓碑键
                # 交给 entry 判定 410——否则旧客户端会按名字重建空会话
                tomb = _recent_tomb_key(parts[1], parts[2], path)
                if tomb is not None:
                    return tomb
    with _lock:
        origin = ALIAS.get(path)
        origin_entry = FILES.get((VAULT_ID, origin)) if origin else None
        origin_live = origin_entry is not None
    if origin_live:
        # SV-M8：源文件已被 Syncthing 删除时不并入源会话——否则会"复活"已删文件
        # 复审 R3：外部键没有服务器磁盘快照，存在性由在线源会话决定（不能 stat）
        if not _origin_exists(origin):
            with _lock:
                ALIAS.pop(path, None)
        elif not _has_snapshot(origin, origin_entry):
            # 复审 R4：源会话在线但从未有过快照（外部键仅有 SSE 订阅、rev==0；
            # 或同步根源文件被外部清掉）。并入会把副本自己的磁盘快照遮蔽成
            # absent/empty——/open、/file 对副本键报 absent，/recent/file 返回
            # 空内容而 /recent/list 仍显示有大小。留在副本会话，等源端真正
            # 推送内容（rev>0）后再并入。
            return path
        else:
            # 复审 R2：切换前迁移已有 SSE 订阅；dst 消失则留在副本会话
            r = _migrate_subs(path, origin)
            if r == "conflict":
                return None
            if r:
                return origin
            return path
    # SV-T4：别名已登记但源会话离线（源设备只是没打开，磁盘文件仍在）——
    # 直接留在副本会话，不再走同名兜底。兜底只校验"唯一匹配"，不校验候选
    # 就是该副本的源文件：另一目录下恰有同名文件在线时，副本会被并入并合并
    # 内容到错误文件，请求本身也会落到错误路径
    if origin:
        return path
    # 复审 R6：外部源副本（ALIAS 因进程重启丢失）不得按同名兜底并入同步根
    # 同名文件——标记由 publish 落盘成功时写入，只认外部键源
    if _is_recent_path(path) and _persisted_external_origin(path):
        return path
    # 还没登记别名（源设备尚未上报过该文件）：按文件名兜底并入已打开的
    # 同名源会话，否则同一文件在两端各自开会话——表现为"有时不提示 xxx端在编辑"
    name = path.rsplit("/", 1)[-1]
    with _lock:
        # SV-M2：兜底必须唯一匹配——跨目录同名文件并入同一会话会串文件
        # SV-S9：兜底只能匹配同步目录内的源会话——另一设备的同名副本
        # (recent/B/f.md) 不是同一文件，并入会跨文件串内容/rev/peer
        # 复审 R3：外部键（同步根外文件）没有同步根磁盘文件，不参与同名兜底
        matches = [p for (v, p) in FILES.keys()
                   if v == VAULT_ID and p != path
                   and not p.startswith(RECENT_PREFIX)
                   and not _is_external_key(p)
                   and (p == name or p.endswith("/" + name))]
    if len(matches) == 1 and _origin_exists(matches[0]):
        # 复审 R2：同名兜底会话切换同样迁移已有订阅
        r = _migrate_subs(path, matches[0])
        if r == "conflict":
            return None
        if r:
            return matches[0]
    return path

def _recent_copies_of(path):
    """源文件路径对应的所有服务器副本路径（反向查 ALIAS）。"""
    with _lock:
        return [r for r, o in ALIAS.items() if o == path]

def _full_path(path):
    """协作 key → 磁盘绝对路径。recent/ 前缀走服务器副本存储，其余走同步目录。"""
    if path.startswith(RECENT_PREFIX):
        return os.path.join(RECENT_ROOT, *path[len(RECENT_PREFIX):].split("/"))
    return os.path.join(DISK_ROOT, *path.split("/"))

def _path_inside_root(path):
    """SRV36-13：解析符号链接后校验落点仍在所属根目录内。

    _safe_path 只做字符串级拦截（拒绝 ..）；同步根内既有的 symlink 会被
    open 跟随，GET /api/v1/file 可读取根目录之外的文件。realpath 不存在
    的叶子时仍会解析既有父级链接，覆盖目录链接穿越。
    """
    root = RECENT_ROOT if path.startswith(RECENT_PREFIX) else DISK_ROOT
    try:
        root_real = os.path.realpath(root)
        full_real = os.path.realpath(_full_path(path))
        return os.path.commonpath([root_real, full_real]) == root_real
    except (OSError, ValueError):
        return False

def _persist_session(path, content):
    """2026-11-18（G17）：源会话内容滚动落盘到 RECENT_ROOT/.sessions。

    仅作崩溃恢复副本：不写同步根、不参与 Syncthing、.sessions 为点目录，
    /recent/devices 的目录扫描会跳过。写入前做 realpath 白名单二次校验，
    保留 7 天，自动清理更早的副本。
    """
    if not content:
        return False
    try:
        if len(content.encode("utf-8")) > MAX_FILE_BYTES:
            return False
        root = os.path.realpath(RECENT_ROOT)
        store = os.path.realpath(SESSION_STORE)
        if os.path.commonpath([root, store]) != root:
            _log(f"[session] DENY store outside RECENT_ROOT: {store}")
            return False
        os.makedirs(SESSION_STORE, exist_ok=True)
        key = hashlib.sha256(path.encode("utf-8")).hexdigest()
        full = os.path.join(SESSION_STORE, key + ".json")
        payload = json.dumps({"path": path, "content": content,
                              "saved_at": time.time()}, ensure_ascii=False)
        fd, tmp = tempfile.mkstemp(prefix=".mktmp-", dir=SESSION_STORE)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
                fh.write(payload)
                fh.flush()
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass
            os.chmod(tmp, 0o600)
            os.replace(tmp, full)
            tmp = None
        finally:
            if tmp is not None:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
        cutoff = time.time() - 7 * 86400
        for name in os.listdir(SESSION_STORE):
            if not name.endswith(".json"):
                continue
            candidate = os.path.join(SESSION_STORE, name)
            try:
                if os.path.getmtime(candidate) < cutoff:
                    os.unlink(candidate)
            except OSError:
                pass
        return True
    except Exception as exc:
        _log(f"[session] persist failed path={path}: {exc}")
        return False


def _write_text_atomic(full, text):
    """SRV36-10：小文本文件（.platform）原子写，读者不会读到截断内容。

    阶段①：调用方只允许传 RECENT_ROOT 下的路径，入口再次强制校验。
    """
    _assert_recent_full_path(full)
    d = os.path.dirname(full) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".mktmp-", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, full)
        tmp = None
        # 复审 R10：.platform 与外部源标记同样是 RECENT_ROOT 落盘，原先不计入
        # recent_writes，使 /health 的审计口径与实际写盘次数不一致（漏计）
        _note_write("recent", full)
        _log(f"[flush] {full} (meta)")
        return True
    finally:
        if tmp and os.path.isfile(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass

def _flush_recent(path, content):
    """把服务器副本（recent/…）原子落到 RECENT_ROOT。成功/无需写入返回 True。

    阶段①（batch73）硬不变式：锁服务零写同步根（DISK_ROOT）。本函数是全服
    唯一内容落盘入口，非 recent/ 前缀一律抛 RuntimeError（fail-fast，不静默
    跳过）；启动自检会主动触发一次以验证守卫仍然生效。
    """
    if not _is_recent_path(path):
        _note_write("disk_denied", path)
        _log(f"[flush] DENY write to DISK_ROOT path={path}")
        raise RuntimeError(f"lockserver must not write sync root: {path}")
    # R16-F4：落盘是内容的最后一个规范位置——保证磁盘副本也只有一个形态
    # （无前导 BOM）。上游各入口已归一，此处再执行一次是幂等的兜底。
    content = _normalize_content(content)
    # SV-T10/SV-U10：落盘前按同一文件级上限复核（按字节口径）
    clen = len(content.encode("utf-8"))
    if clen > MAX_FILE_BYTES:
        _log(f"[flush] FAIL {path}: content too large ({clen} bytes)")
        return False
    full = _full_path(path)
    # 白名单二重校验：解析符号链接后仍必须落在 RECENT_ROOT 内
    _assert_recent_full_path(full)
    tmp = None
    try:
        # 阶段①：RECENT_ROOT 的快照允许首次创建（原实现沿用 SV-BS2 的
        # “目标不存在就跳过”，导致 publish 首次永远写不出副本）。副本的
        # “删除后复活”由 _recent_io_lock + 墓碑 + oplock 三重保护，不依赖
        # 这里的跳过逻辑；同步根已无任何写路径。
        # 内容与磁盘一致时不写盘，省一次 IO
        try:
            if os.path.isfile(full):
                # SV-AE2：比较前先看大小——既有文件可能被写到 16MB 以上，
                # 整篇 read 会瞬间吃掉内存（publish 还在 _recent_io_lock 内，
                # 会同时堵住全服 publish/delete/迁移）；超限既有文件一律不读、
                # 也不覆盖（避免把外部大文件静默截断）
                size = os.path.getsize(full)
                if size > MAX_FILE_BYTES:
                    _log(f"[flush] SKIP {path}: existing file too large ({size} bytes)")
                    return False
                with open(full, "r", encoding="utf-8", newline="") as f:
                    if f.read() == content:
                        return True
        except Exception:
            pass
        # tmp 名带线程标识：两个线程并发 save 同一文件时共用同一 tmp 路径
        # 会交叉写入/截断（P5）
        # SRV36-2：不再用 "<原名>.tmp.<tid>"——原名已占满 255 字节时会
        # ENAMETOOLONG；改用目录内短随机名
        d = os.path.dirname(full) or "."
        os.makedirs(d, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".mktmp-", dir=d)
        # 复审 R15：newline=""——按原样字节落盘，不把 "\n" 翻译成 os.linesep
        # （Windows 下会把客户端原始 CRLF 变成 "\r\r\n"，Linux 下则与读盘归一
        # 叠加后改变内容），保证磁盘副本与 content_hash 始终同口径
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            # 复审 R14：replace 前把数据刷到磁盘。缺此步骤时断电/宿主机崩溃
            # 可能让重命名先落盘而数据块未落盘，副本变成 0 字节（被读成 empty），
            # 而内存 entry 此时已被 GC 回收，权威内容不可恢复。fsync 失败按
            # 尽力而为处理：不能因不支持 fsync 的文件系统把落盘整体判失败
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError as e:
                _log(f"[flush] fsync skipped {path}: {e}")
        os.chmod(tmp, 0o644)
        os.replace(tmp, full)
        tmp = None
        _note_write("recent", path)
        _log(f"[flush] {path} (recent)")
        return True
    except Exception as e:
        _log(f"[flush] FAIL {path}: {e}")
        return False
    finally:
        # 失败时清掉残留 tmp，避免在副本目录留下垃圾文件
        if tmp and os.path.isfile(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass

def _safe_path(path):
    """净化协作路径：拒绝绝对路径与 .. 目录穿越（P7）。合法返回规范路径，非法返回 None。

    SV-AE1：同时按文件系统口径限制长度——超长路径会让 open/makedirs 必然
    ENAMETOOLONG，rev>0 的会话永远落不了盘；NUL/控制字符同样令落盘抛异常。
    recent 端点的 device_name/file_name 也走本函数，字节上限一并生效。
    """
    # SRV37-4：只去首部斜杠，不再 strip 两端空白——否则合法文件名
    # "a.md "/" a.md" 会被静默映射成 "a.md"，读写到另一个文件
    p = path.replace("\\", "/").lstrip("/")
    parts = [seg for seg in p.split("/") if seg not in ("", ".")]
    if not parts or any(seg == ".." for seg in parts):
        return None
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in p):
        return None
    joined = "/".join(parts)
    if _utf8_len(joined) > MAX_PATH_BYTES:
        return None
    if any(_utf8_len(seg) > MAX_SEG_BYTES for seg in parts):
        return None
    return joined

def _recent_write_valid(path):
    """SRV37-3：recent/ 下的写路径只允许 recent/<设备>/<文件名> 两层。

    与 publish 的 dev/name 校验同口径（拒绝 . 开头）。原先 op/save/open 只过
    _safe_path，可建出 recent/PC/.platform 或 recent/PC/a/b.md 这类副本 entry：
    list 不可见、delete 无法寻址、GC 也不清理，并会污染 devices 计数。
    """
    if path is None or not path.startswith(RECENT_PREFIX):
        return True
    parts = path.split("/")
    if len(parts) != 3:
        return False
    _prefix, dev, name = parts
    return (bool(dev) and bool(name)
            and not dev.startswith(".") and not name.startswith("."))


# ======================== 副本目录按 device_id 分段（2026-11-06） ========================
# 旧布局：recent/<device_name>/<文件名>；同名两台设备物理上是同一目录。
# 新布局：段名优先 device_id（Syncthing 设备 ID / 持久化 client id），缺失时才
# 回落 device_name（兼容不带 device_id 的旧客户端）。id 目录写 `.name` 标记
# （设备名），使重启后仍能按名字反查 id 目录；旧名字目录原样保留、不迁移、不删除，
# 读取端按“id 段 → 名字段”顺序回落。
RECENT_NAME_MARKER = ".name"
# 2026-11-07：人工改名覆盖标记（`.name-override`），与设备自报的 `.name` 分开。
# 展示优先级：人工 override > 设备自报 > device_id；自报更新不得覆盖 override。
RECENT_OVERRIDE_MARKER = ".name-override"
MAX_RENAME_NAME = 64


def _valid_recent_seg(seg):
    """副本目录段校验：与 device_name 同口径，另拒绝 "/" 与 .tmp. 形态。"""
    return (isinstance(seg, str) and _valid_device(seg)
            and "/" not in seg and not seg.startswith(".")
            and ".tmp." not in seg)


def _recent_seg(device_id, device_name):
    """选副本目录段：合法 device_id 优先，否则回落设备名（旧客户端兼容）。"""
    did = _req_text(device_id)
    if _valid_recent_seg(did):
        return did
    return device_name if _valid_recent_seg(device_name) else ""


def _recent_dir_name(seg):
    """读取 id 目录里的 `.name` 标记；旧名字目录没有标记 → 返回 ""。"""
    if not _valid_recent_seg(seg):
        return ""
    try:
        with open(os.path.join(RECENT_ROOT, seg, RECENT_NAME_MARKER),
                  encoding="utf-8") as f:
            name = _req_text(f.read())
    except (OSError, ValueError):
        return ""
    return name if _valid_recent_seg(name) else ""


def _valid_rename_name(name):
    """改名目标校验：strip 后 1–64 字符，禁控制字符、禁 "/"、禁为空。

    返回规范化后的名字（去首尾空白）；非法返回 ""，调用方据此返回 400。
    """
    if not isinstance(name, str):
        return ""
    name = _clean_surrogates(name).strip()
    if not name or len(name) > MAX_RENAME_NAME:
        return ""
    if not _valid_device(name, MAX_RENAME_NAME) or "/" in name:
        return ""
    return name


def _recent_override(seg):
    """读取人工改名覆盖（`.name-override`）；无标记/非法返回 ""。"""
    if not _valid_recent_seg(seg):
        return ""
    try:
        with open(os.path.join(RECENT_ROOT, seg, RECENT_OVERRIDE_MARKER),
                  encoding="utf-8") as f:
            name = _req_text(f.read())
    except (OSError, ValueError):
        return ""
    return name if _valid_rename_name(name) else ""


def _recent_display_name(seg):
    """展示名优先级：人工 override > 设备自报 `.name` > device_id。"""
    return _recent_override(seg) or _recent_dir_name(seg) or seg


def _write_recent_override(seg, new_name):
    """落盘人工改名覆盖；与 `.name` 分文件，重启后仍然有效。"""
    full = os.path.join(RECENT_ROOT, seg, RECENT_OVERRIDE_MARKER)
    _write_text_atomic(full, new_name)


def _recent_device_targets(device_id, device_name):
    """定位 rename/delete 的目标设备段。返回 (targets, ambiguous)。

    device_id 优先；为空时按 device_name 唯一匹配，同名多台 ambiguous=True。
    targets 每项 {"id_seg": "...", "name_seg": "..."}：id 目录优先，旧名字目录兼容。
    没有 id 目录但有唯一旧名字目录时，id_seg=""、name_seg=名字。
    """
    try:
        entries = sorted(os.listdir(RECENT_ROOT))
    except OSError:
        entries = []
    ids, names = [], []
    for e in entries:
        if e.startswith(".") or not os.path.isdir(os.path.join(RECENT_ROOT, e)):
            continue
        if _recent_dir_name(e):
            ids.append(e)
        else:
            names.append(e)
    # 旧名字目录被同设备 id 目录的 `.name` 认领 → 两者是同一台设备
    claimed = {}
    for d in ids:
        nm = _recent_dir_name(d)
        if nm:
            claimed[nm] = d

    if device_id:
        if device_id in ids:
            nm = _recent_dir_name(device_id)
            return [{"id_seg": device_id,
                     "name_seg": nm if nm in names else ""}], False
        with _lock:
            alias = DEV_NAME_ALIAS.get(device_id) or ""
        if alias and alias in names:
            return [{"id_seg": "", "name_seg": alias}], False
        # 旧客户端把设备名当 device_id 上报时，按名字唯一匹配兜底
        return _recent_device_targets("", device_id)

    if not device_name:
        return [], False
    matched_ids, matched_names = [], []
    for d in ids:
        nm = _recent_dir_name(d)
        ov = _recent_override(d)
        # 匹配客户端**可见的展示名**：人工 override > 自报 `.name` > device_id。
        # 已有 override 时原名不再参与匹配，避免“改名后按旧名仍 409”的假歧义
        display = ov or nm or d
        if device_name in (d, display):
            matched_ids.append(d)
    for n in names:
        if device_name != _recent_display_name(n):
            continue
        owner = claimed.get(n)
        if owner:
            # 该名字目录属于某个 id 目录；只有两者展示名一致（即同一台可见
            # 设备）才并入，否则它只是被认领隐藏的旧目录，不能单独当目标
            if _recent_display_name(owner) == _recent_display_name(n):
                if owner not in matched_ids:
                    matched_ids.append(owner)
        elif n not in matched_names:
            matched_names.append(n)
    targets = []
    for d in matched_ids:
        nm = _recent_dir_name(d)
        targets.append({"id_seg": d, "name_seg": nm if nm in names else ""})
    for n in matched_names:
        targets.append({"id_seg": "", "name_seg": n})
    return targets, len(targets) > 1


def _recent_memory_purge(device_id, device_name):
    """删除兜底：没有段目录、只存在于内存记录的设备。

    复审 R9：设备可能只参与过别人的快照、从未 publish（recent/<dev>/ 不存在），
    注销后必须从参与端/登记集合中清除，否则那些快照永远满足不了收敛条件。
    返回 (ids, names, ambiguous)；rename 不走此路径（没有目录可写 override，
    否则会凭空建出幽灵设备段）。
    """
    ids, names = set(), set()
    if device_id:
        ids.add(device_id)
    if device_name:
        names.add(device_name)
    with _lock:
        if device_id:
            alias = DEV_NAME_ALIAS.get(device_id) or ""
            if alias:
                names.add(alias)
        elif device_name:
            # 名字→id 反查：有段目录的 id 是独立设备，不能按同名连带清理
            alias_ids = {k for k, v in DEV_NAME_ALIAS.items()
                         if v == device_name
                         and not os.path.isdir(os.path.join(RECENT_ROOT, k))}
            if len(alias_ids) > 1:
                return set(), set(), True
            ids.update(alias_ids)
    with _lock:
        exists = any(i in meta["participants"]
                     for meta in SNAP_META.values() for i in ids)
        exists = exists or any(n in meta["participants"]
                               for meta in SNAP_META.values() for n in names)
        # 不拿 CLIENT_REPORTS 当存在证据：每个请求进门禁时都会先按请求体
        # 登记 device_id/device_name，删除请求自己就会造出一行，导致
        # “目标不存在 404”永远不可达。
        exists = exists or any(n in LAST_SEEN for n in names)
    if not exists:
        return set(), set(), False
    return ids, names, False


def _write_recent_name_marker(seg, device_name):
    """给 id 目录写 `.name`（设备自报名）。名字目录不写，避免旧布局多出隐藏文件。

    已有人工改名 override 时一律不写：设备后续 heartbeat/publish 自报原名
    （或改报其它名）都不得覆盖人工 override，只有再次 rename 才能改。
    """
    if not seg or not device_name or seg == device_name:
        return
    if os.path.isfile(os.path.join(RECENT_ROOT, seg, RECENT_OVERRIDE_MARKER)):
        return
    full = os.path.join(RECENT_ROOT, seg, RECENT_NAME_MARKER)
    try:
        if os.path.isfile(full):
            with open(full, encoding="utf-8") as f:
                if f.read().strip() == device_name:
                    return
        _write_text_atomic(full, device_name)
    except Exception as e:
        _log(f"[recent] write .name FAIL {seg}: {e}")


def _recent_read_segments(ref, existing_only=True):
    """读请求的设备段候选：ref 自身 → 同设备的 id 目录 → 旧名字目录。

    ref 可以是 id 段、设备自报的 `.name`、人工 override 名或旧名字段。名字
    场景下 id 目录优先（新副本），旧名字目录最后兜底；只读兼容，绝不迁移/
    删除旧目录。existing_only=False 用于墓碑判定——目录可能已被删除，仍要
    能反查旧段。
    """
    segs = []

    def add(s):
        if s and s not in segs:
            segs.append(s)

    if _valid_recent_seg(ref):
        nm = _recent_dir_name(ref)
        ov = _recent_override(ref)
        if nm or ov:
            add(ref)
            add(nm)          # 该 id 目录对应的旧名字目录（可能不存在）
        else:
            add(ref)         # ref 当作设备名
            with _lock:
                ids = [did for did, dn in DEV_NAME_ALIAS.items() if dn == ref]
            for did in ids:
                add(did)
            try:
                for entry in sorted(os.listdir(RECENT_ROOT)):
                    if entry == ref or entry.startswith("."):
                        continue
                    if (_recent_dir_name(entry) == ref
                            or _recent_override(entry) == ref):
                        add(entry)
                        add(_recent_dir_name(entry))
            except OSError:
                pass
            add(ref)         # 旧名字目录兜底
    if not existing_only:
        return segs
    return [s for s in segs if os.path.isdir(os.path.join(RECENT_ROOT, s))]


def _recent_tomb_key(ref, rest, path):
    """等价段里已有删除墓碑时返回该墓碑键，避免按旧名字重建已删副本。

    仅在“没有任何活副本”时调用：删除后 10s 墓碑期内，旧客户端按名字打开的
    路径若映射到已删的 id 段，必须同样得到 410，而不是在名字目录重建空会话。
    """
    for s in _recent_read_segments(ref, existing_only=False):
        key = RECENT_PREFIX + s + "/" + rest
        if key == path:
            continue
        with _lock:
            if key in _DELETED_RECENT:
                return key
    return None


def _recent_alt_key(path, rest):
    """返回与 path 同设备、不同段名且确有内容的等价协作 key；没有则 None。"""
    segs = _recent_read_segments(path.split("/")[1])
    for s in segs:
        alt = RECENT_PREFIX + s + "/" + rest
        if alt == path:
            continue
        if _disk_snapshot_exists(alt) or (VAULT_ID, alt) in FILES:
            return alt
    return None


def _load_from_disk(path):
    """磁盘读文件。

    三种结果：内容字符串（含空串——文件不存在/读取异常）、
    None（文件存在但不是合法 UTF-8，或超过 16MB 上限——SV-W1）。
    SV-V5：解码失败独立记日志并返回 None——原先与"不存在"归一为空串，
    open/GET 会为不可读的既有文件建出空 entry，后续任意 op/save 经
    GC/close 落盘把它静默覆盖；SV-W1 起超限同口径返回 None
    """
    if _is_external_key(path):
        # 外部键是“设备+绝对路径”的命名空间，不是同步根内的相对路径：
        # 磁盘上没有对应文件，也绝不因根内同名文件误读（只从空会话起步）
        return ""
    full = _full_path(path)
    try:
        # SRV36-13：符号链接解析后落在同步根之外时拒绝读取（信息泄露）
        if not _path_inside_root(path):
            _log(f"[load] FAIL {path}: outside sync root")
            return None
        # SRV36-5：目标是目录时不得归一为"文件不存在"的空串——否则会为目录
        # 建出空 entry，后续任何落盘都因 EISDIR 永久失败并丢内容
        if os.path.isdir(full):
            _log(f"[load] FAIL {path}: is a directory")
            return None
        if os.path.isfile(full):
            # SV-U10：同步目录里既存的超大文件（外部工具/其它同步端写入）
            # 首次加载前置拦截——否则整篇读入内存后任何 op/struct 都因超限
            # 413，文件被冻结为只读
            # SV-AH1：getsize 与 open 同属"既有文件读取"，stat 失败（权限/IO）
            # 不得落到外层兜底返回空串——否则会为不可读文件建空 entry，后续
            # op/save 落盘把原内容静默覆盖（与 SV-V5/SV-AG2 同口径）
            try:
                size = os.path.getsize(full)
            except FileNotFoundError:
                return ""
            except OSError as e:
                _log(f"[load] FAIL {path}: stat error ({e})")
                return None
            if size > MAX_FILE_BYTES:
                # SV-W1：超 16MB 既有文件同样返回 None（与解码失败同口径）——
                # 返回空串会为实际存在的超大文件建出 content="" 的空 entry，
                # 后续 op/save 落盘会把 16MB+ 原始文件静默替换为微小新内容
                _log(f"[load] SKIP {path}: file too large ({size} bytes)")
                return None
            try:
                # 复审 R15：newline="" —— 读盘不得做通用换行归一（CRLF/CR → LF）。
                # 副本内容来自客户端 JSON（PC FileSidebar 以 decodeForDisplay 读
                # 原始文件后仍可能含 CRLF），归一会让 os.replace 写出的字节与
                # content_hash 口径不一致：他端下载的副本被静默改写，ack 以本地
                # 原文 hash 上报时与归一后的快照 hash 永不相等，快照永不删除
                with open(full, "r", encoding="utf-8", newline="") as f:
                    # R16-F4：读盘是内容进入服务端规范形态的第一处——旧版本
                    # 按原样落盘的副本可能带前导 BOM，此处剥掉后，内存 entry、
                    # content_hash、size 与客户端 ack 才能同口径
                    return _normalize_content(f.read())
            except FileNotFoundError:
                # SV-AG2：isfile 与 open 之间被删除——按"不存在"处理（空串）
                return ""
            except UnicodeDecodeError as e:
                # SV-V5：存在但不可解码——返回 None，调用方拒绝建空 entry
                _log(f"[load] FAIL {path}: not utf-8 ({e})")
                return None
            except OSError as e:
                # SV-AG2：既有文件但读取失败（权限/IO）不得归一为空串——否则会为
                # 不可读文件建空 entry，后续落盘把原内容静默覆盖（同 SV-V5 口径）
                _log(f"[load] FAIL {path}: read error ({e})")
                return None
    except Exception as e:
        _log(f"[load] FAIL {path}: {e}")
    return ""

def _entry_get_or_create(path):
    """取或建 FileEntry。首次访问从磁盘加载。

    SV-Q4：recent 路径处于删除墓碑期内时返回 (key, None)——delete 只拦
    publish，不拦重建；与 delete 并发而身份校验失效的 op/struct/save 或
    SSE 断连自动重连会重建副本 entry，墓碑过期后 GC 空闲落盘把副本文件
    写回 RECENT_ROOT，/recent/list 中删掉的文件重现。调用方按 410 处理。
    SV-V5：返回值新增"undecodable"标记——磁盘文件存在但不是合法 UTF-8 时
    拒绝建空 entry，调用方按 415 处理；原先与"不存在"归一为空串，后续
    op/save 会把它静默覆盖
    """
    key = (VAULT_ID, path.replace("\\", "/"))
    # SV-S4：墓碑判定与查/建 entry 必须同处一个 _lock 临界区——原先
    # _recent_tombstoned 自行取锁，返回后才再取锁查/建 entry，delete 可在这
    # 两次加锁之间登记墓碑并 unlink/pop；并发的 op/SSE 重连仍能在第二段锁里
    # 以"磁盘已删→空串"新建 entry，墓碑过期后 GC 落盘使已删副本复活
    with _lock:
        if _recent_tombstoned_nolock(key[1]):
            return key, None
        entry = FILES.get(key)
        if entry is not None:
            return key, entry
        # 复审 R4：锁内只查表占位，整文件读盘（≤16MB，Syncthing 慢盘）移到锁外
    content = _load_from_disk(key[1])
    if content is None:
        # SV-V5：存在但不可解码——拒绝建空 entry（不写入 FILES：写进内存反而会
        # 被 GC rev==0 路径以"内容与磁盘一致"名义正常回收/落盘）；调用方 415
        return key, "undecodable"
    with _lock:
        # SV-S4：读盘期间可能被 delete 登记墓碑，回锁后在同一临界区内复核
        if _recent_tombstoned_nolock(key[1]):
            return key, None
        # 复审 R4：回锁二次确认，避免覆盖并发创建的 entry
        entry = FILES.get(key)
        if entry is None:
            entry = FileEntry(content, key[1])
            FILES[key] = entry
        return key, entry

def _entry_revalidate(key, entry):
    """SV-H7：close 与并发 op 竞态——close 落盘后删掉 FILES 里的 entry，
    之后到达的 op 若仍写旧 entry，改动会随旧对象一起被丢弃（编辑丢失）。
    写操作前校验 entry 仍是 FILES 中的当前对象，不是则从磁盘重建。"""
    with _lock:
        # SV-S4：返回既有 entry 前同样复核墓碑——delete 已在锁内登记墓碑、
        # 但尚未 pop 的窗口内，继续写该 entry 会让删除的副本在墓碑过期后复活
        if _recent_tombstoned_nolock(key[1]):
            return None
        if FILES.get(key) is entry:
            return entry
        fresh = FILES.get(key)
        if fresh is not None:
            return fresh
    # 复审 R4：需要重建时读盘移到锁外，回锁后再二次确认
    content = _load_from_disk(key[1])
    if content is None:
        # SV-V5：存在但不可解码——拒绝重建空 entry，调用方按 415 处理
        return "undecodable"
    with _lock:
        # SV-Q4/SV-S4：重建前在同一临界区内查删除墓碑，命中返回 None
        # 由调用方按 410 处理（防"先删后复活"，同 _entry_get_or_create）
        if _recent_tombstoned_nolock(key[1]):
            return None
        fresh = FILES.get(key)
        if fresh is None:
            fresh = FileEntry(content, key[1])
            FILES[key] = fresh
        return fresh

# ======================== writer token 内部实现 ========================
# 所有 *_nolock 辅助函数都要求调用方已持 _lock。

def _touch_participant_nolock(entry, device_id, device_name=""):
    """刷新参与者最后活跃时间；device_name 非空时同步显示名。"""
    if not device_id:
        return
    p = entry.participants.get(device_id)
    if p is None:
        if len(entry.participants) >= MAX_SNAP_PARTICIPANTS:
            return        # 有界：与会话快照参与者同一上限
        p = {"device_name": device_name or device_id, "last_active": 0.0}
        entry.participants[device_id] = p
    if device_name:
        p["device_name"] = device_name
    p["last_active"] = _now()


def _participant_online_nolock(entry, device_id, now=None):
    """在线 = 有该设备的 SSE 订阅（socket 存活即在线），或最近活动未超时。"""
    if not device_id:
        return False
    for s in entry.subs:
        if s.device_id == device_id:
            return True
    p = entry.participants.get(device_id)
    if not p:
        return False
    now = _now() if now is None else now
    return (now - p["last_active"]) <= WRITER_OFFLINE_SEC


def _pick_writer_nolock(entry, exclude=None, now=None):
    """按最后活跃选接任者；只考虑在线参与者。"""
    now = _now() if now is None else now
    best = None
    best_ts = -1.0
    for dev, p in entry.participants.items():
        if not dev or dev == exclude:
            continue
        if not _participant_online_nolock(entry, dev, now):
            continue
        if p["last_active"] > best_ts:
            best, best_ts = dev, p["last_active"]
    return best


def _participant_name_nolock(entry, device_id):
    if not device_id:
        return ""
    p = entry.participants.get(device_id)
    return (p or {}).get("device_name", "") or device_id


def _set_writer_nolock(entry, device_id, device_name, reason):
    """变更令牌并返回 writer_changed 事件（广播由调用方在锁外执行）。"""
    prev_id = entry.writer_device_id
    prev_name = entry.writer_device_name
    entry.writer_device_id = device_id or None
    entry.writer_device_name = (device_name or "") if device_id else ""
    entry.writer_since = _now() if device_id else 0.0
    entry.writer_rev += 1
    _WRITER_AUDIT["changes"] += 1
    if reason in ("offline", "timeout", "leave", "release") and prev_id:
        _WRITER_AUDIT["transfers"] += 1
    if reason == "timeout":
        _WRITER_AUDIT["timeouts"] += 1
    return {"type": "writer_changed",
            "writer_device_id": entry.writer_device_id,
            "writer_device_name": entry.writer_device_name,
            "previous_writer_device_id": prev_id,
            "previous_writer_device_name": prev_name,
            "writer_rev": entry.writer_rev,
            "writer_since": int(entry.writer_since),
            "reason": reason}


def _writer_fields_nolock(entry, changed=False):
    """响应/hello 用的 writer 字段快照。"""
    return {"writer_device_id": entry.writer_device_id,
            "writer_device_name": entry.writer_device_name,
            "writer_rev": entry.writer_rev,
            "writer_since": int(entry.writer_since),
            "writer_changed": bool(changed)}


def _writer_watch_loop():
    """掉线 watchdog：writer 无 SSE 且超时 → 按最后活跃移交并广播。"""
    while True:
        try:
            time.sleep(WRITER_WATCH_SEC)
            jobs = []
            with _lock:
                now = _now()
                for key, entry in list(FILES.items()):
                    dev = entry.writer_device_id
                    if not dev:
                        continue
                    if _participant_online_nolock(entry, dev, now):
                        continue
                    nxt = _pick_writer_nolock(entry, exclude=dev, now=now)
                    ev = _set_writer_nolock(
                        entry, nxt,
                        _participant_name_nolock(entry, nxt) if nxt else "",
                        "timeout")
                    jobs.append((key, entry, ev))
            for key, entry, ev in jobs:
                with _lock:
                    if FILES.get(key) is not entry:
                        continue
                _broadcast(entry, ev)
                _log(f"[writer] path={key[1]} timeout "
                     f"writer={ev['writer_device_id']} rev={ev['writer_rev']}")
        except Exception as e:
            # watchdog 不能因单次异常退出，否则写权永久不收敛
            _log(f"[writer] watch error: {e!r}")


def _peers_list(entry, exclude_device_id=None):
    """同文件其他在线设备列表。"""
    peers = []
    for s in entry.subs:
        if s.device_id and s.device_id != exclude_device_id:
            peers.append({"device_id": s.device_id,
                          "device_name": s.device_name})
    return peers

def _broadcast(entry, json_obj, exclude_handler=None):
    """向所有订阅者推送 SSE 事件。锁外调用：锁内只取订阅者快照（SV-C2）。"""
    with _lock:
        # 复审 R6：writer 变更在 _lock 内递增 writer_rev，但 claim/release 与
        # watchdog 均在释放 _lock 后才广播——两个变更的广播顺序可能与 rev 顺序
        # 相反。丢弃已被更新变更覆盖的过期帧，避免客户端看到写权回退。
        if json_obj.get("type") == "writer_changed":
            stale_rev = json_obj.get("writer_rev")
            if isinstance(stale_rev, int) and stale_rev < entry.writer_rev:
                return
        subs = list(entry.subs)
        # 内容/在线/写权事件附带当前 writer 快照，客户端可随时自检是否仍为 writer
        if json_obj.get("type") in ("op", "struct", "peer", "writer_changed"):
            json_obj.setdefault("writer_device_id", entry.writer_device_id)
            json_obj.setdefault("writer_rev", entry.writer_rev)
    line = "data: " + json.dumps(json_obj, ensure_ascii=False) + "\n\n"
    data = line.encode("utf-8")
    dead = []
    for s in subs:
        if s is exclude_handler:
            continue
        try:
            s.write(data)
        except Exception as e:
            dead.append((s, e))
    if dead:
        # R22-1：并发广播时同一个慢订阅者会被多个线程同时写失败、同时进入
        # dead（各自持有的 subs 快照都还包含它）。只对“本次真正从 subs 摘除”
        # 的连接记 DROP / 补发 leave，避免一次故障刷出 N 条重复日志与 N 帧
        # 重复 leave；若它已被 GC/设备删除先行摘除，那些路径各自已有日志。
        removed = []
        with _lock:
            for s, e in dead:
                if s in entry.subs:
                    entry.subs.discard(s)
                    removed.append((s, e))
        # R21-1：写失败被摘除的订阅者原先不留任何日志——SSE 线程下一轮
        # 发现 alive=false 后走 finally 时 removed 已为 False，也不会打 LEAVE，
        # 故障在 journal 里完全不可见。此处按“文件 + 设备 + 异常”记录一次。
        for s, e in removed:
            _log(f"[sse] DROP path={entry.path} "
                 f"dev={s.device_name or s.device_id} "
                 f"reason=write_fail err={e!r}")
        # 复审 N6：与 GC 路径对齐——死连接清理后向其余 peers 补发 leave，
        # 否则对端 peer 列表幽灵在线直到下次 join/op 才被被动刷新
        for s, _e in removed:
            if s.device_id:
                _broadcast(entry, {"type": "peer", "device_id": s.device_id,
                                   "action": "leave"})


# ======================== SSE Handler ========================

class SSEHandler:
    """包装一个 SSE 长连接（非 HTTP handler，只是持 socket + 写方法）。"""
    def __init__(self, handler, device_id, device_name, defer_hello=False):
        self._handler = handler
        self.device_id = device_id
        self.device_name = device_name
        self.last_active = _now()
        # 复审 R2：当前绑定的 FileEntry——副本→源会话迁移时由 _migrate_subs 改写
        self.entry = None
        # 同一连接可能被多个 POST 线程 + keepalive 线程同时写：不加锁时
        # 大 data 帧会分多次 send 交错，缺结尾 \n\n 会让客户端解析器永久卡住
        self._wlock = threading.Lock()
        # SRV36-1：defer_hello=True（_handle_sse 登记新连接）时，hello 写完前
        # （_ready=False）广播帧先入队，写完 hello 后在同一段 _wlock 内按到达
        # 序补发，保证 hello 严格先行；其它场景默认立即可写
        self._ready = not defer_hello
        self._pending = []
        self._pending_bytes = 0

    def _write_now(self, data_bytes, timeout):
        # SV-T6：广播/keepalive/hello 帧使用独立写超时，快速淘汰只连不读的
        # 慢连接；15s 内写不完 16MB 视为不可用连接，直接断开
        try:
            self._handler.connection.settimeout(timeout)
        except OSError:
            pass
        self._handler.wfile.write(data_bytes)
        self._handler.wfile.flush()
        self.last_active = _now()

    def write(self, data_bytes, timeout=SSE_WRITE_TIMEOUT):
        with self._wlock:
            if not self._ready:
                # SRV36-1：hello 未完成——广播帧不落 socket，按有界队列缓存。
                # 溢出说明该连接在 hello 期间被持续灌入大量事件（或对端早已
                # 不读），按写失败处理，由 _broadcast/hello 线程摘除并断开
                if (len(self._pending) >= SSE_PENDING_MAX_FRAMES
                        or self._pending_bytes + len(data_bytes)
                        > SSE_PENDING_MAX_BYTES):
                    raise RuntimeError("sse pending overflow")
                self._pending.append(data_bytes)
                self._pending_bytes += len(data_bytes)
                return
            self._write_now(data_bytes, timeout)

    def write_hello(self, hello_bytes):
        # hello 与待发帧在同一把 _wlock 内连续写出：期间其它线程的 write()
        # 只能阻塞等锁，不会插到 hello 前面或待发帧中间
        with self._wlock:
            self._write_now(hello_bytes, SSE_WRITE_TIMEOUT)
            for d in self._pending:
                self._write_now(d, SSE_WRITE_TIMEOUT)
            self._pending = []
            self._pending_bytes = 0
            self._ready = True

    def is_dead(self, cutoff):
        return self.last_active < cutoff


# ======================== HTTP Handler ========================

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def setup(self):
        # SV-M4：socket 读写超时——无超时时慢客户端可挂死线程（slowloris）。
        # SSE 长连接靠 keepalive 期间无读写，超时会被误断，故 SSE 路径在
        # _handle_sse 内 hello 写完后放宽为 120s（SV-Q3/SV-Q10），普通请求保持 30s
        super().setup()
        self.connection.settimeout(30.0)

    def _client_is_private(self):
        """客户端来源是否在私网/回环/链路本地（含 100.64/10 CGNAT、Tailscale）。

        /api/v1/serverkey 是引导接口（客户端还没有密钥），必须免鉴权；因此
        只允许私网来源，避免公网暴露直接把密钥发给任意主机。
        不依赖 ipaddress.is_private 的版本差异：100.64/10（Tailscale/CGNAT）
        在部分 Python 版本里 is_private=False，这里显式列举网段。
        """
        try:
            ip = ipaddress.ip_address(self.client_address[0])
        except ValueError:
            return False
        if ip.version == 6 and ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        for net in _PRIVATE_NETS:
            if ip.version == net.version and ip in net:
                return True
        return False

    def _handle_server_key(self):
        if not self._client_is_private():
            _log(f"[apikey] denied non-private client {self.client_address[0]}")
            return self._send(403, {"ok": False, "error": "forbidden"})
        hdr = (self.headers.get(CLIENT_HEADER) or "").strip()[:128]
        _log(f"[apikey] issued to {self.client_address[0]} "
             f"client={hdr or '-'} len={len(API_KEY)}")
        return self._send(200, {"ok": True, "key": API_KEY,
                                "length": len(API_KEY)})

    def _auth(self):
        if not API_KEY:
            return True
        # P3：常量时间比较，避免时序侧信道逐字节探测 Key
        # 复审 N3：请求头按 latin-1 解码，含非 ASCII 字符时 str 形式
        # compare_digest 抛 TypeError → 按鉴权失败处理而非断连刷栈
        # 2026-11-17：旧 48 位密钥彻底作废，server-api-key.prev 仅留档不参与鉴权。
        try:
            return hmac.compare_digest(self.headers.get("Authorization", ""),
                                       "Bearer " + API_KEY)
        except TypeError:
            return False

    def _send(self, code, obj):
        data = json.dumps(obj).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            # SRV36-7：客户端提前断开不得冒泡到 socketserver.handle_error。
            # R21-5：除 BrokenPipe/ConnectionReset 外还有 ConnectionAborted
            # （Windows 主动中止）与 socket.timeout（读端长期不取）——不全部
            # 捕获会让每个失败请求打一整段栈到 journal（日志被刷爆），且
            # 这些异常都在响应已开始写之后，客户端本来也收不到完整响应。
            self.close_connection = True

    # ---- GET ----
    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/health":
            # P3：未鉴权接口不再泄露内存中文件数（内部状态），仅存活探测
            # 阶段①：附带写盘范围计数（只有计数，不含路径），便于运行期审计
            with _WRITE_AUDIT_LOCK:
                audit = dict(_WRITE_AUDIT)
            with _lock:
                writers = dict(_WRITER_AUDIT)
                writers["active"] = sum(
                    1 for e in FILES.values() if e.writer_device_id)
                writers["offline_sec"] = WRITER_OFFLINE_SEC
                writers["watch_sec"] = WRITER_WATCH_SEC
            return self._send(200, {
                "ok": True, "service": "markor-lockserver",
                "api_key": {"required": True, "length": len(API_KEY),
                            "endpoint": "/api/v1/serverkey"},
                "write_scope": {"disk_root": "deny", "recent_root": "allow",
                                "recent_writes": audit["recent_writes"],
                                "disk_denied": audit["disk_denied"]},
                "writers": writers})
        # 引导接口：客户端尚无密钥，必须放在 _auth 之前；只允许私网来源。
        if u.path == "/api/v1/serverkey":
            return self._handle_server_key()
        if not self._auth():
            return self._send(401, {"ok": False, "error": "unauthorized"})
        # /api/v1/clients 是只读运维端点：不受“必须带头”与平台阈值影响，
        # 必须在客户端登记之前路由（否则无头请求会被 REQUIRE 开关拦下）。
        if u.path == "/api/v1/clients":
            return self._handle_clients()
        # 老客户端防护：先「必须带头」→ 再「平台阈值」，失败直接返回对应 4xx。
        q = parse_qs(u.query)
        gate = self._report_client(
            (q.get("device_id") or [""])[0].strip(),
            (q.get("device_name") or q.get("device") or [""])[0].strip(),
            (q.get("platform") or [""])[0])
        if gate is not None:
            code, err = gate
            return self._send(code, err)
        if u.path == "/api/v1/events":
            return self._handle_sse(u)
        if u.path == "/api/v1/file":
            return self._handle_get_file(u)
        if u.path == "/api/v1/recent/devices":
            return self._handle_recent_devices(u)
        if u.path == "/api/v1/recent/list":
            return self._handle_recent_list(u)
        if u.path == "/api/v1/recent/file":
            return self._handle_recent_file(u)
        self._send(404, {"ok": False, "error": "not found"})

    # ---- 客户端版本上报（三端对齐第③项） ----
    def _report_client(self, device_id, device_name, platform_hint=""):
        """登记一次客户端上报；返回 None 或 (HTTP 状态码, 错误体)。

        判定顺序：
          1) REQUIRE_CLIENT_HEADER 开启时：无头/头非法 → 400
             （error=client header required，用 reason 区分 missing / invalid）
          2) 按平台阈值 MIN_BUILD_<PLATFORM>：已上报构建号且低于阈值 → 403
             （error=client too old，含 platform/client_build/min_build）
        REQUIRE 关闭且未上报构建号时照旧放行（向后兼容）。
        platform_hint 是既有请求里的 platform/查询参数，仅作无头时的展示兜底。
        """
        raw_header = self.headers.get(CLIENT_HEADER)
        plat, build = _parse_client_header(raw_header)
        if REQUIRE_CLIENT_HEADER and not plat:
            with _lock:
                _CLIENT_AUDIT["rejected"] += 1
            return (400, {
                "ok": False,
                "error": "client header required",
                "reason": "missing" if not raw_header else "invalid",
                "header": CLIENT_HEADER,
                "expected": "X-Markor-Client: <platform>/<build>",
                "platforms": ["desktop", "phone", "tablet"],
            })
        if not plat and isinstance(platform_hint, str):
            hint = platform_hint.strip().lower()
            if hint in ("desktop", "phone", "tablet"):
                plat = hint
        did = device_id if _valid_device(device_id) else ""
        dn = device_name if _valid_device(device_name) else ""
        now = _now()
        with _lock:
            _remember_client_nolock(did, dn, plat, build, now)
            if build is not None:
                minimum = MIN_BUILDS.get(plat, 0)
                if minimum > 0 and build < minimum:
                    _CLIENT_AUDIT["rejected"] += 1
                    return (403, {
                        "ok": False, "error": "client too old",
                        "platform": plat,
                        "client_build": build,
                        "min_build": minimum,
                    })
        return None

    def _handle_clients(self):
        """只读：最近上报的平台/构建号/设备 id 短名（仅内存，不含任何密钥）。"""
        now = _now()
        rows = []
        with _lock:
            for key, rec in list(CLIENT_REPORTS.items()):
                if now - rec["last_seen"] > CLIENT_REPORT_TTL_SEC:
                    CLIENT_REPORTS.pop(key, None)
                    continue
                rows.append({
                    # 2026-11-18：同时返回完整设备 ID，供 enable-versioning.py
                    # 直接写回 Syncthing 设备名（不再依赖 .markor/*.devicename）
                    "device_id": rec.get("device_id", ""),
                    "device_id_short": _short_device_id(
                        rec.get("device_id"), rec.get("device_name")),
                    "device_name": rec.get("device_name", ""),
                    "platform": rec.get("platform", ""),
                    "build": rec.get("build"),
                    "last_seen_sec": int(max(0.0, now - rec["last_seen"])),
                    "requests": rec.get("requests", 0),
                })
            rejected = _CLIENT_AUDIT["rejected"]
        rows.sort(key=lambda r: r["last_seen_sec"])
        # 同名（同 device_name）多行不再强行合并：按返回顺序给后面的重名项加
        # (1)/(2)… 后缀。只改展示字段，内部键、device_id 与登记合并逻辑不变。
        # 名称空时用短 id 作展示名；大小写按现状区分（字典精确比较）。
        used = set()
        for r in rows:
            base = r["device_name"] or r["device_id_short"] or "unknown"
            name = base
            if name in used:
                i = 1
                while f"{base}({i})" in used:
                    i += 1
                name = f"{base}({i})"
            used.add(name)
            r["device_name"] = name
        return self._send(200, {"ok": True,
                                "require_client_header": REQUIRE_CLIENT_HEADER,
                                "min_builds": dict(MIN_BUILDS),
                                "min_client_version": MIN_CLIENT_VERSION,
                                "tracked": len(rows),
                                "rejected": rejected,
                                "clients": rows[:50]})

    # ---- 最近页多端副本 ----
    # 目录树：RECENT_ROOT/<设备名>/<文件名>，不记录原始文件路径
    def _handle_recent_devices(self, u):
        """设备分组入口：每台设备一条，含副本数量与最新修改时间。"""
        # SV-M5：3s 内命中缓存直接返回（online 状态实时组装，不受缓存影响）
        with _lock:
            if (_DEVICES_CACHE["data"] is not None
                    and _now() - _DEVICES_CACHE["ts"] < _DEVICES_CACHE_SEC):
                cached = _DEVICES_CACHE["data"]
            else:
                cached = None
        if cached is None:
            cached = self._build_recent_devices()
            with _lock:
                _DEVICES_CACHE["ts"] = _now()
                _DEVICES_CACHE["data"] = cached
        # online 判定实时计算（缓存期内心跳/SSE 可能已变化）
        online = set()
        last_seen_snap = {}
        with _lock:
            for e in FILES.values():
                for s in e.subs:
                    if s.device_name:
                        online.add(s.device_name)
            # SV-AA2：LAST_SEEN 为共享 dict，读取必须在 _lock 内
            last_seen_snap = dict(LAST_SEEN)
        out = []
        for d in cached:
            # 心跳可能按 id 或名字登记（旧客户端只报名字），两处都要查
            fresh = ((_now() - last_seen_snap.get(d.get("device_id") or "\x00", 0))
                     < ONLINE_WINDOW_SEC
                     or (_now() - last_seen_snap.get(d["device_name"], 0))
                     < ONLINE_WINDOW_SEC)
            out.append({**d, "online": d["device_name"] in online or fresh})
        return self._send(200, {"ok": True, "devices": out})

    def _build_recent_devices(self):
        """遍历 RECENT_ROOT 组装设备列表（不含 online 字段，供缓存复用）。"""
        out = []
        try:
            entries = sorted(os.listdir(RECENT_ROOT))
        except FileNotFoundError:
            return out
        except Exception as e:
            _log(f"[recent] devices FAIL: {e}")
            return out
        # 2026-11-06：目录段优先是 device_id；id 目录里 `.name` 标记记录设备名。
        # 2026-11-07：`.name-override` 是人工改名覆盖（展示优先级 highest）。
        # 先扫一遍标记，再决定哪些旧名字目录需要单独成行
        marks = {}
        overrides = {}
        for name in entries:
            if name.startswith("."):
                continue
            if not os.path.isdir(os.path.join(RECENT_ROOT, name)):
                continue
            marks[name] = _recent_dir_name(name)
            overrides[name] = _recent_override(name)
        # 旧目录认领仍以设备自报的 `.name` 为准：人工改名只改展示名，不能让
        # 同设备的旧名字目录变成第二台“设备”
        claimed = {dn for dn in marks.values() if dn}
        for name, dn_mark in marks.items():
            # 旧名字目录若已被某个 id 目录声明为同一设备（`.name` 命中），不再
            # 单独成行——否则升级后最近页会出现两台同名设备。它的副本文件仍由
            # 该 id 设备的 list/read 回落读出（见 _recent_read_segments）
            if not dn_mark and name in claimed:
                continue
            dirs = [name]
            if dn_mark:
                # 计数与 list 同口径：id 目录 + 同一设备的旧名字目录（若仍在）
                dirs += [seg for seg, m in marks.items()
                         if not m and seg == dn_mark]
            count, latest, seen = 0, 0.0, set()
            for seg in dirs:
                d = os.path.join(RECENT_ROOT, seg)
                try:
                    names = os.listdir(d)
                except OSError:
                    continue   # SV-BL4：设备目录被并发删除，跳过该设备
                for fn in names:
                    if fn.startswith(".") or ".tmp." in fn or fn in seen:
                        continue
                    try:
                        st = os.stat(os.path.join(d, fn))
                    except OSError:
                        continue
                    seen.add(fn)
                    count += 1
                    latest = max(latest, st.st_mtime)
            if count == 0:
                continue   # 空设备目录（副本已全部删除）不显示
            # SV-M5：platform 读取优先走缓存，避免每 5s 轮询重复读盘
            # 展示名：人工 override > 设备自报 > device_id（名字目录用目录名）
            dn = overrides.get(name, "") or dn_mark or name
            did = name if dn_mark else ""
            # 旧名字目录无法确定归属哪台同名设备，device_id 留空让客户端按
            # 名字回落（不猜 id，避免把旧副本算到某台设备头上）
            with _lock:
                plat = _PLATFORM_CACHE.get(dn, "") or _PLATFORM_CACHE.get(name, "")
            if not plat:
                # id 目录缺 .platform（旧客户端心跳只写名字目录）时到同名旧目录兜底
                for pseg in ([name] if name == dn else [name, dn]):
                    try:
                        pf = os.path.join(RECENT_ROOT, pseg, ".platform")
                        if os.path.isfile(pf):
                            with open(pf, "r", encoding="utf-8") as f:
                                plat = f.read().strip()
                    except Exception:
                        plat = ""
                    if plat:
                        break
            out.append({"device_name": dn, "device_id": did, "count": count,
                        "latest": int(latest), "platform": plat})
        out.sort(key=lambda x: -x["latest"])
        return out

    def _handle_recent_list(self, u):
        """指定设备的副本文件列表。"""
        q = parse_qs(u.query)
        # SRV38-1：设备名与写入侧同口径 strip（publish/heartbeat/delete 均 strip），
        # 文件/路径字段保持字面值（首尾空白是合法文件名的一部分）
        dev = _safe_path(_req_text((q.get("device") or [""])[0]))
        if not dev or "/" in dev or len(dev) > MAX_DEV_LEN:
            return self._send(400, {"ok": False, "error": "device required"})
        # 2026-11-06：device 参数可以是 id 段或旧名字段；同名多段时 id 段优先，
        # 旧名字目录只读兜底（升级前副本不迁移、不删除，仍可列出/读取）
        segs = _recent_read_segments(dev)
        files = {}
        # P3：目录不存在与"存在但为空"原来都返回 200+空列表，语义混淆；
        # 加 exists 字段区分（客户端忽略额外字段，向后兼容）
        exists = bool(segs)
        for seg in segs:
            d = os.path.join(RECENT_ROOT, seg)
            try:
                entries = sorted(os.listdir(d))
            except FileNotFoundError:
                continue
            except Exception as e:
                _log(f"[recent] list FAIL {seg}: {e}")
                continue
            for fn in entries:
                if fn.startswith(".") or ".tmp." in fn or fn in files:
                    continue
                full = os.path.join(d, fn)
                if not os.path.isfile(full):
                    continue
                try:
                    st = os.stat(full)
                except OSError:
                    continue   # SV-BL4：文件被并发删除，跳过该项而不是截断列表
                files[fn] = {"name": fn, "mtime": int(st.st_mtime),
                             "size": _canonical_utf8_size(full, st.st_size)}
        files = list(files.values())
        files.sort(key=lambda x: -x["mtime"])
        return self._send(200, {"ok": True, "files": files, "exists": exists})

    def _handle_recent_file(self, u):
        """读取指定设备的一份副本内容。"""
        q = parse_qs(u.query)
        dev = _safe_path(_req_text((q.get("device") or [""])[0]))
        # SV-M1：parse_qs 已完成 URL 解码，再 unquote 会把含 % 的合法文件名解错
        # SRV38-1：文件名保持字面值，与 publish/delete 的 file_name 同口径
        name = _safe_path(_req_raw((q.get("name") or [""])[0]))
        if (not dev or "/" in dev or len(dev) > MAX_DEV_LEN
                or not name or "/" in name or len(name) > MAX_NAME_LEN):
            return self._send(400, {"ok": False, "error": "device and name required"})
        segs = _recent_read_segments(dev)
        recent = RECENT_PREFIX + (segs[0] if segs else dev) + "/" + name
        for seg in segs:
            key = RECENT_PREFIX + seg + "/" + name
            if _recent_tombstoned(key):
                continue
            with _lock:
                live = (VAULT_ID, key) in FILES
            if live or _disk_snapshot_exists(key):
                recent = key
                break
        if _recent_tombstoned(recent):
            return self._send(410, {"ok": False, "error": "deleted"})
        # SV-U8：副本会话有未落盘编辑（rev>0，GC 最长 30s 才落盘）时直接读盘
        # 会拿到落后的旧内容，客户端把它当打开/预览基线后按旧行号发的 op 会
        # 在会话上错位；按会话解析取 entry，与 /open、SSE hello 口径一致——
        # 内存有活跃会话时返回内存权威内容，无会话再读磁盘
        resolved = _resolve_session_path(recent)
        if resolved is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧
            return self._send(409, {"ok": False, "error": "session conflict"})
        with _lock:
            entry = FILES.get((VAULT_ID, resolved))
        if entry is not None:
            # SV-V3：oplock 内只拷贝权威内容到局部变量，退出锁后再 _send——
            # 原先在锁内直接 _send（JSON 序列化最大 16MB + socket 写最长 30s），
            # 慢客户端拉取副本时该文件的 op/struct/save 全部被阻塞约 30s
            gone = False
            with entry.oplock:
                # SV-AI1：解析到源会话（resolved != recent）时，无论 rev 是否
                # 为 0 都要返回会话内容——源会话 rev==0 的基线是源磁盘视图，
                # 而副本磁盘是另一份视图；读副本磁盘会与 /open、SSE hello 的
                # 基线不一致，客户端据此算出的 op 行号会错位
                # 复审 R4：外部键的 rev==0 会话没有磁盘视图（content 恒为空，
                # 真实状态是 absent）。源会话在解析后被 GC 换成新对象时不得
                # 以 200+空内容遮蔽副本磁盘；此时的空内容不是任何基线。
                if entry.rev > 0 or (resolved != recent
                                     and (not _is_external_key(resolved)
                                          or _has_snapshot(resolved, entry))):
                    snapshot = entry.content
                else:
                    snapshot = None
                if resolved == recent:
                    # SRV34-4：读快照前复核删除墓碑——并发 delete 已登记墓碑并
                    # pop entry 时，旧对象上的内容不应再以 200 返回
                    with _lock:
                        gone = _recent_tombstoned_nolock(recent)
            if gone:
                return self._send(410, {"ok": False, "error": "deleted"})
            if snapshot is not None:
                snapshot = _normalize_content(snapshot)   # R16-F4
                return self._send(200, {"ok": True, "name": name,
                                        "content": snapshot,
                                        **_state_fields(snapshot)})
        # proto-2026-11-05：副本磁盘/内存都没有内容 → 显式缺席，不再返回空 content
        if not _disk_snapshot_exists(recent):
            return self._send(404, _absent_fields(recent))
        disk_content = _load_from_disk(recent)
        if disk_content is None:
            # SV-V5：存在但不是合法 UTF-8——拒绝按空内容返回
            return self._send(415, {"ok": False, "error": "not utf-8"})
        if _recent_tombstoned(recent):
            # SRV34-4：初始墓碑判定与读盘之间被并发 delete——原先磁盘读为空串
            # 时会返回 200 + 空内容，复核后按既有的已删除（410）语义处理
            return self._send(410, {"ok": False, "error": "deleted"})
        return self._send(200, {"ok": True, "name": name,
                                "content": disk_content,
                                **_state_fields(disk_content)})

    def _handle_get_file(self, u):
        q = parse_qs(u.query)
        path = _safe_path((q.get("path") or [""])[0])
        if not path:
            return self._send(400, {"ok": False, "error": "path required"})
        # 2026-11-18：.markor 是各端内部元数据（baseline/owners/墓碑），
        # 不属于笔记内容，任何客户端都不得通过读端点取得。
        if path.split("/", 1)[0] == ".markor":
            return self._send(403, {"ok": False, "error": "forbidden"})
        # 复审 rd1：读端点不得为“从未有快照”的键建出空 entry——rev==0 的空
        # 会话会被 publish 误当成“他端旧副本”而回退发布内容（数据丢失）。
        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧
            return self._send(409, {"ok": False, "error": "session conflict"})
        with _lock:
            entry0 = FILES.get((VAULT_ID, path.replace("\\", "/")))
            tomb0 = _recent_tombstoned_nolock(path)
        # 复审 R2：删除墓碑优先于 absent（与 /recent/file 口径一致）
        if entry0 is None and not tomb0 and not _disk_snapshot_exists(path):
            return self._send(404, _absent_fields(path))
        key, entry = _entry_get_or_create(path)
        if entry is None:
            # SV-Q4：副本处于删除墓碑期，拒绝重建已删 entry
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            # SV-V5：磁盘文件存在但不是合法 UTF-8，拒绝建空 entry
            return self._send(415, {"ok": False, "error": "not utf-8"})
        # SRV36-12：取得 entry 与返回之间有 delete 窗口——副本已登记墓碑时
        # 不得再以 200 返回已删内容（与 /recent/file 的 SRV34-4 同口径）
        if path.startswith(RECENT_PREFIX) and _recent_tombstoned(path):
            return self._send(410, {"ok": False, "error": "deleted"})
        # proto-2026-11-05：从未有快照的键一律显式缺席（404 + state=absent），
        # 绝不再用「200 + 空 content」表达不存在（旧客户端会误读为“服务器已删除”）
        if not _has_snapshot(path, entry):
            return self._send(404, _absent_fields(path))
        content = _normalize_content(entry.content)   # R16-F4
        return self._send(200, {"ok": True, "content": content,
                                **_state_fields(content)})

    def _handle_sse(self, u):
        q = parse_qs(u.query)
        # SV-M1：parse_qs 已完成 URL 解码，再 unquote 会把含 % 的合法文件名解错
        path = _safe_path((q.get("path") or [""])[0])
        device_id = (q.get("device_id") or [""])[0].strip()
        device_name = (q.get("device_name") or [device_id])[0].strip()
        # SV-AE1：SSE 查询字段同样需要有界（此前只有 path 经 _safe_path）
        if (not path or not _valid_device(device_id)
                or not _valid_device(device_name)):
            return self._send(400, {"ok": False, "error": "path and device_id required"})
        # 源设备在线时副本并入源会话，两端共享内容与 peer 列表
        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧，拒绝建连
            return self._send(409, {"ok": False, "error": "session conflict"})

        key, entry = _entry_get_or_create(path)
        # SV-Q4：副本处于删除墓碑期——拒绝建连，防止 SSE 断连自动重连重建
        # 已删副本 entry（墓碑过期后 GC 空闲落盘会把副本文件写回 RECENT_ROOT）
        if entry is None:
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            # SV-V5：磁盘文件存在但不是合法 UTF-8，拒绝建连/建空 entry
            return self._send(415, {"ok": False, "error": "not utf-8"})
        # proto-2026-11-05：磁盘快照探测放在锁外（stat 不做锁内 IO），
        # hello 里据此区分 absent / empty / present（旧客户端忽略新增字段）
        # 复审 R10：探测值必须在"最终绑定 entry"的那次尝试里重算——entry 被
        # delete/GC 换掉后重建时，早先的一次性探测可能已过期（文件刚出现/被删），
        # hello 会以 absent 报出非空 content（或反之），快照与磁盘不一致
        # 复审 R10：建连前做与 op 同型的身份校验——并发 delete/GC 后不能订阅到
        # 已不在 FILES 的孤儿 entry；失效则重新解析，最多重试 5 次
        resolved = None
        for _attempt in range(5):
            with _lock:
                current = FILES.get(key) is entry
            if current:
                resolved = entry
                break
            key, entry = _entry_get_or_create(path)
            if entry is None:
                # SV-Q4：墓碑期拒绝重建
                return self._send(410, {"ok": False, "error": "deleted"})
            if entry == "undecodable":
                # SV-V5：存在但不可解码，拒绝建连
                return self._send(415, {"ok": False, "error": "not utf-8"})
        if resolved is None:
            return self._send(503, {"ok": False, "error": "session busy"})

        sse = SSEHandler(self, device_id, device_name, defer_hello=True)
        # SV-Q3/SV-W3：hello 写强制 SSE_WRITE_TIMEOUT=15s（SSEHandler._write_now
        # 每次写 settimeout）。SRV36-1：hello 的序列化与 socket 写都移到全局
        # _lock 之外，慢/半开客户端最多只阻塞本连接 15s，不再冻结全服请求；
        # 先行序由 SSEHandler 的待发队列保证（hello 前到达的广播先入队后补发）

        # HTTP 响应头（必须在任何 body 写之前发出）
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        # 复审 R9：SSE 是一次性长连接流，不声明 Connection: keep-alive，
        # 退出后不再复用该 socket
        self.send_header("X-Accel-Buffering", "no")  # nginx 不缓冲
        self.end_headers()

        # SV-H6：hello 必须严格先于该连接收到的任何事件。SRV36-1 起不再靠
        # "持全局锁写 hello"实现，而是：全局锁内只做订阅登记与状态快照（不做
        # socket 写、不做 json.dumps），锁外写 hello；登记到 hello 写完之间
        # 到达的广播由 SSEHandler 入队，写完 hello 后按到达序补发。
        # 复审 R10：临界区内再复核 entry 仍是当前会话，失效则重新解析后重试
        stale = []
        registered = False
        writer_event = None
        for _attempt in range(5):
            stale = []
            writer_event = None
            hello_obj = None
            disk_ok = _disk_snapshot_exists(path)   # 复审 R10：按本次绑定重算
            try:
                with _lock:
                    if FILES.get(key) is entry:
                        # P8：同设备旧连接（断线未超时的僵尸）需要被替换，否则
                        # peers 出现重复设备名、事件也会被重复投递到旧 socket。
                        # SRV35-3：先登记新连接并写完 hello，成功后才摘除旧连接
                        # ——hello 写失败时旧连接仍留在 subs 且继续有效，不会出现
                        # "旧连接已被踢出却没收到 closed"的幽灵在线；新连接由下方
                        # except 清理（join 广播尚未发送，无需补发 leave）
                        stale = [s for s in entry.subs if s.device_id == device_id]
                        entry.subs.add(sse)
                        sse.entry = entry   # 复审 R2：记录当前绑定会话
                        entry.mtime = _now()
                        _mark_participant_nolock(path, device_id)   # 阶段①
                        # 复审 rd1：登记 device_id → 设备名别名（ack 收敛用）
                        _remember_dev_alias_nolock(device_id, device_name)
                        # writer token：建连即隐式申请；writer 掉线则按最后活跃移交
                        _touch_participant_nolock(entry, device_id, device_name)
                        if entry.writer_device_id is None:
                            writer_event = _set_writer_nolock(
                                entry, device_id, device_name, "claim")
                        elif (entry.writer_device_id != device_id
                                and not _participant_online_nolock(
                                    entry, entry.writer_device_id)):
                            writer_event = _set_writer_nolock(
                                entry, device_id, device_name, "offline")
                        peers = _peers_list(entry, device_id)
                        hello_content = _normalize_content(entry.content)   # R16-F4
                        # 只取状态快照，json.dumps 与 socket 写都在锁外
                        hello_obj = {
                            "content": hello_content, "peers": peers,
                            "rev": entry.rev,
                            **(_state_fields(hello_content)
                               if (disk_ok or entry.rev > 0)
                               else {"state": "absent"}),
                            **_writer_fields_nolock(
                                entry, writer_event is not None)}
                if hello_obj is not None:
                    hello = ("event: hello\ndata: " + json.dumps(
                        hello_obj, ensure_ascii=False) + "\n\n").encode("utf-8")
                    # 锁外写 hello；期间到达的广播进入 sse 待发队列
                    sse.write_hello(hello)
                    # SRV36-1：写完 hello 后复核绑定——hello 期间会话可能被
                    # delete/GC 替换（或被 _migrate_subs 迁移到源会话），也可能
                    # 因待发队列溢出被 _broadcast 摘除。已发出 hello 后无法再发
                    # 第二个 hello，失效一律关闭连接，由客户端重连拿新基线
                    with _lock:
                        cur = sse.entry
                        if (cur is not None
                                and FILES.get((VAULT_ID, cur.path)) is cur
                                and sse in cur.subs):
                            for s in stale:
                                cur.subs.discard(s)
                            registered = True
                        else:
                            if cur is not None:
                                cur.subs.discard(sse)
                            sse.entry = None
                            self.close_connection = True
                            try:
                                self.connection.shutdown(socket.SHUT_RDWR)
                            except OSError:
                                pass
                            return
            except Exception:
                with _lock:
                    if sse.entry is not None:
                        sse.entry.subs.discard(sse)
                    sse.entry = None
                self.close_connection = True   # 复审 R9：写失败即断开
                raise
            if registered:
                break
            key, entry = _entry_get_or_create(path)   # 复审 R10：重新解析
            if entry is None:
                # SV-Q4：墓碑期拒绝重建，走下方未注册断连路径
                break
            if entry == "undecodable":
                # SV-V5：存在但不可解码，同样拒绝注册走断连路径
                break
        if not registered:
            # 复审 R9/R10：响应头已发出但仍无法绑定有效会话，显式关闭连接
            self.close_connection = True
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            return
        # SV-Q3：hello 已写完，此时才放宽 socket 超时（SV-M4：SSE 长连接
        # keepalive 睡眠间隙无读写属正常，30s 超时会误断）。
        # SV-Q10：不用 None 而用 120s 有限超时——半开连接（客户端断电/NAT
        # 静默断开）上 keepalive/广播写会阻塞至 OS TCP 重传超时（分钟级），
        # handler 线程悬挂累积；120s（配合 30s keepalive）超时破环后走现有
        # except 清理。
        # R19-1：光靠写超时兜不住“只塞进发送缓冲区”的小帧，半开连接会挂到
        # 内核重传放弃（约 15 分钟）；此处开启 TCP 保活（约 60s 探死），
        # 让静默失效的连接在 120s 预算内被移除订阅并触发 writer 移交。
        self.connection.settimeout(120.0)
        _enable_tcp_keepalive(self.connection)
        # SV-H8：被踢的旧连接主动发 closed，客户端可据此立即重连/清理状态
        for s in stale:
            try:
                s.write(("event: closed\ndata: "
                         + json.dumps({"reason": "replaced"}) + "\n\n").encode("utf-8"))
            except Exception:
                pass
        # 通知其他订阅者：新 peer 加入
        # SV-AE6：注册后已释放 _lock，hello 与 join 之间另一请求的
        # _resolve_session_path 可把本订阅迁移到源会话并清空旧 entry.subs；
        # join 必须按 sse 当前绑定的 entry 发送，否则迁移后的 peers 收不到
        with _lock:
            join_entry = sse.entry
        if join_entry is not None:
            if writer_event is not None:
                _broadcast(join_entry, writer_event)
                _log(f"[writer] path={path} dev={device_id} "
                     f"reason={writer_event['reason']} "
                     f"rev={writer_event['writer_rev']}")
            _broadcast(join_entry, {"type": "peer", "device_id": device_id,
                                    "device_name": device_name, "action": "join"},
                       exclude_handler=sse)
            _log(f"[sse] JOIN path={path} dev={device_name} "
                 f"total_peers={len(join_entry.subs)}")

        # 保持连接直到断开
        # writer token：掉线判定依赖"订阅已移除"。原先每 30s 才写一次 keepalive，
        # 静默断开的客户端最多要保持 30s 才被发现（writer 移交最长 30+15s）。
        # 改为 1s 粒度用 select+MSG_PEEK 探测 EOF，keepalive 仍按原周期发送。
        next_keepalive = time.time() + GC_SESSIONS_SEC / 2
        try:
            while True:
                time.sleep(1.0)
                with _lock:
                    # 复审 R2：会话可能因别名切换被迁移，按 sse 当前绑定的
                    # entry 检查，避免迁移后被旧 entry 误判为已移除而断开
                    current = sse.entry
                    alive = current is not None and sse in current.subs
                if not alive:
                    break
                try:
                    rd, _, _ = select.select([self.connection], [], [], 0)
                except (OSError, ValueError):
                    rd = [self.connection]
                if rd:
                    try:
                        peek = self.connection.recv(1, socket.MSG_PEEK)
                    except OSError:
                        peek = b""
                    if not peek:
                        break       # 对端已关闭（EOF），立即移除订阅触发移交
                if time.time() >= next_keepalive:
                    sse.write(b": keepalive\n\n")  # SSE comment，保活
                    next_keepalive = time.time() + GC_SESSIONS_SEC / 2
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            # SV-H8：仅当本次确实从 subs 移除成功才广播 leave——同设备重连时
            # 旧连接早已被踢出 subs，若无条件广播 leave 会把新连接误判为离线
            with _lock:
                current = sse.entry
                removed = current is not None and sse in current.subs
                if removed:
                    current.subs.discard(sse)
                    current.mtime = _now()
            if removed:
                _broadcast(current, {"type": "peer", "device_id": device_id,
                                     "device_name": device_name, "action": "leave"})
                _log(f"[sse] LEAVE path={path} dev={device_name} "
                     f"remaining={len(current.subs)}")
            # 复审 R9：SSE 正常/异常退出后恢复 socket 超时并显式关闭连接，
            # 避免 keep-alive 把后续响应写进已发出的 SSE 流、半开 TCP 永久阻塞
            try:
                self.connection.settimeout(30.0)
            except OSError:
                pass
            self.close_connection = True
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    # ---- POST ----
    def do_POST(self):
        if not self._auth():
            # SV-AE4：401 在读取请求体之前返回，body 未被消费；keep-alive 上
            # 残留字节会被当作下一条请求行解析（串包/协议失步）——显式断连
            self.close_connection = True
            return self._send(401, {"ok": False, "error": "unauthorized"})
        u = urlparse(self.path)
        # SV-AD3：未声明 Content-Length（或被 Transfer-Encoding: chunked 替代——
        # stdlib 不解析 chunked）时按 0 读体会让实际发送的 body 残留在 keep-alive
        # 连接上被当作下一条请求解析（串包）；与 N4/R13 同口径显式断连
        if ("Content-Length" not in self.headers
                or self.headers.get("Transfer-Encoding")):
            self.close_connection = True
            return self._send(400, {"ok": False, "error": "content-length required"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except (ValueError, TypeError):
            # 复审 N4：拒绝时未消费 body，keep-alive 上残留字节会被当下一条
            # 请求解析 → 响应前显式关闭连接
            self.close_connection = True
            return self._send(400, {"ok": False, "error": "bad content-length"})
        # SV-H9/SV-M9：请求体硬上限 16MB；负值会让 rfile.read(-1) 永久阻塞
        if length < 0:
            self.close_connection = True   # 复审 N4
            return self._send(400, {"ok": False, "error": "bad content-length"})
        if length > 16 * 1024 * 1024:
            self.close_connection = True   # 复审 N4
            return self._send(413, {"ok": False, "error": "payload too large"})
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            # 复审 R13：读体超时/短读后未消费的 body 会在 keep-alive 下被当作
            # 下一条请求解析，必须显式断连
            self.close_connection = True
            return self._send(400, {"ok": False, "error": "bad json"})
        # SV-S8：body 已整体消费完，顶层非 dict 时直接 400 即可（无需断连）——
        # 原先数组/字符串/数字/null 交给 body.get 抛 AttributeError，
        # socketserver 打栈后关连接，客户端只收到连接重置
        if not isinstance(body, dict):
            return self._send(400, {"ok": False, "error": "bad json"})
        # 老客户端防护：登记平台/构建号（仅内存）+「必须带头」→「平台阈值」。
        # body 已完整消费，4xx 可直接返回，不影响 keep-alive。
        gate = self._report_client(
            _req_text(body.get("device_id")),
            _req_text(body.get("device_name")),
            _req_text(body.get("platform")))
        if gate is not None:
            code, err = gate
            return self._send(code, err)

        if u.path == "/api/v1/open":
            return self._handle_open(body)
        elif u.path == "/api/v1/op":
            return self._handle_op(body)
        elif u.path == "/api/v1/close":
            return self._handle_close(body)
        elif u.path == "/api/v1/save":
            return self._handle_save(body)
        elif u.path == "/api/v1/recent/publish":
            return self._handle_recent_publish(body)
        elif u.path == "/api/v1/recent/heartbeat":
            return self._handle_recent_heartbeat(body)
        elif u.path == "/api/v1/recent/delete":
            return self._handle_recent_delete(body)
        elif u.path == "/api/v1/recent/ack":
            return self._handle_recent_ack(body)
        elif u.path == "/api/v1/recent/device/rename":
            return self._handle_recent_device_rename(body)
        elif u.path == "/api/v1/recent/device/delete":
            return self._handle_recent_device_delete(body)
        elif u.path == "/api/v1/writer/claim":
            return self._handle_writer_claim(body)
        elif u.path == "/api/v1/writer/release":
            return self._handle_writer_release(body)
        self._send(404, {"ok": False, "error": "not found"})

    def _handle_recent_publish(self, body):
        """本设备每打开一个文件就上传一份副本：最近页多端可见、可远程打开编辑。

        副本按设备分目录（2026-11-06 起段名优先 device_id，缺失才回落
        device_name），天然只代表上传它的那台设备；同名两台设备各占一套
        独立目录，互不可见。写的是 RECENT_ROOT，永远不碰同步目录里的原文件，
        因此不存在越权。

        origin_rel：上报时带上该文件在本机的协作 key，服务器据此把
        recent/<设备>/<文件> 与源文件会话绑定（源设备在线时多端共用同一会话）。
        若源设备离线期间副本被其它设备改过，打开时以副本内容为准合并回源文件
        （服务器到达序：后到达的副本改动优先），避免"改了却没同步"。
        """
        # SV-T9：必填字段统一按字符串校验，JSON null 不得变成字面量 "None"
        dev = _safe_path(_req_text(body.get("device_name")))
        name = _safe_path(_req_raw(body.get("file_name")))
        # SV-AG1：origin_rel 可为空（未提供即不绑定源会话）；_safe_path 对空串/非法值
        # 返回 None，不能直接取长度——否则对 None 调 len() 抛 TypeError（500 断连）
        origin_raw = _req_raw(body.get("origin_rel"))
        origin = _safe_path(origin_raw) if origin_raw else ""
        if origin is None:
            origin = ""
        # SV-M7：拒绝 . 开头（可覆盖 .platform 或生成列表不可见文件）与 .tmp. 中段
        # SV-AD2：dev/name/origin 长度上限，防 LAST_SEEN/ALIAS 内存膨胀
        # SRV36-11：dev 与 name 同口径拒绝 . 开头——否则能建出列表不可见的副本目录
        if (not dev or "/" in dev or len(dev) > MAX_DEV_LEN
                or dev.startswith(".")
                or not name or "/" in name or len(name) > MAX_NAME_LEN
                or name.startswith(".") or ".tmp." in name):
            return self._send(400, {"ok": False, "error": "device_name and file_name required"})
        if len(origin) > MAX_ORIGIN_LEN:
            return self._send(400, {"ok": False, "error": "origin_rel too long"})
        # SV-S10：JSON null 不得以字面量 "None" 写进权威内容（adopt 时还会回写源文件）
        # SRV36-9：dict/list 等内容返回 None，按 400 拒绝
        content = _as_text(body.get("content"))
        if content is None:
            return self._send(400, {"ok": False, "error": "bad content"})
        content = _normalize_content(content)   # R16-F4：发布内容进入规范形态
        # 2026-11-06：段名优先 device_id（请求体没带时按别名表把设备名映射到 id，
        # 兼容 PC 发布不带 device_id）；只有唯一 id 才能确定是本机，同名多 id
        # 时无法判断，回落到名字段（旧行为，避免写进同名另一台设备的目录）
        seg = _recent_seg(body.get("device_id"), dev)
        if not seg:
            with _lock:
                matches = [did for did, dn in DEV_NAME_ALIAS.items() if dn == dev]
            seg = matches[0] if len(matches) == 1 else ""
            seg = seg or dev
        recent = RECENT_PREFIX + seg + "/" + name
        recent_full = _full_path(recent)
        ckey = (VAULT_ID, recent)
        # 源路径必须是非 recent 的真实文件；副本不能作为另一个副本的源
        okey = (VAULT_ID, origin) if origin and not origin.startswith(RECENT_PREFIX) else None

        # SV-Q6：ALIAS 登记与 .platform 写盘是副作用，原先在墓碑检查之前
        # 前置执行——被墓碑拦截的 publish 仍会重建已删副本的别名绑定（后续
        # open 该副本路径会被解析进源会话）并复活刚被 delete 清掉的空设备
        # 目录；已移入下方 _recent_io_lock 内、墓碑判定通过之后

        # 复审 R12：与 delete 共享路径级互斥，并先查墓碑——已删副本在墓碑期内
        # 不再落盘，防止并发 publish 把刚删的副本复活
        persisted = True
        blocked = False
        busy = False
        # SV-S2：adopt 决策必须先于"副本落盘 + 广播"，两侧权威值只取一个
        adopted = False
        # SV-T1：两侧都改过且无法证明谁更新时置 conflict，响应回传实际权威内容
        conflict = False
        authority = content
        centry = None
        otarget = None
        copy_json = None
        origin_adopt_json = None
        # R23-1：发布端 device_id（供 ack 重启后核对 owner 门槛的持久标记）
        pub_id = ""

        # SV-V1：_recent_io_lock 改为显式 acquire/release（与迁移的 SV-U7 同款）：
        # 全局锁只覆盖"状态变更 + 落盘"，在发送 adopt/副本刷新广播前提前释放；
        # 广播只持 c0/o0 两把 oplock（ExitStack 持有至发送完毕）。原先广播也在
        # 全局锁内发送，单个慢 SSE 订阅者的 write 最长 15s，会让全服
        # publish/delete/迁移在 _recent_io_lock 上无超时串行等待
        _recent_io_lock.acquire()
        _recent_io_released = False
        try:
            with _lock:
                tomb = _recent_tombstoned_nolock(recent)
            if tomb:
                blocked = True
            else:
                with _lock:
                    _DELETED_RECENT.pop(recent, None)
                    # 复审 rd1：安卓 publish 会带 device_id，可据此建立
                    # device_id → device_name 别名（PC 未带，由 open/SSE 补充）
                    pub_id = _req_text(body.get("device_id"))
                    _remember_dev_alias_nolock(pub_id, dev)
                    if not pub_id:
                        # R23-1：PC publish 不带 id 时用别名表反查本机 id；
                        # 拿不到就留空，由 _set_publisher_marker 清除过期标记
                        for did, dn in DEV_NAME_ALIAS.items():
                            if dn == dev:
                                pub_id = did
                                break
                # 2026-11-06：id 段目录写 `.name`，重启后仍能按设备名反查 id 目录
                _write_recent_name_marker(seg, dev)
                # SV-Q6：副作用移到墓碑判定通过之后（仍在 _recent_io_lock 内，
                # 与 delete 互斥）：写 .platform。
                # SV-AE3：ALIAS 登记改到副本落盘成功之后（见下方 flush_ok 分支）——
                # 原先先登记后落盘，ENAMETOOLONG/磁盘错误时别名永久残留
                # 记录设备形态（desktop/phone/tablet），供客户端显示对应设备图标
                plat = _req_text(body.get("platform")).lower()
                if plat in ("desktop", "phone", "tablet"):
                    try:
                        # SRV36-10：原子写，读者不会读到截断的形态文件
                        _write_text_atomic(
                            os.path.join(os.path.dirname(recent_full), ".platform"),
                            plat)
                        # SV-AB1：写盘成功后同步回填 _PLATFORM_CACHE，与
                        # _handle_recent_heartbeat 同口径——否则缓存与磁盘数据源分叉，
                        # /recent/devices 读到陈旧形态。写盘失败不回填。
                        with _lock:
                            _remember_platform(dev, plat)
                    except Exception:
                        pass
                with _lock:
                    c0 = FILES.get(ckey)
                    o0 = FILES.get(okey) if okey is not None else None
                # SV-S1：在 _recent_io_lock 内按固定顺序取"副本 → 源"两把 oplock，
                # 整段 adopt 判定与两侧落盘都处于 protected 区间内——原先副本侧
                # stat 在锁外，GC 可在此期间落盘并删掉 entry，快照直接变 None。
                # 源路径一律不以 recent/ 开头，与其它 publish 的锁集合不相交，
                # 不会形成锁环（锁序仍为 _recent_io_lock → oplock → _lock）
                # SV-T6：oplock 带超时获取——慢 SSE 订阅者的持锁广播可长期占用
                # oplock，原先在这里无限等待会把全服 publish/delete/迁移一起堵住
                with ExitStack() as stack:
                    try:
                        if c0 is not None:
                            stack.enter_context(_timed_lock(c0.oplock))
                        if o0 is not None:
                            stack.enter_context(_timed_lock(o0.oplock))
                    except _LockTimeout:
                        # 超时交由外层 busy 分支返回 503（publish 本就后台尽力而为）
                        busy = True
                    if not busy:
                        with _lock:
                            c_live = c0 is not None and FILES.get(ckey) is c0
                            o_live = o0 is not None and FILES.get(okey) is o0
                        # 取锁前已被 close/GC 换掉的极端情形：退化为磁盘/无会话分支
                        if c_live:
                            centry = c0
                        if o_live:
                            otarget = o0

                        # ---- 副本侧快照与新近信号（SV-S1/SV-T1）----
                        # 磁盘 mtime 必须在 _recent_io_lock 内重新 stat；rev>0 表示内存
                        # 里有尚未落盘的编辑（GC 30s 空闲才落盘且不回零 rev），内存即权威，
                        # 磁盘 mtime 只是上次 GC 落盘时间，取 max 只会注入噪声
                        copy_mtime = _disk_mtime(recent)
                        copy_snapshot = None
                        if centry is not None:
                            # 持 entry.oplock：内容不会被并发 op 改写
                            copy_snapshot = centry.content
                            if centry.rev > 0:
                                # SV-V2：rev>0 改用 content_mtime（内容最后变更时间），
                                # 与源侧 origin_ts 口径对称——entry.mtime 是活动时间
                                # （hello/leave 都刷新），会把"刚有人打开过"误判成
                                # "副本比源新"，触发用旧副本回滚较新源内容的错误 adopt
                                copy_mtime = centry.content_mtime
                        elif copy_mtime > 0:
                            # SV-BL1（第三十三轮复查）：快照读取原先要求 okey
                            # 非空；客户端未上报 origin_rel 时根本不读副本，
                            # 下面的 copy_foreign 恒为 False，他端编辑被覆盖
                            # 无内存会话：副本内容只在磁盘，覆盖前先读快照；
                            # 读失败保持 None，宁可不合并也不回滚副本编辑
                            # SV-V4：改调 _load_from_disk（与 SV-U10 读入侧统一口径，
                            # 含 >16MB 前置拦截）；失败返回空串、超限/不可解码返回
                            # None（SV-V5/SV-W1）——一律按"快照不可得"处理，不参与合并
                            snap = _load_from_disk(recent)
                            if snap:
                                copy_snapshot = snap
                        with _lock:
                            copy_base = _PUBLISHED_LOCAL.get(recent)
                        # SV-T1：副本是否比"本次上报的源设备视图（content）"更新。
                        # 判据是副本内容与上次上报后的基线（copy_base）不同——说明
                        # 两次上报之间有他端（远程会话的 op/save/adopt）改过副本；
                        # 若副本仍等于基线，它只是上次上报的回声，content 才是最新。
                        # 基线未知（服务端重启过）时无法判定，标记 conflict。
                        # 复审 rd1：只有“真实快照”才能作为权威——读端点 absent 的
                        # open 曾建出 rev==0 且磁盘不存在的空 entry，它不是快照；
                        # 否则首次 publish 会把发布内容替换成空串（数据丢失）。
                        copy_real = ((centry is not None and centry.rev > 0)
                                     or copy_mtime > 0)
                        copy_foreign = (copy_real
                                        and copy_snapshot is not None
                                        and copy_snapshot != content
                                        and copy_base is not None
                                        and _content_digest(copy_snapshot) != copy_base)
                        if (copy_real and copy_snapshot is not None
                                and copy_snapshot != content
                                and copy_base is None):
                            # SV-BL2：基线未知（服务重启/首次上报）时无法判定
                            # 谁更新，旧实现仍用 content 覆盖副本并只回 conflict。
                            # 以副本为权威保留他端可能更新的编辑，源端按 conflict
                            # 重试；不得回滚副本
                            conflict = True
                            authority = copy_snapshot
                        # SV-BK2（第三十二轮复查）：okey 为空（本次上报没有
                        # origin_rel）时下方只走"用 content 覆盖副本"分支，
                        # 他端对副本的编辑会被静默冲掉且不标记冲突。副本此时
                        # 是唯一权威，保留其内容并让源端按 conflict 重试
                        if copy_foreign and okey is None:
                            conflict = True
                            authority = copy_snapshot

                        # ---- 权威值选择（SV-T1/SV-S2）----
                        # 依据：content 代表源设备当前视图；只有副本含上次上报之后
                        # 的编辑（copy_foreign）才可能是更新的一方。原先仅凭副本磁盘
                        # mtime（恒为上次 publish 的服务端写盘时间）判新旧，每次都被
                        # 判成"副本更新"，旧快照反复回写源文件、content 被丢弃
                        if okey is not None and copy_snapshot is not None:
                            if otarget is not None:
                                with _lock:
                                    o_content = otarget.content
                                    o_rev = otarget.rev
                                    o_mtime = otarget.content_mtime   # SV-U6
                                # SV-S1：对照值取内存权威——rev>0 用 entry.mtime；
                                # rev==0 时 entry 只是打开时从磁盘加载的基线，用
                                # 源文件磁盘 mtime，否则源设备刚打开就会误判
                                origin_ts = o_mtime if o_rev > 0 else _disk_mtime(origin)
                                if copy_foreign:
                                    conflict = True
                                    if o_content == copy_snapshot:
                                        # 源会话已是副本值（他端编辑已在共享会话生效），
                                        # 副本按源会话值对齐，content 落后于两端
                                        authority = copy_snapshot
                                    elif copy_mtime > origin_ts:
                                        # 副本确有他端新编辑且不比源旧 → 副本为权威值
                                        adopted = True
                                        authority = copy_snapshot
                                        with _lock:
                                            if FILES.get(okey) is otarget:
                                                otarget.content = authority
                                                otarget.mtime = _now()
                                                otarget.content_mtime = otarget.mtime   # SV-U6
                                                otarget.rev += 1
                                                origin_adopt_json = {
                                                    "type": "struct", "start": 0,
                                                    "delete": -1, "insert": [],
                                                    "content": authority,
                                                    "device_id": "",
                                                    "ts": int(otarget.mtime),
                                                    "rev": otarget.rev}
                                        # 阶段①：服务端零写同步根——源文件由客户端
                                        # 本地保存、Syncthing 传播，此处只校正内存。
                                        # SV-T8：GC 的 rev==0 且无订阅者回收路径不持
                                        # oplock，可能在判定期间删掉 entry，并发 GET/open
                                        # 随后以旧磁盘内容重建 → 内存旧/磁盘新，此处校正
                                        with _lock:
                                            cur = FILES.get(okey)
                                        if cur is not None and cur is not otarget:
                                            # SV-W2：换入 entry 的 oplock 入 ExitStack
                                            # 持有至广播完毕——原先仅校正瞬间持锁，
                                            # 广播时已释放，窗口内并发 op 可先送达
                                            # 高 rev 再被旧全文帧回退
                                            try:
                                                stack.enter_context(
                                                    _timed_lock(cur.oplock))
                                            except _LockTimeout:
                                                cur = None
                                            if cur is not None:
                                                with _lock:
                                                    if (FILES.get(okey) is cur
                                                            and cur.rev == 0
                                                            and cur.content != authority):
                                                        cur.content = authority
                                                        cur.mtime = _now()
                                                        cur.content_mtime = cur.mtime   # SV-U6
                                                        cur.rev += 1
                                                        origin_adopt_json = {
                                                            "type": "struct",
                                                            "start": 0, "delete": -1,
                                                            "insert": [],
                                                            "content": authority,
                                                            "device_id": "",
                                                            "ts": int(cur.mtime),
                                                            "rev": cur.rev}
                                                        otarget = cur
                                elif o_content != content:
                                    # 副本只是上次上报的回声 → 本次 content 才是源设备
                                    # 当前视图，不得反过来用副本旧内容覆盖源（SV-T1）
                                    if o_rev == 0:
                                        # 源会话尚未改动：把 content 合并回源会话与源文件
                                        # （原实现在此丢弃本次 publish 内容）
                                        with _lock:
                                            if FILES.get(okey) is otarget:
                                                otarget.content = content
                                                otarget.mtime = _now()
                                                otarget.content_mtime = otarget.mtime   # SV-U6
                                                otarget.rev += 1
                                                origin_adopt_json = {
                                                    "type": "struct", "start": 0,
                                                    "delete": -1, "insert": [],
                                                    "content": content,
                                                    "device_id": "",
                                                    "ts": int(otarget.mtime),
                                                    "rev": otarget.rev}
                                        # 阶段①：同上，源路径只更新内存、不落盘
                                        # SV-T8：同上复核 GC 回收后重建的 entry
                                        with _lock:
                                            cur = FILES.get(okey)
                                        if cur is not None and cur is not otarget:
                                            # SV-W2：同上——换锁入 ExitStack 持有至广播
                                            try:
                                                stack.enter_context(
                                                    _timed_lock(cur.oplock))
                                            except _LockTimeout:
                                                cur = None
                                            if cur is not None:
                                                with _lock:
                                                    if (FILES.get(okey) is cur
                                                            and cur.rev == 0
                                                            and cur.content != content):
                                                        cur.content = content
                                                        cur.mtime = _now()
                                                        cur.content_mtime = cur.mtime   # SV-U6
                                                        cur.rev += 1
                                                        origin_adopt_json = {
                                                            "type": "struct",
                                                            "start": 0, "delete": -1,
                                                            "insert": [],
                                                            "content": content,
                                                            "device_id": "",
                                                            "ts": int(cur.mtime),
                                                            "rev": cur.rev}
                                                        otarget = cur
                                    else:
                                        # 源会话有更新的实时编辑：两侧都改过且无法判定，
                                        # 保留源会话为权威值，响应回传它以让客户端合并
                                        conflict = True
                                        authority = o_content
                            else:
                                # 复审 N1：无源会话时也不在全局锁内做磁盘 IO
                                origin_mtime = _disk_mtime(origin)
                                if copy_foreign:
                                    conflict = True
                                    if copy_mtime > origin_mtime:
                                        adopted = True
                                        authority = copy_snapshot
                                        # 阶段①：服务端零写同步根——源文件由客户端
                                        # 本地保存；此处只校正内存（并发 open/save 可能
                                        # 在判定过程中建出源 entry）
                                        with _lock:
                                            appeared = FILES.get(okey)
                                        if appeared is not None:
                                            # SV-W2：同上——换锁入 ExitStack 持有至广播
                                            try:
                                                stack.enter_context(
                                                    _timed_lock(appeared.oplock))
                                            except _LockTimeout:
                                                appeared = None
                                            if appeared is not None:
                                                with _lock:
                                                    if (FILES.get(okey) is appeared
                                                            and appeared.rev == 0
                                                            and appeared.content != authority):
                                                        appeared.content = authority
                                                        appeared.mtime = _now()
                                                        appeared.content_mtime = appeared.mtime   # SV-U6
                                                        appeared.rev += 1
                                                        origin_adopt_json = {
                                                            "type": "struct",
                                                            "start": 0,
                                                            "delete": -1,
                                                            "insert": [],
                                                            "content": authority,
                                                            "device_id": "",
                                                            "ts": int(appeared.mtime),
                                                            "rev": appeared.rev}
                                                        otarget = appeared
                                # 副本不比源新：保留 content 为权威值（conflict 已标记）

                        # ---- 副本侧权威值与落盘（SV-S2/SV-T1）----
                        flush_ok = _flush_recent(recent, authority)
                        if not flush_ok:
                            persisted = False   # 复审 R11：不吞掉落盘失败
                        with _lock:
                            # SV-T1：记录本次 publish 后的副本基线，供下次判定
                            # 落盘失败时磁盘仍是旧值，不更新基线——否则下次会把
                            # 旧磁盘内容误判成"他端新编辑"而回滚源文件
                            # SV-U1：只看本次 flush 结果（persisted 是累积标志，
                            # 早前阶段失败时会让本次成功也被误判）
                            if flush_ok:
                                _remember_published(recent, authority)
                                # SV-AE3：别名只在副本真正落盘后登记（含容量上限）
                                if okey is not None:
                                    _remember_alias(recent, origin)
                                # batch77：发布端无条件登记为参与者——原来只在
                                # “已有内存 entry 且内容变化”的分支里登记，publish
                                # 新建副本（entry 为 None）时发布端缺失，另一端
                                # open 后成为唯一参与者，一 ack 就提前 settled，
                                # 发布端随后 ack 必得 410。
                                _mark_participant_nolock(recent, dev)
                                # 2026-11-06：id 段副本的 owner 是发布端 id，
                                # 旧名字段的 owner 仍是名字——两者都登记
                                if pub_id:
                                    _mark_participant_nolock(recent, pub_id)
                            # 复审 R10：与 op 同型身份校验，不写孤儿 entry
                            if centry is not None and FILES.get(ckey) is centry:
                                if centry.content != authority:
                                    centry.content = authority
                                    centry.mtime = _now()
                                    centry.content_mtime = centry.mtime   # SV-U6
                                    centry.rev += 1
                                    _mark_participant_nolock(recent, dev)   # 阶段①：发布者也是参与端
                                    if pub_id:
                                        _mark_participant_nolock(recent, pub_id)
                                    copy_json = {"type": "struct", "start": 0,
                                                 "delete": -1, "insert": [],
                                                 "content": authority, "device_id": "",
                                                 "ts": int(centry.mtime),
                                                 "rev": centry.rev}
                        if flush_ok:
                            # R23-1：发布端标识落盘（辅助元数据，失败只记日志）。
                            # 无 id 时清除旧标记，避免重启后旧发布端冒充 owner
                            _set_publisher_marker(recent, pub_id)
                        if flush_ok and okey is not None:
                            # 复审 R6：外部源副本写隐藏标记（源已不是外部键则清除
                            # 旧标记），供进程重启后的 _resolve_session_path 放弃
                            # 同名兜底；okey 为空表示本次上报未带 origin，源未知，
                            # 保守起见保留既有标记
                            _set_external_origin_marker(
                                recent, origin if _is_external_key(origin) else "")
                        # SRV34-5：落盘后无条件复核当前副本 entry——快照对象可能在
                        # 落盘期间被 GC 回收（rev==0 且无订阅者）后由并发 GET/open
                        # 以旧磁盘内容重建，原先只在 centry is None 时校正会漏掉；
                        # 统一按源侧同口径校正：持对应 oplock 并复核身份，rev==0
                        # 的重建基线改为权威值，rev>0 的他端编辑则用内存较新值覆回
                        if flush_ok:
                            with _lock:
                                cur = FILES.get(ckey)
                            if cur is not None and cur is not centry:
                                restore = None
                                # SV-AD1：带超时获取，与源侧 SV-S7 分支同口径——
                                # 超时放弃本次校正，避免在 _recent_io_lock 内无限
                                # 等待堵住全服 publish/delete/迁移（SV-T6）
                                try:
                                    stack.enter_context(_timed_lock(cur.oplock))
                                except _LockTimeout:
                                    cur = None
                                if cur is not None:
                                    with _lock:
                                        if (FILES.get(ckey) is cur
                                                and cur.content != authority):
                                            if cur.rev == 0:
                                                # 只是并发重建出的磁盘旧基线
                                                cur.content = authority
                                                cur.mtime = _now()
                                                cur.content_mtime = cur.mtime   # SV-U6
                                                cur.rev += 1
                                                copy_json = {
                                                    "type": "struct", "start": 0,
                                                    "delete": -1, "insert": [],
                                                    "content": authority,
                                                    "device_id": "",
                                                    "ts": int(cur.mtime),
                                                    "rev": cur.rev}
                                                centry = cur
                                            else:
                                                # 内存已有他端更新编辑，用较新值覆回磁盘
                                                restore = cur.content
                                if restore is not None:
                                    if not _flush_recent(recent, restore):
                                        persisted = False
                    # SV-V1：广播前提前释放 _recent_io_lock——慢 SSE 订阅者的持锁
                    # 广播不再堵住全服 publish/delete/迁移；两把 oplock 由 ExitStack
                    # 继续持有至下方广播发送完毕，保序不受影响
                    _recent_io_lock.release()
                    _recent_io_released = True
                    # SV-U4：广播移入 ExitStack 区间（两把 oplock 仍持有），与
                    # op/struct/save 的"持锁广播"处于同一保序区间。原先在锁外发送，
                    # 并发 op 可先送达更高 rev，随后到达的 publish 旧全文帧会把
                    # 客户端按到达序整篇回退且不会自愈
                    if origin_adopt_json is not None and otarget is not None:
                        _broadcast(otarget, origin_adopt_json)
                    if copy_json is not None and centry is not None:
                        _broadcast(centry, copy_json)
        finally:
            # SV-V1：提前 return/异常路径与 blocked（墓碑）分支统一在此释放——
            # 这些路径不会到达上方 ExitStack 内的释放点
            if not _recent_io_released:
                _recent_io_lock.release()
        if blocked:
            # 复审 R12：墓碑期内忽略本次 publish（可视为已删除）
            return self._send(200, {"ok": True, "ignored": "deleted"})
        if busy:
            # SV-T6：oplock 等待超时，本轮放弃（全局锁已释放，客户端稍后重发）
            return self._send(503, {"ok": False, "error": "busy"})
        if adopted:
            _log(f"[recent] adopt {recent} -> {origin}")
        # SV-Q8：响应在锁外发送
        resp = {"ok": True, "mtime": int(_now()),
                "adopted": adopted, "persisted": persisted}
        if conflict:
            # SV-T1：无法判定新旧时不静默丢弃——回传实际权威内容供客户端合并
            resp["conflict"] = True
            resp["content"] = authority
        return self._send(200, resp)

    def _handle_recent_heartbeat(self, body):
        """设备在线心跳：客户端前台运行期间每 3s 打一次（三端统一），用于最近页在线状态。

        不用 SSE 订阅判断在线——设备只是停在最近页、没打开文件时没有订阅，
        会被误判为离线（表现为手机在线但 PC 显示灰色图标）。
        """
        # SV-T9：device_name 非字符串（null/数字）不得变成 "None" 设备目录
        dev = _safe_path(_req_text(body.get("device_name")))
        # SV-AD2：超长 dev 名会以键驻留 LAST_SEEN 24h，换名重发即线性膨胀
        # SRV36-11：. 开头的 dev 在 /recent/devices 中被跳过，与 publish/delete 同口径拒绝
        if (not dev or "/" in dev or len(dev) > MAX_DEV_LEN
                or dev.startswith(".")):
            return self._send(400, {"ok": False, "error": "device_name required"})
        # 2026-11-06：新客户端心跳带 device_id，在线状态与 .platform 都记到
        # id 目录；旧客户端只有名字，仍写到名字目录（与 publish 同口径）
        did = _recent_seg(body.get("device_id"), "") or ""
        with _lock:
            now = _now()
            # 心跳 3s 一次，顺手清理一天没动静的条目，避免 LAST_SEEN 无界增长
            for k, v in list(LAST_SEEN.items()):
                if now - v > 86400:
                    LAST_SEEN.pop(k, None)
            # SRV34-7：设备名可随意更换，仅靠过期清理挡不住短时间大量换名；
            # 与 _remember_platform 同款上限淘汰，重新插入保持 LRU 顺序，
            # 淘汰的都是最久无心跳的条目，不影响在线判定
            LAST_SEEN.pop(dev, None)
            LAST_SEEN[dev] = now
            if did:
                LAST_SEEN.pop(did, None)
                LAST_SEEN[did] = now
            while len(LAST_SEEN) > MAX_LAST_SEEN:
                try:
                    LAST_SEEN.pop(next(iter(LAST_SEEN)))
                except StopIteration:
                    break
        plat = _req_text(body.get("platform")).lower()
        if plat in ("desktop", "phone", "tablet"):
            # 心跳每 3s 一次，只在形态变化时才写盘，否则 24 小时写 2.8 万次
            seg = did or dev
            pdir = os.path.join(RECENT_ROOT, seg)
            pf = os.path.join(pdir, ".platform")
            # SV-AA3：_PLATFORM_CACHE 为共享 dict，读写须在 _lock 内；
            # 缓存读在锁内，写盘放锁外，再回写缓存到锁内
            with _lock:
                cached_plat = _PLATFORM_CACHE.get(seg)
            if cached_plat != plat or not os.path.isfile(pf):
                try:
                    # SRV36-10：与 publish 同口径原子写
                    _write_text_atomic(pf, plat)
                    if did:
                        _write_recent_name_marker(did, dev)
                    with _lock:
                        _remember_platform(seg, plat)
                        _remember_platform(dev, plat)
                except Exception:
                    pass
        self._send(200, {"ok": True})

    def _handle_recent_delete(self, body):
        """删除最近页记录对应的服务器副本。只能删自己设备目录下的副本。

        SV-H3 所有权模型说明：服务端身份只有 API Key 一级（Bearer），无按设备
        的二级身份。路径已硬性限定在 RECENT_ROOT/<dev>/<name> 内（_safe_path
        拒绝穿越），即持 Key 者可删除任意设备目录的副本——这是有意设计：
        Key 只在三端私有部署内分发，持 Key 即视为受信；副本删除不影响同步
        目录中的源文件，最坏后果是最近页副本丢失，可接受。publish 同理。
        """
        # SV-T9：必填字段按字符串校验，避免 "path": null 变成合法路径 "None"
        dev = _safe_path(_req_text(body.get("device_name")))
        name = _safe_path(_req_raw(body.get("file_name")))
        # SV-AD4：与 publish（SV-M7）对齐——拒绝 . 开头与 .tmp. 中段，否则
        # delete 能删到 publish 建不了的 .platform 形态文件（校验不对称）；
        # SV-AD2：长度上限与 publish 同口径
        # SRV36-11：dev 同样拒绝 . 开头，与列表可见性口径一致
        if (not dev or "/" in dev or len(dev) > MAX_DEV_LEN
                or dev.startswith(".")
                or not name or "/" in name or len(name) > MAX_NAME_LEN
                or name.startswith(".") or ".tmp." in name):
            return self._send(400, {"ok": False, "error": "device_name and file_name required"})
        # 2026-11-06：删除只作用于目标设备目录——有 device_id 用 id 段，
        # 否则沿用旧名字段；旧名字目录不做隐式删除（避免误删同名另一台设备）
        seg = _recent_seg(body.get("device_id"), "")
        if not seg:
            seg = dev
            # 旧客户端只报名字，而副本可能已落在本机 id 目录（publish 经别名
            # 映射或新端写入）。名字目录没有该副本、且只有一个同名字 id 目录
            # 有时，改删 id 目录；多于一个则同名歧义，保持旧行为只删名字目录
            try:
                has_legacy = os.path.isfile(os.path.join(RECENT_ROOT, dev, name))
            except OSError:
                has_legacy = False
            if not has_legacy:
                try:
                    cands = [s for s in sorted(os.listdir(RECENT_ROOT))
                             if not s.startswith(".") and s != dev
                             and _recent_dir_name(s) == dev]
                except OSError:
                    cands = []
                with _lock:
                    live = {s for s in cands
                            if (VAULT_ID, RECENT_PREFIX + s + "/" + name)
                            in FILES}
                cands = [s for s in cands
                         if s in live or os.path.isfile(os.path.join(
                             RECENT_ROOT, s, name))]
                if len(cands) == 1:
                    seg = cands[0]
        full = os.path.join(RECENT_ROOT, seg, name)
        recent = RECENT_PREFIX + seg + "/" + name
        # 复审 R12：delete 与 publish 共用同一路径级互斥，先登记墓碑再删文件，
        # 使紧邻到达的 publish 在墓碑期内被拦截，不会复活已删副本
        # SV-S3：unlink/pop 还必须持副本 entry.oplock——GC/close/save 的 recent
        # 落盘点都是"oplock 内复核 FILES 身份 → 写盘"，持同一把 oplock 才能让
        # unlink 与写盘互斥；否则 unlink 可落在其身份复核之后、写盘之前，文件
        # 被重新创建而 entry 已被 pop，RECENT_ROOT 留下孤儿副本（先删后复活）。
        # 选此方案而非给每个落盘点都套 _recent_io_lock：锁序仍为
        # _recent_io_lock → oplock → _lock，改动面最小
        delete_err = None
        entry = None
        subs = []
        busy = False
        with _recent_io_lock:
            with _lock:
                entry = FILES.get((VAULT_ID, recent))
                _DELETED_RECENT[recent] = _now()
            acquired = False
            if entry is not None:
                # SV-T6：带超时获取——慢 SSE 订阅者的持锁广播可长期占用 oplock，
                # 原先在全局锁内无限等待会堵住全服所有 publish/delete/迁移
                acquired = entry.oplock.acquire(timeout=OPLOCK_WAIT_SEC)
                if not acquired:
                    busy = True
                    # SV-T7：未删任何东西就放弃，必须撤销刚登记的墓碑
                    with _lock:
                        _DELETED_RECENT.pop(recent, None)
            if not busy:
                try:
                    if os.path.isfile(full):
                        try:
                            os.unlink(full)
                            _log(f"[recent] delete {seg}/{name}")
                        except OSError as e:
                            delete_err = str(e)
                    if delete_err is None:
                        # 复审 R6：副本删除后清除外部源标记，避免同名文件下次经
                        # 非 publish 通道重建时继承过期的“外部源”身份
                        _set_external_origin_marker(recent, "")
                        # R23-1：发布端标记同步清除（否则同名副本重建后
                        # 旧发布端 id 可能被误认为新快照的 owner）
                        _set_publisher_marker(recent, "")
                        # SV-T7：目录清理失败不影响删除结果——副本已删，listdir
                        # 抛错不应让 entry 留在 FILES 被 GC 落盘复活
                        try:
                            dev_dir = os.path.join(RECENT_ROOT, seg)
                            if os.path.isdir(dev_dir) and not os.listdir(dev_dir):
                                os.rmdir(dev_dir)   # 设备目录空了就一并清理
                        except OSError as e:
                            _log(f"[recent] rmdir {seg} skipped: {e}")
                        with _lock:
                            ALIAS.pop(recent, None)
                            _PUBLISHED_LOCAL.pop(recent, None)
                            SNAP_META.pop(recent, None)
                            popped = FILES.pop((VAULT_ID, recent), None)
                            if popped is not None:
                                subs = list(popped.subs)
                                popped.subs.clear()
                    else:
                        # SV-T7：unlink 失败——副本仍存在却被墓碑拦截会令 publish
                        # 被忽略、get/open 返回 410；同临界区内撤销墓碑
                        with _lock:
                            _DELETED_RECENT.pop(recent, None)
                finally:
                    if acquired:
                        entry.oplock.release()
        if busy:
            # SV-T6：等待 oplock 超时，本轮放弃（全局锁已释放，客户端可重试）
            return self._send(503, {"ok": False, "error": "busy"})
        if delete_err is not None:
            # 复审 R3 同类：锁外发送响应
            # SRV36-8：OSError 文本含服务器绝对路径/权限细节，只记日志不回给客户端
            _log(f"[recent] delete FAIL {dev}/{name}: {delete_err}")
            return self._send(500, {"ok": False, "error": "delete failed"})
        # 锁外逐个发 closed 并断开，避免订阅者成为孤儿（SV-C2/SV-H4）
        for s in subs:
            try:
                s.write(("event: closed\ndata: "
                         + json.dumps({"reason": "deleted"}) + "\n\n").encode("utf-8"))
            except Exception:
                pass
        return self._send(200, {"ok": True})

    def _handle_recent_ack(self, body):
        """阶段①：客户端上报“本机该副本内容已处理”的内容哈希。

        删除条件（替代设计稿中的 TTL / 容量上限）：当**所有参与设备**上报的
        本地 hash 都等于快照当前 hash 时，快照才算处理完并从 RECENT_ROOT 移除。
        关闭弹窗、断开连接都不会改变 participants/acks，因此不构成删除条件；
        设备被删除时走 /api/v1/recent/device/delete 批量清理。

        “同一份文件”的判定用路径 + 版本标识（open 返回的 rev/content_hash），
        “设备已处理”只用这里的 hash 上报，二者分离。
        """
        dev = _safe_path(_req_text(body.get("device_name")))
        name = _safe_path(_req_raw(body.get("file_name")))
        device_id = _req_text(body.get("device_id")) or dev
        h = _req_text(body.get("hash")) or _req_text(body.get("sha256"))
        if not _valid_device(device_id):
            return self._send(400, {"ok": False, "error": "device_id required"})
        # 与 publish/delete 同口径校验设备名与文件名
        if (not dev or "/" in dev or len(dev) > MAX_DEV_LEN
                or dev.startswith(".")
                or not name or "/" in name or len(name) > MAX_NAME_LEN
                or name.startswith(".") or ".tmp." in name):
            return self._send(400, {"ok": False,
                                    "error": "device_name and file_name required"})
        if h.startswith("sha256:"):
            h = h[7:]
        h = h.lower()
        if len(h) != 64 or any(c not in "0123456789abcdef" for c in h):
            return self._send(400, {"ok": False, "error": "bad hash"})
        # 2026-11-06：ack 的 device_name 是"副本所属段"（发布端目录段，可能是
        # id 或旧名字）；device_id 是上报端自己的身份，只用于收敛判定，不能
        # 拿来定位目录（任何参与设备都会 ack 别人的副本）。
        # 2026-11-07：人工改名后展示名 != 目录名，故候选段需覆盖 override 名，
        # 且按“实际含该文件/活会话”的段定位（id 段与旧名字段都在候选里）。
        segs = _recent_read_segments(dev)
        seg = segs[0] if segs else (_recent_seg("", dev) or dev)
        for s in segs:
            with _lock:
                live = (VAULT_ID, RECENT_PREFIX + s + "/" + name) in FILES
            if live or os.path.isfile(os.path.join(RECENT_ROOT, s, name)):
                seg = s
                break
        recent = RECENT_PREFIX + seg + "/" + name
        ckey = (VAULT_ID, recent)
        full = os.path.join(RECENT_ROOT, seg, name)

        settled = False
        busy = False
        early = None
        converged = False
        snap_hash = ""
        pub_hint = ""
        participants = []
        acked = {}
        subs = []
        delete_err = None
        with _recent_io_lock:
            with _lock:
                entry = FILES.get(ckey)
                tomb = _recent_tombstoned_nolock(recent)
            if tomb:
                # 复审 rd1：锁内只置结果，socket 写在锁外发送（原实现在
                # _recent_io_lock 内 _send，慢客户端可阻塞全服 recent IO）
                early = (410, {"ok": False, "error": "deleted"})
            acquired = False
            lock_entry = None
            if early is None and entry is not None:
                # 与 delete/save 的 recent 落盘点共用 oplock，避免“删除与写盘”竞争
                acquired = entry.oplock.acquire(timeout=OPLOCK_WAIT_SEC)
                if acquired:
                    lock_entry = entry
                    with _lock:
                        cur = FILES.get(ckey)
                        cur_rev = cur.rev if cur is not None else 0
                    if cur is not entry:
                        # 复审 rd1：旧对象已被 GC/close 回收。若当前会话已有
                        # 未落盘的新编辑（rev>0），绝不能在旧对象上判定收敛并
                        # 删除——那会丢掉内存里最新内容并删盘。退避重试。
                        # 复审 R2：释放旧锁后**在 _lock 外**取当前对象 oplock，
                        # 保持 oplock → _lock 锁序（锁内取 oplock 会与持
                        # oplock 等 _lock 的 op/save 形成死锁）
                        lock_entry.oplock.release()
                        acquired = False
                        lock_entry = None
                        if cur is None:
                            entry = None
                        elif cur_rev > 0:
                            entry = None
                            busy = True
                        else:
                            entry = cur
                            acquired = entry.oplock.acquire(
                                timeout=OPLOCK_WAIT_SEC)
                            if acquired:
                                lock_entry = entry
                            else:
                                entry = None
                                busy = True
                else:
                    busy = True
                    entry = None
            if early is None and not busy:
                try:
                    content = None
                    if entry is not None:
                        with _lock:
                            live = FILES.get(ckey) is entry
                            if live:
                                content = entry.content
                        if not live:
                            # 复审 R2：取锁后被并发 open/GC 换掉——放弃本轮，
                            # 绝不在旧对象上读旧内容判定收敛
                            busy = True
                    if entry is None and not busy:
                        content = _load_from_disk(recent)
                        if content is None:
                            early = (415, {"ok": False, "error": "not utf-8"})
                        elif not os.path.isfile(full):
                            early = (410, {"ok": False, "error": "deleted"})
                    if early is None and not busy:
                        snap_hash = _content_digest(content)
                        # R23-1：DEV_NAME_ALIAS 是内存态，进程重启即清空；此时
                        # ack 的 Syncthing ID 无法映射到 owner 设备名，batch77
                        # 的 owner 门槛永远满足不了。别名缺失时读 publish 落盘
                        # 的发布端标识，只有该 id 的 ack 才能代替 owner（语义不变）
                        pub_hint = ""
                        if DEV_NAME_ALIAS.get(device_id) is None:
                            pub_hint = _persisted_publisher(recent)
                        with _lock:
                            # 复审 R3：entry 为 None 时上面在读盘采样（此刻持有
                            # _recent_io_lock，但 open/op/save 不需要它），此间可能
                            # 已由并发 open/op 建出新会话并写入 rev>0 编辑。收敛
                            # 判定不能基于过期样本——否则下面的 unlink + FILES.pop
                            # 会把新会话里尚未落盘的编辑一并丢弃，改为退避重试。
                            if FILES.get(ckey) is not entry:
                                busy = True
                            else:
                                meta = _snap_meta_nolock(recent)
                                if (len(meta["participants"])
                                        < MAX_SNAP_PARTICIPANTS):
                                    meta["participants"].add(device_id)
                                meta["last_active"][device_id] = _now()
                                # batch77：副本路径 recent/<dev>/<name> 的第一段就是发布端。
                                # 以路径为准而不是只信 SNAP_META——后者是内存态，服务重启
                                # 后会丢失，重启前创建的快照会被单端 ack 立刻 settled。
                                # 发布端未上报前不得 settled:true。
                                owner = dev
                                if (len(meta["participants"])
                                        < MAX_SNAP_PARTICIPANTS):
                                    meta["participants"].add(owner)
                                meta["last_active"][owner] = _now()
                                # 复审 R10：acks 只记录参与设备——participants
                                # 有 MAX_SNAP_PARTICIPANTS 上限，acks 原先没有；
                                # 任意 device_id 反复 ack 会让单条快照的字典
                                # 无界增长（收敛判定只读 participants 内的 ack）
                                if device_id in meta["participants"]:
                                    meta["acks"][device_id] = h
                                    meta["last_active"][device_id] = _now()
                                # 复审 rd1：ack 的 device_id 是 Syncthing ID，而
                                # participants/owner 是设备名（recent/<设备>/ 目录段）。
                                # 别名命中时同步记一份设备名 ack（owner 自己的 ack
                                # 才能满足 batch77 的 owner 门槛），否则
                                # acked.get(owner) 恒缺失 → 收敛永不成立、快照永不删除。
                                alias = DEV_NAME_ALIAS.get(device_id)
                                if alias:
                                    if (len(meta["participants"])
                                            < MAX_SNAP_PARTICIPANTS):
                                        meta["participants"].add(alias)
                                    if alias in meta["participants"]:
                                        meta["acks"][alias] = h
                                        meta["last_active"][alias] = _now()
                                elif pub_hint and pub_hint == device_id:
                                    # R23-1：别名缺失（典型为进程重启后）时，
                                    # 发布端持久标记命中才记 owner 的 ack——
                                    # 其他设备的 id 对不上，owner 门槛不被绕过
                                    if owner in meta["participants"]:
                                        meta["acks"][owner] = h
                                        meta["last_active"][owner] = _now()
                                participants = sorted(meta["participants"])
                                acked = {d: meta["acks"][d]
                                         for d in meta["participants"]
                                         if d in meta["acks"]}
                                # 2026-11-18（G18）：超过 7 天没有任何活动的参与者
                                # 视为放弃，不再阻塞快照收敛/清理；发布端始终必须
                                # 亲自 ack，避免未上报就被单端 settled。
                                abandon_cutoff = _now() - float(
                                    os.environ.get("MARKOR_SNAP_ABANDON_DAYS", "7")
                                ) * 86400
                                active = [d for d in participants
                                          if meta["last_active"].get(
                                              d, 0.0) > abandon_cutoff]
                                # 2026-11-18：发布端自己 ack 不得单独触发收敛删除——
                                # 客户端打开/保存后立刻自 ack，若按“参与者均已处理”
                                # 直接删快照，recent 目录会被清空，最近页永远为空。
                                # 至少有另一台设备参与并 ack 时才允许删除。
                                # 注意：同一台设备会同时以“目录名(owner)”和
                                # “Syncthing ID”两种身份出现在 participants 中，
                                # 必须按别名/发布端持久标记归并为同一设备，否则
                                # 发布端自 ack 仍会被误判为“另一台设备”。
                                others = []
                                for d in active:
                                    if d == owner:
                                        continue
                                    if pub_hint and d == pub_hint:
                                        continue
                                    if DEV_NAME_ALIAS.get(d) == owner:
                                        continue
                                    others.append(d)
                                converged = (bool(others)
                                             and owner in active
                                             and acked.get(owner) == snap_hash
                                             and all(acked.get(d) == snap_hash
                                                     for d in active))
                                if converged:
                                    _DELETED_RECENT[recent] = _now()
                        if converged:
                            try:
                                if os.path.isfile(full):
                                    os.unlink(full)
                            except OSError as e:
                                delete_err = str(e)
                            if delete_err is None:
                                with _lock:
                                    ALIAS.pop(recent, None)
                                    _PUBLISHED_LOCAL.pop(recent, None)
                                    SNAP_META.pop(recent, None)
                                    popped = FILES.pop(ckey, None)
                                    if popped is not None:
                                        subs = list(popped.subs)
                                        popped.subs.clear()
                                # R23-1：快照已删除，发布端标记一并清除
                                _set_publisher_marker(recent, "")
                                settled = True
                            else:
                                with _lock:
                                    _DELETED_RECENT.pop(recent, None)
                finally:
                    if acquired and lock_entry is not None:
                        lock_entry.oplock.release()
        if early is not None:
            return self._send(early[0], early[1])
        if busy:
            return self._send(503, {"ok": False, "error": "busy"})
        if delete_err is not None:
            _log(f"[recent] ack settle FAIL {dev}/{name}: {delete_err}")
            return self._send(500, {"ok": False, "error": "delete failed"})
        for s in subs:
            try:
                s.write(("event: closed\ndata: "
                         + json.dumps({"reason": "settled"}, ensure_ascii=False)
                         + "\n\n").encode("utf-8"))
            except Exception:
                pass
        return self._send(200, {
            "ok": True, "settled": settled, "snapshot_hash": snap_hash,
            "participants": participants, "acked": acked,
            "pending": [d for d in participants if acked.get(d) != snap_hash]})

    def _handle_recent_device_rename(self, body):
        """人工重命名设备（只改展示名：写 `.name-override`，不移动目录/文件）。

        2026-11-07 新增。契约：device_id 优先；为空时按 device_name 唯一匹配，
        同名多台 409；new_name 去空白后 1–64、禁控制字符与 "/"；目标不存在 404。
        override 落盘后优先级高于设备自报的 `.name`，后续 heartbeat/publish 不覆盖。
        """
        did = _req_text(body.get("device_id"))
        dev = _safe_path(_req_text(body.get("device_name")))
        rd_id = _req_text(body.get("requester_device_id"))[:MAX_DEV_LEN]
        rd_name = _req_text(body.get("requester_device_name"))[:MAX_DEV_LEN]
        new_name = _valid_rename_name(_req_text(body.get("new_name")))
        if not new_name:
            _log(f"[recent] rename by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=bad-name")
            return self._send(400, {"ok": False, "error": "invalid new_name"})
        if dev and ("/" in dev or len(dev) > MAX_DEV_LEN):
            _log(f"[recent] rename by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=bad-target")
            return self._send(400, {"ok": False, "error": "bad device_name"})
        targets, ambiguous = _recent_device_targets(did, dev)
        if ambiguous:
            _log(f"[recent] rename by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=ambiguous")
            return self._send(409, {"ok": False, "error": "ambiguous device"})
        if not targets:
            _log(f"[recent] rename by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=not-found")
            return self._send(404, {"ok": False, "error": "device not found"})
        target = targets[0]
        id_seg, name_seg = target["id_seg"], target["name_seg"]
        seg = id_seg or name_seg
        old_name = _recent_display_name(seg)
        try:
            if id_seg:
                # 首次改名时确保 id 目录有结构 `.name`（用于旧名字目录认领与
                # 名字反查）；已有 `.name` 时保持不变（自报名是稳定结构名）
                if not _recent_dir_name(id_seg):
                    _write_recent_name_marker(
                        id_seg, name_seg or dev or old_name or id_seg)
                _write_recent_override(id_seg, new_name)
            else:
                # 无 id 的旧名字目录：只写 override（展示名），不移动目录，
                # 也不写 `.name`（否则会被误认成 id 目录）
                _write_recent_override(name_seg, new_name)
        except Exception as e:
            _log(f"[recent] rename FAIL seg={seg}: {e}")
            return self._send(500, {"ok": False, "error": "rename failed"})
        segs = [s for s in (id_seg, name_seg) if s]
        with _lock:
            if id_seg:
                # 发布端 id → 名字别名更新，后续 publish/ack 用新名对齐
                _remember_dev_alias_nolock(id_seg, new_name)
            structural = _recent_dir_name(id_seg) if id_seg else ""
            old_keys = {k for k in (old_name, structural) if k and k != new_name}
            for key, meta in SNAP_META.items():
                if not key.startswith(RECENT_PREFIX):
                    continue
                if key.split("/")[1] not in segs:
                    continue
                # 快照的 owner/参与端名字随设备改名迁移，否则旧快照永远满足
                # 不了收敛条件（参与端名字对不上，副本不会自动删除）
                meta.setdefault("last_active", {})
                for old in old_keys:
                    if old in meta["participants"]:
                        meta["participants"].discard(old)
                        ts = meta["last_active"].pop(old, 0.0)
                        if len(meta["participants"]) < MAX_SNAP_PARTICIPANTS:
                            meta["participants"].add(new_name)
                        meta["last_active"][new_name] = max(
                            ts, meta["last_active"].get(new_name, 0.0))
                    if old in meta["acks"]:
                        meta["acks"][new_name] = meta["acks"].pop(old)
            _DEVICES_CACHE["ts"] = 0.0
        _log(f"[recent] rename by={rd_name or rd_id or '-'} target={seg} "
             f"new={new_name} result=ok")
        return self._send(200, {"ok": True, "device_id": id_seg or "",
                                "device_name": new_name, "renamed_files": 0})

    def _handle_recent_device_delete(self, body):
        """设备被删除时清理其全部副本快照（阶段①唯一的批量删除入口）。

        旧客户端不会调用；新客户端在移除设备时调用。删除范围仍受
        RECENT_ROOT/<dev>/ 白名单限制，绝不触碰 DISK_ROOT。
        2026-11-07：device_id 优先、名字唯一匹配（同名多台 409），只删目标设备
        （含 `.name-override`、别名与客户端登记行），不踢在线连接。
        """
        dev = _safe_path(_req_text(body.get("device_name")))
        did = _req_text(body.get("device_id"))
        rd_id = _req_text(body.get("requester_device_id"))[:MAX_DEV_LEN]
        rd_name = _req_text(body.get("requester_device_name"))[:MAX_DEV_LEN]
        if dev and ("/" in dev or len(dev) > MAX_DEV_LEN or dev.startswith(".")):
            _log(f"[recent] delete by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=bad-target")
            return self._send(400, {"ok": False, "error": "bad device_name"})
        targets, ambiguous = _recent_device_targets(did, dev)
        if ambiguous:
            _log(f"[recent] delete by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=ambiguous")
            return self._send(409, {"ok": False, "error": "ambiguous device"})
        mem_ids, mem_names = set(), set()
        mem_only = False
        if not targets:
            # 从未 publish、只参与过别人快照的设备没有段目录，但注销仍需
            # 清理其服务端记录（否则那些快照永远无法收敛）
            mem_ids, mem_names, mem_ambiguous = _recent_memory_purge(did, dev)
            if mem_ambiguous:
                _log(f"[recent] delete by={rd_name or rd_id or '-'} "
                     f"target={did or dev} result=ambiguous")
                return self._send(409, {"ok": False, "error": "ambiguous device"})
            if not mem_ids and not mem_names:
                _log(f"[recent] delete by={rd_name or rd_id or '-'} "
                     f"target={did or dev} result=not-found")
                return self._send(404, {"ok": False, "error": "device not found"})
            mem_only = True
            target = {"id_seg": "", "name_seg": ""}
        else:
            target = targets[0]
        id_seg, name_seg = target["id_seg"], target["name_seg"]
        if not mem_only and not id_seg and not name_seg:
            _log(f"[recent] delete by={rd_name or rd_id or '-'} "
                 f"target={did or dev} result=not-found")
            return self._send(404, {"ok": False, "error": "device not found"})
        if id_seg and name_seg:
            # 旧名字目录若被多台 id 设备共同认领（同名歧义），只删目标 id 段：
            # 那段旧目录仍属于别的设备，删掉会误伤
            try:
                claimers = [e for e in os.listdir(RECENT_ROOT)
                            if not e.startswith(".")
                            and os.path.isdir(os.path.join(RECENT_ROOT, e))
                            and _recent_dir_name(e) == name_seg]
            except OSError:
                claimers = []
            if len(claimers) > 1:
                name_seg = ""
        segs = [s for s in (id_seg, name_seg) if s]
        # 该设备可被引用的全部名字/ID（id 段、自报名、人工 override、旧名字段）
        purged = set(segs)
        for s in segs:
            for alias in (_recent_dir_name(s), _recent_override(s)):
                if alias:
                    purged.add(alias)
        purge_ids = {id_seg} if id_seg else set()
        if mem_only:
            # 没有段目录：只清理内存记录，不碰任何目录
            purged.update(mem_ids)
            purged.update(mem_names)
            purge_ids.update(mem_ids)
        # 同名设备共用名字时（无法区分的历史歧义），名字不能从其它设备的
        # 参与/登记集合里清掉——只清理目标 id 与独占名字，保证“只删目标”
        other_names = set()
        try:
            for e in os.listdir(RECENT_ROOT):
                if (e == id_seg or e.startswith(".")
                        or not os.path.isdir(os.path.join(RECENT_ROOT, e))):
                    continue
                nm = _recent_dir_name(e)
                if nm:
                    other_names.add(nm)
                    other_names.add(_recent_display_name(e))
        except OSError:
            pass
        if mem_only:
            purge_names = set(mem_names) - other_names
        else:
            purge_names = {p for p in purged if p not in other_names}
        if not id_seg:
            # 按旧名字段删除时，真实 device_id 只存在于别名/登记行（段目录按
            # 名字存放，id 没有自己的目录）。不反查清理会让 /clients 仍拼出
            # 这台“已删除”的设备，其登记行也继续留住 LAST_SEEN。
            with _lock:
                alias_ids = {d for d, dn in list(DEV_NAME_ALIAS.items())
                             if dn in purge_names}
                for key, rec in list(CLIENT_REPORTS.items()):
                    if (key.startswith("id:") and isinstance(rec, dict)
                            and rec.get("device_name") in purge_names):
                        alias_ids.add(key[3:])
            # 有自己段目录的 id 是独立设备，按名字删除不得连带清理
            alias_ids = {d for d in alias_ids
                         if not os.path.isdir(os.path.join(RECENT_ROOT, d))}
            purged.update(alias_ids)
            purge_ids.update(alias_ids)
        snap_purge = purge_ids | purge_names
        # 复审 R9：注销设备从**其它**副本的参与/上报集合中移除。它不会再 ack，
        # 残留会让那些快照永久满足不了 all(...) 收敛条件（副本无界增长）。
        # 必须先于目录存在性检查执行——设备可能只参与过别人的快照、从未
        # publish 出自己的副本（此时 recent/<dev>/ 根本不存在）
        with _lock:
            for meta in SNAP_META.values():
                meta.setdefault("last_active", {})
                meta["participants"].difference_update(snap_purge)
                for d in snap_purge:
                    meta["acks"].pop(d, None)
                    meta["last_active"].pop(d, None)
            # 设备名别名与发布端 id 映射：带 id 只删该 id 的映射，避免连带
            # 另一台同名设备；仅名字目标才按名字清理（唯一匹配已由上文保证）
            for d, dn in list(DEV_NAME_ALIAS.items()):
                if d in purged or (not id_seg and dn in purge_names):
                    DEV_NAME_ALIAS.pop(d, None)
            # 客户端登记行（该 id 与该名字的行）；同名仍被其它设备使用时保留
            for a in purged:
                CLIENT_REPORTS.pop("id:" + a, None)
            for a in purge_names:
                key = "name:" + a
                if key in CLIENT_REPORTS:
                    CLIENT_REPORTS.pop(key, None)
            still_named = {r.get("device_name") for r in CLIENT_REPORTS.values()
                           if isinstance(r, dict)}
            for a in purge_names | purge_ids:
                if a not in still_named:
                    LAST_SEEN.pop(a, None)
                    _PLATFORM_CACHE.pop(a, None)
            _DEVICES_CACHE["ts"] = 0.0
        deleted = 0
        failed = []
        with _recent_io_lock:
            for seg in segs:
                dev_dir = os.path.join(RECENT_ROOT, seg)
                if not os.path.isdir(dev_dir):
                    continue
                try:
                    names = [n for n in os.listdir(dev_dir)
                             if not n.startswith(".") and ".tmp." not in n]
                except OSError as e:
                    # R21-4：目录读不了时原先静默返回 deleted=0，调用方误以为“没有副本”
                    names = []
                    _log(f"[recent] device delete listdir FAIL {seg}: {e}")
                seg_failed_names = []
                for name in names:
                    recent = RECENT_PREFIX + seg + "/" + name
                    full = os.path.join(dev_dir, name)
                    with _lock:
                        entry = FILES.get((VAULT_ID, recent))
                        _DELETED_RECENT[recent] = _now()
                    acquired = False
                    if entry is not None:
                        acquired = entry.oplock.acquire(timeout=OPLOCK_WAIT_SEC)
                        if not acquired:
                            with _lock:
                                _DELETED_RECENT.pop(recent, None)
                            failed.append(name)
                            seg_failed_names.append(name)
                            continue
                    try:
                        if os.path.isfile(full):
                            os.unlink(full)
                        with _lock:
                            ALIAS.pop(recent, None)
                            _PUBLISHED_LOCAL.pop(recent, None)
                            SNAP_META.pop(recent, None)
                            # 只清服务端记录：不下发 closed/删除事件，也不清
                            # 订阅（不踢在线连接）；客户端后续 op/save 按既有
                            # 墓碑逻辑得到 410，本地文件完全不动
                            FILES.pop((VAULT_ID, recent), None)
                        deleted += 1
                    except OSError as e:
                        with _lock:
                            _DELETED_RECENT.pop(recent, None)
                        failed.append(name)
                        seg_failed_names.append(name)
                        _log(f"[recent] device delete FAIL {seg}/{name}: {e}")
                    finally:
                        if acquired:
                            entry.oplock.release()
                # 复审 R7：隐藏的外部源标记不属于副本文件（list 不列出），但不删掉
                # 会让 rmdir 因 ENOTEMPTY 失败；GC 只清理“仅剩 .platform”的目录，
                # .platform 已在此删除 → 旧标记目录永久残留（最近页出现幽灵设备）
                # R24-1：本轮若有副本删除失败（oplock 忙/OSError），快照仍在，其
                # 发布端与外部源标记必须保留——否则重启后该快照的 owner ack 永远
                # 满足不了 batch77 门槛，既不收敛也不会再被 ack 清理（与 R23-1 同型）。
                # 标记名按 basename 哈希，无法从目录项反查，故失败时按成功删除的
                # 文件名逐个反算；全部成功时沿用整目录清扫（覆盖无主隐藏残留）。
                try:
                    if seg_failed_names:
                        skip = set(seg_failed_names)
                        for n in names:
                            if n in skip:
                                continue
                            recent = RECENT_PREFIX + seg + "/" + n
                            for marker in (_external_origin_marker(recent),
                                           _publisher_marker(recent)):
                                try:
                                    os.unlink(marker)
                                except OSError:
                                    pass
                    else:
                        for n in os.listdir(dev_dir):
                            if (n.startswith(".origin-") or n.startswith(".pub-")) \
                                    and n.endswith(".json"):
                                try:
                                    os.unlink(os.path.join(dev_dir, n))
                                except OSError:
                                    pass
                            elif ".tmp." in n:
                                # 原子写残留的临时文件同样属于本设备段，清掉
                                # 后才能 rmdir，避免“设备已删却留空壳目录”
                                try:
                                    os.unlink(os.path.join(dev_dir, n))
                                except OSError:
                                    pass
                except OSError:
                    pass
                # .platform/.name/.name-override 与空设备目录一并清理
                for meta in (".platform", RECENT_NAME_MARKER,
                             RECENT_OVERRIDE_MARKER):
                    try:
                        os.unlink(os.path.join(dev_dir, meta))
                    except OSError:
                        pass
                try:
                    os.rmdir(dev_dir)
                except OSError as e:
                    _log(f"[recent] device delete rmdir left {seg}: {e}")
        _log(f"[recent] delete by={rd_name or rd_id or '-'} "
             f"target={id_seg or name_seg} files={deleted} "
             f"failed={len(failed)} "
             f"result={'partial' if failed else 'ok'}")
        return self._send(200, {"ok": True, "deleted_files": deleted,
                                "deleted": deleted, "failed": failed})

    def _handle_writer_claim(self, body):
        """显式申请写权（协议见 docs/design-2026-11-05-writer-token.md）。"""
        path = _safe_path(_req_raw(body.get("path")))
        device_id = _req_text(body.get("device_id"))
        device_name = _req_text(body.get("device_name")) or device_id
        if (not path or not _valid_device(device_id)
                or not _valid_device(device_name)):
            return self._send(400, {"ok": False, "error": "path and device_id required"})
        if not _recent_write_valid(path):
            return self._send(400, {"ok": False, "error": "bad path"})
        path = _resolve_session_path(path)
        if path is None:
            return self._send(409, {"ok": False, "error": "session conflict"})
        key, entry = _entry_get_or_create(path)
        if entry is None:
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            return self._send(415, {"ok": False, "error": "not utf-8"})
        force = body.get("force") is True
        writer_event = None
        busy = None
        with _lock:
            if FILES.get(key) is not entry:
                retry = True
            else:
                retry = False
                _remember_dev_alias_nolock(device_id, device_name)
                _touch_participant_nolock(entry, device_id, device_name)
                if entry.writer_device_id is None:
                    writer_event = _set_writer_nolock(entry, device_id,
                                                      device_name, "claim")
                elif entry.writer_device_id != device_id:
                    if not _participant_online_nolock(entry,
                                                      entry.writer_device_id):
                        writer_event = _set_writer_nolock(entry, device_id,
                                                          device_name, "offline")
                    elif force:
                        writer_event = _set_writer_nolock(entry, device_id,
                                                          device_name, "force")
                    else:
                        busy = {"ok": False, "error": "writer busy",
                                "writer_device_id": entry.writer_device_id,
                                "writer_device_name": entry.writer_device_name,
                                "writer_rev": entry.writer_rev,
                                "writer_since": int(entry.writer_since),
                                "writer_changed": False}
                fields = _writer_fields_nolock(entry, writer_event is not None)
        if retry:
            return self._send(409, {"ok": False, "error": "retry later"})
        if busy is not None:
            return self._send(409, busy)
        if writer_event is not None:
            _broadcast(entry, writer_event)
            _log(f"[writer] path={path} dev={device_id} "
                 f"reason={writer_event['reason']} rev={writer_event['writer_rev']}")
        return self._send(200, {"ok": True, **fields})

    def _handle_writer_release(self, body):
        """主动释放写权；非当前 writer 调用是幂等空操作。"""
        path = _safe_path(_req_raw(body.get("path")))
        device_id = _req_text(body.get("device_id"))
        if not path or not _valid_device(device_id):
            return self._send(400, {"ok": False, "error": "path and device_id required"})
        if not _recent_write_valid(path):
            return self._send(400, {"ok": False, "error": "bad path"})
        path = _resolve_session_path(path)
        if path is None:
            return self._send(409, {"ok": False, "error": "session conflict"})
        key, entry = _entry_get_or_create(path)
        if entry is None:
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            return self._send(415, {"ok": False, "error": "not utf-8"})
        writer_event = None
        retry = False
        with _lock:
            if FILES.get(key) is not entry:
                retry = True
            else:
                _touch_participant_nolock(entry, device_id)
                if entry.writer_device_id == device_id:
                    nxt = _pick_writer_nolock(entry, exclude=device_id)
                    writer_event = _set_writer_nolock(
                        entry, nxt,
                        _participant_name_nolock(entry, nxt) if nxt else "",
                        "release")
                fields = _writer_fields_nolock(entry, writer_event is not None)
        if retry:
            return self._send(409, {"ok": False, "error": "retry later"})
        if writer_event is not None:
            _broadcast(entry, writer_event)
            _log(f"[writer] path={path} dev={device_id} reason=release "
                 f"rev={writer_event['writer_rev']}")
        return self._send(200, {"ok": True, **fields})

    def _handle_open(self, body):
        # SV-T9：必填字段按字符串校验，"path": null 不得变成合法路径 "None"
        path = _safe_path(_req_raw(body.get("path")))
        device_id = _req_text(body.get("device_id"))
        device_name = _req_text(body.get("device_name")) or device_id
        # SV-AE1：设备标识/名称有界（此前 open 端点完全未校验）
        if (not path or not _valid_device(device_id)
                or not _valid_device(device_name)):
            return self._send(400, {"ok": False, "error": "path and device_id required"})
        # SRV37-3：副本镜像只允许 recent/<设备>/<文件名> 两层
        if not _recent_write_valid(path):
            return self._send(400, {"ok": False, "error": "bad path"})
        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧，要求重新 open 拿基线
            return self._send(409, {"ok": False, "error": "session conflict"})
        # 复审 rd1：身份别名与“有无快照”无关，absent 的 open 也要建立
        # device_id→设备名 映射——否则发布端稍后的 ack 无法与 recent/<设备>/
        # 对上，recent 快照永远不会收敛删除。
        with _lock:
            _remember_dev_alias_nolock(device_id, device_name)
            entry0 = FILES.get((VAULT_ID, path.replace("\\", "/")))
            tomb0 = _recent_tombstoned_nolock(path)
        # 复审 rd1：读端点不得为“从未有快照”的键建出空 entry——rev==0 的空
        # 会话会被 publish 误当成“他端旧副本”而回退发布内容（数据丢失）
        # 复审 R2：删除墓碑优先于 absent（否则 410 被降级成 404）
        if entry0 is None and not tomb0 and not _disk_snapshot_exists(path):
            return self._send(404, _absent_fields(path))
        key, entry = _entry_get_or_create(path)
        if entry is None:
            # SV-Q4：副本处于删除墓碑期，拒绝重建已删 entry
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            # SV-V5：磁盘文件存在但不是合法 UTF-8，拒绝建空 entry
            return self._send(415, {"ok": False, "error": "not utf-8"})
        # proto-2026-11-05：没有快照的键返回 state=absent（404，不含 content），
        # 不再用空 content 表达「服务器没有这份文件」；客户端据此绝不可删盘/移盘
        if not _has_snapshot(path, entry):
            return self._send(404, _absent_fields(path))
        # 复审 R12：open 与 SSE hello 同型——从 _entry_get_or_create 返回到
        # 这里取快照之间，entry 可能被 GC/close 换掉（open 不订阅，GC 的
        # rev==0 空闲回收不等待它）。在孤儿对象上申领 writer / 登记参与者
        # 会让本端拿到“writer:true”的假令牌（真实 entry 已由另一台设备申领），
        # 且 peers/participants 落在已回收对象上。锁内复核身份，失效则重新
        # 解析（最多 5 次，与 SSE 建连口径一致）。
        for _attempt in range(5):
            with _lock:
                if FILES.get(key) is not entry:
                    stale = True
                else:
                    stale = False
                    # SRV36-12：与 /open 返回同临界区复核删除墓碑
                    gone = _recent_tombstoned_nolock(path)
                    writer_event = None
                    if not gone:
                        # writer token：首个 open 隐式申请；已有 writer 且已掉线则移交
                        _touch_participant_nolock(entry, device_id, device_name)
                        if entry.writer_device_id is None:
                            writer_event = _set_writer_nolock(
                                entry, device_id, device_name, "claim")
                        elif (entry.writer_device_id != device_id
                                and not _participant_online_nolock(
                                    entry, entry.writer_device_id)):
                            writer_event = _set_writer_nolock(
                                entry, device_id, device_name, "offline")
                        writer_fields = _writer_fields_nolock(
                            entry, writer_event is not None)
                    peers = _peers_list(entry, device_id)
                    content = _normalize_content(entry.content)   # R16-F4
                    rev = entry.rev
                    # 阶段①：登记参与设备——快照删除只依据“所有参与设备上报的
                    # 本地内容 hash == 快照 hash”，与本端是否仍连接无关
                    # 复审 R4：墓碑复核命中时不得登记——delete 可能已 pop 掉
                    # SNAP_META，此处再建会把“已删除快照”的参与设备带到下一次
                    # publish 的同名副本，ack 永远收敛不了（RECENT_ROOT 无界增长）
                    if not gone:
                        _mark_participant_nolock(path, device_id)
            if not stale:
                break
            key, entry = _entry_get_or_create(path)
            if entry is None:
                return self._send(410, {"ok": False, "error": "deleted"})
            if entry == "undecodable":
                return self._send(415, {"ok": False, "error": "not utf-8"})
            if not _has_snapshot(path, entry):
                return self._send(404, _absent_fields(path))
        else:
            return self._send(503, {"ok": False, "error": "session busy"})
        if gone:
            return self._send(410, {"ok": False, "error": "deleted"})
        if writer_event is not None:
            _broadcast(entry, writer_event)
            _log(f"[writer] path={path} dev={device_id} "
                 f"reason={writer_event['reason']} "
                 f"rev={writer_event['writer_rev']}")
        # 复审 N7：与 SSE hello 协议对齐补 rev，走 open 拉初始内容的客户端
        # 可据此对齐版本基线
        # 阶段①：content_hash 作为“同一份文件”的版本标识（路径 + rev + hash），
        # 与“设备已处理”的 hash 上报分开使用；旧客户端忽略新增字段即可
        return self._send(200, {"ok": True, "content": content,
                                "peers": peers, "rev": rev,
                                **_state_fields(content),
                                **writer_fields})

    def _handle_op(self, body):
        """行内文本替换（set）或行结构变更（struct）。"""
        # SV-T9：必填字段按字符串校验，"path": null 不得变成合法路径 "None"
        path = _safe_path(_req_raw(body.get("path")))
        device_id = _req_text(body.get("device_id"))
        if _req_text(body.get("op")) == "struct":
            return self._handle_struct(path, device_id, body)
        try:
            row = int(body.get("row", -1))
            # SV-S10：null 不得变成字面量 "None" 写进权威内容
            text = _as_text(body.get("text"))
            if text is None:
                # SRV36-9：dict/list 等容器不得变成 Python repr 写进文件
                raise ValueError("bad text")
        except (ValueError, TypeError, OverflowError):
            # SV-BK1（第三十二轮复查）：json.loads 接受 Infinity/NaN，int(inf)
            # 抛 OverflowError，原先未捕获会让异常穿透 do_POST 并断连（客户端
            # 收到连接重置而不是 400）
            return self._send(400, {"ok": False, "error": "bad row/text"})
        # P6：row 必须有上限——伪造的超大行号会让下面的 while 循环无限补空行，
        # 直接吃光服务器内存
        if not path or row < 0 or row > 2_000_000:
            return self._send(400, {"ok": False, "error": "path and row required"})
        # SV-AE1：device_id 会写入广播帧与 peer 列表，必须有界
        if not _valid_device(device_id):
            return self._send(400, {"ok": False, "error": "device_id required"})
        # SRV37-3：副本镜像只允许 recent/<设备>/<文件名> 两层
        if not _recent_write_valid(path):
            return self._send(400, {"ok": False, "error": "bad path"})

        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧，要求重新 open/hello
            return self._send(409, {"ok": False, "error": "session conflict"})
        key, entry = _entry_get_or_create(path)
        if entry is None:
            # SV-Q4：副本处于删除墓碑期，拒绝重建已删 entry
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            # SV-V5：磁盘文件存在但不是合法 UTF-8，拒绝建空 entry
            return self._send(415, {"ok": False, "error": "not utf-8"})
        # SV-H9：行内容限长，防单条 op 吃光内存
        if len(text) > 1_000_000:
            return self._send(413, {"ok": False, "error": "text too large"})

        # SV-C2：oplock 串行化"改状态→广播"整段，保证广播顺序与 rev 一致；
        # 全局锁内只做状态变更，慢客户端的 socket 写在全局锁外执行
        # SV-H7/复审 N2：身份校验（FILES.get(key) is entry）必须与状态变更在
        # 同一临界区——校验通过后到进锁之间 entry 可能被 close/GC 删除，写入
        # 孤儿对象会静默丢编辑；失效则用 _entry_revalidate 取当前 entry 重试
        attempts = 0
        while True:
            bad_row = False
            too_large = False
            with entry.oplock:
                op_json = None
                with _lock:
                    stale = FILES.get(key) is not entry
                    if not stale:
                        _mark_participant_nolock(path, device_id)   # 阶段①
                        _touch_participant_nolock(entry, device_id)  # writer token
                        lines = entry.content.split("\n")
                        # SV-H9：行号填充上限——伪造的远超实际行数的 row 不得触发大量补空行
                        if row > len(lines) + 1000:
                            # 复审 R3：锁内只置错误标志，socket 写在锁外发送
                            bad_row = True
                        else:
                            # 复审 R8：ts 在锁内取，避免重试后仍使用循环外的过期时间
                            ts = _now()
                            # R16-F4：只有第 0 行的前导 U+FEFF 属于“文档 BOM”，
                            # 必须剥掉；行中/其它行的 U+FEFF 是合法字符，不能动
                            if row == 0:
                                text = _normalize_content(text)
                            while row >= len(lines):
                                lines.append("")
                            lines[row] = text   # 直接替换整行（客户端发完整行内容）
                            # 兜底：整篇结果同样只允许无前导 BOM 的规范形态
                            new_content = _normalize_content("\n".join(lines))
                            # SV-T10：文件级总量上限——单条 op 有上限，但反复 op
                            # 会在已有内容上累加，内存与每条广播帧无界膨胀
                            # SV-U10：按字节口径比较（与请求体上限同单位）
                            if len(new_content.encode("utf-8")) > MAX_FILE_BYTES:
                                too_large = True
                            elif new_content == entry.content:
                                # SV-U6：内容无变化的 op 不抬 rev、不广播
                                # （否则活动时间戳与无意义帧会污染新旧判定）
                                pass
                            else:
                                entry.content = new_content
                                entry.mtime = ts
                                entry.content_mtime = ts   # SV-U6
                                entry.rev += 1
                                op_json = {"type": "op", "row": row, "text": text,
                                           "device_id": device_id, "ts": int(ts),
                                           "rev": entry.rev,
                                           # 附带整篇权威内容：客户端据此整篇替换，规避逐行替换
                                           # 在部分 Qt 版本上"内容已改但界面不重绘"的问题
                                           "content": new_content}
                if op_json is not None:
                    _broadcast(entry, op_json)
            if bad_row:
                # 复审 R3：错误响应在锁外发送
                return self._send(400, {"ok": False, "error": "row out of range"})
            if too_large:
                # SV-T10：变更后的文件超过总量上限
                return self._send(413, {"ok": False, "error": "file too large"})
            if not stale:
                break
            attempts += 1
            if attempts >= 5:
                # 复审 R8：重试上限，避免持续失效造成的活锁
                return self._send(409, {"ok": False, "error": "retry later"})
            entry = _entry_revalidate(key, entry)   # SV-H7：换当前 entry 重试
            if entry is None:
                # SV-Q4：副本处于删除墓碑期，拒绝重建
                return self._send(410, {"ok": False, "error": "deleted"})
            if entry == "undecodable":
                # SV-V5：存在但不可解码，拒绝重建空 entry
                return self._send(415, {"ok": False, "error": "not utf-8"})

        with _lock:
            peers = _peers_list(entry, device_id)
            writer_fields = _writer_fields_nolock(entry, False)
        return self._send(200, {"ok": True, "row": row, "peers": peers,
                                **writer_fields})

    def _handle_struct(self, path, device_id, body):
        """行结构变更：从 start 行起删除 delete 行，再插入 insert 行。"""
        if not path:
            return self._send(400, {"ok": False, "error": "path required"})
        # SV-AE1：device_id 会写入广播帧，必须有界
        if not _valid_device(device_id):
            return self._send(400, {"ok": False, "error": "device_id required"})
        try:
            start = int(body.get("start", 0))
            delete = int(body.get("delete", 0))
            insert_raw = body.get("insert") or []
            # SV-Q5：insert 必须是列表——字符串会被逐字符拆行（"ab"→["a","b"]）、
            # dict 逐键拆行，畸形请求会把垃圾行写入权威内容并广播全端
            if not isinstance(insert_raw, list):
                return self._send(400, {"ok": False, "error": "bad struct"})
            # SV-S10：数组元素为 null 时不得插入字面量 "None"
            insert = [_as_text(x) for x in insert_raw]
            # SRV36-9：容器元素返回 None，按 400 拒绝而不是写成 Python repr
            if any(x is None for x in insert):
                return self._send(400, {"ok": False, "error": "bad struct"})
        except (ValueError, TypeError, OverflowError):
            # SV-BK1：同 /op，struct 的 start/delete 为 Infinity 时不得断连
            return self._send(400, {"ok": False, "error": "bad struct"})
        if start < 0 or delete < 0:
            return self._send(400, {"ok": False, "error": "bad struct"})
        # SRV37-3：副本镜像只允许 recent/<设备>/<文件名> 两层
        if not _recent_write_valid(path):
            return self._send(400, {"ok": False, "error": "bad path"})

        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧，要求重新 open/hello
            return self._send(409, {"ok": False, "error": "session conflict"})
        key, entry = _entry_get_or_create(path)
        if entry is None:
            # SV-Q4：副本处于删除墓碑期，拒绝重建已删 entry
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            # SV-V5：磁盘文件存在但不是合法 UTF-8，拒绝建空 entry
            return self._send(415, {"ok": False, "error": "not utf-8"})
        # SV-H9：insert 行数与总长度限长，防结构变更吃光内存
        if len(insert) > 100_000 or sum(len(x) for x in insert) > 8_000_000:
            return self._send(413, {"ok": False, "error": "insert too large"})
        # 同 op：oplock 保证快照顺序，广播在全局锁外（SV-C2）；
        # 身份校验与变更同临界区，失效重试（SV-H7/复审 N2）
        attempts = 0
        while True:
            too_large = False
            with entry.oplock:
                struct_json = None
                with _lock:
                    stale = FILES.get(key) is not entry
                    if not stale:
                        _mark_participant_nolock(path, device_id)   # 阶段①
                        _touch_participant_nolock(entry, device_id)  # writer token
                        lines = entry.content.split("\n")
                        # SRV40-1：裁剪只作用于本次尝试的局部变量。原先把 min() 结果写回
                        # start/delete，失效重试拿到行数不同的新 entry 时会沿用上一次的
                        # 裁剪值，导致结构变更落在错误的行（广播帧的行号也随之错误）
                        apply_start = min(start, len(lines))
                        apply_delete = min(delete, len(lines) - apply_start)
                        # R16-F4：插入到文档开头时，首行的前导 U+FEFF 是文档
                        # BOM，剥掉；其它位置（含插入行内部）原样保留
                        apply_insert = list(insert)
                        if apply_start == 0 and apply_insert:
                            apply_insert[0] = _normalize_content(apply_insert[0])
                        lines[apply_start:apply_start + apply_delete] = apply_insert
                        new_content = _normalize_content("\n".join(lines))
                        # SV-T10：变更后的文件总量上限（反复 struct 可在已有内容上累加）
                        # SV-U10：按字节口径比较（与请求体上限同单位）
                        if len(new_content.encode("utf-8")) > MAX_FILE_BYTES:
                            too_large = True
                        elif new_content == entry.content:
                            # SV-U6：内容无变化的 struct 不抬 rev、不广播
                            pass
                        else:
                            entry.content = new_content
                            # 复审 R8：ts 在锁内取，避免重试后使用过期时间戳
                            ts = _now()
                            entry.mtime = ts
                            entry.content_mtime = ts   # SV-U6
                            entry.rev += 1
                            struct_json = {"type": "struct", "start": apply_start,
                                           "delete": apply_delete,
                                           "insert": apply_insert,
                                           "content": new_content,
                                           "device_id": device_id, "ts": int(ts),
                                           "rev": entry.rev}
                if struct_json is not None:
                    _broadcast(entry, struct_json)
            if too_large:
                # SV-T10：变更后的文件超过总量上限
                return self._send(413, {"ok": False, "error": "file too large"})
            if not stale:
                break
            attempts += 1
            if attempts >= 5:
                # 复审 R8：重试上限，避免活锁
                return self._send(409, {"ok": False, "error": "retry later"})
            entry = _entry_revalidate(key, entry)   # SV-H7
            if entry is None:
                # SV-Q4：副本处于删除墓碑期，拒绝重建
                return self._send(410, {"ok": False, "error": "deleted"})
            if entry == "undecodable":
                # SV-V5：存在但不可解码，拒绝重建空 entry
                return self._send(415, {"ok": False, "error": "not utf-8"})
        with _lock:
            peers = _peers_list(entry, device_id)
            writer_fields = _writer_fields_nolock(entry, False)
        return self._send(200, {"ok": True, "peers": peers, **writer_fields})

    def _handle_save(self, body):
        """客户端主动请求落盘（保存按钮）。

        P4：save 也必须递增 rev 并广播——否则其它端在自己下次输入前
        永远看不到保存进来的内容（典型场景：一端离线编辑后保存）。
        """
        # SV-T9：必填字段按字符串校验，"path": null 不得变成合法路径 "None"
        path = _safe_path(_req_raw(body.get("path")))
        # SV-S10：null 不得以字面量 "None" 整篇写进文件
        # SRV36-9：dict/list 等内容返回 None，按 400 拒绝
        full_content = _as_text(body.get("content"))
        if full_content is None:
            return self._send(400, {"ok": False, "error": "bad content"})
        full_content = _normalize_content(full_content)   # R16-F4：保存内容进入规范形态
        device_id = _req_text(body.get("device_id"))
        if not path:
            return self._send(400, {"ok": False, "error": "path required"})
        # SV-AE1：device_id 会写入广播帧与 peer 列表，必须有界
        if not _valid_device(device_id):
            return self._send(400, {"ok": False, "error": "device_id required"})
        # SV-T10：整篇保存同样受文件级总量上限约束（请求体 16MB 已限，此处同口径）
        # SV-U10：按字节口径比较（与请求体上限同单位）
        if len(full_content.encode("utf-8")) > MAX_FILE_BYTES:
            return self._send(413, {"ok": False, "error": "file too large"})
        # SRV37-3：副本镜像只允许 recent/<设备>/<文件名> 两层
        if not _recent_write_valid(path):
            return self._send(400, {"ok": False, "error": "bad path"})
        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：副本与源会话内容各自更新且无法判定新旧，要求重新 open/hello
            return self._send(409, {"ok": False, "error": "session conflict"})
        key, entry = _entry_get_or_create(path)
        if entry is None:
            # SV-Q4：副本处于删除墓碑期，拒绝重建已删 entry
            return self._send(410, {"ok": False, "error": "deleted"})
        if entry == "undecodable":
            # SV-V5：磁盘文件存在但不是合法 UTF-8，拒绝建空 entry
            return self._send(415, {"ok": False, "error": "not utf-8"})
        # 同 op：oplock 保证顺序，广播与落盘均在全局锁外（SV-C2）；
        # 身份校验与变更同临界区，失效重试（SV-H7/复审 N2）
        # SV-Q7：与 publish 对齐接入 persisted 语义——主落盘与两处副本刷新
        # 失败不得仍回报 ok（否则客户端无法感知保存未持久化）
        persisted = True
        attempts = 0
        while True:
            # 复审 R4：显式 /save 也必须能把 absent 推成 empty——外部键与无
            # 磁盘快照的键首次保存空内容时 entry.rev==0 且内容未变，原先不抬
            # rev，GET/open 仍报 absent，与“empty = 有快照且 0 字节”矛盾，
            # 多端也无法就空文件建立快照。快照判定含 stat，放在锁外。
            had_snapshot = _has_snapshot(path, entry)
            with entry.oplock:
                save_json = None
                with _lock:
                    stale = FILES.get(key) is not entry
                    if not stale:
                        _mark_participant_nolock(path, device_id)   # 阶段①
                        _touch_participant_nolock(entry, device_id)  # writer token
                        rev = entry.rev
                        if entry.content != full_content or not had_snapshot:
                            # SV-U6：内容真正变化才抬 rev/广播/刷新 content_mtime；
                            # 无变化保存只是活动时间戳更新，不污染新旧判定
                            entry.content = full_content
                            entry.mtime = _now()
                            entry.content_mtime = entry.mtime
                            entry.rev += 1
                            rev = entry.rev
                            save_json = {"type": "struct", "start": 0,
                                         "delete": -1, "insert": [],
                                         "content": entry.content,
                                         "device_id": device_id,
                                         "ts": int(entry.mtime),
                                         "rev": entry.rev}
                # SV-BL3（第三十三轮复查）：内容与内存一致但 entry 仍有未落盘
                # 修改（rev>0，例如先 op 后 save）时也必须落盘——否则 save
                # 回报 persisted=true 而磁盘仍是旧内容，GC/close 前崩溃即丢失
                if save_json is not None or (not stale and rev > 0):
                    if save_json is not None:
                        _broadcast(entry, save_json)
                    # 复审 R6：复核 rev 与写盘收进同一 oplock 临界区——原先是
                    # 两个分离的临界区，复核后到写盘之间到达的 op 会被旧快照覆盖
                    with _lock:
                        current = FILES.get(key) is entry and entry.rev == rev
                    if current and _is_recent_path(path):
                        # 阶段①：服务端零写同步根——源路径只更新内存并广播，
                        # 内容由各端本地保存、Syncthing 传播；仅 recent 副本落盘
                        if not _flush_recent(path, full_content):
                            persisted = False   # SV-Q7：不吞副本落盘失败
            if not stale:
                break
            attempts += 1
            if attempts >= 5:
                # 复审 R8：重试上限，避免活锁
                return self._send(409, {"ok": False, "error": "retry later"})
            entry = _entry_revalidate(key, entry)   # SV-H7
            if entry is None:
                # SV-Q4：副本处于删除墓碑期，拒绝重建
                return self._send(410, {"ok": False, "error": "deleted"})
            if entry == "undecodable":
                # SV-V5：存在但不可解码，拒绝重建空 entry
                return self._send(415, {"ok": False, "error": "not utf-8"})
        # 源文件保存：同步刷新它自己的服务器副本（最近页备份保持最新）
        # SRV34-1：副本 rev>0 且内容不同于"上次 publish 的基线摘要"时，说明
        # 副本会话里已有他端编辑——此时不得用源内容静默覆盖（不广播覆盖帧）。
        # 判定口径与 publish 的 copy_foreign 一致（摘要基线），不跨时钟比较 mtime。
        echo_jobs = []
        for rp in _recent_copies_of(path):
            with _lock:
                rentry = FILES.get((VAULT_ID, rp))
            if rentry is None:
                # SV-S3：无内存会话的副本刷新原先裸写盘，delete 的 unlink 可落在
                # 写入之前 → 已删副本被写回。改为与 delete 共享 _recent_io_lock
                # 并在同一临界区内查墓碑；期间若建出了会话则交给下方 oplock 分支
                with _recent_io_lock:
                    with _lock:
                        tomb = _recent_tombstoned_nolock(rp)
                        rentry = None if tomb else FILES.get((VAULT_ID, rp))
                        baseline = _PUBLISHED_LOCAL.get(rp)
                    if tomb:
                        continue
                    if rentry is None:
                        # 无内存会话：只保证副本磁盘最新。SRV35-1：覆盖前先
                        # 在 _recent_io_lock 内读取副本磁盘内容（_load_from_disk
                        # 已带既有大小上限），与上次 publish 的基线摘要比较；
                        # 偏离基线说明副本已被他端（远程会话）改过，不得用源
                        # 内容静默覆盖，也不更新基线。基线未知或内容仍等于
                        # 基线时保持原有镜像刷新
                        snap = _load_from_disk(rp)
                        # SRV36-3：基线未知（服务重启）时无法判定副本是否被他端
                        # 改过，与 publish 的 SV-BL2 同口径——跳过副本刷新，不得
                        # 用源内容静默覆盖
                        if baseline is None:
                            continue
                        if snap is None or _content_digest(snap) != baseline:
                            continue
                        if _flush_recent(rp, full_content):
                            # SRV36-4：写盘期间并发 GET/open 可能以旧磁盘内容建出
                            # rev==0 的副本 entry；不校正会与磁盘永久分叉，随后
                            # 该端基于旧基线的 op 会把更新内容覆盖回旧值
                            with _lock:
                                appeared = FILES.get((VAULT_ID, rp))
                            if appeared is not None:
                                # 非阻塞取锁：此处仍持 _recent_io_lock，不能因他端
                                # 正在 op 而阻塞 publish/delete；取不到则跳过校正
                                if appeared.oplock.acquire(blocking=False):
                                    try:
                                        with _lock:
                                            if (FILES.get((VAULT_ID, rp)) is appeared
                                                    and appeared.rev == 0
                                                    and appeared.content != full_content):
                                                appeared.content = full_content
                                                appeared.mtime = _now()
                                                appeared.content_mtime = appeared.mtime
                                                # SRV37-2：rev==0 的副本 entry 可能已有
                                                # SSE 订阅者（GET/open 建 entry 后订阅）。
                                                # 静默改内存会让订阅端保留旧基线，随后
                                                # 该端的 op 用旧行号覆盖刚保存的内容；
                                                # 此处抬 rev，广播留到 _recent_io_lock
                                                # 释放后执行（慢客户端不得阻塞 publish）
                                                appeared.rev += 1
                                                echo_jobs.append((
                                                    (VAULT_ID, rp), appeared, {
                                                    "type": "struct", "start": 0,
                                                    "delete": -1, "insert": [],
                                                    "content": full_content,
                                                    "device_id": device_id,
                                                    "ts": int(appeared.mtime),
                                                    "rev": appeared.rev}))
                                    finally:
                                        appeared.oplock.release()
                            # SV-U1：save 也是副本的"服务端写入回声"，必须同步
                            # 基线，否则下次 publish 会把这份最新内容误判成他端
                            # 新编辑而回滚源文件
                            with _lock:
                                _remember_published(rp, full_content)
                        else:
                            persisted = False   # SV-Q7
                        continue
            # 有内存会话：持 rentry.oplock 复核身份后写盘。delete 现在也持同一把
            # oplock 做 unlink/pop（SV-S3），复核与写盘不会被 unlink 插入
            # 复审 R7：副本内存刷新按 op 同路径处理——持 rentry.oplock、锁内
            # 更新并构造 struct、锁外广播；不再只改值不广播造成客户端分叉
            copy_json = None
            copy_rev = rentry.rev
            with rentry.oplock:
                with _lock:
                    if FILES.get((VAULT_ID, rp)) is rentry:
                        # 复审 R7：覆盖前比较副本内容，无变化则不抬 rev、不广播
                        copy_current = True
                        if rentry.content != full_content:
                            # SRV34-1/SRV35-1：副本内容若已偏离"上次 publish 后的
                            # 基线摘要"，说明两次上报之间被其他设备改过
                            # （copy_foreign），源端保存不得静默覆盖；否则按原
                            # 逻辑刷新副本镜像。判定不看 rev——rev==0 时内存内容
                            # 只是打开时从磁盘加载的旧值，同样可能是他端编辑
                            baseline = _PUBLISHED_LOCAL.get(rp)
                            # SRV36-3：基线未知（重启后）时与 publish 的 SV-BL2
                            # 同口径——不得用源内容静默覆盖副本
                            if (baseline is None
                                    or _content_digest(rentry.content) != baseline):
                                copy_current = False
                            else:
                                rentry.content = full_content
                                rentry.mtime = _now()
                                rentry.content_mtime = rentry.mtime   # SV-U6
                                rentry.rev += 1
                                _mark_participant_nolock(rp, device_id)   # 阶段①
                                copy_rev = rentry.rev
                                copy_json = {"type": "struct", "start": 0,
                                             "delete": -1, "insert": [],
                                             "content": full_content,
                                             "device_id": device_id,
                                             "ts": int(rentry.mtime),
                                             "rev": rentry.rev}
                    else:
                        copy_current = False
                if copy_current:
                    if copy_json is not None:
                        _broadcast(rentry, copy_json)
                    # 复审 R6：复核 rev 后仍持 oplock 立即写盘
                    with _lock:
                        still = (FILES.get((VAULT_ID, rp)) is rentry
                                 and rentry.rev == copy_rev)
                    if still:
                        if _flush_recent(rp, full_content):
                            # SV-U1：同上，副本刷新成功后同步基线
                            with _lock:
                                _remember_published(rp, full_content)
                        else:
                            persisted = False   # SV-Q7
        # SRV37-2：副本回声广播放在两把锁之外——锁内只改状态，慢订阅者
        # 不得阻塞 publish/delete；广播前复核 entry 仍存活且 rev 未被再改
        for echo_key, echo_entry, echo_json in echo_jobs:
            with _lock:
                still = (FILES.get(echo_key) is echo_entry
                         and echo_entry.rev == echo_json["rev"])
            if still:
                _broadcast(echo_entry, echo_json)
        with _lock:
            writer_fields = _writer_fields_nolock(entry, False)
        return self._send(200, {"ok": True, "persisted": persisted,
                                **writer_fields})

    def _handle_close(self, body):
        # SV-T9：必填字段按字符串校验，"path": null 不得变成合法路径 "None"
        path = _safe_path(_req_raw(body.get("path")))
        device_id = _req_text(body.get("device_id"))
        if not path:
            return self._send(400, {"ok": False, "error": "path required"})
        path = _resolve_session_path(path)
        if path is None:
            # SV-T2：迁移冲突时不落盘（内容各自保留），要求重新 hello
            return self._send(409, {"ok": False, "error": "session conflict"})
        # SV-BS1：删除/重命名源文件后客户端会 close 旧会话，若照常落盘会把刚被
        # 删除的文件按内存内容重新创建（重命名则留下旧名幽灵）。discard=true 表示
        # "磁盘上的旧路径已被客户端处理"，只丢会话不落盘；有其它订阅者时仍不删，
        # 避免抽走别人正在编辑的会话。
        discard = body.get("discard") is True
        key = (VAULT_ID, path)
        skip = False
        writer_event = None
        with _lock:
            entry = FILES.get(key)
            if entry is not None and device_id and _valid_device(device_id):
                # writer token：写者关闭会话时立即移交（按最后活跃），不等超时
                _touch_participant_nolock(entry, device_id)
                if entry.writer_device_id == device_id:
                    nxt = _pick_writer_nolock(entry, exclude=device_id)
                    writer_event = _set_writer_nolock(
                        entry, nxt,
                        _participant_name_nolock(entry, nxt) if nxt else "",
                        "leave")
                # 关闭即退出会话：从参与者移除，避免"已关闭但仍因 15s 宽限
                # 被选为接任 writer"；若同设备另有 SSE 订阅则不依赖该条目
                entry.participants.pop(device_id, None)
                writer_fields = _writer_fields_nolock(
                    entry, writer_event is not None)
            else:
                writer_fields = ({"writer_device_id": None,
                                  "writer_device_name": "",
                                  "writer_rev": 0, "writer_since": 0,
                                  "writer_changed": False}
                                 if entry is None
                                 else _writer_fields_nolock(entry, False))
            if entry is None or entry.subs:
                # 复审 R3：锁内只置标志，响应在锁外发送
                skip = True
            else:
                rev = entry.rev
                content = entry.content
        if writer_event is not None:
            _broadcast(entry, writer_event)
            _log(f"[writer] path={path} dev={device_id} reason=leave "
                 f"rev={writer_event['writer_rev']}")
        if skip:
            return self._send(200, {"ok": True, **writer_fields})
        if discard:
            with entry.oplock:
                with _lock:
                    # 持 entry.oplock 复核：并发 op/save 正在写同一 entry 时等它结束
                    # 复审 R4：还要复核 rev——判 skip 之后到取 oplock 之间到达的
                    # op 会抬 rev，丢弃整条会话会一并丢掉他端尚未落盘的编辑
                    # （非 discard 分支一直有该复核，此处原先漏掉）
                    if (FILES.get(key) is entry and not entry.subs
                            and entry.rev == rev):
                        del FILES[key]
            return self._send(200, {"ok": True, **writer_fields})
        # 落盘移到锁外（SV-C2）；失败保留 entry 由 GC 重试（SV-H2）
        # 复审 R6：落盘整段持 entry.oplock，入锁复核 rev 后立即写盘——
        # 复核与写盘不能分属两个临界区，否则之间到达的 op 会被旧快照覆盖
        with entry.oplock:
            with _lock:
                if FILES.get(key) is not entry or entry.rev != rev:
                    skip = True
            if not skip:
                if rev > 0 and _is_recent_path(path):
                    # 阶段①：只有 recent 副本允许落盘；源路径不写同步根——
                    # 内容已由各端本地保存、Syncthing 传播，直接回收内存
                    if _flush_recent(path, content):
                        with _lock:
                            # 期间有新订阅者则不删，避免并发 close/sse 丢编辑（SV-H7）
                            if (FILES.get(key) is entry and entry.rev == rev
                                    and not entry.subs):
                                del FILES[key]
                else:
                    # SV-T5：rev==0 表示从未修改过；源路径（rev>0 或 rev==0）
                    # 一律不写盘，只在无订阅者时回收 entry
                    with _lock:
                        if (FILES.get(key) is entry and entry.rev == rev
                                and not entry.subs):
                            del FILES[key]
        return self._send(200, {"ok": True, **writer_fields})

    def log_message(self, fmt, *args):
        msg = fmt % args
        # SSE 长连接不打日志刷屏
        if "/events" not in msg:
            # P3：请求行/路径里的控制字符（\r\n 等）可伪造日志行，过滤非打印字符
            msg = "".join(ch if ch.isprintable() else "?" for ch in msg)
            print("[lockserver]", self.address_string(), msg, flush=True)


# ======================== main ========================

def _migrate_bom_snapshots():
    """R16-F4：把存量磁盘副本的前导 BOM 一次性迁移掉（启动时执行）。

    旧版本按原样落盘客户端内容，RECENT_ROOT 里可能留有带 BOM 的副本。
    读路径已统一剥 BOM，hash/size 口径不再分叉；但磁盘本身仍有“带 BOM /
    不带 BOM”两种形态，/recent/list 之类的 stat 口径需要额外兼容。启动时
    把这类副本改写为规范形态，之后磁盘上同一文件只剩一种形态。

    只探测前 3 字节，命中 UTF-8 BOM 才整篇读入并走统一落盘入口（_flush_recent
    自带大小上限与 RECENT_ROOT 白名单校验）。失败只记日志，不阻断启动——
    读路径的归一仍能保证各端点 hash 一致。
    """
    migrated = 0
    try:
        devs = os.listdir(RECENT_ROOT)
    except OSError as e:
        _log(f"[migrate] skip: {e}")
        return
    for dev in devs:
        if dev.startswith("."):
            continue
        ddir = os.path.join(RECENT_ROOT, dev)
        if not os.path.isdir(ddir):
            continue
        try:
            names = os.listdir(ddir)
        except OSError:
            continue
        for name in names:
            if name.startswith(".") or ".tmp." in name:
                continue
            full = os.path.join(ddir, name)
            recent = RECENT_PREFIX + dev + "/" + name
            if not _recent_write_valid(recent) or not os.path.isfile(full):
                continue
            try:
                st = os.stat(full)
                with open(full, "rb") as f:
                    if f.read(3) != b"\xef\xbb\xbf":
                        continue
            except OSError:
                continue
            content = _load_from_disk(recent)
            if content is None:
                # 不可解码/超大：保持原样（读路径仍会按规范口径解释）
                continue
            if _flush_recent(recent, content):
                # R18-1：_flush_recent 走 tmp + os.replace，落盘后 mtime 变成
                # 启动时刻；/recent/list 按 mtime 倒序展示，若不还原，所有存量
                # BOM 副本会在每次重启后集体跳到最近页顶部（排序跳变）。
                # 迁移只改字节形态，不改用户可见的时间序，故还原原 mtime。
                try:
                    os.utime(full, ns=(st.st_atime_ns, st.st_mtime_ns))
                except OSError:
                    pass
                migrated += 1
    if migrated:
        _log(f"[migrate] BOM snapshots normalized: {migrated}")


def _startup_selfcheck():
    """阶段①启动自检：验证“锁服务零写同步根”的守卫确实生效（fail-fast）。

    1) 用统一落盘入口写一个同步根路径（无 recent/ 前缀）——必须被拒绝；
       若未被拒绝，说明守卫被移除，进程直接启动失败而不是静默写盘；
    2) 校验 recent 白名单落点解析后仍在 RECENT_ROOT 内。
    探针会计一次 disk_denied，验证后清零，不影响运行期审计口径。
    """
    try:
        _flush_recent("__selfcheck_sync_root__.md", "probe")
    except RuntimeError as e:
        msg = str(e)
        if "must not write sync root" not in msg and "outside RECENT_ROOT" not in msg:
            raise
        _log("[selfcheck] DENY write to DISK_ROOT: guard active (probe rejected)")
    else:
        raise RuntimeError(
            "FATAL: write guard missing - DISK_ROOT write was not rejected")
    _assert_recent_full_path(_full_path(RECENT_PREFIX + "__selfcheck__/probe.txt"))
    with _WRITE_AUDIT_LOCK:
        _WRITE_AUDIT["disk_denied"] = 0
    _log(f"[selfcheck] write scope OK: sync_root=DENY recent=ALLOW "
         f"({RECENT_ROOT})")


class _QuietThreadingHTTPServer(ThreadingHTTPServer):
    """静默客户端读完响应即断开的连接重置/管道断开，其它异常保持默认打印。

    ConnectionResetError/BrokenPipeError 来自对端已关闭连接：socketserver 在
    handle_one_request 读下一个请求（keep-alive）时抛出，属于正常客户端行为
    而非服务异常。默认 BaseServer.handle_error 会给每次这类断连打一整段
    traceback 到 journal，掩盖真实错误；这里只吞这两类，其余交回默认实现。
    """

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, BrokenPipeError)):
            return
        super().handle_error(request, client_address)


def main():
    _init_api_key()
    _startup_selfcheck()
    _migrate_bom_snapshots()
    threading.Thread(target=_gc_loop, daemon=True).start()
    threading.Thread(target=_writer_watch_loop, daemon=True).start()
    # 服务器自管密钥后始终有 API_KEY；仅监听回环的分支保留给“密钥异常为空”
    # 的极端情况（此时不把无鉴权文件读写暴露到 0.0.0.0）。
    bind = "0.0.0.0" if API_KEY else "127.0.0.1"
    _log(f"markor-lockserver v2 (realtime collab) on {bind}:{PORT}, "
         f"api_key={'set(len=%d)' % len(API_KEY) if API_KEY else 'DISABLED'}, "
         f"key_file={KEY_FILE}, disk={DISK_ROOT}")
    _log(f"[clients] require_header={int(REQUIRE_CLIENT_HEADER)} "
         f"min_builds=desktop:{MIN_BUILDS['desktop']},"
         f"phone:{MIN_BUILDS['phone']},tablet:{MIN_BUILDS['tablet']}")
    _QuietThreadingHTTPServer((bind, PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
